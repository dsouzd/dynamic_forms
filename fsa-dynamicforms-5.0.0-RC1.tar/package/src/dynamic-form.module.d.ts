import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@spartacus/core";
import * as i3 from "./core/form-containers/form-container.module";
import * as i4 from "./cms-components/form-cms/form-cms.module";
import * as i5 from "./core/store/form-store.module";
import * as i6 from "./occ/adapters/form/form-occ.module";
import * as i7 from "./components/components.module";
export declare class DynamicFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DynamicFormModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.FormContainerModule, typeof i4.FormCMSModule, typeof i5.FormStoreModule, typeof i6.FormOccModule, typeof i2.ConfigModule, typeof i7.ComponentsModule], [typeof i3.FormContainerModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DynamicFormModule>;
}
