import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
export declare class DataHolderComponent extends AbstractFormComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DataHolderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataHolderComponent, "ng-component", never, {}, {}, never, never, false>;
}
