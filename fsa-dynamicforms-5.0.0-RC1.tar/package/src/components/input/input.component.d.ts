import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
export declare class InputComponent extends AbstractFormComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<InputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputComponent, "cx-input", never, {}, {}, never, never, false>;
}
