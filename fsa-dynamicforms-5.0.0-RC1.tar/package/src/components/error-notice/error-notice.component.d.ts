import { OnInit, OnDestroy } from '@angular/core';
import { LanguageService } from '@spartacus/core';
import * as i0 from "@angular/core";
export declare class ErrorNoticeComponent implements OnInit, OnDestroy {
    private languageService;
    constructor(languageService: LanguageService);
    warn: any;
    parentConfig: any;
    errorMessage: string;
    private subscription;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorNoticeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ErrorNoticeComponent, "cx-error-notice", never, { "warn": "warn"; "parentConfig": "parentConfig"; }, {}, never, never, false>;
}
