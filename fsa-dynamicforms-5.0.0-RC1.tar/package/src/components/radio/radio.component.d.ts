import { AbstractOptionsComponent } from '../abstract-options/abstract-options.component';
import * as i0 from "@angular/core";
export declare class RadioComponent extends AbstractOptionsComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioComponent, "cx-radio", never, {}, {}, never, never, false>;
}
