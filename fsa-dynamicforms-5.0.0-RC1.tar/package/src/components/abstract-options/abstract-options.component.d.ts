import { OnInit } from '@angular/core';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import { LocalizedString } from '../../core/models/form-config.interface';
import * as i0 from "@angular/core";
export declare class AbstractOptionsComponent extends AbstractFormComponent implements OnInit {
    ngOnInit(): void;
    getLocalizedOption(localizationObj: LocalizedString, activelanguage: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractOptionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AbstractOptionsComponent, "ng-component", never, {}, {}, never, never, false>;
}
