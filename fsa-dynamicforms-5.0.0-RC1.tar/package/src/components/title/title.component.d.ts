import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
export declare class TitleComponent extends AbstractFormComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<TitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TitleComponent, "cx-title", never, {}, {}, never, never, false>;
}
