import * as i0 from "@angular/core";
import * as i1 from "./form-component.directive";
import * as i2 from "./abstract-form/abstract-form.component";
import * as i3 from "./abstract-options/abstract-options.component";
import * as i4 from "./button/button.component";
import * as i5 from "./datepicker/datepicker.component";
import * as i6 from "./error-notice/error-notice.component";
import * as i7 from "./data-holder/data-holder.component";
import * as i8 from "./input/input.component";
import * as i9 from "./radio/radio.component";
import * as i10 from "./select/select.component";
import * as i11 from "./text-area/text-area.component";
import * as i12 from "./time/time.component";
import * as i13 from "./title/title.component";
import * as i14 from "./separator/separator.component";
import * as i15 from "./checkbox/checkbox.component";
import * as i16 from "./form-popup-error/form-popup-error.component";
import * as i17 from "./upload/upload.component";
import * as i18 from "./currency/currency.component";
import * as i19 from "@angular/common";
import * as i20 from "@angular/forms";
import * as i21 from "@spartacus/core";
export declare class ComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ComponentsModule, [typeof i1.FormComponentDirective, typeof i2.AbstractFormComponent, typeof i3.AbstractOptionsComponent, typeof i4.ButtonComponent, typeof i5.DatePickerComponent, typeof i6.ErrorNoticeComponent, typeof i7.DataHolderComponent, typeof i8.InputComponent, typeof i9.RadioComponent, typeof i10.SelectComponent, typeof i11.TextAreaComponent, typeof i12.TimeComponent, typeof i13.TitleComponent, typeof i14.SeparatorComponent, typeof i15.CheckboxComponent, typeof i16.FormPopupErrorComponent, typeof i17.UploadComponent, typeof i18.CurrencyComponent], [typeof i19.CommonModule, typeof i20.ReactiveFormsModule, typeof i21.I18nModule], [typeof i1.FormComponentDirective, typeof i2.AbstractFormComponent, typeof i3.AbstractOptionsComponent, typeof i4.ButtonComponent, typeof i5.DatePickerComponent, typeof i6.ErrorNoticeComponent, typeof i7.DataHolderComponent, typeof i8.InputComponent, typeof i9.RadioComponent, typeof i10.SelectComponent, typeof i11.TextAreaComponent, typeof i12.TimeComponent, typeof i13.TitleComponent, typeof i14.SeparatorComponent, typeof i15.CheckboxComponent, typeof i16.FormPopupErrorComponent, typeof i17.UploadComponent, typeof i18.CurrencyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ComponentsModule>;
}
