import { ComponentFactoryResolver, ComponentRef, OnInit, Type, ViewContainerRef } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { DynamicFormsConfig } from '../core/config/form-config';
import { FieldConfig } from '../core/models/form-config.interface';
import { AbstractFormComponent } from './abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
export declare class FormComponentDirective implements OnInit {
    protected resolver: ComponentFactoryResolver;
    protected container: ViewContainerRef;
    protected formConfig: DynamicFormsConfig;
    config: FieldConfig;
    group: UntypedFormGroup;
    component: ComponentRef<AbstractFormComponent>;
    components: {
        [fieldType: string]: Type<AbstractFormComponent>;
    };
    constructor(resolver: ComponentFactoryResolver, container: ViewContainerRef, formConfig: DynamicFormsConfig);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormComponentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormComponentDirective, "[cxFormComponent]", never, { "config": "config"; "group": "group"; }, {}, never, never, false>;
}
