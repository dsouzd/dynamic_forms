import { Injector } from '@angular/core';
import { LanguageService } from '@spartacus/core';
import { FormDateConfig } from '../../core/config/date-config/date-config';
import { DynamicFormsConfig } from '../../core/config/form-config';
import { FormService } from '../../core/services/form/form.service';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
export declare class DatePickerComponent extends AbstractFormComponent {
    protected appConfig: DynamicFormsConfig;
    protected languageService: LanguageService;
    protected injector: Injector;
    protected formService: FormService;
    protected dateConfig: FormDateConfig;
    constructor(appConfig: DynamicFormsConfig, languageService: LanguageService, injector: Injector, formService: FormService, dateConfig: FormDateConfig);
    getDateFormat(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatePickerComponent, "cx-datepicker", never, {}, {}, never, never, false>;
}
