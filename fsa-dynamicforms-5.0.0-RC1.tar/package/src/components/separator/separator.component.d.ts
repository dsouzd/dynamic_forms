import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
export declare class SeparatorComponent extends AbstractFormComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SeparatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SeparatorComponent, "cx-separator", never, {}, {}, never, never, false>;
}
