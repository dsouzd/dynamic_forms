import { ElementRef } from '@angular/core';
import { LaunchDialogService } from '@spartacus/storefront';
import { FormComponentService } from '../form-component.service';
import * as i0 from "@angular/core";
export declare class FormPopupErrorComponent {
    protected launchDialogService: LaunchDialogService;
    protected formComponentService: FormComponentService;
    protected el: ElementRef;
    constructor(launchDialogService: LaunchDialogService, formComponentService: FormComponentService, el: ElementRef);
    handleClick(event: UIEvent): void;
    dismissModal(reason?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormPopupErrorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormPopupErrorComponent, "cx-form-popup-error", never, {}, {}, never, never, false>;
}
