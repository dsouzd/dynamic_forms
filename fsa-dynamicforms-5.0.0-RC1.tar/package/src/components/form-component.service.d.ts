import { LaunchDialogService } from '@spartacus/storefront';
import { BehaviorSubject, Subscription } from 'rxjs';
import * as i0 from "@angular/core";
export declare class FormComponentService {
    protected launchDialogService: LaunchDialogService;
    constructor(launchDialogService: LaunchDialogService);
    isPopulatedFormInvalidSource: BehaviorSubject<boolean>;
    isPopulatedFormInvalid: import("rxjs").Observable<boolean>;
    launchFormPopupError(): Subscription;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormComponentService>;
}
