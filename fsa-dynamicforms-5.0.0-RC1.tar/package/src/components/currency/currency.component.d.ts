import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import { DynamicFormsConfig } from '../../core/config/form-config';
import { CurrencyService, LanguageService } from '@spartacus/core';
import { FormService } from '../../core/services/form/form.service';
import * as i0 from "@angular/core";
export declare class CurrencyComponent extends AbstractFormComponent {
    protected appConfig: DynamicFormsConfig;
    protected languageService: LanguageService;
    protected injector: Injector;
    protected formService: FormService;
    protected currencyService: CurrencyService;
    currentCurrency$: Observable<string>;
    constructor(appConfig: DynamicFormsConfig, languageService: LanguageService, injector: Injector, formService: FormService, currencyService: CurrencyService);
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CurrencyComponent, "cx-currency", never, {}, {}, never, never, false>;
}
