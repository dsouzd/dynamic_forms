import { AbstractOptionsComponent } from '../abstract-options/abstract-options.component';
import * as i0 from "@angular/core";
export declare class CheckboxComponent extends AbstractOptionsComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "cx-checkbox", never, {}, {}, never, never, false>;
}
