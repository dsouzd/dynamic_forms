import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
export declare class TextAreaComponent extends AbstractFormComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextAreaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextAreaComponent, "cx-text-area", never, {}, {}, never, never, false>;
}
