import { AbstractOptionsComponent } from '../abstract-options/abstract-options.component';
import * as i0 from "@angular/core";
export declare class SelectComponent extends AbstractOptionsComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectComponent, "cx-select", never, {}, {}, never, never, false>;
}
