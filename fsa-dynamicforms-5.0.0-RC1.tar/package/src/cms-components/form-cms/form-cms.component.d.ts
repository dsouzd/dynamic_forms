import { OnDestroy, OnInit } from '@angular/core';
import { CmsComponentData } from '@spartacus/storefront';
import { Observable, Subscription } from 'rxjs';
import { FormDefinition } from '../../core/models/form-config.interface';
import { YFormData, YFormDefinition } from '../../core/models/form-occ.models';
import { FormDataService } from '../../core/services/data/form-data.service';
import { YFormCmsComponent } from '../cms-component.models';
import { FormDataStorageService } from './../../core/services/storage/form-data-storage.service';
import * as i0 from "@angular/core";
export declare class FormCMSComponent implements OnInit, OnDestroy {
    protected componentData: CmsComponentData<YFormCmsComponent>;
    protected formDataService: FormDataService;
    protected formDataStorageService: FormDataStorageService;
    constructor(componentData: CmsComponentData<YFormCmsComponent>, formDataService: FormDataService, formDataStorageService: FormDataStorageService);
    component$: Observable<YFormCmsComponent>;
    formDefinition$: Observable<YFormDefinition>;
    formData$: Observable<YFormData>;
    formConfig: FormDefinition;
    formDataId: string;
    subscription: Subscription;
    ngOnInit(): void;
    loadForm(): void;
    loadFormDefinition(component: any): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormCMSComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormCMSComponent, "cx-form-cms", never, {}, {}, never, never, false>;
}
