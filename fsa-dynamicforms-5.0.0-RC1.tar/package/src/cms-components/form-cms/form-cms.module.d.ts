import * as i0 from "@angular/core";
import * as i1 from "./form-cms.component";
import * as i2 from "@angular/common";
import * as i3 from "@spartacus/storefront";
import * as i4 from "../../core/form-containers/form-container.module";
import * as i5 from "@spartacus/core";
export declare class FormCMSModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FormCMSModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FormCMSModule, [typeof i1.FormCMSComponent], [typeof i2.CommonModule, typeof i3.SpinnerModule, typeof i4.FormContainerModule, typeof i5.ConfigModule], [typeof i1.FormCMSComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FormCMSModule>;
}
