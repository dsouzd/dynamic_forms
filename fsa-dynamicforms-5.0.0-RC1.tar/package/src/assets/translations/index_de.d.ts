import { TranslationResources } from '@spartacus/core';
export declare const dynamicformsTranslationsDe: TranslationResources;
