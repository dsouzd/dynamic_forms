export declare const dynamicforms: {
    dynamicforms: {
        optional: string;
        maxFileSize: string;
        chooseFile: string;
        startUpload: string;
        removeAll: string;
        upload: string;
        pleaseSelect: string;
        enterValidValue: string;
        validationErrors: string;
        definitionLoadError: string;
        documentUploadError: string;
        fillOutProperly: string;
    };
};
