import { HttpClient } from '@angular/common/http';
import { OccEndpointsService } from '@spartacus/core';
import { Observable } from 'rxjs';
import { FormAdapter } from '../../../core/connectors/form.adapter';
import { YFormData } from '../../../core/models/form-occ.models';
import * as i0 from "@angular/core";
export declare class OccFormAdapter implements FormAdapter {
    protected http: HttpClient;
    protected occEndpointService: OccEndpointsService;
    constructor(http: HttpClient, occEndpointService: OccEndpointsService);
    saveFormData(formData: YFormData, userId: string): Observable<YFormData>;
    getFormData(formDataId: string, userId: string): Observable<YFormData>;
    getFormDefinitions(categoryCode: string, formDefinitionType: string): Observable<any>;
    getFormDefinition(applicationId: string, formDefinitionId: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccFormAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccFormAdapter>;
}
