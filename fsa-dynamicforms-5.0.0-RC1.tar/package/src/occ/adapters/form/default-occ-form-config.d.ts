import { FormOccConfig } from '../../config/form-occ-config';
export declare const defaultOccFormConfig: FormOccConfig;
