import { HttpClient } from '@angular/common/http';
import { OccEndpointsService } from '@spartacus/core';
import { Observable } from 'rxjs';
import { FileAdapter } from '../../../core/connectors/file.adapter';
import * as i0 from "@angular/core";
export declare class OccFileAdapter implements FileAdapter {
    protected http: HttpClient;
    protected occEndpointService: OccEndpointsService;
    constructor(http: HttpClient, occEndpointService: OccEndpointsService);
    uploadFile(userId: any, file: File): Observable<any>;
    removeFileForUserAndCode(userId: string, fileCode: string): Observable<any>;
    getFileForCodeAndType(userId: string, fileCode: string, fileType: string): Observable<Blob>;
    getFilesForUser(userId: string, fileCodes?: Array<string>): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccFileAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccFileAdapter>;
}
