export interface FormStorageObject {
    formDefinitionId?: string;
    formDataId?: string;
    categoryCode?: string;
}
