import { Observable } from 'rxjs';
import { YFormData, YFormDefinition } from '../models';
import { FormAdapter } from './form.adapter';
import * as i0 from "@angular/core";
export declare class FormConnector {
    protected formAdapter: FormAdapter;
    constructor(formAdapter: FormAdapter);
    getFormDefinition(applicationId: any, formDefinitionId: any): Observable<YFormDefinition>;
    getFormDefinitions(categoryCode: string, formDefinitionType: string): Observable<YFormDefinition>;
    getFormData(formDataId: string, userId: string): Observable<YFormData>;
    saveFormData(formData: YFormData, userId: string): Observable<YFormData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormConnector>;
}
