import { Observable } from 'rxjs';
import { FileAdapter } from './file.adapter';
import * as i0 from "@angular/core";
export declare class FileConnector {
    protected uploadAdapter: FileAdapter;
    constructor(uploadAdapter: FileAdapter);
    getFile(userId: string, fileCode: string, fileType: string): Observable<any>;
    getFiles(userId: string, fileCode?: Array<string>): Observable<any>;
    uploadFile(userId: string, file: File): Observable<any>;
    removeFile(userId: string, fileCode: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileConnector>;
}
