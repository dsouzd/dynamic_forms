import { Action } from '@ngrx/store';
export declare const LOAD_FORM_DEFINITION = "[Form Definition] Load Form Definition";
export declare const LOAD_FORM_DEFINITION_FAIL = "[Form Definition] Load Form Definition Fail";
export declare const LOAD_FORM_DEFINITION_SUCCESS = "[Form Definition] Load Form Definition Success";
export declare class LoadFormDefinition implements Action {
    payload: any;
    readonly type = "[Form Definition] Load Form Definition";
    constructor(payload: any);
}
export declare class LoadFormDefinitionFail implements Action {
    payload: any;
    readonly type = "[Form Definition] Load Form Definition Fail";
    constructor(payload: any);
}
export declare class LoadFormDefinitionSuccess implements Action {
    payload: any;
    readonly type = "[Form Definition] Load Form Definition Success";
    constructor(payload: any);
}
export declare type FormDefinitionAction = LoadFormDefinition | LoadFormDefinitionFail | LoadFormDefinitionSuccess;
