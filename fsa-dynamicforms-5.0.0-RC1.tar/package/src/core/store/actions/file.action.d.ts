import { Action } from '@ngrx/store';
export declare const UPLOAD_FILE_SUCCESS = "[File] Upload file Success";
export declare const RESET_FILE_SUCCESS = "[File] Reset file Success";
export declare const REMOVE_FILE = "[File] Remove File";
export declare const REMOVE_FILE_SUCCESS = "[File] Remove File Success";
export declare const REMOVE_FILE_FAIL = "[File] Remove File Fail";
export declare const SET_UPLOADED_FILES = "[File] Set Uploaded Files";
export declare class UploadFileSuccess implements Action {
    payload: any;
    readonly type = "[File] Upload file Success";
    constructor(payload: any);
}
export declare class ResetFileSuccess implements Action {
    payload: any;
    readonly type = "[File] Reset file Success";
    constructor(payload: any);
}
export declare class RemoveFile implements Action {
    payload: any;
    readonly type = "[File] Remove File";
    constructor(payload: any);
}
export declare class RemoveFileSuccess implements Action {
    payload: any;
    readonly type = "[File] Remove File Success";
    constructor(payload: any);
}
export declare class RemoveFileFail implements Action {
    payload: any;
    readonly type = "[File] Remove File Fail";
    constructor(payload: any);
}
export declare class SetUploadedFiles implements Action {
    payload: any;
    readonly type = "[File] Set Uploaded Files";
    constructor(payload: any);
}
export declare type FileAction = UploadFileSuccess | ResetFileSuccess | RemoveFile | RemoveFileSuccess | RemoveFileFail | SetUploadedFiles;
