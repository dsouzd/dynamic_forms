import { Action } from '@ngrx/store';
export declare const LOAD_FORM_DATA = "[Form Data] Load Form Data";
export declare const LOAD_FORM_DATA_FAIL = "[Form Data] Load Form Data Fail";
export declare const LOAD_FORM_DATA_SUCCESS = "[Form Data] Load Form Data Success";
export declare const SAVE_FORM_DATA = "[Form Data] Save Form Data";
export declare const SAVE_FORM_DATA_FAIL = "[Form Data] Save Form Data Fail";
export declare const SAVE_FORM_DATA_SUCCESS = "[Form Data] Save Form Data Success";
export declare class LoadFormData implements Action {
    payload: any;
    readonly type = "[Form Data] Load Form Data";
    constructor(payload: any);
}
export declare class LoadFormDataFail implements Action {
    payload: any;
    readonly type = "[Form Data] Load Form Data Fail";
    constructor(payload: any);
}
export declare class LoadFormDataSuccess implements Action {
    payload: any;
    readonly type = "[Form Data] Load Form Data Success";
    constructor(payload: any);
}
export declare class SaveFormData implements Action {
    payload: any;
    readonly type = "[Form Data] Save Form Data";
    constructor(payload: any);
}
export declare class SaveFormDataSuccess implements Action {
    payload: any;
    readonly type = "[Form Data] Save Form Data Success";
    constructor(payload: any);
}
export declare class SaveFormDataFail implements Action {
    payload: any;
    readonly type = "[Form Data] Save Form Data Fail";
    constructor(payload: any);
}
export declare type FormDataAction = LoadFormData | LoadFormDataFail | LoadFormDataSuccess | SaveFormData | SaveFormDataSuccess | SaveFormDataFail;
