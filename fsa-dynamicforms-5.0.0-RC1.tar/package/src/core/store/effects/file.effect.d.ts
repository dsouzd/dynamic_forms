import { Actions } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { FileConnector } from '../../connectors/file.connector';
import * as i0 from "@angular/core";
export declare class FilesEffect {
    private actions$;
    private fileConnector;
    removeFile$: Observable<any>;
    constructor(actions$: Actions, fileConnector: FileConnector);
    static ɵfac: i0.ɵɵFactoryDeclaration<FilesEffect, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FilesEffect>;
}
