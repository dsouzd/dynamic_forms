import { Actions } from '@ngrx/effects';
import { GlobalMessageService } from '@spartacus/core';
import { Observable } from 'rxjs';
import { FormConnector } from '../../connectors/form.connector';
import * as i0 from "@angular/core";
export declare class FormDefinitionEffects {
    private actions$;
    private formConnector;
    private globalMessageService;
    loadFormDefinition$: Observable<any>;
    private showGlobalMessage;
    constructor(actions$: Actions, formConnector: FormConnector, globalMessageService: GlobalMessageService);
    static ɵfac: i0.ɵɵFactoryDeclaration<FormDefinitionEffects, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormDefinitionEffects>;
}
