import { Actions } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { FormConnector } from '../../connectors/form.connector';
import { FormDataStorageService } from '../../services/storage/form-data-storage.service';
import * as i0 from "@angular/core";
export declare class FormDataEffects {
    private formDataStorageService;
    private actions$;
    private formConnector;
    loadFormData$: Observable<any>;
    saveFormData$: Observable<any>;
    clearFormData$: Observable<never> & import("@ngrx/effects").CreateEffectMetadata;
    constructor(formDataStorageService: FormDataStorageService, actions$: Actions, formConnector: FormConnector);
    static ɵfac: i0.ɵɵFactoryDeclaration<FormDataEffects, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormDataEffects>;
}
