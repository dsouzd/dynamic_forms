import { InjectionToken, Provider } from '@angular/core';
import { ActionReducer, ActionReducerMap, MetaReducer } from '@ngrx/store';
import { FormsState } from '../state';
export declare function getReducers(): ActionReducerMap<FormsState>;
export declare const reducerToken: InjectionToken<ActionReducerMap<FormsState>>;
export declare const reducerProvider: Provider;
export declare function clearFormDefinitionState(reducer: ActionReducer<any>): ActionReducer<any>;
export declare const metaReducers: MetaReducer<any>[];
