import * as fromAction from '../actions/';
import { FormDefinitionState } from '../state';
export declare const initialState: FormDefinitionState;
export declare function reducer(state: FormDefinitionState, action: fromAction.FormDefinitionAction): FormDefinitionState;
export declare const getFormDefinition: (state: FormDefinitionState) => {};
export declare const getLoaded: (state: FormDefinitionState) => boolean;
