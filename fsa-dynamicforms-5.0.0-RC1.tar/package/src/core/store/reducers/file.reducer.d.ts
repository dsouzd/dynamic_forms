import * as fromAction from '../actions';
import { FilesState } from '../state';
export declare const initialState: FilesState;
export declare function reducer(state: FilesState, action: fromAction.FileAction): FilesState;
export declare const getUploadFiles: (state: FilesState) => {
    files: File[];
};
