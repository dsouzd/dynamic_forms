import * as fromAction from '../actions/';
import { FormDataState } from '../state';
export declare const initialState: FormDataState;
export declare function reducer(state: FormDataState, action: fromAction.FormDataAction): FormDataState;
export declare const getFormData: (state: FormDataState) => {};
export declare const getLoaded: (state: FormDataState) => boolean;
