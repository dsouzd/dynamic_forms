import { MemoizedSelector } from '@ngrx/store';
import { FormsState, StateWithForm } from '../state';
export declare const getFormState: MemoizedSelector<StateWithForm, FormsState>;
