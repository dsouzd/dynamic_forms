import { MemoizedSelector } from '@ngrx/store';
import { FormDataState, StateWithForm } from '../state';
export declare const getFormDataState: MemoizedSelector<StateWithForm, FormDataState>;
export declare const getFormData: MemoizedSelector<StateWithForm, any>;
export declare const getFormDataLoaded: MemoizedSelector<StateWithForm, any>;
