import { MemoizedSelector } from '@ngrx/store';
import { FilesState, StateWithForm } from '../state';
export declare const getUploadFilesState: MemoizedSelector<StateWithForm, FilesState>;
export declare const getUploadFiles: MemoizedSelector<StateWithForm, any>;
