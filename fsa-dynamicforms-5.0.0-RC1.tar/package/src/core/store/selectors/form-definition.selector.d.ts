import { MemoizedSelector } from '@ngrx/store';
import { FormDefinitionState, StateWithForm } from '../state';
export declare const getFormDefinitionState: MemoizedSelector<StateWithForm, FormDefinitionState>;
export declare const getFormDefinition: MemoizedSelector<StateWithForm, any>;
export declare const getFormDefinitionLoaded: MemoizedSelector<StateWithForm, any>;
