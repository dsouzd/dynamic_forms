import { FormPersistenceService } from '../services/form-persistance.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/common/http";
import * as i3 from "@spartacus/core";
import * as i4 from "@ngrx/store";
import * as i5 from "@ngrx/effects";
export declare function formStatePersistenceFactory(formStatePersistenceService: FormPersistenceService): () => void;
export declare class FormStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FormStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FormStoreModule, never, [typeof i1.CommonModule, typeof i2.HttpClientModule, typeof i3.StateModule, typeof i4.StoreFeatureModule, typeof i5.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FormStoreModule>;
}
