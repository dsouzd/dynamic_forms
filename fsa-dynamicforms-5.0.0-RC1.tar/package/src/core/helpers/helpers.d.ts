export declare class GeneralHelpers {
    static getObjectDepth(data: any, depth?: number): any;
}
