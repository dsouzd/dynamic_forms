import * as i0 from "@angular/core";
import * as i1 from "./form/form.component";
import * as i2 from "./dynamic-form/dynamic-form.component";
import * as i3 from "@angular/common";
import * as i4 from "@spartacus/core";
import * as i5 from "@angular/router";
import * as i6 from "@angular/forms";
import * as i7 from "../../components/components.module";
export declare class FormContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FormContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FormContainerModule, [typeof i1.FormComponent, typeof i2.DynamicFormComponent], [typeof i3.CommonModule, typeof i4.I18nModule, typeof i5.RouterModule, typeof i6.ReactiveFormsModule, typeof i7.ComponentsModule], [typeof i1.FormComponent, typeof i2.DynamicFormComponent, typeof i7.ComponentsModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FormContainerModule>;
}
