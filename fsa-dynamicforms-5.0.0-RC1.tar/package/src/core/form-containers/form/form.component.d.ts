import { OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { FormDefinition } from '../../models/form-config.interface';
import { FormDataService } from '../../services/data/form-data.service';
import { DynamicFormComponent } from '../dynamic-form/dynamic-form.component';
import { YFormData } from './../../models/form-occ.models';
import { FormDataStorageService } from './../../services/storage/form-data-storage.service';
import * as i0 from "@angular/core";
export declare class FormComponent implements OnDestroy {
    protected formDataService: FormDataService;
    protected formDataStorageService: FormDataStorageService;
    private subscription;
    constructor(formDataService: FormDataService, formDataStorageService: FormDataStorageService);
    form: DynamicFormComponent;
    formCategoryCode: string;
    formId: string;
    formSubject: string;
    formConfig: FormDefinition;
    applicationId: string;
    formData: Observable<YFormData>;
    submit(formData: YFormData): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormComponent, "cx-form-component", never, { "formCategoryCode": "formCategoryCode"; "formId": "formId"; "formSubject": "formSubject"; "formConfig": "formConfig"; "applicationId": "applicationId"; "formData": "formData"; }, {}, never, never, false>;
}
