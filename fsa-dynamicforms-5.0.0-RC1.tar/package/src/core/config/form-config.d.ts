import { Config } from '@spartacus/core';
export interface FormComponentMapping {
    component: any;
}
export declare abstract class FormComponentConfig {
    [_: string]: FormComponentMapping;
}
export interface ValidatorMapping {
    validator: any;
}
export declare abstract class ValidatorConfig {
    [_: string]: ValidatorMapping;
}
export interface PrefillMapping {
    prefillResolver: any;
}
export declare abstract class PrefillConfig {
    [_: string]: PrefillMapping;
}
export declare abstract class DynamicFormsConfig extends Config {
    dynamicForms: {
        components?: FormComponentConfig;
        validators?: ValidatorConfig;
        prefill?: PrefillConfig;
    };
}
