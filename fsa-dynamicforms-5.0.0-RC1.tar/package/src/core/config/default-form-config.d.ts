import { DynamicFormsConfig } from './form-config';
export declare const defaultFormConfig: DynamicFormsConfig;
