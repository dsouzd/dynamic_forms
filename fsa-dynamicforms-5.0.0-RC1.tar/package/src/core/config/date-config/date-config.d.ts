import * as i0 from "@angular/core";
export declare abstract class FormDateConfig {
    date?: {
        format?: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<FormDateConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormDateConfig>;
}
