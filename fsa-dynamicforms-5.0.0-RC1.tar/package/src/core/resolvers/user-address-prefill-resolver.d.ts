import { UserAddressService } from '@spartacus/core';
import { PrefillResolver } from './prefill-resolver.interface';
import * as i0 from "@angular/core";
export declare class UserAddressPrefillResolver implements PrefillResolver {
    protected userAddressService: UserAddressService;
    constructor(userAddressService: UserAddressService);
    getPrefillValue(fieldPath: string): import("rxjs").Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAddressPrefillResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAddressPrefillResolver>;
}
