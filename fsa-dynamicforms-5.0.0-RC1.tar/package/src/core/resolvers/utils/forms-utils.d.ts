import * as i0 from "@angular/core";
export declare class FormsUtils {
    static convertIfDate(value: any): any;
    static getValueByPath(fieldPath: string, object: any): any;
    private static getValueForAttribute;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormsUtils, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormsUtils>;
}
