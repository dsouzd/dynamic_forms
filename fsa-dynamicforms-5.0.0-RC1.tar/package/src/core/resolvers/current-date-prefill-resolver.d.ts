import { DatePipe } from '@angular/common';
import { PrefillResolver } from './prefill-resolver.interface';
import * as i0 from "@angular/core";
export declare class CurrentDatePrefillResolver implements PrefillResolver {
    private datePipe;
    constructor(datePipe: DatePipe);
    getPrefillValue(): import("rxjs").Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentDatePrefillResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentDatePrefillResolver>;
}
