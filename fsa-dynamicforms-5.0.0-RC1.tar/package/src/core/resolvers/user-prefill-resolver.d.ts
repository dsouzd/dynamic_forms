import { PrefillResolver } from './prefill-resolver.interface';
import { UserAccountFacade } from '@spartacus/user/account/root';
import * as i0 from "@angular/core";
export declare class UserPrefillResolver implements PrefillResolver {
    protected userAccountFacade: UserAccountFacade;
    constructor(userAccountFacade: UserAccountFacade);
    getPrefillValue(fieldPath: string): import("rxjs").Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserPrefillResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserPrefillResolver>;
}
