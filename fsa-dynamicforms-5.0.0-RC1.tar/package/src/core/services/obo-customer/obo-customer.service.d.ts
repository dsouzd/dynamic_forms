import { OnDestroy } from '@angular/core';
import { EventService, UserIdService } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class OboCustomerService implements OnDestroy {
    protected eventService: EventService;
    protected userIdService: UserIdService;
    private sessionStorageKey;
    private subscription;
    constructor(eventService: EventService, userIdService: UserIdService);
    setSelectedCustomer(user: any): void;
    getOboCustomerUserId(): Observable<string>;
    ngOnDestroy(): void;
    private onLogout;
    static ɵfac: i0.ɵɵFactoryDeclaration<OboCustomerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OboCustomerService>;
}
