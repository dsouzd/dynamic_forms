import { ValidatorFn } from '@angular/forms';
import { DynamicFormsConfig } from '../../config/form-config';
import { FieldConfig, ValidatorFunction } from './../../models/form-config.interface';
import * as i0 from "@angular/core";
export declare class FormValidationService {
    protected formConfig: DynamicFormsConfig;
    constructor(formConfig: DynamicFormsConfig);
    configValidators: import("../../config/form-config").ValidatorConfig;
    getValidatorsForField(fieldConfig: FieldConfig): ValidatorFn[];
    getValidatorForFunction(validatorFunction: ValidatorFunction): ValidatorFn;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormValidationService>;
}
