import { AbstractControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class FormService {
    constructor();
    /**
     * Method used to recursively find form control by its code in specified form group
     *
     * @param formControlCode The form control code
     * @param formGroup The form group
     */
    getFormControlForCode(formControlCode: string, formGroup: any): AbstractControl;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormService>;
}
