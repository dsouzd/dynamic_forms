import { FormStorageObject, YFormData } from '../../models';
import * as i0 from "@angular/core";
export declare const DYNAMIC_FORMS_LOCAL_STORAGE_KEY = "dynamicForms-local-data";
export declare class FormDataStorageService {
    formLocalStorageData: any;
    clearFormDataLocalStorage(): void;
    clearFormDataIdFromLocalStorage(formDataId: string): void;
    setFormDataToLocalStorage(formData: YFormData): void;
    getFormDataIdByDefinitionCode(formDefinitionCode: string): string;
    getFormDataIdByCategory(categoryCode: string): string;
    protected createDataForLocalStorage(formData: YFormData): FormStorageObject;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormDataStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormDataStorageService>;
}
