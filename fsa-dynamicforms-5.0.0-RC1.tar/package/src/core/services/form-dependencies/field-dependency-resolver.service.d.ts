import { AbstractControl, UntypedFormBuilder, UntypedFormGroup, ValidatorFn } from '@angular/forms';
import { FormService } from '../form/form.service';
import { ControlDependency, DynamicFormGroup } from './../../models/form-config.interface';
import { FormValidationService } from './../form-validation/form-validation.service';
import * as i0 from "@angular/core";
export declare class FieldDependencyResolverService {
    protected formValidationService: FormValidationService;
    protected formService: FormService;
    protected fb: UntypedFormBuilder;
    constructor(formValidationService: FormValidationService, formService: FormService, fb: UntypedFormBuilder);
    /**
     * Method used to enable/disable dependent control based on conditions defined at main control
     *
     * @param controlConfig The dependent field config for which dependencies are resolved
     * @param dependentControl The dependent field control for which dependencies are resolved
     * @param formGroup The form group which tracks value and validity of main form controls
     */
    resolveFormControlDependencies(controlConfig: any, dependentControl: AbstractControl, formGroup: UntypedFormGroup): void;
    /**
     * Method used to enable/disable control based on input parameter and form configuration value.
     * In case control is from group, check is done for nested controls to see if any of them has configuration set to disabled.
     * If any field config has disabled property set to true, dynamic condition cannot change that.
     *
     * @param dependentControl The dependent field control for which dependencies are resolved
     * @param controlConfig The dependent field config for which dependencies are resolved (control or group)
     * @param enabled The enabled flag which indicates if parent control conditions are met.
     */
    changeControlEnabled(dependentControl: any, controlConfig: DynamicFormGroup, enabled: boolean): void;
    geValidationsForCondition(dependencyFn: ControlDependency): ValidatorFn[];
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldDependencyResolverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FieldDependencyResolverService>;
}
