import { OnDestroy } from '@angular/core';
import { MemoizedSelector, Store } from '@ngrx/store';
import { StatePersistenceService } from '@spartacus/core';
import { Observable, Subscription } from 'rxjs';
import { FormsState, StateWithForm } from '../store/state';
import * as i0 from "@angular/core";
export declare const getFormsState: MemoizedSelector<StateWithForm, FormsState>;
/**
 * Forms state synced to browser storage.
 */
export declare type SyncedFormsState = Partial<FormsState>;
/**
 * Responsible for storing Form state in the browser storage.
 * Uses `StatePersistenceService` mechanism.
 */
export declare class FormPersistenceService implements OnDestroy {
    protected statePersistenceService: StatePersistenceService;
    protected store: Store<StateWithForm>;
    protected subscription: Subscription;
    constructor(statePersistenceService: StatePersistenceService, store: Store<StateWithForm>);
    /**
     * Identifier used for storage key.
     */
    protected key: string;
    /**
     * Initializes the synchronization between state and browser storage.
     */
    initSync(): void;
    /**
     * Gets and transforms state from different sources into the form that should
     * be saved in storage.
     */
    protected getUploadedFiles(): Observable<{
        files: File[];
    }>;
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     */
    protected onRead(state: {
        files: File[];
    }): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormPersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormPersistenceService>;
}
