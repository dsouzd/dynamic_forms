import { Store } from '@ngrx/store';
import { UserIdService } from '@spartacus/core';
import { Observable } from 'rxjs';
import { FileConnector } from '../../connectors/file.connector';
import { StateWithForm } from '../../store/state';
import { OboCustomerService } from '../../../core/services/obo-customer/obo-customer.service';
import * as i0 from "@angular/core";
export declare class FileService {
    protected userIdService: UserIdService;
    protected fileConnector: FileConnector;
    protected store: Store<StateWithForm>;
    protected oboCustomerService: OboCustomerService;
    constructor(userIdService: UserIdService, fileConnector: FileConnector, store: Store<StateWithForm>, oboCustomerService: OboCustomerService);
    getFile(fileCode: string, fileType: string): Observable<any>;
    getFiles(fileCodes?: Array<string>): Observable<any>;
    uploadFile(file: File): Observable<any>;
    resetFiles(): void;
    setFileInStore(body: any): void;
    getUploadedDocuments(): Observable<any>;
    removeFileForCode(userId: string, fileCode: string): void;
    removeAllFiles(userId: any, fileList: any): void;
    getDocument(document: any): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileService>;
}
