import { UntypedFormBuilder, UntypedFormControl } from '@angular/forms';
import { UserAccountFacade } from '@spartacus/user/account/root';
import { FormValidationService } from '../form-validation/form-validation.service';
import { FieldConfig } from './../../models/form-config.interface';
import { FieldDependencyResolverService } from './../form-dependencies/field-dependency-resolver.service';
import * as i0 from "@angular/core";
export declare class FormBuilderService {
    protected fb: UntypedFormBuilder;
    protected formValidationService: FormValidationService;
    protected fieldDependencyResolverService: FieldDependencyResolverService;
    protected userAccountFacade: UserAccountFacade;
    constructor(fb: UntypedFormBuilder, formValidationService: FormValidationService, fieldDependencyResolverService: FieldDependencyResolverService, userAccountFacade: UserAccountFacade);
    createForm(config: any): import("@angular/forms").UntypedFormGroup;
    createControl(fieldConfig: FieldConfig): UntypedFormControl;
    /**
     * Method is used to enable all form controls when currently logged in customer is part of seller user group.
     * This is temporary solution. Control property should be defined in the form defintion's JSON metadata.
     */
    private enableFieldsForSellerUserGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormBuilderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormBuilderService>;
}
