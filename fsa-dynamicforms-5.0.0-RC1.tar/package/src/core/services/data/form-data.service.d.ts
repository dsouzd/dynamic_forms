import { Store } from '@ngrx/store';
import { UserIdService } from '@spartacus/core';
import { OboCustomerService } from '../../../core/services/obo-customer/obo-customer.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { YFormData, YFormDefinition } from '../../models';
import { StateWithForm } from '../../store/state';
import * as i0 from "@angular/core";
export declare class FormDataService {
    protected store: Store<StateWithForm>;
    protected userIdService: UserIdService;
    protected oboCustomerService: OboCustomerService;
    submittedForm: BehaviorSubject<YFormData>;
    continueToNextStepSource: BehaviorSubject<boolean>;
    continueToNextStep$: Observable<boolean>;
    constructor(store: Store<StateWithForm>, userIdService: UserIdService, oboCustomerService: OboCustomerService);
    setContinueToNextStep(isContinueClicked: boolean): void;
    submit(form: YFormData): void;
    getSubmittedForm(): Observable<YFormData>;
    saveFormData(formData: YFormData): void;
    loadFormDefinition(applicationId: string, formDefinitionId: string): void;
    loadFormDefinitions(categoryCode: string, formDefinitionType: string): void;
    loadFormData(formDataId: string): void;
    getFormData(): Observable<YFormData>;
    getFormDefinition(): Observable<YFormDefinition>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormDataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormDataService>;
}
