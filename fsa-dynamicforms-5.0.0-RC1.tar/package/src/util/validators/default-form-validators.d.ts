import { AbstractControl, ValidationErrors, Validators, UntypedFormGroup } from '@angular/forms';
export declare class DefaultFormValidators extends Validators {
    static passwordRegex: RegExp;
    static phoneNumberRegex: RegExp;
    static checkEmptyValue(control: AbstractControl): {
        required: boolean;
    };
    static valueComparison(baseValue: number | Date, comparisonValue: number | Date, operator: string): {
        valueShouldBeGreater: boolean;
        valueShouldBeLess?: undefined;
    } | {
        valueShouldBeLess: boolean;
        valueShouldBeGreater?: undefined;
    };
    static getFormControlForCode(formControlCode: string, formGroup: UntypedFormGroup): AbstractControl;
    static regexValidator(regex: any): (control: AbstractControl) => ValidationErrors | null;
    static matchFields(controlName: string, controlName2: string): (control: AbstractControl) => {
        notEqual: boolean;
    };
    static dateOfBirthValidator(minAge: number): (control: AbstractControl) => ValidationErrors | null;
    static compareDOBtoAge(comparisonField: string, operator: string): (control: AbstractControl) => ValidationErrors | null;
    static compareAgeToDOB(comparisonField: string, operator: string): (control: AbstractControl) => ValidationErrors | null;
    static compareNumbers(comparisonField: string, operator: string): (control: AbstractControl) => ValidationErrors | null;
    static compareDates(comparisonField: string, operator: string): (control: AbstractControl) => ValidationErrors | null;
    static compareToCurrentDate(operator: any): (control: AbstractControl) => ValidationErrors | null;
    static number(control: AbstractControl): {
        pattern: {
            requiredPattern: RegExp;
            actualValue: any;
        };
    };
    static alphanumeric(control: AbstractControl): {
        pattern: {
            requiredPattern: RegExp;
            actualValue: any;
        };
    };
    static checkValue(allowedValues: string[]): (control: AbstractControl) => ValidationErrors | null;
    static shouldContainValue(value: any): (control: AbstractControl) => ValidationErrors | null;
}
