import '@spartacus/storefront';
declare module '@spartacus/storefront' {
    const enum LAUNCH_CALLER {
        FORM_POPUP_ERROR = "FORM_POPUP_ERROR"
    }
}
