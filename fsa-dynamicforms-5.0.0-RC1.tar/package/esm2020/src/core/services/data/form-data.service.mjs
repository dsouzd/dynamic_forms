import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { UserIdService } from '@spartacus/core';
import { OboCustomerService } from '../../../core/services/obo-customer/obo-customer.service';
import { BehaviorSubject } from 'rxjs';
import { filter, map, switchMap, take } from 'rxjs/operators';
import * as fromAction from '../../store/actions';
import * as fromSelector from '../../store/selectors';
import * as i0 from "@angular/core";
import * as i1 from "@ngrx/store";
import * as i2 from "@spartacus/core";
import * as i3 from "../../../core/services/obo-customer/obo-customer.service";
export class FormDataService {
    constructor(store, userIdService, oboCustomerService) {
        this.store = store;
        this.userIdService = userIdService;
        this.oboCustomerService = oboCustomerService;
        this.submittedForm = new BehaviorSubject(null);
        this.continueToNextStepSource = new BehaviorSubject(false);
        this.continueToNextStep$ = this.continueToNextStepSource.asObservable();
    }
    setContinueToNextStep(isContinueClicked) {
        this.continueToNextStepSource.next(isContinueClicked);
    }
    submit(form) {
        this.submittedForm.next(form);
    }
    getSubmittedForm() {
        return this.submittedForm.asObservable();
    }
    saveFormData(formData) {
        this.oboCustomerService
            .getOboCustomerUserId()
            .pipe(map(userId => {
            this.store.dispatch(new fromAction.SaveFormData({ formData, userId }));
        }))
            .subscribe()
            .unsubscribe();
    }
    loadFormDefinition(applicationId, formDefinitionId) {
        this.store.dispatch(new fromAction.LoadFormDefinition({
            applicationId: applicationId,
            formDefinitionId: formDefinitionId,
        }));
    }
    loadFormDefinitions(categoryCode, formDefinitionType) {
        this.store.dispatch(new fromAction.LoadFormDefinition({
            categoryCode: categoryCode,
            formDefinitionType: formDefinitionType,
        }));
    }
    loadFormData(formDataId) {
        this.oboCustomerService
            .getOboCustomerUserId()
            .pipe(map(userId => {
            this.store.dispatch(new fromAction.LoadFormData({ formDataId, userId }));
        }))
            .subscribe()
            .unsubscribe();
    }
    getFormData() {
        return this.store.select(fromSelector.getFormDataLoaded).pipe(filter(loaded => loaded), take(1), switchMap(_ => {
            return this.store.select(fromSelector.getFormData);
        }));
    }
    getFormDefinition() {
        return this.store.select(fromSelector.getFormDefinitionLoaded).pipe(filter(loaded => loaded), take(1), switchMap(_ => {
            return this.store.select(fromSelector.getFormDefinition);
        }));
    }
}
FormDataService.ɵfac = function FormDataService_Factory(t) { return new (t || FormDataService)(i0.ɵɵinject(i1.Store), i0.ɵɵinject(i2.UserIdService), i0.ɵɵinject(i3.OboCustomerService)); };
FormDataService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormDataService, factory: FormDataService.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormDataService, [{
        type: Injectable
    }], function () { return [{ type: i1.Store }, { type: i2.UserIdService }, { type: i3.OboCustomerService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1kYXRhLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvc2VydmljZXMvZGF0YS9mb3JtLWRhdGEuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxhQUFhLENBQUM7QUFDcEMsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ2hELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDBEQUEwRCxDQUFDO0FBQzlGLE9BQU8sRUFBRSxlQUFlLEVBQWMsTUFBTSxNQUFNLENBQUM7QUFDbkQsT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBRTlELE9BQU8sS0FBSyxVQUFVLE1BQU0scUJBQXFCLENBQUM7QUFDbEQsT0FBTyxLQUFLLFlBQVksTUFBTSx1QkFBdUIsQ0FBQzs7Ozs7QUFJdEQsTUFBTSxPQUFPLGVBQWU7SUFLMUIsWUFDWSxLQUEyQixFQUMzQixhQUE0QixFQUM1QixrQkFBc0M7UUFGdEMsVUFBSyxHQUFMLEtBQUssQ0FBc0I7UUFDM0Isa0JBQWEsR0FBYixhQUFhLENBQWU7UUFDNUIsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUFvQjtRQVBsRCxrQkFBYSxHQUFHLElBQUksZUFBZSxDQUFZLElBQUksQ0FBQyxDQUFDO1FBQ3JELDZCQUF3QixHQUFHLElBQUksZUFBZSxDQUFVLEtBQUssQ0FBQyxDQUFDO1FBQy9ELHdCQUFtQixHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQU1oRSxDQUFDO0lBRUoscUJBQXFCLENBQUMsaUJBQTBCO1FBQzlDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBRUQsTUFBTSxDQUFDLElBQWU7UUFDcEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVELGdCQUFnQjtRQUNkLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUMzQyxDQUFDO0lBRUQsWUFBWSxDQUFDLFFBQW1CO1FBQzlCLElBQUksQ0FBQyxrQkFBa0I7YUFDcEIsb0JBQW9CLEVBQUU7YUFDdEIsSUFBSSxDQUNILEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNYLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUNqQixJQUFJLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FDbEQsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUNIO2FBQ0EsU0FBUyxFQUFFO2FBQ1gsV0FBVyxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVELGtCQUFrQixDQUFDLGFBQXFCLEVBQUUsZ0JBQXdCO1FBQ2hFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUNqQixJQUFJLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQztZQUNoQyxhQUFhLEVBQUUsYUFBYTtZQUM1QixnQkFBZ0IsRUFBRSxnQkFBZ0I7U0FDbkMsQ0FBQyxDQUNILENBQUM7SUFDSixDQUFDO0lBRUQsbUJBQW1CLENBQUMsWUFBb0IsRUFBRSxrQkFBMEI7UUFDbEUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQ2pCLElBQUksVUFBVSxDQUFDLGtCQUFrQixDQUFDO1lBQ2hDLFlBQVksRUFBRSxZQUFZO1lBQzFCLGtCQUFrQixFQUFFLGtCQUFrQjtTQUN2QyxDQUFDLENBQ0gsQ0FBQztJQUNKLENBQUM7SUFFRCxZQUFZLENBQUMsVUFBa0I7UUFDN0IsSUFBSSxDQUFDLGtCQUFrQjthQUNwQixvQkFBb0IsRUFBRTthQUN0QixJQUFJLENBQ0gsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ1gsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQ2pCLElBQUksVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUNwRCxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQ0g7YUFDQSxTQUFTLEVBQUU7YUFDWCxXQUFXLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsV0FBVztRQUNULE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUMzRCxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFDeEIsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUNQLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNaLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3JELENBQUMsQ0FBQyxDQUNILENBQUM7SUFDSixDQUFDO0lBRUQsaUJBQWlCO1FBQ2YsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxJQUFJLENBQ2pFLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUN4QixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQ1AsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ1osT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUMzRCxDQUFDLENBQUMsQ0FDSCxDQUFDO0lBQ0osQ0FBQzs7OEVBdkZVLGVBQWU7cUVBQWYsZUFBZSxXQUFmLGVBQWU7dUZBQWYsZUFBZTtjQUQzQixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU3RvcmUgfSBmcm9tICdAbmdyeC9zdG9yZSc7XG5pbXBvcnQgeyBVc2VySWRTZXJ2aWNlIH0gZnJvbSAnQHNwYXJ0YWN1cy9jb3JlJztcbmltcG9ydCB7IE9ib0N1c3RvbWVyU2VydmljZSB9IGZyb20gJy4uLy4uLy4uL2NvcmUvc2VydmljZXMvb2JvLWN1c3RvbWVyL29iby1jdXN0b21lci5zZXJ2aWNlJztcbmltcG9ydCB7IEJlaGF2aW9yU3ViamVjdCwgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgZmlsdGVyLCBtYXAsIHN3aXRjaE1hcCwgdGFrZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IFlGb3JtRGF0YSwgWUZvcm1EZWZpbml0aW9uIH0gZnJvbSAnLi4vLi4vbW9kZWxzJztcbmltcG9ydCAqIGFzIGZyb21BY3Rpb24gZnJvbSAnLi4vLi4vc3RvcmUvYWN0aW9ucyc7XG5pbXBvcnQgKiBhcyBmcm9tU2VsZWN0b3IgZnJvbSAnLi4vLi4vc3RvcmUvc2VsZWN0b3JzJztcbmltcG9ydCB7IFN0YXRlV2l0aEZvcm0gfSBmcm9tICcuLi8uLi9zdG9yZS9zdGF0ZSc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBGb3JtRGF0YVNlcnZpY2Uge1xuICBzdWJtaXR0ZWRGb3JtID0gbmV3IEJlaGF2aW9yU3ViamVjdDxZRm9ybURhdGE+KG51bGwpO1xuICBjb250aW51ZVRvTmV4dFN0ZXBTb3VyY2UgPSBuZXcgQmVoYXZpb3JTdWJqZWN0PGJvb2xlYW4+KGZhbHNlKTtcbiAgY29udGludWVUb05leHRTdGVwJCA9IHRoaXMuY29udGludWVUb05leHRTdGVwU291cmNlLmFzT2JzZXJ2YWJsZSgpO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByb3RlY3RlZCBzdG9yZTogU3RvcmU8U3RhdGVXaXRoRm9ybT4sXG4gICAgcHJvdGVjdGVkIHVzZXJJZFNlcnZpY2U6IFVzZXJJZFNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIG9ib0N1c3RvbWVyU2VydmljZTogT2JvQ3VzdG9tZXJTZXJ2aWNlXG4gICkge31cblxuICBzZXRDb250aW51ZVRvTmV4dFN0ZXAoaXNDb250aW51ZUNsaWNrZWQ6IGJvb2xlYW4pIHtcbiAgICB0aGlzLmNvbnRpbnVlVG9OZXh0U3RlcFNvdXJjZS5uZXh0KGlzQ29udGludWVDbGlja2VkKTtcbiAgfVxuXG4gIHN1Ym1pdChmb3JtOiBZRm9ybURhdGEpIHtcbiAgICB0aGlzLnN1Ym1pdHRlZEZvcm0ubmV4dChmb3JtKTtcbiAgfVxuXG4gIGdldFN1Ym1pdHRlZEZvcm0oKTogT2JzZXJ2YWJsZTxZRm9ybURhdGE+IHtcbiAgICByZXR1cm4gdGhpcy5zdWJtaXR0ZWRGb3JtLmFzT2JzZXJ2YWJsZSgpO1xuICB9XG5cbiAgc2F2ZUZvcm1EYXRhKGZvcm1EYXRhOiBZRm9ybURhdGEpIHtcbiAgICB0aGlzLm9ib0N1c3RvbWVyU2VydmljZVxuICAgICAgLmdldE9ib0N1c3RvbWVyVXNlcklkKClcbiAgICAgIC5waXBlKFxuICAgICAgICBtYXAodXNlcklkID0+IHtcbiAgICAgICAgICB0aGlzLnN0b3JlLmRpc3BhdGNoKFxuICAgICAgICAgICAgbmV3IGZyb21BY3Rpb24uU2F2ZUZvcm1EYXRhKHsgZm9ybURhdGEsIHVzZXJJZCB9KVxuICAgICAgICAgICk7XG4gICAgICAgIH0pXG4gICAgICApXG4gICAgICAuc3Vic2NyaWJlKClcbiAgICAgIC51bnN1YnNjcmliZSgpO1xuICB9XG5cbiAgbG9hZEZvcm1EZWZpbml0aW9uKGFwcGxpY2F0aW9uSWQ6IHN0cmluZywgZm9ybURlZmluaXRpb25JZDogc3RyaW5nKSB7XG4gICAgdGhpcy5zdG9yZS5kaXNwYXRjaChcbiAgICAgIG5ldyBmcm9tQWN0aW9uLkxvYWRGb3JtRGVmaW5pdGlvbih7XG4gICAgICAgIGFwcGxpY2F0aW9uSWQ6IGFwcGxpY2F0aW9uSWQsXG4gICAgICAgIGZvcm1EZWZpbml0aW9uSWQ6IGZvcm1EZWZpbml0aW9uSWQsXG4gICAgICB9KVxuICAgICk7XG4gIH1cblxuICBsb2FkRm9ybURlZmluaXRpb25zKGNhdGVnb3J5Q29kZTogc3RyaW5nLCBmb3JtRGVmaW5pdGlvblR5cGU6IHN0cmluZykge1xuICAgIHRoaXMuc3RvcmUuZGlzcGF0Y2goXG4gICAgICBuZXcgZnJvbUFjdGlvbi5Mb2FkRm9ybURlZmluaXRpb24oe1xuICAgICAgICBjYXRlZ29yeUNvZGU6IGNhdGVnb3J5Q29kZSxcbiAgICAgICAgZm9ybURlZmluaXRpb25UeXBlOiBmb3JtRGVmaW5pdGlvblR5cGUsXG4gICAgICB9KVxuICAgICk7XG4gIH1cblxuICBsb2FkRm9ybURhdGEoZm9ybURhdGFJZDogc3RyaW5nKSB7XG4gICAgdGhpcy5vYm9DdXN0b21lclNlcnZpY2VcbiAgICAgIC5nZXRPYm9DdXN0b21lclVzZXJJZCgpXG4gICAgICAucGlwZShcbiAgICAgICAgbWFwKHVzZXJJZCA9PiB7XG4gICAgICAgICAgdGhpcy5zdG9yZS5kaXNwYXRjaChcbiAgICAgICAgICAgIG5ldyBmcm9tQWN0aW9uLkxvYWRGb3JtRGF0YSh7IGZvcm1EYXRhSWQsIHVzZXJJZCB9KVxuICAgICAgICAgICk7XG4gICAgICAgIH0pXG4gICAgICApXG4gICAgICAuc3Vic2NyaWJlKClcbiAgICAgIC51bnN1YnNjcmliZSgpO1xuICB9XG5cbiAgZ2V0Rm9ybURhdGEoKTogT2JzZXJ2YWJsZTxZRm9ybURhdGE+IHtcbiAgICByZXR1cm4gdGhpcy5zdG9yZS5zZWxlY3QoZnJvbVNlbGVjdG9yLmdldEZvcm1EYXRhTG9hZGVkKS5waXBlKFxuICAgICAgZmlsdGVyKGxvYWRlZCA9PiBsb2FkZWQpLFxuICAgICAgdGFrZSgxKSxcbiAgICAgIHN3aXRjaE1hcChfID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3RvcmUuc2VsZWN0KGZyb21TZWxlY3Rvci5nZXRGb3JtRGF0YSk7XG4gICAgICB9KVxuICAgICk7XG4gIH1cblxuICBnZXRGb3JtRGVmaW5pdGlvbigpOiBPYnNlcnZhYmxlPFlGb3JtRGVmaW5pdGlvbj4ge1xuICAgIHJldHVybiB0aGlzLnN0b3JlLnNlbGVjdChmcm9tU2VsZWN0b3IuZ2V0Rm9ybURlZmluaXRpb25Mb2FkZWQpLnBpcGUoXG4gICAgICBmaWx0ZXIobG9hZGVkID0+IGxvYWRlZCksXG4gICAgICB0YWtlKDEpLFxuICAgICAgc3dpdGNoTWFwKF8gPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5zdG9yZS5zZWxlY3QoZnJvbVNlbGVjdG9yLmdldEZvcm1EZWZpbml0aW9uKTtcbiAgICAgIH0pXG4gICAgKTtcbiAgfVxufVxuIl19