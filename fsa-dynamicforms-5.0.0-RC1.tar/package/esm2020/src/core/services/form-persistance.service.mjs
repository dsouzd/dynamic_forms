import { Injectable } from '@angular/core';
import { createFeatureSelector, select, Store, } from '@ngrx/store';
import { StatePersistenceService } from '@spartacus/core';
import { Subscription } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { FORM_FEATURE } from '../store/state';
import * as fromAction from '../store/actions';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/core";
import * as i2 from "@ngrx/store";
export const getFormsState = createFeatureSelector(FORM_FEATURE);
/**
 * Responsible for storing Form state in the browser storage.
 * Uses `StatePersistenceService` mechanism.
 */
export class FormPersistenceService {
    constructor(statePersistenceService, store) {
        this.statePersistenceService = statePersistenceService;
        this.store = store;
        this.subscription = new Subscription();
        /**
         * Identifier used for storage key.
         */
        this.key = 'form';
    }
    /**
     * Initializes the synchronization between state and browser storage.
     */
    initSync() {
        this.subscription.add(this.statePersistenceService.syncWithStorage({
            key: this.key,
            state$: this.getUploadedFiles(),
            onRead: state => this.onRead(state),
        }));
    }
    /**
     * Gets and transforms state from different sources into the form that should
     * be saved in storage.
     */
    getUploadedFiles() {
        return this.store.pipe(select(getFormsState), filter(state => !!state), map(state => {
            return {
                files: state.uploadedFiles.content.files,
            };
        }));
    }
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     */
    onRead(state) {
        if (state) {
            this.store.dispatch(new fromAction.SetUploadedFiles(state.files));
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
}
FormPersistenceService.ɵfac = function FormPersistenceService_Factory(t) { return new (t || FormPersistenceService)(i0.ɵɵinject(i1.StatePersistenceService), i0.ɵɵinject(i2.Store)); };
FormPersistenceService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormPersistenceService, factory: FormPersistenceService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormPersistenceService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: i1.StatePersistenceService }, { type: i2.Store }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1wZXJzaXN0YW5jZS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb3JlL3NlcnZpY2VzL2Zvcm0tcGVyc2lzdGFuY2Uuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFhLE1BQU0sZUFBZSxDQUFDO0FBQ3RELE9BQU8sRUFDTCxxQkFBcUIsRUFFckIsTUFBTSxFQUNOLEtBQUssR0FDTixNQUFNLGFBQWEsQ0FBQztBQUNyQixPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMxRCxPQUFPLEVBQWMsWUFBWSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ2hELE9BQU8sRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDN0MsT0FBTyxFQUFjLFlBQVksRUFBaUIsTUFBTSxnQkFBZ0IsQ0FBQztBQUN6RSxPQUFPLEtBQUssVUFBVSxNQUFNLGtCQUFrQixDQUFDOzs7O0FBRS9DLE1BQU0sQ0FBQyxNQUFNLGFBQWEsR0FDeEIscUJBQXFCLENBQWEsWUFBWSxDQUFDLENBQUM7QUFNbEQ7OztHQUdHO0FBSUgsTUFBTSxPQUFPLHNCQUFzQjtJQUdqQyxZQUNZLHVCQUFnRCxFQUNoRCxLQUEyQjtRQUQzQiw0QkFBdUIsR0FBdkIsdUJBQXVCLENBQXlCO1FBQ2hELFVBQUssR0FBTCxLQUFLLENBQXNCO1FBSjdCLGlCQUFZLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQU81Qzs7V0FFRztRQUNPLFFBQUcsR0FBRyxNQUFNLENBQUM7SUFMcEIsQ0FBQztJQU9KOztPQUVHO0lBQ0ksUUFBUTtRQUNiLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUNuQixJQUFJLENBQUMsdUJBQXVCLENBQUMsZUFBZSxDQUFDO1lBQzNDLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRztZQUNiLE1BQU0sRUFBRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDL0IsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7U0FDcEMsQ0FBQyxDQUNILENBQUM7SUFDSixDQUFDO0lBRUQ7OztPQUdHO0lBQ08sZ0JBQWdCO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQ3BCLE1BQU0sQ0FBQyxhQUFhLENBQUMsRUFDckIsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUN4QixHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDVixPQUFPO2dCQUNMLEtBQUssRUFBRSxLQUFLLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxLQUFLO2FBQ3pDLENBQUM7UUFDSixDQUFDLENBQUMsQ0FDSCxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7T0FHRztJQUNPLE1BQU0sQ0FBQyxLQUF3QjtRQUN2QyxJQUFJLEtBQUssRUFBRTtZQUNULElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksVUFBVSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1NBQ25FO0lBQ0gsQ0FBQztJQUVELFdBQVc7UUFDVCxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ2xDLENBQUM7OzRGQXREVSxzQkFBc0I7NEVBQXRCLHNCQUFzQixXQUF0QixzQkFBc0IsbUJBRnJCLE1BQU07dUZBRVAsc0JBQXNCO2NBSGxDLFVBQVU7ZUFBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgY3JlYXRlRmVhdHVyZVNlbGVjdG9yLFxuICBNZW1vaXplZFNlbGVjdG9yLFxuICBzZWxlY3QsXG4gIFN0b3JlLFxufSBmcm9tICdAbmdyeC9zdG9yZSc7XG5pbXBvcnQgeyBTdGF0ZVBlcnNpc3RlbmNlU2VydmljZSB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGZpbHRlciwgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgRm9ybXNTdGF0ZSwgRk9STV9GRUFUVVJFLCBTdGF0ZVdpdGhGb3JtIH0gZnJvbSAnLi4vc3RvcmUvc3RhdGUnO1xuaW1wb3J0ICogYXMgZnJvbUFjdGlvbiBmcm9tICcuLi9zdG9yZS9hY3Rpb25zJztcblxuZXhwb3J0IGNvbnN0IGdldEZvcm1zU3RhdGU6IE1lbW9pemVkU2VsZWN0b3I8U3RhdGVXaXRoRm9ybSwgRm9ybXNTdGF0ZT4gPVxuICBjcmVhdGVGZWF0dXJlU2VsZWN0b3I8Rm9ybXNTdGF0ZT4oRk9STV9GRUFUVVJFKTtcblxuLyoqXG4gKiBGb3JtcyBzdGF0ZSBzeW5jZWQgdG8gYnJvd3NlciBzdG9yYWdlLlxuICovXG5leHBvcnQgdHlwZSBTeW5jZWRGb3Jtc1N0YXRlID0gUGFydGlhbDxGb3Jtc1N0YXRlPjtcbi8qKlxuICogUmVzcG9uc2libGUgZm9yIHN0b3JpbmcgRm9ybSBzdGF0ZSBpbiB0aGUgYnJvd3NlciBzdG9yYWdlLlxuICogVXNlcyBgU3RhdGVQZXJzaXN0ZW5jZVNlcnZpY2VgIG1lY2hhbmlzbS5cbiAqL1xuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIEZvcm1QZXJzaXN0ZW5jZVNlcnZpY2UgaW1wbGVtZW50cyBPbkRlc3Ryb3kge1xuICBwcm90ZWN0ZWQgc3Vic2NyaXB0aW9uID0gbmV3IFN1YnNjcmlwdGlvbigpO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByb3RlY3RlZCBzdGF0ZVBlcnNpc3RlbmNlU2VydmljZTogU3RhdGVQZXJzaXN0ZW5jZVNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIHN0b3JlOiBTdG9yZTxTdGF0ZVdpdGhGb3JtPlxuICApIHt9XG5cbiAgLyoqXG4gICAqIElkZW50aWZpZXIgdXNlZCBmb3Igc3RvcmFnZSBrZXkuXG4gICAqL1xuICBwcm90ZWN0ZWQga2V5ID0gJ2Zvcm0nO1xuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgc3luY2hyb25pemF0aW9uIGJldHdlZW4gc3RhdGUgYW5kIGJyb3dzZXIgc3RvcmFnZS5cbiAgICovXG4gIHB1YmxpYyBpbml0U3luYygpIHtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbi5hZGQoXG4gICAgICB0aGlzLnN0YXRlUGVyc2lzdGVuY2VTZXJ2aWNlLnN5bmNXaXRoU3RvcmFnZSh7XG4gICAgICAgIGtleTogdGhpcy5rZXksXG4gICAgICAgIHN0YXRlJDogdGhpcy5nZXRVcGxvYWRlZEZpbGVzKCksXG4gICAgICAgIG9uUmVhZDogc3RhdGUgPT4gdGhpcy5vblJlYWQoc3RhdGUpLFxuICAgICAgfSlcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldHMgYW5kIHRyYW5zZm9ybXMgc3RhdGUgZnJvbSBkaWZmZXJlbnQgc291cmNlcyBpbnRvIHRoZSBmb3JtIHRoYXQgc2hvdWxkXG4gICAqIGJlIHNhdmVkIGluIHN0b3JhZ2UuXG4gICAqL1xuICBwcm90ZWN0ZWQgZ2V0VXBsb2FkZWRGaWxlcygpOiBPYnNlcnZhYmxlPHsgZmlsZXM6IEZpbGVbXSB9PiB7XG4gICAgcmV0dXJuIHRoaXMuc3RvcmUucGlwZShcbiAgICAgIHNlbGVjdChnZXRGb3Jtc1N0YXRlKSxcbiAgICAgIGZpbHRlcihzdGF0ZSA9PiAhIXN0YXRlKSxcbiAgICAgIG1hcChzdGF0ZSA9PiB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZmlsZXM6IHN0YXRlLnVwbG9hZGVkRmlsZXMuY29udGVudC5maWxlcyxcbiAgICAgICAgfTtcbiAgICAgIH0pXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBGdW5jdGlvbiBjYWxsZWQgb24gZWFjaCBicm93c2VyIHN0b3JhZ2UgcmVhZC5cbiAgICogVXNlZCB0byB1cGRhdGUgc3RhdGUgZnJvbSBicm93c2VyIC0+IHN0YXRlLlxuICAgKi9cbiAgcHJvdGVjdGVkIG9uUmVhZChzdGF0ZTogeyBmaWxlczogRmlsZVtdIH0pIHtcbiAgICBpZiAoc3RhdGUpIHtcbiAgICAgIHRoaXMuc3RvcmUuZGlzcGF0Y2gobmV3IGZyb21BY3Rpb24uU2V0VXBsb2FkZWRGaWxlcyhzdGF0ZS5maWxlcykpO1xuICAgIH1cbiAgfVxuXG4gIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIHRoaXMuc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gIH1cbn1cbiJdfQ==