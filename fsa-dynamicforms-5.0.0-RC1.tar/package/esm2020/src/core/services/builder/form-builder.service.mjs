import { Injectable } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { UserAccountFacade } from '@spartacus/user/account/root';
import { FormValidationService } from '../form-validation/form-validation.service';
import { FieldDependencyResolverService } from './../form-dependencies/field-dependency-resolver.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "../form-validation/form-validation.service";
import * as i3 from "./../form-dependencies/field-dependency-resolver.service";
import * as i4 from "@spartacus/user/account/root";
export class FormBuilderService {
    constructor(fb, formValidationService, fieldDependencyResolverService, userAccountFacade) {
        this.fb = fb;
        this.formValidationService = formValidationService;
        this.fieldDependencyResolverService = fieldDependencyResolverService;
        this.userAccountFacade = userAccountFacade;
    }
    createForm(config) {
        const form = this.fb.group({});
        config.formGroups.forEach(formGroup => {
            const controlGroup = formGroup.groupCode !== undefined ? this.fb.group({}) : form;
            if (formGroup.groupCode !== undefined) {
                form.addControl(formGroup.groupCode, controlGroup);
            }
            formGroup.fieldConfigs.forEach(fieldConfig => {
                fieldConfig.group = controlGroup;
                const fieldControl = this.createControl(fieldConfig);
                controlGroup.addControl(fieldConfig.name, fieldControl);
                if (fieldConfig.dependsOn) {
                    this.fieldDependencyResolverService.resolveFormControlDependencies(fieldConfig, fieldControl, form);
                }
                this.enableFieldsForSellerUserGroup(fieldControl, fieldConfig);
            });
            if (formGroup.dependsOn) {
                this.fieldDependencyResolverService.resolveFormControlDependencies(formGroup, controlGroup, form);
            }
        });
        return form;
    }
    createControl(fieldConfig) {
        const { disabled, value } = fieldConfig;
        const validations = this.formValidationService.getValidatorsForField(fieldConfig);
        return this.fb.control({ disabled, value }, validations);
    }
    /**
     * Method is used to enable all form controls when currently logged in customer is part of seller user group.
     * This is temporary solution. Control property should be defined in the form defintion's JSON metadata.
     */
    enableFieldsForSellerUserGroup(fieldControl, fieldConfig) {
        this.userAccountFacade
            .get()
            .subscribe(user => {
            if (user?.roles.includes('sellergroup')) {
                fieldControl.enable();
                fieldConfig.readonly = false;
            }
        })
            .unsubscribe();
    }
}
FormBuilderService.ɵfac = function FormBuilderService_Factory(t) { return new (t || FormBuilderService)(i0.ɵɵinject(i1.UntypedFormBuilder), i0.ɵɵinject(i2.FormValidationService), i0.ɵɵinject(i3.FieldDependencyResolverService), i0.ɵɵinject(i4.UserAccountFacade)); };
FormBuilderService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormBuilderService, factory: FormBuilderService.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormBuilderService, [{
        type: Injectable
    }], function () { return [{ type: i1.UntypedFormBuilder }, { type: i2.FormValidationService }, { type: i3.FieldDependencyResolverService }, { type: i4.UserAccountFacade }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1idWlsZGVyLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvc2VydmljZXMvYnVpbGRlci9mb3JtLWJ1aWxkZXIuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxrQkFBa0IsRUFBc0IsTUFBTSxnQkFBZ0IsQ0FBQztBQUN4RSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNqRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSw0Q0FBNEMsQ0FBQztBQUVuRixPQUFPLEVBQUUsOEJBQThCLEVBQUUsTUFBTSwwREFBMEQsQ0FBQzs7Ozs7O0FBRzFHLE1BQU0sT0FBTyxrQkFBa0I7SUFDN0IsWUFDWSxFQUFzQixFQUN0QixxQkFBNEMsRUFDNUMsOEJBQThELEVBQzlELGlCQUFvQztRQUhwQyxPQUFFLEdBQUYsRUFBRSxDQUFvQjtRQUN0QiwwQkFBcUIsR0FBckIscUJBQXFCLENBQXVCO1FBQzVDLG1DQUE4QixHQUE5Qiw4QkFBOEIsQ0FBZ0M7UUFDOUQsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFtQjtJQUM3QyxDQUFDO0lBRUosVUFBVSxDQUFDLE1BQU07UUFDZixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMvQixNQUFNLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNwQyxNQUFNLFlBQVksR0FDaEIsU0FBUyxDQUFDLFNBQVMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDL0QsSUFBSSxTQUFTLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBRTtnQkFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO2FBQ3BEO1lBRUQsU0FBUyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQzNDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDO2dCQUNqQyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNyRCxZQUFZLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7Z0JBQ3hELElBQUksV0FBVyxDQUFDLFNBQVMsRUFBRTtvQkFDekIsSUFBSSxDQUFDLDhCQUE4QixDQUFDLDhCQUE4QixDQUNoRSxXQUFXLEVBQ1gsWUFBWSxFQUNaLElBQUksQ0FDTCxDQUFDO2lCQUNIO2dCQUNELElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxZQUFZLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDakUsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLFNBQVMsQ0FBQyxTQUFTLEVBQUU7Z0JBQ3ZCLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyw4QkFBOEIsQ0FDaEUsU0FBUyxFQUNULFlBQVksRUFDWixJQUFJLENBQ0wsQ0FBQzthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFRCxhQUFhLENBQUMsV0FBd0I7UUFDcEMsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsR0FBRyxXQUFXLENBQUM7UUFDeEMsTUFBTSxXQUFXLEdBQ2YsSUFBSSxDQUFDLHFCQUFxQixDQUFDLHFCQUFxQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2hFLE9BQU8sSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVEOzs7T0FHRztJQUNLLDhCQUE4QixDQUNwQyxZQUFnQyxFQUNoQyxXQUFXO1FBRVgsSUFBSSxDQUFDLGlCQUFpQjthQUNuQixHQUFHLEVBQUU7YUFDTCxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDaEIsSUFBVSxJQUFLLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDOUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUN0QixXQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQzthQUM5QjtRQUNILENBQUMsQ0FBQzthQUNELFdBQVcsRUFBRSxDQUFDO0lBQ25CLENBQUM7O29GQWpFVSxrQkFBa0I7d0VBQWxCLGtCQUFrQixXQUFsQixrQkFBa0I7dUZBQWxCLGtCQUFrQjtjQUQ5QixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgVW50eXBlZEZvcm1CdWlsZGVyLCBVbnR5cGVkRm9ybUNvbnRyb2wgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBVc2VyQWNjb3VudEZhY2FkZSB9IGZyb20gJ0BzcGFydGFjdXMvdXNlci9hY2NvdW50L3Jvb3QnO1xuaW1wb3J0IHsgRm9ybVZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi4vZm9ybS12YWxpZGF0aW9uL2Zvcm0tdmFsaWRhdGlvbi5zZXJ2aWNlJztcbmltcG9ydCB7IEZpZWxkQ29uZmlnIH0gZnJvbSAnLi8uLi8uLi9tb2RlbHMvZm9ybS1jb25maWcuaW50ZXJmYWNlJztcbmltcG9ydCB7IEZpZWxkRGVwZW5kZW5jeVJlc29sdmVyU2VydmljZSB9IGZyb20gJy4vLi4vZm9ybS1kZXBlbmRlbmNpZXMvZmllbGQtZGVwZW5kZW5jeS1yZXNvbHZlci5zZXJ2aWNlJztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIEZvcm1CdWlsZGVyU2VydmljZSB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByb3RlY3RlZCBmYjogVW50eXBlZEZvcm1CdWlsZGVyLFxuICAgIHByb3RlY3RlZCBmb3JtVmFsaWRhdGlvblNlcnZpY2U6IEZvcm1WYWxpZGF0aW9uU2VydmljZSxcbiAgICBwcm90ZWN0ZWQgZmllbGREZXBlbmRlbmN5UmVzb2x2ZXJTZXJ2aWNlOiBGaWVsZERlcGVuZGVuY3lSZXNvbHZlclNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIHVzZXJBY2NvdW50RmFjYWRlOiBVc2VyQWNjb3VudEZhY2FkZVxuICApIHt9XG5cbiAgY3JlYXRlRm9ybShjb25maWcpIHtcbiAgICBjb25zdCBmb3JtID0gdGhpcy5mYi5ncm91cCh7fSk7XG4gICAgY29uZmlnLmZvcm1Hcm91cHMuZm9yRWFjaChmb3JtR3JvdXAgPT4ge1xuICAgICAgY29uc3QgY29udHJvbEdyb3VwID1cbiAgICAgICAgZm9ybUdyb3VwLmdyb3VwQ29kZSAhPT0gdW5kZWZpbmVkID8gdGhpcy5mYi5ncm91cCh7fSkgOiBmb3JtO1xuICAgICAgaWYgKGZvcm1Hcm91cC5ncm91cENvZGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBmb3JtLmFkZENvbnRyb2woZm9ybUdyb3VwLmdyb3VwQ29kZSwgY29udHJvbEdyb3VwKTtcbiAgICAgIH1cblxuICAgICAgZm9ybUdyb3VwLmZpZWxkQ29uZmlncy5mb3JFYWNoKGZpZWxkQ29uZmlnID0+IHtcbiAgICAgICAgZmllbGRDb25maWcuZ3JvdXAgPSBjb250cm9sR3JvdXA7XG4gICAgICAgIGNvbnN0IGZpZWxkQ29udHJvbCA9IHRoaXMuY3JlYXRlQ29udHJvbChmaWVsZENvbmZpZyk7XG4gICAgICAgIGNvbnRyb2xHcm91cC5hZGRDb250cm9sKGZpZWxkQ29uZmlnLm5hbWUsIGZpZWxkQ29udHJvbCk7XG4gICAgICAgIGlmIChmaWVsZENvbmZpZy5kZXBlbmRzT24pIHtcbiAgICAgICAgICB0aGlzLmZpZWxkRGVwZW5kZW5jeVJlc29sdmVyU2VydmljZS5yZXNvbHZlRm9ybUNvbnRyb2xEZXBlbmRlbmNpZXMoXG4gICAgICAgICAgICBmaWVsZENvbmZpZyxcbiAgICAgICAgICAgIGZpZWxkQ29udHJvbCxcbiAgICAgICAgICAgIGZvcm1cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZW5hYmxlRmllbGRzRm9yU2VsbGVyVXNlckdyb3VwKGZpZWxkQ29udHJvbCwgZmllbGRDb25maWcpO1xuICAgICAgfSk7XG4gICAgICBpZiAoZm9ybUdyb3VwLmRlcGVuZHNPbikge1xuICAgICAgICB0aGlzLmZpZWxkRGVwZW5kZW5jeVJlc29sdmVyU2VydmljZS5yZXNvbHZlRm9ybUNvbnRyb2xEZXBlbmRlbmNpZXMoXG4gICAgICAgICAgZm9ybUdyb3VwLFxuICAgICAgICAgIGNvbnRyb2xHcm91cCxcbiAgICAgICAgICBmb3JtXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGZvcm07XG4gIH1cblxuICBjcmVhdGVDb250cm9sKGZpZWxkQ29uZmlnOiBGaWVsZENvbmZpZykge1xuICAgIGNvbnN0IHsgZGlzYWJsZWQsIHZhbHVlIH0gPSBmaWVsZENvbmZpZztcbiAgICBjb25zdCB2YWxpZGF0aW9ucyA9XG4gICAgICB0aGlzLmZvcm1WYWxpZGF0aW9uU2VydmljZS5nZXRWYWxpZGF0b3JzRm9yRmllbGQoZmllbGRDb25maWcpO1xuICAgIHJldHVybiB0aGlzLmZiLmNvbnRyb2woeyBkaXNhYmxlZCwgdmFsdWUgfSwgdmFsaWRhdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIE1ldGhvZCBpcyB1c2VkIHRvIGVuYWJsZSBhbGwgZm9ybSBjb250cm9scyB3aGVuIGN1cnJlbnRseSBsb2dnZWQgaW4gY3VzdG9tZXIgaXMgcGFydCBvZiBzZWxsZXIgdXNlciBncm91cC5cbiAgICogVGhpcyBpcyB0ZW1wb3Jhcnkgc29sdXRpb24uIENvbnRyb2wgcHJvcGVydHkgc2hvdWxkIGJlIGRlZmluZWQgaW4gdGhlIGZvcm0gZGVmaW50aW9uJ3MgSlNPTiBtZXRhZGF0YS5cbiAgICovXG4gIHByaXZhdGUgZW5hYmxlRmllbGRzRm9yU2VsbGVyVXNlckdyb3VwKFxuICAgIGZpZWxkQ29udHJvbDogVW50eXBlZEZvcm1Db250cm9sLFxuICAgIGZpZWxkQ29uZmlnXG4gICkge1xuICAgIHRoaXMudXNlckFjY291bnRGYWNhZGVcbiAgICAgIC5nZXQoKVxuICAgICAgLnN1YnNjcmliZSh1c2VyID0+IHtcbiAgICAgICAgaWYgKCg8YW55PnVzZXIpPy5yb2xlcy5pbmNsdWRlcygnc2VsbGVyZ3JvdXAnKSkge1xuICAgICAgICAgIGZpZWxkQ29udHJvbC5lbmFibGUoKTtcbiAgICAgICAgICBmaWVsZENvbmZpZy5yZWFkb25seSA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLnVuc3Vic2NyaWJlKCk7XG4gIH1cbn1cbiJdfQ==