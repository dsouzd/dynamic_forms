import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { DynamicFormsConfig } from '../../config/form-config';
import * as i0 from "@angular/core";
import * as i1 from "../../config/form-config";
export class FormValidationService {
    constructor(formConfig) {
        this.formConfig = formConfig;
        this.configValidators = this.formConfig.dynamicForms.validators;
    }
    getValidatorsForField(fieldConfig) {
        const validators = [];
        if (fieldConfig) {
            if (fieldConfig.validations) {
                fieldConfig.validations.forEach(fieldValidation => {
                    const validatorFn = this.getValidatorForFunction(fieldValidation);
                    if (validatorFn) {
                        validators.push(validatorFn);
                    }
                });
            }
            if (fieldConfig.required) {
                validators.push(Validators.required);
            }
        }
        return validators;
    }
    getValidatorForFunction(validatorFunction) {
        const validatorMapping = this.configValidators[validatorFunction.name];
        if (validatorMapping && validatorMapping.validator) {
            if (validatorFunction.arguments) {
                return validatorMapping.validator.apply(this, validatorFunction.arguments.map(arg => arg.value));
            }
            else {
                return validatorMapping.validator;
            }
        }
    }
}
FormValidationService.ɵfac = function FormValidationService_Factory(t) { return new (t || FormValidationService)(i0.ɵɵinject(i1.DynamicFormsConfig)); };
FormValidationService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormValidationService, factory: FormValidationService.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormValidationService, [{
        type: Injectable
    }], function () { return [{ type: i1.DynamicFormsConfig }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS12YWxpZGF0aW9uLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvc2VydmljZXMvZm9ybS12YWxpZGF0aW9uL2Zvcm0tdmFsaWRhdGlvbi5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFlLFVBQVUsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3pELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDBCQUEwQixDQUFDOzs7QUFPOUQsTUFBTSxPQUFPLHFCQUFxQjtJQUNoQyxZQUFzQixVQUE4QjtRQUE5QixlQUFVLEdBQVYsVUFBVSxDQUFvQjtRQUVwRCxxQkFBZ0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUM7SUFGSixDQUFDO0lBSXhELHFCQUFxQixDQUFDLFdBQXdCO1FBQzVDLE1BQU0sVUFBVSxHQUFrQixFQUFFLENBQUM7UUFDckMsSUFBSSxXQUFXLEVBQUU7WUFDZixJQUFJLFdBQVcsQ0FBQyxXQUFXLEVBQUU7Z0JBQzNCLFdBQVcsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxFQUFFO29CQUNoRCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQ2xFLElBQUksV0FBVyxFQUFFO3dCQUNmLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7cUJBQzlCO2dCQUNILENBQUMsQ0FBQyxDQUFDO2FBQ0o7WUFDRCxJQUFJLFdBQVcsQ0FBQyxRQUFRLEVBQUU7Z0JBQ3hCLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3RDO1NBQ0Y7UUFDRCxPQUFPLFVBQVUsQ0FBQztJQUNwQixDQUFDO0lBRUQsdUJBQXVCLENBQUMsaUJBQW9DO1FBQzFELE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZFLElBQUksZ0JBQWdCLElBQUksZ0JBQWdCLENBQUMsU0FBUyxFQUFFO1lBQ2xELElBQUksaUJBQWlCLENBQUMsU0FBUyxFQUFFO2dCQUMvQixPQUFPLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQ3JDLElBQUksRUFDSixpQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUNsRCxDQUFDO2FBQ0g7aUJBQU07Z0JBQ0wsT0FBTyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUM7YUFDbkM7U0FDRjtJQUNILENBQUM7OzBGQW5DVSxxQkFBcUI7MkVBQXJCLHFCQUFxQixXQUFyQixxQkFBcUI7dUZBQXJCLHFCQUFxQjtjQURqQyxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgVmFsaWRhdG9yRm4sIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBEeW5hbWljRm9ybXNDb25maWcgfSBmcm9tICcuLi8uLi9jb25maWcvZm9ybS1jb25maWcnO1xuaW1wb3J0IHtcbiAgRmllbGRDb25maWcsXG4gIFZhbGlkYXRvckZ1bmN0aW9uLFxufSBmcm9tICcuLy4uLy4uL21vZGVscy9mb3JtLWNvbmZpZy5pbnRlcmZhY2UnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgRm9ybVZhbGlkYXRpb25TZXJ2aWNlIHtcbiAgY29uc3RydWN0b3IocHJvdGVjdGVkIGZvcm1Db25maWc6IER5bmFtaWNGb3Jtc0NvbmZpZykge31cblxuICBjb25maWdWYWxpZGF0b3JzID0gdGhpcy5mb3JtQ29uZmlnLmR5bmFtaWNGb3Jtcy52YWxpZGF0b3JzO1xuXG4gIGdldFZhbGlkYXRvcnNGb3JGaWVsZChmaWVsZENvbmZpZzogRmllbGRDb25maWcpOiBWYWxpZGF0b3JGbltdIHtcbiAgICBjb25zdCB2YWxpZGF0b3JzOiBWYWxpZGF0b3JGbltdID0gW107XG4gICAgaWYgKGZpZWxkQ29uZmlnKSB7XG4gICAgICBpZiAoZmllbGRDb25maWcudmFsaWRhdGlvbnMpIHtcbiAgICAgICAgZmllbGRDb25maWcudmFsaWRhdGlvbnMuZm9yRWFjaChmaWVsZFZhbGlkYXRpb24gPT4ge1xuICAgICAgICAgIGNvbnN0IHZhbGlkYXRvckZuID0gdGhpcy5nZXRWYWxpZGF0b3JGb3JGdW5jdGlvbihmaWVsZFZhbGlkYXRpb24pO1xuICAgICAgICAgIGlmICh2YWxpZGF0b3JGbikge1xuICAgICAgICAgICAgdmFsaWRhdG9ycy5wdXNoKHZhbGlkYXRvckZuKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgaWYgKGZpZWxkQ29uZmlnLnJlcXVpcmVkKSB7XG4gICAgICAgIHZhbGlkYXRvcnMucHVzaChWYWxpZGF0b3JzLnJlcXVpcmVkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHZhbGlkYXRvcnM7XG4gIH1cblxuICBnZXRWYWxpZGF0b3JGb3JGdW5jdGlvbih2YWxpZGF0b3JGdW5jdGlvbjogVmFsaWRhdG9yRnVuY3Rpb24pOiBWYWxpZGF0b3JGbiB7XG4gICAgY29uc3QgdmFsaWRhdG9yTWFwcGluZyA9IHRoaXMuY29uZmlnVmFsaWRhdG9yc1t2YWxpZGF0b3JGdW5jdGlvbi5uYW1lXTtcbiAgICBpZiAodmFsaWRhdG9yTWFwcGluZyAmJiB2YWxpZGF0b3JNYXBwaW5nLnZhbGlkYXRvcikge1xuICAgICAgaWYgKHZhbGlkYXRvckZ1bmN0aW9uLmFyZ3VtZW50cykge1xuICAgICAgICByZXR1cm4gdmFsaWRhdG9yTWFwcGluZy52YWxpZGF0b3IuYXBwbHkoXG4gICAgICAgICAgdGhpcyxcbiAgICAgICAgICB2YWxpZGF0b3JGdW5jdGlvbi5hcmd1bWVudHMubWFwKGFyZyA9PiBhcmcudmFsdWUpXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gdmFsaWRhdG9yTWFwcGluZy52YWxpZGF0b3I7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0=