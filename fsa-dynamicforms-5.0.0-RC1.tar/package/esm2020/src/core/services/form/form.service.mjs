import { Injectable } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export class FormService {
    constructor() { }
    /**
     * Method used to recursively find form control by its code in specified form group
     *
     * @param formControlCode The form control code
     * @param formGroup The form group
     */
    getFormControlForCode(formControlCode, formGroup) {
        let abstractFormControl;
        for (const key of Object.keys(formGroup.controls)) {
            const nestedFormGroup = formGroup.get(key);
            if (key === formControlCode) {
                abstractFormControl = formGroup.get(key);
                break;
            }
            else if (nestedFormGroup instanceof UntypedFormGroup) {
                abstractFormControl = this.getFormControlForCode(formControlCode, nestedFormGroup);
                if (abstractFormControl !== undefined) {
                    break;
                }
            }
        }
        return abstractFormControl;
    }
}
FormService.ɵfac = function FormService_Factory(t) { return new (t || FormService)(); };
FormService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormService, factory: FormService.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormService, [{
        type: Injectable
    }], function () { return []; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb3JlL3NlcnZpY2VzL2Zvcm0vZm9ybS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFtQixnQkFBZ0IsRUFBRSxNQUFNLGdCQUFnQixDQUFDOztBQUduRSxNQUFNLE9BQU8sV0FBVztJQUN0QixnQkFBZSxDQUFDO0lBRWhCOzs7OztPQUtHO0lBQ0gscUJBQXFCLENBQ25CLGVBQXVCLEVBQ3ZCLFNBQWM7UUFFZCxJQUFJLG1CQUFtQixDQUFDO1FBQ3hCLEtBQUssTUFBTSxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDakQsTUFBTSxlQUFlLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMzQyxJQUFJLEdBQUcsS0FBSyxlQUFlLEVBQUU7Z0JBQzNCLG1CQUFtQixHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3pDLE1BQU07YUFDUDtpQkFBTSxJQUFJLGVBQWUsWUFBWSxnQkFBZ0IsRUFBRTtnQkFDdEQsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUM5QyxlQUFlLEVBQ2YsZUFBZSxDQUNoQixDQUFDO2dCQUNGLElBQUksbUJBQW1CLEtBQUssU0FBUyxFQUFFO29CQUNyQyxNQUFNO2lCQUNQO2FBQ0Y7U0FDRjtRQUNELE9BQU8sbUJBQW1CLENBQUM7SUFDN0IsQ0FBQzs7c0VBOUJVLFdBQVc7aUVBQVgsV0FBVyxXQUFYLFdBQVc7dUZBQVgsV0FBVztjQUR2QixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWJzdHJhY3RDb250cm9sLCBVbnR5cGVkRm9ybUdyb3VwIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgRm9ybVNlcnZpY2Uge1xuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgLyoqXG4gICAqIE1ldGhvZCB1c2VkIHRvIHJlY3Vyc2l2ZWx5IGZpbmQgZm9ybSBjb250cm9sIGJ5IGl0cyBjb2RlIGluIHNwZWNpZmllZCBmb3JtIGdyb3VwXG4gICAqXG4gICAqIEBwYXJhbSBmb3JtQ29udHJvbENvZGUgVGhlIGZvcm0gY29udHJvbCBjb2RlXG4gICAqIEBwYXJhbSBmb3JtR3JvdXAgVGhlIGZvcm0gZ3JvdXBcbiAgICovXG4gIGdldEZvcm1Db250cm9sRm9yQ29kZShcbiAgICBmb3JtQ29udHJvbENvZGU6IHN0cmluZyxcbiAgICBmb3JtR3JvdXA6IGFueVxuICApOiBBYnN0cmFjdENvbnRyb2wge1xuICAgIGxldCBhYnN0cmFjdEZvcm1Db250cm9sO1xuICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGZvcm1Hcm91cC5jb250cm9scykpIHtcbiAgICAgIGNvbnN0IG5lc3RlZEZvcm1Hcm91cCA9IGZvcm1Hcm91cC5nZXQoa2V5KTtcbiAgICAgIGlmIChrZXkgPT09IGZvcm1Db250cm9sQ29kZSkge1xuICAgICAgICBhYnN0cmFjdEZvcm1Db250cm9sID0gZm9ybUdyb3VwLmdldChrZXkpO1xuICAgICAgICBicmVhaztcbiAgICAgIH0gZWxzZSBpZiAobmVzdGVkRm9ybUdyb3VwIGluc3RhbmNlb2YgVW50eXBlZEZvcm1Hcm91cCkge1xuICAgICAgICBhYnN0cmFjdEZvcm1Db250cm9sID0gdGhpcy5nZXRGb3JtQ29udHJvbEZvckNvZGUoXG4gICAgICAgICAgZm9ybUNvbnRyb2xDb2RlLFxuICAgICAgICAgIG5lc3RlZEZvcm1Hcm91cFxuICAgICAgICApO1xuICAgICAgICBpZiAoYWJzdHJhY3RGb3JtQ29udHJvbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGFic3RyYWN0Rm9ybUNvbnRyb2w7XG4gIH1cbn1cbiJdfQ==