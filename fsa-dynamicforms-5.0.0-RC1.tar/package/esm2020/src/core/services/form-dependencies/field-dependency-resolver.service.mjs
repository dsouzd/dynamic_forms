import { Injectable } from '@angular/core';
import { UntypedFormBuilder, } from '@angular/forms';
import { FormService } from '../form/form.service';
import { FormValidationService } from './../form-validation/form-validation.service';
import * as i0 from "@angular/core";
import * as i1 from "./../form-validation/form-validation.service";
import * as i2 from "../form/form.service";
import * as i3 from "@angular/forms";
export class FieldDependencyResolverService {
    constructor(formValidationService, formService, fb) {
        this.formValidationService = formValidationService;
        this.formService = formService;
        this.fb = fb;
    }
    /**
     * Method used to enable/disable dependent control based on conditions defined at main control
     *
     * @param controlConfig The dependent field config for which dependencies are resolved
     * @param dependentControl The dependent field control for which dependencies are resolved
     * @param formGroup The form group which tracks value and validity of main form controls
     */
    resolveFormControlDependencies(controlConfig, dependentControl, formGroup) {
        controlConfig.dependsOn.controls.forEach(condition => {
            const mainFormControl = this.formService.getFormControlForCode(condition.controlName, formGroup);
            if (mainFormControl) {
                if (!mainFormControl.value) {
                    if (controlConfig.dependsOn.hide === true) {
                        controlConfig.hidden = true;
                    }
                    this.changeControlEnabled(dependentControl, controlConfig, false);
                }
                mainFormControl.valueChanges.subscribe(fieldValue => {
                    const dependencyValidations = this.geValidationsForCondition(condition);
                    const dependancyControl = this.fb.control({ disabled: false, value: fieldValue }, dependencyValidations);
                    if (dependancyControl.valid) {
                        if (controlConfig.dependsOn.hide === true) {
                            controlConfig.hidden = false;
                        }
                        this.changeControlEnabled(dependentControl, controlConfig, true);
                    }
                    else {
                        if (controlConfig.dependsOn.hide === true) {
                            controlConfig.hidden = true;
                        }
                        this.changeControlEnabled(dependentControl, controlConfig, false);
                    }
                });
            }
        });
    }
    /**
     * Method used to enable/disable control based on input parameter and form configuration value.
     * In case control is from group, check is done for nested controls to see if any of them has configuration set to disabled.
     * If any field config has disabled property set to true, dynamic condition cannot change that.
     *
     * @param dependentControl The dependent field control for which dependencies are resolved
     * @param controlConfig The dependent field config for which dependencies are resolved (control or group)
     * @param enabled The enabled flag which indicates if parent control conditions are met.
     */
    changeControlEnabled(dependentControl, controlConfig, enabled) {
        if (enabled) {
            if (dependentControl.controls && controlConfig.fieldConfigs) {
                controlConfig.fieldConfigs.forEach(childConfig => {
                    childConfig.disabled
                        ? dependentControl.controls[childConfig.name].disable()
                        : dependentControl.controls[childConfig.name].enable();
                });
            }
            else {
                dependentControl.enable();
            }
        }
        else {
            dependentControl.disable();
        }
        dependentControl.updateValueAndValidity({ emitEvent: false });
    }
    geValidationsForCondition(dependencyFn) {
        const dependencyFunctions = [];
        if (dependencyFn && dependencyFn.conditions) {
            dependencyFn.conditions.forEach(conditionFunction => {
                dependencyFunctions.push(this.formValidationService.getValidatorForFunction(conditionFunction));
            });
        }
        return dependencyFunctions;
    }
}
FieldDependencyResolverService.ɵfac = function FieldDependencyResolverService_Factory(t) { return new (t || FieldDependencyResolverService)(i0.ɵɵinject(i1.FormValidationService), i0.ɵɵinject(i2.FormService), i0.ɵɵinject(i3.UntypedFormBuilder)); };
FieldDependencyResolverService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FieldDependencyResolverService, factory: FieldDependencyResolverService.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FieldDependencyResolverService, [{
        type: Injectable
    }], function () { return [{ type: i1.FormValidationService }, { type: i2.FormService }, { type: i3.UntypedFormBuilder }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmllbGQtZGVwZW5kZW5jeS1yZXNvbHZlci5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb3JlL3NlcnZpY2VzL2Zvcm0tZGVwZW5kZW5jaWVzL2ZpZWxkLWRlcGVuZGVuY3ktcmVzb2x2ZXIuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFFTCxrQkFBa0IsR0FHbkIsTUFBTSxnQkFBZ0IsQ0FBQztBQUN4QixPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFLbkQsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sOENBQThDLENBQUM7Ozs7O0FBR3JGLE1BQU0sT0FBTyw4QkFBOEI7SUFDekMsWUFDWSxxQkFBNEMsRUFDNUMsV0FBd0IsRUFDeEIsRUFBc0I7UUFGdEIsMEJBQXFCLEdBQXJCLHFCQUFxQixDQUF1QjtRQUM1QyxnQkFBVyxHQUFYLFdBQVcsQ0FBYTtRQUN4QixPQUFFLEdBQUYsRUFBRSxDQUFvQjtJQUMvQixDQUFDO0lBRUo7Ozs7OztPQU1HO0lBQ0gsOEJBQThCLENBQzVCLGFBQWtCLEVBQ2xCLGdCQUFpQyxFQUNqQyxTQUEyQjtRQUUzQixhQUFhLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDbkQsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsQ0FDNUQsU0FBUyxDQUFDLFdBQVcsRUFDckIsU0FBUyxDQUNWLENBQUM7WUFDRixJQUFJLGVBQWUsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUU7b0JBQzFCLElBQUksYUFBYSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFO3dCQUN6QyxhQUFhLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztxQkFDN0I7b0JBQ0QsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGdCQUFnQixFQUFFLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztpQkFDbkU7Z0JBQ0QsZUFBZSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLEVBQUU7b0JBQ2xELE1BQU0scUJBQXFCLEdBQ3pCLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDNUMsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FDdkMsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsRUFDdEMscUJBQXFCLENBQ3RCLENBQUM7b0JBRUYsSUFBSSxpQkFBaUIsQ0FBQyxLQUFLLEVBQUU7d0JBQzNCLElBQUksYUFBYSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFOzRCQUN6QyxhQUFhLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQzt5QkFDOUI7d0JBQ0QsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGdCQUFnQixFQUFFLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDbEU7eUJBQU07d0JBQ0wsSUFBSSxhQUFhLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxJQUFJLEVBQUU7NEJBQ3pDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO3lCQUM3Qjt3QkFDRCxJQUFJLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUNuRTtnQkFDSCxDQUFDLENBQUMsQ0FBQzthQUNKO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxvQkFBb0IsQ0FDbEIsZ0JBQXFCLEVBQ3JCLGFBQStCLEVBQy9CLE9BQWdCO1FBRWhCLElBQUksT0FBTyxFQUFFO1lBQ1gsSUFBSSxnQkFBZ0IsQ0FBQyxRQUFRLElBQUksYUFBYSxDQUFDLFlBQVksRUFBRTtnQkFDM0QsYUFBYSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQy9DLFdBQVcsQ0FBQyxRQUFRO3dCQUNsQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUU7d0JBQ3ZELENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUMzRCxDQUFDLENBQUMsQ0FBQzthQUNKO2lCQUFNO2dCQUNMLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxDQUFDO2FBQzNCO1NBQ0Y7YUFBTTtZQUNMLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzVCO1FBQ0QsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUMsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRUQseUJBQXlCLENBQUMsWUFBK0I7UUFDdkQsTUFBTSxtQkFBbUIsR0FBa0IsRUFBRSxDQUFDO1FBQzlDLElBQUksWUFBWSxJQUFJLFlBQVksQ0FBQyxVQUFVLEVBQUU7WUFDM0MsWUFBWSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsRUFBRTtnQkFDbEQsbUJBQW1CLENBQUMsSUFBSSxDQUN0QixJQUFJLENBQUMscUJBQXFCLENBQUMsdUJBQXVCLENBQUMsaUJBQWlCLENBQUMsQ0FDdEUsQ0FBQztZQUNKLENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFDRCxPQUFPLG1CQUFtQixDQUFDO0lBQzdCLENBQUM7OzRHQS9GVSw4QkFBOEI7b0ZBQTlCLDhCQUE4QixXQUE5Qiw4QkFBOEI7dUZBQTlCLDhCQUE4QjtjQUQxQyxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgQWJzdHJhY3RDb250cm9sLFxuICBVbnR5cGVkRm9ybUJ1aWxkZXIsXG4gIFVudHlwZWRGb3JtR3JvdXAsXG4gIFZhbGlkYXRvckZuLFxufSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBGb3JtU2VydmljZSB9IGZyb20gJy4uL2Zvcm0vZm9ybS5zZXJ2aWNlJztcbmltcG9ydCB7XG4gIENvbnRyb2xEZXBlbmRlbmN5LFxuICBEeW5hbWljRm9ybUdyb3VwLFxufSBmcm9tICcuLy4uLy4uL21vZGVscy9mb3JtLWNvbmZpZy5pbnRlcmZhY2UnO1xuaW1wb3J0IHsgRm9ybVZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi8uLi9mb3JtLXZhbGlkYXRpb24vZm9ybS12YWxpZGF0aW9uLnNlcnZpY2UnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgRmllbGREZXBlbmRlbmN5UmVzb2x2ZXJTZXJ2aWNlIHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJvdGVjdGVkIGZvcm1WYWxpZGF0aW9uU2VydmljZTogRm9ybVZhbGlkYXRpb25TZXJ2aWNlLFxuICAgIHByb3RlY3RlZCBmb3JtU2VydmljZTogRm9ybVNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIGZiOiBVbnR5cGVkRm9ybUJ1aWxkZXJcbiAgKSB7fVxuXG4gIC8qKlxuICAgKiBNZXRob2QgdXNlZCB0byBlbmFibGUvZGlzYWJsZSBkZXBlbmRlbnQgY29udHJvbCBiYXNlZCBvbiBjb25kaXRpb25zIGRlZmluZWQgYXQgbWFpbiBjb250cm9sXG4gICAqXG4gICAqIEBwYXJhbSBjb250cm9sQ29uZmlnIFRoZSBkZXBlbmRlbnQgZmllbGQgY29uZmlnIGZvciB3aGljaCBkZXBlbmRlbmNpZXMgYXJlIHJlc29sdmVkXG4gICAqIEBwYXJhbSBkZXBlbmRlbnRDb250cm9sIFRoZSBkZXBlbmRlbnQgZmllbGQgY29udHJvbCBmb3Igd2hpY2ggZGVwZW5kZW5jaWVzIGFyZSByZXNvbHZlZFxuICAgKiBAcGFyYW0gZm9ybUdyb3VwIFRoZSBmb3JtIGdyb3VwIHdoaWNoIHRyYWNrcyB2YWx1ZSBhbmQgdmFsaWRpdHkgb2YgbWFpbiBmb3JtIGNvbnRyb2xzXG4gICAqL1xuICByZXNvbHZlRm9ybUNvbnRyb2xEZXBlbmRlbmNpZXMoXG4gICAgY29udHJvbENvbmZpZzogYW55LFxuICAgIGRlcGVuZGVudENvbnRyb2w6IEFic3RyYWN0Q29udHJvbCxcbiAgICBmb3JtR3JvdXA6IFVudHlwZWRGb3JtR3JvdXBcbiAgKSB7XG4gICAgY29udHJvbENvbmZpZy5kZXBlbmRzT24uY29udHJvbHMuZm9yRWFjaChjb25kaXRpb24gPT4ge1xuICAgICAgY29uc3QgbWFpbkZvcm1Db250cm9sID0gdGhpcy5mb3JtU2VydmljZS5nZXRGb3JtQ29udHJvbEZvckNvZGUoXG4gICAgICAgIGNvbmRpdGlvbi5jb250cm9sTmFtZSxcbiAgICAgICAgZm9ybUdyb3VwXG4gICAgICApO1xuICAgICAgaWYgKG1haW5Gb3JtQ29udHJvbCkge1xuICAgICAgICBpZiAoIW1haW5Gb3JtQ29udHJvbC52YWx1ZSkge1xuICAgICAgICAgIGlmIChjb250cm9sQ29uZmlnLmRlcGVuZHNPbi5oaWRlID09PSB0cnVlKSB7XG4gICAgICAgICAgICBjb250cm9sQ29uZmlnLmhpZGRlbiA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuY2hhbmdlQ29udHJvbEVuYWJsZWQoZGVwZW5kZW50Q29udHJvbCwgY29udHJvbENvbmZpZywgZmFsc2UpO1xuICAgICAgICB9XG4gICAgICAgIG1haW5Gb3JtQ29udHJvbC52YWx1ZUNoYW5nZXMuc3Vic2NyaWJlKGZpZWxkVmFsdWUgPT4ge1xuICAgICAgICAgIGNvbnN0IGRlcGVuZGVuY3lWYWxpZGF0aW9ucyA9XG4gICAgICAgICAgICB0aGlzLmdlVmFsaWRhdGlvbnNGb3JDb25kaXRpb24oY29uZGl0aW9uKTtcbiAgICAgICAgICBjb25zdCBkZXBlbmRhbmN5Q29udHJvbCA9IHRoaXMuZmIuY29udHJvbChcbiAgICAgICAgICAgIHsgZGlzYWJsZWQ6IGZhbHNlLCB2YWx1ZTogZmllbGRWYWx1ZSB9LFxuICAgICAgICAgICAgZGVwZW5kZW5jeVZhbGlkYXRpb25zXG4gICAgICAgICAgKTtcblxuICAgICAgICAgIGlmIChkZXBlbmRhbmN5Q29udHJvbC52YWxpZCkge1xuICAgICAgICAgICAgaWYgKGNvbnRyb2xDb25maWcuZGVwZW5kc09uLmhpZGUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgY29udHJvbENvbmZpZy5oaWRkZW4gPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuY2hhbmdlQ29udHJvbEVuYWJsZWQoZGVwZW5kZW50Q29udHJvbCwgY29udHJvbENvbmZpZywgdHJ1ZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmIChjb250cm9sQ29uZmlnLmRlcGVuZHNPbi5oaWRlID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgIGNvbnRyb2xDb25maWcuaGlkZGVuID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuY2hhbmdlQ29udHJvbEVuYWJsZWQoZGVwZW5kZW50Q29udHJvbCwgY29udHJvbENvbmZpZywgZmFsc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogTWV0aG9kIHVzZWQgdG8gZW5hYmxlL2Rpc2FibGUgY29udHJvbCBiYXNlZCBvbiBpbnB1dCBwYXJhbWV0ZXIgYW5kIGZvcm0gY29uZmlndXJhdGlvbiB2YWx1ZS5cbiAgICogSW4gY2FzZSBjb250cm9sIGlzIGZyb20gZ3JvdXAsIGNoZWNrIGlzIGRvbmUgZm9yIG5lc3RlZCBjb250cm9scyB0byBzZWUgaWYgYW55IG9mIHRoZW0gaGFzIGNvbmZpZ3VyYXRpb24gc2V0IHRvIGRpc2FibGVkLlxuICAgKiBJZiBhbnkgZmllbGQgY29uZmlnIGhhcyBkaXNhYmxlZCBwcm9wZXJ0eSBzZXQgdG8gdHJ1ZSwgZHluYW1pYyBjb25kaXRpb24gY2Fubm90IGNoYW5nZSB0aGF0LlxuICAgKlxuICAgKiBAcGFyYW0gZGVwZW5kZW50Q29udHJvbCBUaGUgZGVwZW5kZW50IGZpZWxkIGNvbnRyb2wgZm9yIHdoaWNoIGRlcGVuZGVuY2llcyBhcmUgcmVzb2x2ZWRcbiAgICogQHBhcmFtIGNvbnRyb2xDb25maWcgVGhlIGRlcGVuZGVudCBmaWVsZCBjb25maWcgZm9yIHdoaWNoIGRlcGVuZGVuY2llcyBhcmUgcmVzb2x2ZWQgKGNvbnRyb2wgb3IgZ3JvdXApXG4gICAqIEBwYXJhbSBlbmFibGVkIFRoZSBlbmFibGVkIGZsYWcgd2hpY2ggaW5kaWNhdGVzIGlmIHBhcmVudCBjb250cm9sIGNvbmRpdGlvbnMgYXJlIG1ldC5cbiAgICovXG4gIGNoYW5nZUNvbnRyb2xFbmFibGVkKFxuICAgIGRlcGVuZGVudENvbnRyb2w6IGFueSxcbiAgICBjb250cm9sQ29uZmlnOiBEeW5hbWljRm9ybUdyb3VwLFxuICAgIGVuYWJsZWQ6IGJvb2xlYW5cbiAgKSB7XG4gICAgaWYgKGVuYWJsZWQpIHtcbiAgICAgIGlmIChkZXBlbmRlbnRDb250cm9sLmNvbnRyb2xzICYmIGNvbnRyb2xDb25maWcuZmllbGRDb25maWdzKSB7XG4gICAgICAgIGNvbnRyb2xDb25maWcuZmllbGRDb25maWdzLmZvckVhY2goY2hpbGRDb25maWcgPT4ge1xuICAgICAgICAgIGNoaWxkQ29uZmlnLmRpc2FibGVkXG4gICAgICAgICAgICA/IGRlcGVuZGVudENvbnRyb2wuY29udHJvbHNbY2hpbGRDb25maWcubmFtZV0uZGlzYWJsZSgpXG4gICAgICAgICAgICA6IGRlcGVuZGVudENvbnRyb2wuY29udHJvbHNbY2hpbGRDb25maWcubmFtZV0uZW5hYmxlKCk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZGVwZW5kZW50Q29udHJvbC5lbmFibGUoKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgZGVwZW5kZW50Q29udHJvbC5kaXNhYmxlKCk7XG4gICAgfVxuICAgIGRlcGVuZGVudENvbnRyb2wudXBkYXRlVmFsdWVBbmRWYWxpZGl0eSh7IGVtaXRFdmVudDogZmFsc2UgfSk7XG4gIH1cblxuICBnZVZhbGlkYXRpb25zRm9yQ29uZGl0aW9uKGRlcGVuZGVuY3lGbjogQ29udHJvbERlcGVuZGVuY3kpOiBWYWxpZGF0b3JGbltdIHtcbiAgICBjb25zdCBkZXBlbmRlbmN5RnVuY3Rpb25zOiBWYWxpZGF0b3JGbltdID0gW107XG4gICAgaWYgKGRlcGVuZGVuY3lGbiAmJiBkZXBlbmRlbmN5Rm4uY29uZGl0aW9ucykge1xuICAgICAgZGVwZW5kZW5jeUZuLmNvbmRpdGlvbnMuZm9yRWFjaChjb25kaXRpb25GdW5jdGlvbiA9PiB7XG4gICAgICAgIGRlcGVuZGVuY3lGdW5jdGlvbnMucHVzaChcbiAgICAgICAgICB0aGlzLmZvcm1WYWxpZGF0aW9uU2VydmljZS5nZXRWYWxpZGF0b3JGb3JGdW5jdGlvbihjb25kaXRpb25GdW5jdGlvbilcbiAgICAgICAgKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gZGVwZW5kZW5jeUZ1bmN0aW9ucztcbiAgfVxufVxuIl19