import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { UserIdService } from '@spartacus/core';
import { map, switchMap, take } from 'rxjs/operators';
import { FileConnector } from '../../connectors/file.connector';
import * as fromAction from '../../store/actions';
import * as uploadSelector from '../../store/selectors/upload.selector';
import { saveAs } from 'file-saver';
import { OboCustomerService } from '../../../core/services/obo-customer/obo-customer.service';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/core";
import * as i2 from "../../connectors/file.connector";
import * as i3 from "@ngrx/store";
import * as i4 from "../../../core/services/obo-customer/obo-customer.service";
export class FileService {
    constructor(userIdService, fileConnector, store, oboCustomerService) {
        this.userIdService = userIdService;
        this.fileConnector = fileConnector;
        this.store = store;
        this.oboCustomerService = oboCustomerService;
    }
    getFile(fileCode, fileType) {
        return this.userIdService.getUserId().pipe(take(1), switchMap(occUserId => {
            return this.fileConnector.getFile(occUserId, fileCode, fileType);
        }));
    }
    getFiles(fileCodes) {
        return this.userIdService.getUserId().pipe(take(1), switchMap(occUserId => {
            return this.fileConnector.getFiles(occUserId, fileCodes);
        }));
    }
    uploadFile(file) {
        return this.oboCustomerService
            .getOboCustomerUserId()
            .pipe(switchMap(userId => this.fileConnector.uploadFile(userId, file)));
    }
    resetFiles() {
        this.store.dispatch(new fromAction.ResetFileSuccess({}));
    }
    setFileInStore(body) {
        this.store.dispatch(new fromAction.UploadFileSuccess({
            body,
        }));
    }
    getUploadedDocuments() {
        return this.store.select(uploadSelector.getUploadFiles);
    }
    removeFileForCode(userId, fileCode) {
        this.store.dispatch(new fromAction.RemoveFile({
            user: userId,
            fileCode: fileCode,
        }));
    }
    removeAllFiles(userId, fileList) {
        if (fileList?.length > 0) {
            fileList.forEach(file => {
                const fileCode = file?.code;
                if (fileCode) {
                    this.removeFileForCode(userId, fileCode);
                }
            });
        }
    }
    getDocument(document) {
        return this.getFile(document.code, document.mime).pipe(map(downloadedFile => {
            saveAs(downloadedFile, document.altText);
        }));
    }
}
FileService.ɵfac = function FileService_Factory(t) { return new (t || FileService)(i0.ɵɵinject(i1.UserIdService), i0.ɵɵinject(i2.FileConnector), i0.ɵɵinject(i3.Store), i0.ɵɵinject(i4.OboCustomerService)); };
FileService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FileService, factory: FileService.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FileService, [{
        type: Injectable
    }], function () { return [{ type: i1.UserIdService }, { type: i2.FileConnector }, { type: i3.Store }, { type: i4.OboCustomerService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb3JlL3NlcnZpY2VzL2ZpbGUvZmlsZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLGFBQWEsQ0FBQztBQUNwQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFFaEQsT0FBTyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDdEQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLGlDQUFpQyxDQUFDO0FBQ2hFLE9BQU8sS0FBSyxVQUFVLE1BQU0scUJBQXFCLENBQUM7QUFDbEQsT0FBTyxLQUFLLGNBQWMsTUFBTSx1Q0FBdUMsQ0FBQztBQUV4RSxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQ3BDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDBEQUEwRCxDQUFDOzs7Ozs7QUFHOUYsTUFBTSxPQUFPLFdBQVc7SUFDdEIsWUFDWSxhQUE0QixFQUM1QixhQUE0QixFQUM1QixLQUEyQixFQUMzQixrQkFBc0M7UUFIdEMsa0JBQWEsR0FBYixhQUFhLENBQWU7UUFDNUIsa0JBQWEsR0FBYixhQUFhLENBQWU7UUFDNUIsVUFBSyxHQUFMLEtBQUssQ0FBc0I7UUFDM0IsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUFvQjtJQUMvQyxDQUFDO0lBRUosT0FBTyxDQUFDLFFBQWdCLEVBQUUsUUFBZ0I7UUFDeEMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FDeEMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUNQLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNwQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDbkUsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUNKLENBQUM7SUFFRCxRQUFRLENBQUMsU0FBeUI7UUFDaEMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FDeEMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUNQLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNwQixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUMzRCxDQUFDLENBQUMsQ0FDSCxDQUFDO0lBQ0osQ0FBQztJQUVELFVBQVUsQ0FBQyxJQUFVO1FBQ25CLE9BQU8sSUFBSSxDQUFDLGtCQUFrQjthQUMzQixvQkFBb0IsRUFBRTthQUN0QixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRUQsVUFBVTtRQUNSLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksVUFBVSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVELGNBQWMsQ0FBQyxJQUFTO1FBQ3RCLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUNqQixJQUFJLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQztZQUMvQixJQUFJO1NBQ0wsQ0FBQyxDQUNILENBQUM7SUFDSixDQUFDO0lBRUQsb0JBQW9CO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxNQUFjLEVBQUUsUUFBZ0I7UUFDaEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQ2pCLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FBQztZQUN4QixJQUFJLEVBQUUsTUFBTTtZQUNaLFFBQVEsRUFBRSxRQUFRO1NBQ25CLENBQUMsQ0FDSCxDQUFDO0lBQ0osQ0FBQztJQUVELGNBQWMsQ0FBQyxNQUFNLEVBQUUsUUFBUTtRQUM3QixJQUFJLFFBQVEsRUFBRSxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3hCLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3RCLE1BQU0sUUFBUSxHQUFHLElBQUksRUFBRSxJQUFJLENBQUM7Z0JBQzVCLElBQUksUUFBUSxFQUFFO29CQUNaLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7aUJBQzFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7U0FDSjtJQUNILENBQUM7SUFFRCxXQUFXLENBQUMsUUFBUTtRQUNsQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUNwRCxHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUU7WUFDbkIsTUFBTSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUNKLENBQUM7O3NFQTFFVSxXQUFXO2lFQUFYLFdBQVcsV0FBWCxXQUFXO3VGQUFYLFdBQVc7Y0FEdkIsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFN0b3JlIH0gZnJvbSAnQG5ncngvc3RvcmUnO1xuaW1wb3J0IHsgVXNlcklkU2VydmljZSB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBtYXAsIHN3aXRjaE1hcCwgdGFrZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEZpbGVDb25uZWN0b3IgfSBmcm9tICcuLi8uLi9jb25uZWN0b3JzL2ZpbGUuY29ubmVjdG9yJztcbmltcG9ydCAqIGFzIGZyb21BY3Rpb24gZnJvbSAnLi4vLi4vc3RvcmUvYWN0aW9ucyc7XG5pbXBvcnQgKiBhcyB1cGxvYWRTZWxlY3RvciBmcm9tICcuLi8uLi9zdG9yZS9zZWxlY3RvcnMvdXBsb2FkLnNlbGVjdG9yJztcbmltcG9ydCB7IFN0YXRlV2l0aEZvcm0gfSBmcm9tICcuLi8uLi9zdG9yZS9zdGF0ZSc7XG5pbXBvcnQgeyBzYXZlQXMgfSBmcm9tICdmaWxlLXNhdmVyJztcbmltcG9ydCB7IE9ib0N1c3RvbWVyU2VydmljZSB9IGZyb20gJy4uLy4uLy4uL2NvcmUvc2VydmljZXMvb2JvLWN1c3RvbWVyL29iby1jdXN0b21lci5zZXJ2aWNlJztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIEZpbGVTZXJ2aWNlIHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJvdGVjdGVkIHVzZXJJZFNlcnZpY2U6IFVzZXJJZFNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIGZpbGVDb25uZWN0b3I6IEZpbGVDb25uZWN0b3IsXG4gICAgcHJvdGVjdGVkIHN0b3JlOiBTdG9yZTxTdGF0ZVdpdGhGb3JtPixcbiAgICBwcm90ZWN0ZWQgb2JvQ3VzdG9tZXJTZXJ2aWNlOiBPYm9DdXN0b21lclNlcnZpY2VcbiAgKSB7fVxuXG4gIGdldEZpbGUoZmlsZUNvZGU6IHN0cmluZywgZmlsZVR5cGU6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuIHRoaXMudXNlcklkU2VydmljZS5nZXRVc2VySWQoKS5waXBlKFxuICAgICAgdGFrZSgxKSxcbiAgICAgIHN3aXRjaE1hcChvY2NVc2VySWQgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5maWxlQ29ubmVjdG9yLmdldEZpbGUob2NjVXNlcklkLCBmaWxlQ29kZSwgZmlsZVR5cGUpO1xuICAgICAgfSlcbiAgICApO1xuICB9XG5cbiAgZ2V0RmlsZXMoZmlsZUNvZGVzPzogQXJyYXk8c3RyaW5nPik6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuIHRoaXMudXNlcklkU2VydmljZS5nZXRVc2VySWQoKS5waXBlKFxuICAgICAgdGFrZSgxKSxcbiAgICAgIHN3aXRjaE1hcChvY2NVc2VySWQgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5maWxlQ29ubmVjdG9yLmdldEZpbGVzKG9jY1VzZXJJZCwgZmlsZUNvZGVzKTtcbiAgICAgIH0pXG4gICAgKTtcbiAgfVxuXG4gIHVwbG9hZEZpbGUoZmlsZTogRmlsZSk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuIHRoaXMub2JvQ3VzdG9tZXJTZXJ2aWNlXG4gICAgICAuZ2V0T2JvQ3VzdG9tZXJVc2VySWQoKVxuICAgICAgLnBpcGUoc3dpdGNoTWFwKHVzZXJJZCA9PiB0aGlzLmZpbGVDb25uZWN0b3IudXBsb2FkRmlsZSh1c2VySWQsIGZpbGUpKSk7XG4gIH1cblxuICByZXNldEZpbGVzKCk6IHZvaWQge1xuICAgIHRoaXMuc3RvcmUuZGlzcGF0Y2gobmV3IGZyb21BY3Rpb24uUmVzZXRGaWxlU3VjY2Vzcyh7fSkpO1xuICB9XG5cbiAgc2V0RmlsZUluU3RvcmUoYm9keTogYW55KSB7XG4gICAgdGhpcy5zdG9yZS5kaXNwYXRjaChcbiAgICAgIG5ldyBmcm9tQWN0aW9uLlVwbG9hZEZpbGVTdWNjZXNzKHtcbiAgICAgICAgYm9keSxcbiAgICAgIH0pXG4gICAgKTtcbiAgfVxuXG4gIGdldFVwbG9hZGVkRG9jdW1lbnRzKCk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuIHRoaXMuc3RvcmUuc2VsZWN0KHVwbG9hZFNlbGVjdG9yLmdldFVwbG9hZEZpbGVzKTtcbiAgfVxuXG4gIHJlbW92ZUZpbGVGb3JDb2RlKHVzZXJJZDogc3RyaW5nLCBmaWxlQ29kZTogc3RyaW5nKSB7XG4gICAgdGhpcy5zdG9yZS5kaXNwYXRjaChcbiAgICAgIG5ldyBmcm9tQWN0aW9uLlJlbW92ZUZpbGUoe1xuICAgICAgICB1c2VyOiB1c2VySWQsXG4gICAgICAgIGZpbGVDb2RlOiBmaWxlQ29kZSxcbiAgICAgIH0pXG4gICAgKTtcbiAgfVxuXG4gIHJlbW92ZUFsbEZpbGVzKHVzZXJJZCwgZmlsZUxpc3QpIHtcbiAgICBpZiAoZmlsZUxpc3Q/Lmxlbmd0aCA+IDApIHtcbiAgICAgIGZpbGVMaXN0LmZvckVhY2goZmlsZSA9PiB7XG4gICAgICAgIGNvbnN0IGZpbGVDb2RlID0gZmlsZT8uY29kZTtcbiAgICAgICAgaWYgKGZpbGVDb2RlKSB7XG4gICAgICAgICAgdGhpcy5yZW1vdmVGaWxlRm9yQ29kZSh1c2VySWQsIGZpbGVDb2RlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgZ2V0RG9jdW1lbnQoZG9jdW1lbnQpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRGaWxlKGRvY3VtZW50LmNvZGUsIGRvY3VtZW50Lm1pbWUpLnBpcGUoXG4gICAgICBtYXAoZG93bmxvYWRlZEZpbGUgPT4ge1xuICAgICAgICBzYXZlQXMoZG93bmxvYWRlZEZpbGUsIGRvY3VtZW50LmFsdFRleHQpO1xuICAgICAgfSlcbiAgICApO1xuICB9XG59XG4iXX0=