import { Injectable } from '@angular/core';
import { EventService, LogoutEvent, UserIdService } from '@spartacus/core';
import { combineLatest, of, Subscription } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/core";
export class OboCustomerService {
    constructor(eventService, userIdService) {
        this.eventService = eventService;
        this.userIdService = userIdService;
        this.sessionStorageKey = 'selectedOboCustomerId';
        this.subscription = new Subscription();
        this.onLogout();
    }
    setSelectedCustomer(user) {
        sessionStorage.setItem(this.sessionStorageKey, user.uid);
    }
    getOboCustomerUserId() {
        return combineLatest([
            of(sessionStorage.getItem(this.sessionStorageKey)),
            this.userIdService.getUserId(),
        ]).pipe(map(([selectedCustomer, userOccId]) => selectedCustomer ? selectedCustomer : userOccId));
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    onLogout() {
        this.subscription.add(this.eventService
            .get(LogoutEvent)
            .pipe(tap(() => sessionStorage.removeItem(this.sessionStorageKey)))
            .subscribe());
    }
}
OboCustomerService.ɵfac = function OboCustomerService_Factory(t) { return new (t || OboCustomerService)(i0.ɵɵinject(i1.EventService), i0.ɵɵinject(i1.UserIdService)); };
OboCustomerService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: OboCustomerService, factory: OboCustomerService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OboCustomerService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], function () { return [{ type: i1.EventService }, { type: i1.UserIdService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib2JvLWN1c3RvbWVyLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvc2VydmljZXMvb2JvLWN1c3RvbWVyL29iby1jdXN0b21lci5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQWEsTUFBTSxlQUFlLENBQUM7QUFDdEQsT0FBTyxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDM0UsT0FBTyxFQUFFLGFBQWEsRUFBYyxFQUFFLEVBQUUsWUFBWSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ25FLE9BQU8sRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7OztBQUcxQyxNQUFNLE9BQU8sa0JBQWtCO0lBSTdCLFlBQ1ksWUFBMEIsRUFDMUIsYUFBNEI7UUFENUIsaUJBQVksR0FBWixZQUFZLENBQWM7UUFDMUIsa0JBQWEsR0FBYixhQUFhLENBQWU7UUFMaEMsc0JBQWlCLEdBQUcsdUJBQXVCLENBQUM7UUFDNUMsaUJBQVksR0FBaUIsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQU10RCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbEIsQ0FBQztJQUVELG1CQUFtQixDQUFDLElBQVM7UUFDM0IsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCxvQkFBb0I7UUFDbEIsT0FBTyxhQUFhLENBQUM7WUFDbkIsRUFBRSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDbEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUU7U0FDL0IsQ0FBQyxDQUFDLElBQUksQ0FDTCxHQUFHLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsQ0FBQyxFQUFFLEVBQUUsQ0FDcEMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxTQUFTLENBQ2hELENBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRCxXQUFXO1FBQ1QsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3JCLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDakM7SUFDSCxDQUFDO0lBRU8sUUFBUTtRQUNkLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUNuQixJQUFJLENBQUMsWUFBWTthQUNkLEdBQUcsQ0FBQyxXQUFXLENBQUM7YUFDaEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7YUFDbEUsU0FBUyxFQUFFLENBQ2YsQ0FBQztJQUNKLENBQUM7O29GQXZDVSxrQkFBa0I7d0VBQWxCLGtCQUFrQixXQUFsQixrQkFBa0IsbUJBREwsTUFBTTt1RkFDbkIsa0JBQWtCO2NBRDlCLFVBQVU7ZUFBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBPbkRlc3Ryb3kgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEV2ZW50U2VydmljZSwgTG9nb3V0RXZlbnQsIFVzZXJJZFNlcnZpY2UgfSBmcm9tICdAc3BhcnRhY3VzL2NvcmUnO1xuaW1wb3J0IHsgY29tYmluZUxhdGVzdCwgT2JzZXJ2YWJsZSwgb2YsIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgbWFwLCB0YXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgT2JvQ3VzdG9tZXJTZXJ2aWNlIGltcGxlbWVudHMgT25EZXN0cm95IHtcbiAgcHJpdmF0ZSBzZXNzaW9uU3RvcmFnZUtleSA9ICdzZWxlY3RlZE9ib0N1c3RvbWVySWQnO1xuICBwcml2YXRlIHN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uID0gbmV3IFN1YnNjcmlwdGlvbigpO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByb3RlY3RlZCBldmVudFNlcnZpY2U6IEV2ZW50U2VydmljZSxcbiAgICBwcm90ZWN0ZWQgdXNlcklkU2VydmljZTogVXNlcklkU2VydmljZVxuICApIHtcbiAgICB0aGlzLm9uTG9nb3V0KCk7XG4gIH1cblxuICBzZXRTZWxlY3RlZEN1c3RvbWVyKHVzZXI6IGFueSkge1xuICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0odGhpcy5zZXNzaW9uU3RvcmFnZUtleSwgdXNlci51aWQpO1xuICB9XG5cbiAgZ2V0T2JvQ3VzdG9tZXJVc2VySWQoKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcbiAgICByZXR1cm4gY29tYmluZUxhdGVzdChbXG4gICAgICBvZihzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKHRoaXMuc2Vzc2lvblN0b3JhZ2VLZXkpKSxcbiAgICAgIHRoaXMudXNlcklkU2VydmljZS5nZXRVc2VySWQoKSxcbiAgICBdKS5waXBlKFxuICAgICAgbWFwKChbc2VsZWN0ZWRDdXN0b21lciwgdXNlck9jY0lkXSkgPT5cbiAgICAgICAgc2VsZWN0ZWRDdXN0b21lciA/IHNlbGVjdGVkQ3VzdG9tZXIgOiB1c2VyT2NjSWRcbiAgICAgIClcbiAgICApO1xuICB9XG5cbiAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuc3Vic2NyaXB0aW9uKSB7XG4gICAgICB0aGlzLnN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgb25Mb2dvdXQoKSB7XG4gICAgdGhpcy5zdWJzY3JpcHRpb24uYWRkKFxuICAgICAgdGhpcy5ldmVudFNlcnZpY2VcbiAgICAgICAgLmdldChMb2dvdXRFdmVudClcbiAgICAgICAgLnBpcGUodGFwKCgpID0+IHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5zZXNzaW9uU3RvcmFnZUtleSkpKVxuICAgICAgICAuc3Vic2NyaWJlKClcbiAgICApO1xuICB9XG59XG4iXX0=