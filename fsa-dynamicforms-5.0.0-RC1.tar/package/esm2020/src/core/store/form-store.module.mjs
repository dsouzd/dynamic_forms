import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StateModule } from '@spartacus/core';
import { FormPersistenceService } from '../services/form-persistance.service';
import { effects } from './effects/index';
import { metaReducers, reducerProvider, reducerToken } from './reducers/index';
import { FORM_FEATURE } from './state';
import * as i0 from "@angular/core";
import * as i1 from "@ngrx/store";
import * as i2 from "@ngrx/effects";
export function formStatePersistenceFactory(formStatePersistenceService) {
    const result = () => formStatePersistenceService.initSync();
    return result;
}
export class FormStoreModule {
}
FormStoreModule.ɵfac = function FormStoreModule_Factory(t) { return new (t || FormStoreModule)(); };
FormStoreModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: FormStoreModule });
FormStoreModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        reducerProvider,
        {
            provide: APP_INITIALIZER,
            useFactory: formStatePersistenceFactory,
            deps: [FormPersistenceService],
            multi: true,
        },
    ], imports: [CommonModule,
        HttpClientModule,
        StateModule,
        StoreModule.forFeature(FORM_FEATURE, reducerToken, {
            metaReducers,
        }),
        EffectsModule.forFeature(effects)] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormStoreModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule,
                    HttpClientModule,
                    StateModule,
                    StoreModule.forFeature(FORM_FEATURE, reducerToken, {
                        metaReducers,
                    }),
                    EffectsModule.forFeature(effects),
                ],
                providers: [
                    reducerProvider,
                    {
                        provide: APP_INITIALIZER,
                        useFactory: formStatePersistenceFactory,
                        deps: [FormPersistenceService],
                        multi: true,
                    },
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(FormStoreModule, { imports: [CommonModule,
        HttpClientModule,
        StateModule, i1.StoreFeatureModule, i2.EffectsFeatureModule] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1zdG9yZS5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvc3RvcmUvZm9ybS1zdG9yZS5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxlQUFlLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDOUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGFBQWEsQ0FBQztBQUMxQyxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDOUMsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFDOUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLFlBQVksRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBQy9FLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxTQUFTLENBQUM7Ozs7QUFFdkMsTUFBTSxVQUFVLDJCQUEyQixDQUN6QywyQkFBbUQ7SUFFbkQsTUFBTSxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUMsMkJBQTJCLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDNUQsT0FBTyxNQUFNLENBQUM7QUFDaEIsQ0FBQztBQXNCRCxNQUFNLE9BQU8sZUFBZTs7OEVBQWYsZUFBZTtpRUFBZixlQUFlO3NFQVZmO1FBQ1QsZUFBZTtRQUNmO1lBQ0UsT0FBTyxFQUFFLGVBQWU7WUFDeEIsVUFBVSxFQUFFLDJCQUEyQjtZQUN2QyxJQUFJLEVBQUUsQ0FBQyxzQkFBc0IsQ0FBQztZQUM5QixLQUFLLEVBQUUsSUFBSTtTQUNaO0tBQ0YsWUFoQkMsWUFBWTtRQUNaLGdCQUFnQjtRQUNoQixXQUFXO1FBQ1gsV0FBVyxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsWUFBWSxFQUFFO1lBQ2pELFlBQVk7U0FDYixDQUFDO1FBQ0YsYUFBYSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7dUZBWXhCLGVBQWU7Y0FwQjNCLFFBQVE7ZUFBQztnQkFDUixPQUFPLEVBQUU7b0JBQ1AsWUFBWTtvQkFDWixnQkFBZ0I7b0JBQ2hCLFdBQVc7b0JBQ1gsV0FBVyxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsWUFBWSxFQUFFO3dCQUNqRCxZQUFZO3FCQUNiLENBQUM7b0JBQ0YsYUFBYSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7aUJBQ2xDO2dCQUNELFNBQVMsRUFBRTtvQkFDVCxlQUFlO29CQUNmO3dCQUNFLE9BQU8sRUFBRSxlQUFlO3dCQUN4QixVQUFVLEVBQUUsMkJBQTJCO3dCQUN2QyxJQUFJLEVBQUUsQ0FBQyxzQkFBc0IsQ0FBQzt3QkFDOUIsS0FBSyxFQUFFLElBQUk7cUJBQ1o7aUJBQ0Y7YUFDRjs7d0ZBQ1ksZUFBZSxjQWxCeEIsWUFBWTtRQUNaLGdCQUFnQjtRQUNoQixXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IEh0dHBDbGllbnRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBBUFBfSU5JVElBTElaRVIsIE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBFZmZlY3RzTW9kdWxlIH0gZnJvbSAnQG5ncngvZWZmZWN0cyc7XG5pbXBvcnQgeyBTdG9yZU1vZHVsZSB9IGZyb20gJ0BuZ3J4L3N0b3JlJztcbmltcG9ydCB7IFN0YXRlTW9kdWxlIH0gZnJvbSAnQHNwYXJ0YWN1cy9jb3JlJztcbmltcG9ydCB7IEZvcm1QZXJzaXN0ZW5jZVNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9mb3JtLXBlcnNpc3RhbmNlLnNlcnZpY2UnO1xuaW1wb3J0IHsgZWZmZWN0cyB9IGZyb20gJy4vZWZmZWN0cy9pbmRleCc7XG5pbXBvcnQgeyBtZXRhUmVkdWNlcnMsIHJlZHVjZXJQcm92aWRlciwgcmVkdWNlclRva2VuIH0gZnJvbSAnLi9yZWR1Y2Vycy9pbmRleCc7XG5pbXBvcnQgeyBGT1JNX0ZFQVRVUkUgfSBmcm9tICcuL3N0YXRlJztcblxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1TdGF0ZVBlcnNpc3RlbmNlRmFjdG9yeShcbiAgZm9ybVN0YXRlUGVyc2lzdGVuY2VTZXJ2aWNlOiBGb3JtUGVyc2lzdGVuY2VTZXJ2aWNlXG4pOiAoKSA9PiB2b2lkIHtcbiAgY29uc3QgcmVzdWx0ID0gKCkgPT4gZm9ybVN0YXRlUGVyc2lzdGVuY2VTZXJ2aWNlLmluaXRTeW5jKCk7XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtcbiAgICBDb21tb25Nb2R1bGUsXG4gICAgSHR0cENsaWVudE1vZHVsZSxcbiAgICBTdGF0ZU1vZHVsZSxcbiAgICBTdG9yZU1vZHVsZS5mb3JGZWF0dXJlKEZPUk1fRkVBVFVSRSwgcmVkdWNlclRva2VuLCB7XG4gICAgICBtZXRhUmVkdWNlcnMsXG4gICAgfSksXG4gICAgRWZmZWN0c01vZHVsZS5mb3JGZWF0dXJlKGVmZmVjdHMpLFxuICBdLFxuICBwcm92aWRlcnM6IFtcbiAgICByZWR1Y2VyUHJvdmlkZXIsXG4gICAge1xuICAgICAgcHJvdmlkZTogQVBQX0lOSVRJQUxJWkVSLFxuICAgICAgdXNlRmFjdG9yeTogZm9ybVN0YXRlUGVyc2lzdGVuY2VGYWN0b3J5LFxuICAgICAgZGVwczogW0Zvcm1QZXJzaXN0ZW5jZVNlcnZpY2VdLFxuICAgICAgbXVsdGk6IHRydWUsXG4gICAgfSxcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgRm9ybVN0b3JlTW9kdWxlIHt9XG4iXX0=