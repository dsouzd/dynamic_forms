import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import * as fromActions from '../actions';
import { FileConnector } from '../../connectors/file.connector';
import * as i0 from "@angular/core";
import * as i1 from "@ngrx/effects";
import * as i2 from "../../connectors/file.connector";
export class FilesEffect {
    constructor(actions$, fileConnector) {
        this.actions$ = actions$;
        this.fileConnector = fileConnector;
        this.removeFile$ = createEffect(() => this.actions$.pipe(ofType(fromActions.REMOVE_FILE), map((action) => action.payload), mergeMap(payload => {
            return this.fileConnector
                .removeFile(payload.user, payload.fileCode)
                .pipe(map(() => {
                return new fromActions.RemoveFileSuccess(payload.fileCode);
            }), catchError(error => {
                return of(new fromActions.RemoveFileFail(JSON.stringify(error)));
            }));
        })));
    }
}
FilesEffect.ɵfac = function FilesEffect_Factory(t) { return new (t || FilesEffect)(i0.ɵɵinject(i1.Actions), i0.ɵɵinject(i2.FileConnector)); };
FilesEffect.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FilesEffect, factory: FilesEffect.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FilesEffect, [{
        type: Injectable
    }], function () { return [{ type: i1.Actions }, { type: i2.FileConnector }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS5lZmZlY3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvc3RvcmUvZWZmZWN0cy9maWxlLmVmZmVjdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUM5RCxPQUFPLEVBQWMsRUFBRSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ3RDLE9BQU8sRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzNELE9BQU8sS0FBSyxXQUFXLE1BQU0sWUFBWSxDQUFDO0FBQzFDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQzs7OztBQUdoRSxNQUFNLE9BQU8sV0FBVztJQW9CdEIsWUFDVSxRQUFpQixFQUNqQixhQUE0QjtRQUQ1QixhQUFRLEdBQVIsUUFBUSxDQUFTO1FBQ2pCLGtCQUFhLEdBQWIsYUFBYSxDQUFlO1FBckJ0QyxnQkFBVyxHQUFvQixZQUFZLENBQUMsR0FBRyxFQUFFLENBQy9DLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUNoQixNQUFNLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxFQUMvQixHQUFHLENBQUMsQ0FBQyxNQUE4QixFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQ3ZELFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNqQixPQUFPLElBQUksQ0FBQyxhQUFhO2lCQUN0QixVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsUUFBUSxDQUFDO2lCQUMxQyxJQUFJLENBQ0gsR0FBRyxDQUFDLEdBQUcsRUFBRTtnQkFDUCxPQUFPLElBQUksV0FBVyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUM3RCxDQUFDLENBQUMsRUFDRixVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2pCLE9BQU8sRUFBRSxDQUFDLElBQUksV0FBVyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuRSxDQUFDLENBQUMsQ0FDSCxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQ0gsQ0FDRixDQUFDO0lBS0MsQ0FBQzs7c0VBdkJPLFdBQVc7aUVBQVgsV0FBVyxXQUFYLFdBQVc7dUZBQVgsV0FBVztjQUR2QixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWN0aW9ucywgY3JlYXRlRWZmZWN0LCBvZlR5cGUgfSBmcm9tICdAbmdyeC9lZmZlY3RzJztcbmltcG9ydCB7IE9ic2VydmFibGUsIG9mIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBtYXAsIG1lcmdlTWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0ICogYXMgZnJvbUFjdGlvbnMgZnJvbSAnLi4vYWN0aW9ucyc7XG5pbXBvcnQgeyBGaWxlQ29ubmVjdG9yIH0gZnJvbSAnLi4vLi4vY29ubmVjdG9ycy9maWxlLmNvbm5lY3Rvcic7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBGaWxlc0VmZmVjdCB7XG4gIHJlbW92ZUZpbGUkOiBPYnNlcnZhYmxlPGFueT4gPSBjcmVhdGVFZmZlY3QoKCkgPT5cbiAgICB0aGlzLmFjdGlvbnMkLnBpcGUoXG4gICAgICBvZlR5cGUoZnJvbUFjdGlvbnMuUkVNT1ZFX0ZJTEUpLFxuICAgICAgbWFwKChhY3Rpb246IGZyb21BY3Rpb25zLlJlbW92ZUZpbGUpID0+IGFjdGlvbi5wYXlsb2FkKSxcbiAgICAgIG1lcmdlTWFwKHBheWxvYWQgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5maWxlQ29ubmVjdG9yXG4gICAgICAgICAgLnJlbW92ZUZpbGUocGF5bG9hZC51c2VyLCBwYXlsb2FkLmZpbGVDb2RlKVxuICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgbWFwKCgpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIG5ldyBmcm9tQWN0aW9ucy5SZW1vdmVGaWxlU3VjY2VzcyhwYXlsb2FkLmZpbGVDb2RlKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBvZihuZXcgZnJvbUFjdGlvbnMuUmVtb3ZlRmlsZUZhaWwoSlNPTi5zdHJpbmdpZnkoZXJyb3IpKSk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICk7XG4gICAgICB9KVxuICAgIClcbiAgKTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGFjdGlvbnMkOiBBY3Rpb25zLFxuICAgIHByaXZhdGUgZmlsZUNvbm5lY3RvcjogRmlsZUNvbm5lY3RvclxuICApIHt9XG59XG4iXX0=