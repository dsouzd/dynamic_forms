import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { GlobalMessageService, GlobalMessageType } from '@spartacus/core';
import { of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { FormConnector } from '../../connectors/form.connector';
import * as fromActions from '../actions';
import * as i0 from "@angular/core";
import * as i1 from "@ngrx/effects";
import * as i2 from "../../connectors/form.connector";
import * as i3 from "@spartacus/core";
export class FormDefinitionEffects {
    constructor(actions$, formConnector, globalMessageService) {
        this.actions$ = actions$;
        this.formConnector = formConnector;
        this.globalMessageService = globalMessageService;
        this.loadFormDefinition$ = createEffect(() => this.actions$.pipe(ofType(fromActions.LOAD_FORM_DEFINITION), map((action) => action.payload), mergeMap(payload => {
            if (payload.formDefinitionId) {
                return this.formConnector
                    .getFormDefinition(payload.applicationId, payload.formDefinitionId)
                    .pipe(map((formDefinition) => {
                    return new fromActions.LoadFormDefinitionSuccess(formDefinition);
                }), catchError(error => {
                    this.showGlobalMessage('dynamicforms.definitionLoadError');
                    return of(new fromActions.LoadFormDefinitionFail(JSON.stringify(error)));
                }));
            }
            return this.formConnector
                .getFormDefinitions(payload.categoryCode, payload.formDefinitionType)
                .pipe(map((definitions) => {
                return new fromActions.LoadFormDefinitionSuccess(definitions.formDefinitions[0]);
            }), catchError(error => {
                this.showGlobalMessage('dynamicforms.definitionLoadError');
                return of(new fromActions.LoadFormDefinitionFail(JSON.stringify(error)));
            }));
        })));
    }
    showGlobalMessage(text) {
        this.globalMessageService.add({ key: text }, GlobalMessageType.MSG_TYPE_ERROR);
    }
}
FormDefinitionEffects.ɵfac = function FormDefinitionEffects_Factory(t) { return new (t || FormDefinitionEffects)(i0.ɵɵinject(i1.Actions), i0.ɵɵinject(i2.FormConnector), i0.ɵɵinject(i3.GlobalMessageService)); };
FormDefinitionEffects.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormDefinitionEffects, factory: FormDefinitionEffects.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormDefinitionEffects, [{
        type: Injectable
    }], function () { return [{ type: i1.Actions }, { type: i2.FormConnector }, { type: i3.GlobalMessageService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1kZWZpbml0aW9uLmVmZmVjdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29yZS9zdG9yZS9lZmZlY3RzL2Zvcm0tZGVmaW5pdGlvbi5lZmZlY3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDOUQsT0FBTyxFQUFFLG9CQUFvQixFQUFFLGlCQUFpQixFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDMUUsT0FBTyxFQUFjLEVBQUUsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUN0QyxPQUFPLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxRQUFRLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUMzRCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0saUNBQWlDLENBQUM7QUFDaEUsT0FBTyxLQUFLLFdBQVcsTUFBTSxZQUFZLENBQUM7Ozs7O0FBRzFDLE1BQU0sT0FBTyxxQkFBcUI7SUFpRGhDLFlBQ1UsUUFBaUIsRUFDakIsYUFBNEIsRUFDNUIsb0JBQTBDO1FBRjFDLGFBQVEsR0FBUixRQUFRLENBQVM7UUFDakIsa0JBQWEsR0FBYixhQUFhLENBQWU7UUFDNUIseUJBQW9CLEdBQXBCLG9CQUFvQixDQUFzQjtRQW5EcEQsd0JBQW1CLEdBQW9CLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FDdkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQ2hCLE1BQU0sQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsRUFDeEMsR0FBRyxDQUFDLENBQUMsTUFBc0MsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUMvRCxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDakIsSUFBSSxPQUFPLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQzVCLE9BQU8sSUFBSSxDQUFDLGFBQWE7cUJBQ3RCLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLGdCQUFnQixDQUFDO3FCQUNsRSxJQUFJLENBQ0gsR0FBRyxDQUFDLENBQUMsY0FBbUIsRUFBRSxFQUFFO29CQUMxQixPQUFPLElBQUksV0FBVyxDQUFDLHlCQUF5QixDQUM5QyxjQUFjLENBQ2YsQ0FBQztnQkFDSixDQUFDLENBQUMsRUFDRixVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ2pCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO29CQUMzRCxPQUFPLEVBQUUsQ0FDUCxJQUFJLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQzlELENBQUM7Z0JBQ0osQ0FBQyxDQUFDLENBQ0gsQ0FBQzthQUNMO1lBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYTtpQkFDdEIsa0JBQWtCLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsa0JBQWtCLENBQUM7aUJBQ3BFLElBQUksQ0FDSCxHQUFHLENBQUMsQ0FBQyxXQUFnQixFQUFFLEVBQUU7Z0JBQ3ZCLE9BQU8sSUFBSSxXQUFXLENBQUMseUJBQXlCLENBQzlDLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQy9CLENBQUM7WUFDSixDQUFDLENBQUMsRUFDRixVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2pCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO2dCQUMzRCxPQUFPLEVBQUUsQ0FDUCxJQUFJLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQzlELENBQUM7WUFDSixDQUFDLENBQUMsQ0FDSCxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQ0gsQ0FDRixDQUFDO0lBYUMsQ0FBQztJQVhJLGlCQUFpQixDQUFDLElBQVk7UUFDcEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FDM0IsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQ2IsaUJBQWlCLENBQUMsY0FBYyxDQUNqQyxDQUFDO0lBQ0osQ0FBQzs7MEZBL0NVLHFCQUFxQjsyRUFBckIscUJBQXFCLFdBQXJCLHFCQUFxQjt1RkFBckIscUJBQXFCO2NBRGpDLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBY3Rpb25zLCBjcmVhdGVFZmZlY3QsIG9mVHlwZSB9IGZyb20gJ0BuZ3J4L2VmZmVjdHMnO1xuaW1wb3J0IHsgR2xvYmFsTWVzc2FnZVNlcnZpY2UsIEdsb2JhbE1lc3NhZ2VUeXBlIH0gZnJvbSAnQHNwYXJ0YWN1cy9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUsIG9mIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBtYXAsIG1lcmdlTWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgRm9ybUNvbm5lY3RvciB9IGZyb20gJy4uLy4uL2Nvbm5lY3RvcnMvZm9ybS5jb25uZWN0b3InO1xuaW1wb3J0ICogYXMgZnJvbUFjdGlvbnMgZnJvbSAnLi4vYWN0aW9ucyc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBGb3JtRGVmaW5pdGlvbkVmZmVjdHMge1xuICBsb2FkRm9ybURlZmluaXRpb24kOiBPYnNlcnZhYmxlPGFueT4gPSBjcmVhdGVFZmZlY3QoKCkgPT5cbiAgICB0aGlzLmFjdGlvbnMkLnBpcGUoXG4gICAgICBvZlR5cGUoZnJvbUFjdGlvbnMuTE9BRF9GT1JNX0RFRklOSVRJT04pLFxuICAgICAgbWFwKChhY3Rpb246IGZyb21BY3Rpb25zLkxvYWRGb3JtRGVmaW5pdGlvbikgPT4gYWN0aW9uLnBheWxvYWQpLFxuICAgICAgbWVyZ2VNYXAocGF5bG9hZCA9PiB7XG4gICAgICAgIGlmIChwYXlsb2FkLmZvcm1EZWZpbml0aW9uSWQpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5mb3JtQ29ubmVjdG9yXG4gICAgICAgICAgICAuZ2V0Rm9ybURlZmluaXRpb24ocGF5bG9hZC5hcHBsaWNhdGlvbklkLCBwYXlsb2FkLmZvcm1EZWZpbml0aW9uSWQpXG4gICAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgICAgbWFwKChmb3JtRGVmaW5pdGlvbjogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBmcm9tQWN0aW9ucy5Mb2FkRm9ybURlZmluaXRpb25TdWNjZXNzKFxuICAgICAgICAgICAgICAgICAgZm9ybURlZmluaXRpb25cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zaG93R2xvYmFsTWVzc2FnZSgnZHluYW1pY2Zvcm1zLmRlZmluaXRpb25Mb2FkRXJyb3InKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gb2YoXG4gICAgICAgICAgICAgICAgICBuZXcgZnJvbUFjdGlvbnMuTG9hZEZvcm1EZWZpbml0aW9uRmFpbChKU09OLnN0cmluZ2lmeShlcnJvcikpXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuZm9ybUNvbm5lY3RvclxuICAgICAgICAgIC5nZXRGb3JtRGVmaW5pdGlvbnMocGF5bG9hZC5jYXRlZ29yeUNvZGUsIHBheWxvYWQuZm9ybURlZmluaXRpb25UeXBlKVxuICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgbWFwKChkZWZpbml0aW9uczogYW55KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBuZXcgZnJvbUFjdGlvbnMuTG9hZEZvcm1EZWZpbml0aW9uU3VjY2VzcyhcbiAgICAgICAgICAgICAgICBkZWZpbml0aW9ucy5mb3JtRGVmaW5pdGlvbnNbMF1cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgY2F0Y2hFcnJvcihlcnJvciA9PiB7XG4gICAgICAgICAgICAgIHRoaXMuc2hvd0dsb2JhbE1lc3NhZ2UoJ2R5bmFtaWNmb3Jtcy5kZWZpbml0aW9uTG9hZEVycm9yJyk7XG4gICAgICAgICAgICAgIHJldHVybiBvZihcbiAgICAgICAgICAgICAgICBuZXcgZnJvbUFjdGlvbnMuTG9hZEZvcm1EZWZpbml0aW9uRmFpbChKU09OLnN0cmluZ2lmeShlcnJvcikpXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICk7XG4gICAgICB9KVxuICAgIClcbiAgKTtcblxuICBwcml2YXRlIHNob3dHbG9iYWxNZXNzYWdlKHRleHQ6IHN0cmluZykge1xuICAgIHRoaXMuZ2xvYmFsTWVzc2FnZVNlcnZpY2UuYWRkKFxuICAgICAgeyBrZXk6IHRleHQgfSxcbiAgICAgIEdsb2JhbE1lc3NhZ2VUeXBlLk1TR19UWVBFX0VSUk9SXG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgYWN0aW9ucyQ6IEFjdGlvbnMsXG4gICAgcHJpdmF0ZSBmb3JtQ29ubmVjdG9yOiBGb3JtQ29ubmVjdG9yLFxuICAgIHByaXZhdGUgZ2xvYmFsTWVzc2FnZVNlcnZpY2U6IEdsb2JhbE1lc3NhZ2VTZXJ2aWNlXG4gICkge31cbn1cbiJdfQ==