import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { AuthActions } from '@spartacus/core';
import { of } from 'rxjs';
import { catchError, map, mergeMap, tap } from 'rxjs/operators';
import { FormConnector } from '../../connectors/form.connector';
import { FormDataStorageService } from '../../services/storage/form-data-storage.service';
import * as fromActions from '../actions';
import * as i0 from "@angular/core";
import * as i1 from "../../services/storage/form-data-storage.service";
import * as i2 from "@ngrx/effects";
import * as i3 from "../../connectors/form.connector";
export class FormDataEffects {
    constructor(formDataStorageService, actions$, formConnector) {
        this.formDataStorageService = formDataStorageService;
        this.actions$ = actions$;
        this.formConnector = formConnector;
        this.loadFormData$ = createEffect(() => this.actions$.pipe(ofType(fromActions.LOAD_FORM_DATA), map((action) => action.payload), mergeMap(payload => {
            return this.formConnector
                .getFormData(payload.formDataId, payload.userId)
                .pipe(map((formData) => {
                return new fromActions.LoadFormDataSuccess(formData);
            }), catchError(error => {
                return of(new fromActions.LoadFormDataFail(JSON.stringify(error)));
            }));
        })));
        this.saveFormData$ = createEffect(() => this.actions$.pipe(ofType(fromActions.SAVE_FORM_DATA), map((action) => action.payload), mergeMap(payload => {
            return this.formConnector
                .saveFormData(payload.formData, payload.userId)
                .pipe(map((formData) => {
                return new fromActions.SaveFormDataSuccess(formData);
            }), catchError(error => {
                return of(new fromActions.SaveFormDataFail(JSON.stringify(error)));
            }));
        })));
        this.clearFormData$ = createEffect(() => this.actions$.pipe(ofType(AuthActions.LOGOUT), tap(_ => {
            sessionStorage.removeItem('quoteCodes');
            this.formDataStorageService.clearFormDataLocalStorage();
        })), { dispatch: false });
    }
}
FormDataEffects.ɵfac = function FormDataEffects_Factory(t) { return new (t || FormDataEffects)(i0.ɵɵinject(i1.FormDataStorageService), i0.ɵɵinject(i2.Actions), i0.ɵɵinject(i3.FormConnector)); };
FormDataEffects.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormDataEffects, factory: FormDataEffects.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormDataEffects, [{
        type: Injectable
    }], function () { return [{ type: i1.FormDataStorageService }, { type: i2.Actions }, { type: i3.FormConnector }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1kYXRhLmVmZmVjdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29yZS9zdG9yZS9lZmZlY3RzL2Zvcm0tZGF0YS5lZmZlY3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDOUQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzlDLE9BQU8sRUFBYyxFQUFFLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDdEMsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQztBQUNoRSxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSxrREFBa0QsQ0FBQztBQUMxRixPQUFPLEtBQUssV0FBVyxNQUFNLFlBQVksQ0FBQzs7Ozs7QUFHMUMsTUFBTSxPQUFPLGVBQWU7SUF1RDFCLFlBQ1Usc0JBQThDLEVBQzlDLFFBQWlCLEVBQ2pCLGFBQTRCO1FBRjVCLDJCQUFzQixHQUF0QixzQkFBc0IsQ0FBd0I7UUFDOUMsYUFBUSxHQUFSLFFBQVEsQ0FBUztRQUNqQixrQkFBYSxHQUFiLGFBQWEsQ0FBZTtRQXpEdEMsa0JBQWEsR0FBb0IsWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUNqRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FDaEIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsRUFDbEMsR0FBRyxDQUFDLENBQUMsTUFBZ0MsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUN6RCxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDakIsT0FBTyxJQUFJLENBQUMsYUFBYTtpQkFDdEIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQztpQkFDL0MsSUFBSSxDQUNILEdBQUcsQ0FBQyxDQUFDLFFBQWEsRUFBRSxFQUFFO2dCQUNwQixPQUFPLElBQUksV0FBVyxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3ZELENBQUMsQ0FBQyxFQUNGLFVBQVUsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDakIsT0FBTyxFQUFFLENBQ1AsSUFBSSxXQUFXLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUN4RCxDQUFDO1lBQ0osQ0FBQyxDQUFDLENBQ0gsQ0FBQztRQUNOLENBQUMsQ0FBQyxDQUNILENBQ0YsQ0FBQztRQUVGLGtCQUFhLEdBQW9CLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FDakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQ2hCLE1BQU0sQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLEVBQ2xDLEdBQUcsQ0FBQyxDQUFDLE1BQWdDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFDekQsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2pCLE9BQU8sSUFBSSxDQUFDLGFBQWE7aUJBQ3RCLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUM7aUJBQzlDLElBQUksQ0FDSCxHQUFHLENBQUMsQ0FBQyxRQUFhLEVBQUUsRUFBRTtnQkFDcEIsT0FBTyxJQUFJLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN2RCxDQUFDLENBQUMsRUFDRixVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2pCLE9BQU8sRUFBRSxDQUNQLElBQUksV0FBVyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FDeEQsQ0FBQztZQUNKLENBQUMsQ0FBQyxDQUNILENBQUM7UUFDTixDQUFDLENBQUMsQ0FDSCxDQUNGLENBQUM7UUFFRixtQkFBYyxHQUFHLFlBQVksQ0FDM0IsR0FBRyxFQUFFLENBQ0gsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQ2hCLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQzFCLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNOLGNBQWMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDeEMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHlCQUF5QixFQUFFLENBQUM7UUFDMUQsQ0FBQyxDQUFDLENBQ0gsRUFDSCxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsQ0FDcEIsQ0FBQztJQU1DLENBQUM7OzhFQTNETyxlQUFlO3FFQUFmLGVBQWUsV0FBZixlQUFlO3VGQUFmLGVBQWU7Y0FEM0IsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGlvbnMsIGNyZWF0ZUVmZmVjdCwgb2ZUeXBlIH0gZnJvbSAnQG5ncngvZWZmZWN0cyc7XG5pbXBvcnQgeyBBdXRoQWN0aW9ucyB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBvZiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgY2F0Y2hFcnJvciwgbWFwLCBtZXJnZU1hcCwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgRm9ybUNvbm5lY3RvciB9IGZyb20gJy4uLy4uL2Nvbm5lY3RvcnMvZm9ybS5jb25uZWN0b3InO1xuaW1wb3J0IHsgRm9ybURhdGFTdG9yYWdlU2VydmljZSB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL3N0b3JhZ2UvZm9ybS1kYXRhLXN0b3JhZ2Uuc2VydmljZSc7XG5pbXBvcnQgKiBhcyBmcm9tQWN0aW9ucyBmcm9tICcuLi9hY3Rpb25zJztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIEZvcm1EYXRhRWZmZWN0cyB7XG4gIGxvYWRGb3JtRGF0YSQ6IE9ic2VydmFibGU8YW55PiA9IGNyZWF0ZUVmZmVjdCgoKSA9PlxuICAgIHRoaXMuYWN0aW9ucyQucGlwZShcbiAgICAgIG9mVHlwZShmcm9tQWN0aW9ucy5MT0FEX0ZPUk1fREFUQSksXG4gICAgICBtYXAoKGFjdGlvbjogZnJvbUFjdGlvbnMuTG9hZEZvcm1EYXRhKSA9PiBhY3Rpb24ucGF5bG9hZCksXG4gICAgICBtZXJnZU1hcChwYXlsb2FkID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZm9ybUNvbm5lY3RvclxuICAgICAgICAgIC5nZXRGb3JtRGF0YShwYXlsb2FkLmZvcm1EYXRhSWQsIHBheWxvYWQudXNlcklkKVxuICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgbWFwKChmb3JtRGF0YTogYW55KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBuZXcgZnJvbUFjdGlvbnMuTG9hZEZvcm1EYXRhU3VjY2Vzcyhmb3JtRGF0YSk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIGNhdGNoRXJyb3IoZXJyb3IgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gb2YoXG4gICAgICAgICAgICAgICAgbmV3IGZyb21BY3Rpb25zLkxvYWRGb3JtRGF0YUZhaWwoSlNPTi5zdHJpbmdpZnkoZXJyb3IpKVxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICApO1xuICAgICAgfSlcbiAgICApXG4gICk7XG5cbiAgc2F2ZUZvcm1EYXRhJDogT2JzZXJ2YWJsZTxhbnk+ID0gY3JlYXRlRWZmZWN0KCgpID0+XG4gICAgdGhpcy5hY3Rpb25zJC5waXBlKFxuICAgICAgb2ZUeXBlKGZyb21BY3Rpb25zLlNBVkVfRk9STV9EQVRBKSxcbiAgICAgIG1hcCgoYWN0aW9uOiBmcm9tQWN0aW9ucy5TYXZlRm9ybURhdGEpID0+IGFjdGlvbi5wYXlsb2FkKSxcbiAgICAgIG1lcmdlTWFwKHBheWxvYWQgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5mb3JtQ29ubmVjdG9yXG4gICAgICAgICAgLnNhdmVGb3JtRGF0YShwYXlsb2FkLmZvcm1EYXRhLCBwYXlsb2FkLnVzZXJJZClcbiAgICAgICAgICAucGlwZShcbiAgICAgICAgICAgIG1hcCgoZm9ybURhdGE6IGFueSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IGZyb21BY3Rpb25zLlNhdmVGb3JtRGF0YVN1Y2Nlc3MoZm9ybURhdGEpO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBjYXRjaEVycm9yKGVycm9yID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIG9mKFxuICAgICAgICAgICAgICAgIG5ldyBmcm9tQWN0aW9ucy5TYXZlRm9ybURhdGFGYWlsKEpTT04uc3RyaW5naWZ5KGVycm9yKSlcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgKTtcbiAgICAgIH0pXG4gICAgKVxuICApO1xuXG4gIGNsZWFyRm9ybURhdGEkID0gY3JlYXRlRWZmZWN0KFxuICAgICgpID0+XG4gICAgICB0aGlzLmFjdGlvbnMkLnBpcGUoXG4gICAgICAgIG9mVHlwZShBdXRoQWN0aW9ucy5MT0dPVVQpLFxuICAgICAgICB0YXAoXyA9PiB7XG4gICAgICAgICAgc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbSgncXVvdGVDb2RlcycpO1xuICAgICAgICAgIHRoaXMuZm9ybURhdGFTdG9yYWdlU2VydmljZS5jbGVhckZvcm1EYXRhTG9jYWxTdG9yYWdlKCk7XG4gICAgICAgIH0pXG4gICAgICApLFxuICAgIHsgZGlzcGF0Y2g6IGZhbHNlIH1cbiAgKTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGZvcm1EYXRhU3RvcmFnZVNlcnZpY2U6IEZvcm1EYXRhU3RvcmFnZVNlcnZpY2UsXG4gICAgcHJpdmF0ZSBhY3Rpb25zJDogQWN0aW9ucyxcbiAgICBwcml2YXRlIGZvcm1Db25uZWN0b3I6IEZvcm1Db25uZWN0b3JcbiAgKSB7fVxufVxuIl19