import { Injectable } from '@angular/core';
import { FormAdapter } from './form.adapter';
import * as i0 from "@angular/core";
import * as i1 from "./form.adapter";
export class FormConnector {
    constructor(formAdapter) {
        this.formAdapter = formAdapter;
    }
    getFormDefinition(applicationId, formDefinitionId) {
        return this.formAdapter.getFormDefinition(applicationId, formDefinitionId);
    }
    getFormDefinitions(categoryCode, formDefinitionType) {
        return this.formAdapter.getFormDefinitions(categoryCode, formDefinitionType);
    }
    getFormData(formDataId, userId) {
        return this.formAdapter.getFormData(formDataId, userId);
    }
    saveFormData(formData, userId) {
        return this.formAdapter.saveFormData(formData, userId);
    }
}
FormConnector.ɵfac = function FormConnector_Factory(t) { return new (t || FormConnector)(i0.ɵɵinject(i1.FormAdapter)); };
FormConnector.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormConnector, factory: FormConnector.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormConnector, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: i1.FormAdapter }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS5jb25uZWN0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvY29ubmVjdG9ycy9mb3JtLmNvbm5lY3Rvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRzNDLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7O0FBSzdDLE1BQU0sT0FBTyxhQUFhO0lBQ3hCLFlBQXNCLFdBQXdCO1FBQXhCLGdCQUFXLEdBQVgsV0FBVyxDQUFhO0lBQUcsQ0FBQztJQUVsRCxpQkFBaUIsQ0FDZixhQUFhLEVBQ2IsZ0JBQWdCO1FBRWhCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBQ0Qsa0JBQWtCLENBQ2hCLFlBQW9CLEVBQ3BCLGtCQUEwQjtRQUUxQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQ3hDLFlBQVksRUFDWixrQkFBa0IsQ0FDbkIsQ0FBQztJQUNKLENBQUM7SUFDRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxNQUFjO1FBQzVDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFRCxZQUFZLENBQUMsUUFBbUIsRUFBRSxNQUFjO1FBQzlDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3pELENBQUM7OzBFQXhCVSxhQUFhO21FQUFiLGFBQWEsV0FBYixhQUFhLG1CQUZaLE1BQU07dUZBRVAsYUFBYTtjQUh6QixVQUFVO2VBQUM7Z0JBQ1YsVUFBVSxFQUFFLE1BQU07YUFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBZRm9ybURhdGEsIFlGb3JtRGVmaW5pdGlvbiB9IGZyb20gJy4uL21vZGVscyc7XG5pbXBvcnQgeyBGb3JtQWRhcHRlciB9IGZyb20gJy4vZm9ybS5hZGFwdGVyJztcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIEZvcm1Db25uZWN0b3Ige1xuICBjb25zdHJ1Y3Rvcihwcm90ZWN0ZWQgZm9ybUFkYXB0ZXI6IEZvcm1BZGFwdGVyKSB7fVxuXG4gIGdldEZvcm1EZWZpbml0aW9uKFxuICAgIGFwcGxpY2F0aW9uSWQsXG4gICAgZm9ybURlZmluaXRpb25JZFxuICApOiBPYnNlcnZhYmxlPFlGb3JtRGVmaW5pdGlvbj4ge1xuICAgIHJldHVybiB0aGlzLmZvcm1BZGFwdGVyLmdldEZvcm1EZWZpbml0aW9uKGFwcGxpY2F0aW9uSWQsIGZvcm1EZWZpbml0aW9uSWQpO1xuICB9XG4gIGdldEZvcm1EZWZpbml0aW9ucyhcbiAgICBjYXRlZ29yeUNvZGU6IHN0cmluZyxcbiAgICBmb3JtRGVmaW5pdGlvblR5cGU6IHN0cmluZ1xuICApOiBPYnNlcnZhYmxlPFlGb3JtRGVmaW5pdGlvbj4ge1xuICAgIHJldHVybiB0aGlzLmZvcm1BZGFwdGVyLmdldEZvcm1EZWZpbml0aW9ucyhcbiAgICAgIGNhdGVnb3J5Q29kZSxcbiAgICAgIGZvcm1EZWZpbml0aW9uVHlwZVxuICAgICk7XG4gIH1cbiAgZ2V0Rm9ybURhdGEoZm9ybURhdGFJZDogc3RyaW5nLCB1c2VySWQ6IHN0cmluZyk6IE9ic2VydmFibGU8WUZvcm1EYXRhPiB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybUFkYXB0ZXIuZ2V0Rm9ybURhdGEoZm9ybURhdGFJZCwgdXNlcklkKTtcbiAgfVxuXG4gIHNhdmVGb3JtRGF0YShmb3JtRGF0YTogWUZvcm1EYXRhLCB1c2VySWQ6IHN0cmluZyk6IE9ic2VydmFibGU8WUZvcm1EYXRhPiB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybUFkYXB0ZXIuc2F2ZUZvcm1EYXRhKGZvcm1EYXRhLCB1c2VySWQpO1xuICB9XG59XG4iXX0=