import { Injectable } from '@angular/core';
import { FileAdapter } from './file.adapter';
import * as i0 from "@angular/core";
import * as i1 from "./file.adapter";
export class FileConnector {
    constructor(uploadAdapter) {
        this.uploadAdapter = uploadAdapter;
    }
    getFile(userId, fileCode, fileType) {
        return this.uploadAdapter.getFileForCodeAndType(userId, fileCode, fileType);
    }
    getFiles(userId, fileCode) {
        return this.uploadAdapter.getFilesForUser(userId, fileCode);
    }
    uploadFile(userId, file) {
        return this.uploadAdapter.uploadFile(userId, file);
    }
    removeFile(userId, fileCode) {
        return this.uploadAdapter.removeFileForUserAndCode(userId, fileCode);
    }
}
FileConnector.ɵfac = function FileConnector_Factory(t) { return new (t || FileConnector)(i0.ɵɵinject(i1.FileAdapter)); };
FileConnector.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FileConnector, factory: FileConnector.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FileConnector, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: i1.FileAdapter }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS5jb25uZWN0b3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvY29ubmVjdG9ycy9maWxlLmNvbm5lY3Rvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7O0FBSzdDLE1BQU0sT0FBTyxhQUFhO0lBQ3hCLFlBQXNCLGFBQTBCO1FBQTFCLGtCQUFhLEdBQWIsYUFBYSxDQUFhO0lBQUcsQ0FBQztJQUVwRCxPQUFPLENBQUMsTUFBYyxFQUFFLFFBQWdCLEVBQUUsUUFBZ0I7UUFDeEQsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDOUUsQ0FBQztJQUVELFFBQVEsQ0FBQyxNQUFjLEVBQUUsUUFBd0I7UUFDL0MsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVELFVBQVUsQ0FBQyxNQUFjLEVBQUUsSUFBVTtRQUNuQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRUQsVUFBVSxDQUFDLE1BQWMsRUFBRSxRQUFnQjtRQUN6QyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsd0JBQXdCLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3ZFLENBQUM7OzBFQWpCVSxhQUFhO21FQUFiLGFBQWEsV0FBYixhQUFhLG1CQUZaLE1BQU07dUZBRVAsYUFBYTtjQUh6QixVQUFVO2VBQUM7Z0JBQ1YsVUFBVSxFQUFFLE1BQU07YUFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBGaWxlQWRhcHRlciB9IGZyb20gJy4vZmlsZS5hZGFwdGVyJztcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIEZpbGVDb25uZWN0b3Ige1xuICBjb25zdHJ1Y3Rvcihwcm90ZWN0ZWQgdXBsb2FkQWRhcHRlcjogRmlsZUFkYXB0ZXIpIHt9XG5cbiAgZ2V0RmlsZSh1c2VySWQ6IHN0cmluZywgZmlsZUNvZGU6IHN0cmluZywgZmlsZVR5cGU6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuIHRoaXMudXBsb2FkQWRhcHRlci5nZXRGaWxlRm9yQ29kZUFuZFR5cGUodXNlcklkLCBmaWxlQ29kZSwgZmlsZVR5cGUpO1xuICB9XG5cbiAgZ2V0RmlsZXModXNlcklkOiBzdHJpbmcsIGZpbGVDb2RlPzogQXJyYXk8c3RyaW5nPik6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuIHRoaXMudXBsb2FkQWRhcHRlci5nZXRGaWxlc0ZvclVzZXIodXNlcklkLCBmaWxlQ29kZSk7XG4gIH1cblxuICB1cGxvYWRGaWxlKHVzZXJJZDogc3RyaW5nLCBmaWxlOiBGaWxlKTogT2JzZXJ2YWJsZTxhbnk+IHtcbiAgICByZXR1cm4gdGhpcy51cGxvYWRBZGFwdGVyLnVwbG9hZEZpbGUodXNlcklkLCBmaWxlKTtcbiAgfVxuXG4gIHJlbW92ZUZpbGUodXNlcklkOiBzdHJpbmcsIGZpbGVDb2RlOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybiB0aGlzLnVwbG9hZEFkYXB0ZXIucmVtb3ZlRmlsZUZvclVzZXJBbmRDb2RlKHVzZXJJZCwgZmlsZUNvZGUpO1xuICB9XG59XG4iXX0=