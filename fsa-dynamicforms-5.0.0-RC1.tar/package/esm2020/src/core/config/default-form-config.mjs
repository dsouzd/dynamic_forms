import { ButtonComponent } from '../../components/button/button.component';
import { DatePickerComponent } from '../../components/datepicker/datepicker.component';
import { InputComponent } from '../../components/input/input.component';
import { RadioComponent } from '../../components/radio/radio.component';
import { SelectComponent } from '../../components/select/select.component';
import { TextAreaComponent } from '../../components/text-area/text-area.component';
import { TimeComponent } from '../../components/time/time.component';
import { TitleComponent } from '../../components/title/title.component';
import { DefaultFormValidators } from './../../util/validators/default-form-validators';
import { SeparatorComponent } from '../../components/separator/separator.component';
import { CheckboxComponent } from '../../components/checkbox/checkbox.component';
import { UserPrefillResolver } from '../resolvers/user-prefill-resolver';
import { DataHolderComponent } from '../../components/data-holder/data-holder.component';
import { UploadComponent } from '../../components/upload/upload.component';
import { CurrentDatePrefillResolver } from '../resolvers/current-date-prefill-resolver';
import { UserAddressPrefillResolver } from '../resolvers/user-address-prefill-resolver';
import { CurrencyComponent } from '../../components/currency/currency.component';
export const defaultFormConfig = {
    dynamicForms: {
        components: {
            button: {
                component: ButtonComponent,
            },
            input: {
                component: InputComponent,
            },
            select: {
                component: SelectComponent,
            },
            title: {
                component: TitleComponent,
            },
            datepicker: {
                component: DatePickerComponent,
            },
            radio: {
                component: RadioComponent,
            },
            textarea: {
                component: TextAreaComponent,
            },
            time: {
                component: TimeComponent,
            },
            checkbox: {
                component: CheckboxComponent,
            },
            separator: {
                component: SeparatorComponent,
            },
            dataHolder: {
                component: DataHolderComponent,
            },
            upload: {
                component: UploadComponent,
            },
            currency: {
                component: CurrencyComponent,
            },
        },
        validators: {
            compareToCurrentDate: {
                validator: DefaultFormValidators.compareToCurrentDate,
            },
            dateOfBirth: {
                validator: DefaultFormValidators.dateOfBirthValidator,
            },
            compareDOBtoAge: {
                validator: DefaultFormValidators.compareDOBtoAge,
            },
            compareAgeToDOB: {
                validator: DefaultFormValidators.compareAgeToDOB,
            },
            maxValue: {
                validator: DefaultFormValidators.max,
            },
            minValue: {
                validator: DefaultFormValidators.min,
            },
            maxLength: {
                validator: DefaultFormValidators.maxLength,
            },
            minLength: {
                validator: DefaultFormValidators.minLength,
            },
            number: {
                validator: DefaultFormValidators.number,
            },
            compareDates: {
                validator: DefaultFormValidators.compareDates,
            },
            checkValue: {
                validator: DefaultFormValidators.checkValue,
            },
            checkEmptyValue: {
                validator: DefaultFormValidators.checkEmptyValue,
            },
            containsValue: {
                validator: DefaultFormValidators.shouldContainValue,
            },
            compareNumbers: {
                validator: DefaultFormValidators.compareNumbers,
            },
            email: {
                validator: DefaultFormValidators.email,
            },
            alphanumeric: {
                validator: DefaultFormValidators.alphanumeric,
            },
        },
        prefill: {
            address: {
                prefillResolver: UserAddressPrefillResolver,
            },
            user: {
                prefillResolver: UserPrefillResolver,
            },
            currentDate: {
                prefillResolver: CurrentDatePrefillResolver,
            },
        },
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVmYXVsdC1mb3JtLWNvbmZpZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29yZS9jb25maWcvZGVmYXVsdC1mb3JtLWNvbmZpZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sMENBQTBDLENBQUM7QUFDM0UsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sa0RBQWtELENBQUM7QUFDdkYsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHdDQUF3QyxDQUFDO0FBQ3hFLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSx3Q0FBd0MsQ0FBQztBQUN4RSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sMENBQTBDLENBQUM7QUFDM0UsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sZ0RBQWdELENBQUM7QUFDbkYsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHNDQUFzQyxDQUFDO0FBQ3JFLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSx3Q0FBd0MsQ0FBQztBQUN4RSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxpREFBaUQsQ0FBQztBQUV4RixPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxnREFBZ0QsQ0FBQztBQUNwRixPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw4Q0FBOEMsQ0FBQztBQUNqRixPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQUN6RSxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxvREFBb0QsQ0FBQztBQUN6RixPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sMENBQTBDLENBQUM7QUFDM0UsT0FBTyxFQUFFLDBCQUEwQixFQUFFLE1BQU0sNENBQTRDLENBQUM7QUFDeEYsT0FBTyxFQUFFLDBCQUEwQixFQUFFLE1BQU0sNENBQTRDLENBQUM7QUFDeEYsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sOENBQThDLENBQUM7QUFFakYsTUFBTSxDQUFDLE1BQU0saUJBQWlCLEdBQXVCO0lBQ25ELFlBQVksRUFBRTtRQUNaLFVBQVUsRUFBRTtZQUNWLE1BQU0sRUFBRTtnQkFDTixTQUFTLEVBQUUsZUFBZTthQUMzQjtZQUNELEtBQUssRUFBRTtnQkFDTCxTQUFTLEVBQUUsY0FBYzthQUMxQjtZQUNELE1BQU0sRUFBRTtnQkFDTixTQUFTLEVBQUUsZUFBZTthQUMzQjtZQUNELEtBQUssRUFBRTtnQkFDTCxTQUFTLEVBQUUsY0FBYzthQUMxQjtZQUNELFVBQVUsRUFBRTtnQkFDVixTQUFTLEVBQUUsbUJBQW1CO2FBQy9CO1lBQ0QsS0FBSyxFQUFFO2dCQUNMLFNBQVMsRUFBRSxjQUFjO2FBQzFCO1lBQ0QsUUFBUSxFQUFFO2dCQUNSLFNBQVMsRUFBRSxpQkFBaUI7YUFDN0I7WUFDRCxJQUFJLEVBQUU7Z0JBQ0osU0FBUyxFQUFFLGFBQWE7YUFDekI7WUFDRCxRQUFRLEVBQUU7Z0JBQ1IsU0FBUyxFQUFFLGlCQUFpQjthQUM3QjtZQUNELFNBQVMsRUFBRTtnQkFDVCxTQUFTLEVBQUUsa0JBQWtCO2FBQzlCO1lBQ0QsVUFBVSxFQUFFO2dCQUNWLFNBQVMsRUFBRSxtQkFBbUI7YUFDL0I7WUFDRCxNQUFNLEVBQUU7Z0JBQ04sU0FBUyxFQUFFLGVBQWU7YUFDM0I7WUFDRCxRQUFRLEVBQUU7Z0JBQ1IsU0FBUyxFQUFFLGlCQUFpQjthQUM3QjtTQUNGO1FBQ0QsVUFBVSxFQUFFO1lBQ1Ysb0JBQW9CLEVBQUU7Z0JBQ3BCLFNBQVMsRUFBRSxxQkFBcUIsQ0FBQyxvQkFBb0I7YUFDdEQ7WUFDRCxXQUFXLEVBQUU7Z0JBQ1gsU0FBUyxFQUFFLHFCQUFxQixDQUFDLG9CQUFvQjthQUN0RDtZQUNELGVBQWUsRUFBRTtnQkFDZixTQUFTLEVBQUUscUJBQXFCLENBQUMsZUFBZTthQUNqRDtZQUNELGVBQWUsRUFBRTtnQkFDZixTQUFTLEVBQUUscUJBQXFCLENBQUMsZUFBZTthQUNqRDtZQUNELFFBQVEsRUFBRTtnQkFDUixTQUFTLEVBQUUscUJBQXFCLENBQUMsR0FBRzthQUNyQztZQUNELFFBQVEsRUFBRTtnQkFDUixTQUFTLEVBQUUscUJBQXFCLENBQUMsR0FBRzthQUNyQztZQUNELFNBQVMsRUFBRTtnQkFDVCxTQUFTLEVBQUUscUJBQXFCLENBQUMsU0FBUzthQUMzQztZQUNELFNBQVMsRUFBRTtnQkFDVCxTQUFTLEVBQUUscUJBQXFCLENBQUMsU0FBUzthQUMzQztZQUNELE1BQU0sRUFBRTtnQkFDTixTQUFTLEVBQUUscUJBQXFCLENBQUMsTUFBTTthQUN4QztZQUNELFlBQVksRUFBRTtnQkFDWixTQUFTLEVBQUUscUJBQXFCLENBQUMsWUFBWTthQUM5QztZQUNELFVBQVUsRUFBRTtnQkFDVixTQUFTLEVBQUUscUJBQXFCLENBQUMsVUFBVTthQUM1QztZQUNELGVBQWUsRUFBRTtnQkFDZixTQUFTLEVBQUUscUJBQXFCLENBQUMsZUFBZTthQUNqRDtZQUNELGFBQWEsRUFBRTtnQkFDYixTQUFTLEVBQUUscUJBQXFCLENBQUMsa0JBQWtCO2FBQ3BEO1lBQ0QsY0FBYyxFQUFFO2dCQUNkLFNBQVMsRUFBRSxxQkFBcUIsQ0FBQyxjQUFjO2FBQ2hEO1lBQ0QsS0FBSyxFQUFFO2dCQUNMLFNBQVMsRUFBRSxxQkFBcUIsQ0FBQyxLQUFLO2FBQ3ZDO1lBQ0QsWUFBWSxFQUFFO2dCQUNaLFNBQVMsRUFBRSxxQkFBcUIsQ0FBQyxZQUFZO2FBQzlDO1NBQ0Y7UUFDRCxPQUFPLEVBQUU7WUFDUCxPQUFPLEVBQUU7Z0JBQ1AsZUFBZSxFQUFFLDBCQUEwQjthQUM1QztZQUNELElBQUksRUFBRTtnQkFDSixlQUFlLEVBQUUsbUJBQW1CO2FBQ3JDO1lBQ0QsV0FBVyxFQUFFO2dCQUNYLGVBQWUsRUFBRSwwQkFBMEI7YUFDNUM7U0FDRjtLQUNGO0NBQ0YsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvbkNvbXBvbmVudCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvYnV0dG9uL2J1dHRvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgRGF0ZVBpY2tlckNvbXBvbmVudCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvZGF0ZXBpY2tlci9kYXRlcGlja2VyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBJbnB1dENvbXBvbmVudCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvaW5wdXQvaW5wdXQuY29tcG9uZW50JztcbmltcG9ydCB7IFJhZGlvQ29tcG9uZW50IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9yYWRpby9yYWRpby5jb21wb25lbnQnO1xuaW1wb3J0IHsgU2VsZWN0Q29tcG9uZW50IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9zZWxlY3Qvc2VsZWN0LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBUZXh0QXJlYUNvbXBvbmVudCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdGV4dC1hcmVhL3RleHQtYXJlYS5jb21wb25lbnQnO1xuaW1wb3J0IHsgVGltZUNvbXBvbmVudCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdGltZS90aW1lLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBUaXRsZUNvbXBvbmVudCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvdGl0bGUvdGl0bGUuY29tcG9uZW50JztcbmltcG9ydCB7IERlZmF1bHRGb3JtVmFsaWRhdG9ycyB9IGZyb20gJy4vLi4vLi4vdXRpbC92YWxpZGF0b3JzL2RlZmF1bHQtZm9ybS12YWxpZGF0b3JzJztcbmltcG9ydCB7IER5bmFtaWNGb3Jtc0NvbmZpZyB9IGZyb20gJy4vZm9ybS1jb25maWcnO1xuaW1wb3J0IHsgU2VwYXJhdG9yQ29tcG9uZW50IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9zZXBhcmF0b3Ivc2VwYXJhdG9yLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDaGVja2JveENvbXBvbmVudCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvY2hlY2tib3gvY2hlY2tib3guY29tcG9uZW50JztcbmltcG9ydCB7IFVzZXJQcmVmaWxsUmVzb2x2ZXIgfSBmcm9tICcuLi9yZXNvbHZlcnMvdXNlci1wcmVmaWxsLXJlc29sdmVyJztcbmltcG9ydCB7IERhdGFIb2xkZXJDb21wb25lbnQgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL2RhdGEtaG9sZGVyL2RhdGEtaG9sZGVyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBVcGxvYWRDb21wb25lbnQgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL3VwbG9hZC91cGxvYWQuY29tcG9uZW50JztcbmltcG9ydCB7IEN1cnJlbnREYXRlUHJlZmlsbFJlc29sdmVyIH0gZnJvbSAnLi4vcmVzb2x2ZXJzL2N1cnJlbnQtZGF0ZS1wcmVmaWxsLXJlc29sdmVyJztcbmltcG9ydCB7IFVzZXJBZGRyZXNzUHJlZmlsbFJlc29sdmVyIH0gZnJvbSAnLi4vcmVzb2x2ZXJzL3VzZXItYWRkcmVzcy1wcmVmaWxsLXJlc29sdmVyJztcbmltcG9ydCB7IEN1cnJlbmN5Q29tcG9uZW50IH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9jdXJyZW5jeS9jdXJyZW5jeS5jb21wb25lbnQnO1xuXG5leHBvcnQgY29uc3QgZGVmYXVsdEZvcm1Db25maWc6IER5bmFtaWNGb3Jtc0NvbmZpZyA9IHtcbiAgZHluYW1pY0Zvcm1zOiB7XG4gICAgY29tcG9uZW50czoge1xuICAgICAgYnV0dG9uOiB7XG4gICAgICAgIGNvbXBvbmVudDogQnV0dG9uQ29tcG9uZW50LFxuICAgICAgfSxcbiAgICAgIGlucHV0OiB7XG4gICAgICAgIGNvbXBvbmVudDogSW5wdXRDb21wb25lbnQsXG4gICAgICB9LFxuICAgICAgc2VsZWN0OiB7XG4gICAgICAgIGNvbXBvbmVudDogU2VsZWN0Q29tcG9uZW50LFxuICAgICAgfSxcbiAgICAgIHRpdGxlOiB7XG4gICAgICAgIGNvbXBvbmVudDogVGl0bGVDb21wb25lbnQsXG4gICAgICB9LFxuICAgICAgZGF0ZXBpY2tlcjoge1xuICAgICAgICBjb21wb25lbnQ6IERhdGVQaWNrZXJDb21wb25lbnQsXG4gICAgICB9LFxuICAgICAgcmFkaW86IHtcbiAgICAgICAgY29tcG9uZW50OiBSYWRpb0NvbXBvbmVudCxcbiAgICAgIH0sXG4gICAgICB0ZXh0YXJlYToge1xuICAgICAgICBjb21wb25lbnQ6IFRleHRBcmVhQ29tcG9uZW50LFxuICAgICAgfSxcbiAgICAgIHRpbWU6IHtcbiAgICAgICAgY29tcG9uZW50OiBUaW1lQ29tcG9uZW50LFxuICAgICAgfSxcbiAgICAgIGNoZWNrYm94OiB7XG4gICAgICAgIGNvbXBvbmVudDogQ2hlY2tib3hDb21wb25lbnQsXG4gICAgICB9LFxuICAgICAgc2VwYXJhdG9yOiB7XG4gICAgICAgIGNvbXBvbmVudDogU2VwYXJhdG9yQ29tcG9uZW50LFxuICAgICAgfSxcbiAgICAgIGRhdGFIb2xkZXI6IHtcbiAgICAgICAgY29tcG9uZW50OiBEYXRhSG9sZGVyQ29tcG9uZW50LFxuICAgICAgfSxcbiAgICAgIHVwbG9hZDoge1xuICAgICAgICBjb21wb25lbnQ6IFVwbG9hZENvbXBvbmVudCxcbiAgICAgIH0sXG4gICAgICBjdXJyZW5jeToge1xuICAgICAgICBjb21wb25lbnQ6IEN1cnJlbmN5Q29tcG9uZW50LFxuICAgICAgfSxcbiAgICB9LFxuICAgIHZhbGlkYXRvcnM6IHtcbiAgICAgIGNvbXBhcmVUb0N1cnJlbnREYXRlOiB7XG4gICAgICAgIHZhbGlkYXRvcjogRGVmYXVsdEZvcm1WYWxpZGF0b3JzLmNvbXBhcmVUb0N1cnJlbnREYXRlLFxuICAgICAgfSxcbiAgICAgIGRhdGVPZkJpcnRoOiB7XG4gICAgICAgIHZhbGlkYXRvcjogRGVmYXVsdEZvcm1WYWxpZGF0b3JzLmRhdGVPZkJpcnRoVmFsaWRhdG9yLFxuICAgICAgfSxcbiAgICAgIGNvbXBhcmVET0J0b0FnZToge1xuICAgICAgICB2YWxpZGF0b3I6IERlZmF1bHRGb3JtVmFsaWRhdG9ycy5jb21wYXJlRE9CdG9BZ2UsXG4gICAgICB9LFxuICAgICAgY29tcGFyZUFnZVRvRE9COiB7XG4gICAgICAgIHZhbGlkYXRvcjogRGVmYXVsdEZvcm1WYWxpZGF0b3JzLmNvbXBhcmVBZ2VUb0RPQixcbiAgICAgIH0sXG4gICAgICBtYXhWYWx1ZToge1xuICAgICAgICB2YWxpZGF0b3I6IERlZmF1bHRGb3JtVmFsaWRhdG9ycy5tYXgsXG4gICAgICB9LFxuICAgICAgbWluVmFsdWU6IHtcbiAgICAgICAgdmFsaWRhdG9yOiBEZWZhdWx0Rm9ybVZhbGlkYXRvcnMubWluLFxuICAgICAgfSxcbiAgICAgIG1heExlbmd0aDoge1xuICAgICAgICB2YWxpZGF0b3I6IERlZmF1bHRGb3JtVmFsaWRhdG9ycy5tYXhMZW5ndGgsXG4gICAgICB9LFxuICAgICAgbWluTGVuZ3RoOiB7XG4gICAgICAgIHZhbGlkYXRvcjogRGVmYXVsdEZvcm1WYWxpZGF0b3JzLm1pbkxlbmd0aCxcbiAgICAgIH0sXG4gICAgICBudW1iZXI6IHtcbiAgICAgICAgdmFsaWRhdG9yOiBEZWZhdWx0Rm9ybVZhbGlkYXRvcnMubnVtYmVyLFxuICAgICAgfSxcbiAgICAgIGNvbXBhcmVEYXRlczoge1xuICAgICAgICB2YWxpZGF0b3I6IERlZmF1bHRGb3JtVmFsaWRhdG9ycy5jb21wYXJlRGF0ZXMsXG4gICAgICB9LFxuICAgICAgY2hlY2tWYWx1ZToge1xuICAgICAgICB2YWxpZGF0b3I6IERlZmF1bHRGb3JtVmFsaWRhdG9ycy5jaGVja1ZhbHVlLFxuICAgICAgfSxcbiAgICAgIGNoZWNrRW1wdHlWYWx1ZToge1xuICAgICAgICB2YWxpZGF0b3I6IERlZmF1bHRGb3JtVmFsaWRhdG9ycy5jaGVja0VtcHR5VmFsdWUsXG4gICAgICB9LFxuICAgICAgY29udGFpbnNWYWx1ZToge1xuICAgICAgICB2YWxpZGF0b3I6IERlZmF1bHRGb3JtVmFsaWRhdG9ycy5zaG91bGRDb250YWluVmFsdWUsXG4gICAgICB9LFxuICAgICAgY29tcGFyZU51bWJlcnM6IHtcbiAgICAgICAgdmFsaWRhdG9yOiBEZWZhdWx0Rm9ybVZhbGlkYXRvcnMuY29tcGFyZU51bWJlcnMsXG4gICAgICB9LFxuICAgICAgZW1haWw6IHtcbiAgICAgICAgdmFsaWRhdG9yOiBEZWZhdWx0Rm9ybVZhbGlkYXRvcnMuZW1haWwsXG4gICAgICB9LFxuICAgICAgYWxwaGFudW1lcmljOiB7XG4gICAgICAgIHZhbGlkYXRvcjogRGVmYXVsdEZvcm1WYWxpZGF0b3JzLmFscGhhbnVtZXJpYyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBwcmVmaWxsOiB7XG4gICAgICBhZGRyZXNzOiB7XG4gICAgICAgIHByZWZpbGxSZXNvbHZlcjogVXNlckFkZHJlc3NQcmVmaWxsUmVzb2x2ZXIsXG4gICAgICB9LFxuICAgICAgdXNlcjoge1xuICAgICAgICBwcmVmaWxsUmVzb2x2ZXI6IFVzZXJQcmVmaWxsUmVzb2x2ZXIsXG4gICAgICB9LFxuICAgICAgY3VycmVudERhdGU6IHtcbiAgICAgICAgcHJlZmlsbFJlc29sdmVyOiBDdXJyZW50RGF0ZVByZWZpbGxSZXNvbHZlcixcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn07XG4iXX0=