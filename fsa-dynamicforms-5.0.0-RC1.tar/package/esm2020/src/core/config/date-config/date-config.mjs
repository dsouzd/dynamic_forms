import { Injectable } from '@angular/core';
import { Config } from '@spartacus/core';
import * as i0 from "@angular/core";
export class FormDateConfig {
}
FormDateConfig.ɵfac = function FormDateConfig_Factory(t) { return new (t || FormDateConfig)(); };
FormDateConfig.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormDateConfig, factory: function FormDateConfig_Factory(t) { let r = null; if (t) {
        r = new (t || FormDateConfig)();
    }
    else {
        r = i0.ɵɵinject(Config);
    } return r; }, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormDateConfig, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
                useExisting: Config,
            }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZS1jb25maWcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvY29uZmlnL2RhdGUtY29uZmlnL2RhdGUtY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixDQUFDOztBQU16QyxNQUFNLE9BQWdCLGNBQWM7OzRFQUFkLGNBQWM7b0VBQWQsY0FBYztzQkFBZCxjQUFjOzs7d0JBRnJCLE1BQU07K0JBRFAsTUFBTTt1RkFHRSxjQUFjO2NBSm5DLFVBQVU7ZUFBQztnQkFDVixVQUFVLEVBQUUsTUFBTTtnQkFDbEIsV0FBVyxFQUFFLE1BQU07YUFDcEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb25maWcgfSBmcm9tICdAc3BhcnRhY3VzL2NvcmUnO1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290JyxcbiAgdXNlRXhpc3Rpbmc6IENvbmZpZyxcbn0pXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgRm9ybURhdGVDb25maWcge1xuICBkYXRlPzoge1xuICAgIGZvcm1hdD86IHN0cmluZztcbiAgfTtcbn1cbiJdfQ==