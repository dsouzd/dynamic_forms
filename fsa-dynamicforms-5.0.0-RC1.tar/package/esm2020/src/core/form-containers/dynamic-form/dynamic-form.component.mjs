import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, Output, } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { DynamicFormsConfig } from '../../config/form-config';
import { GeneralHelpers } from '../../helpers/helpers';
import { FormBuilderService } from '../../services/builder/form-builder.service';
import { FormDataService } from '../../services/data/form-data.service';
import { FormComponentService } from '../../../components/form-component.service';
import * as i0 from "@angular/core";
import * as i1 from "../../services/builder/form-builder.service";
import * as i2 from "../../services/data/form-data.service";
import * as i3 from "../../../components/form-component.service";
import * as i4 from "../../config/form-config";
import * as i5 from "@angular/common";
import * as i6 from "@angular/forms";
import * as i7 from "../../../components/form-component.directive";
function DynamicFormComponent_ng_container_0_ng_container_2_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0, 5);
} if (rf & 2) {
    const field_r4 = ctx.$implicit;
    const formGroup_r2 = i0.ɵɵnextContext().$implicit;
    const ctx_r3 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("config", field_r4)("group", formGroup_r2.groupCode ? ctx_r3.form.controls[formGroup_r2.groupCode] : ctx_r3.form);
} }
function DynamicFormComponent_ng_container_0_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 3);
    i0.ɵɵtemplate(2, DynamicFormComponent_ng_container_0_ng_container_2_ng_container_2_Template, 1, 2, "ng-container", 4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const formGroup_r2 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngClass", formGroup_r2.cssClass)("hidden", formGroup_r2.hidden);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngForOf", formGroup_r2.fieldConfigs);
} }
function DynamicFormComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "form", 1);
    i0.ɵɵtemplate(2, DynamicFormComponent_ng_container_0_ng_container_2_Template, 3, 3, "ng-container", 2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngClass", ctx_r0.config.cssClass)("formGroup", ctx_r0.form);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngForOf", ctx_r0.config.formGroups);
} }
export class DynamicFormComponent {
    constructor(changeDetectorRef, formService, formDataService, formComponentService, formConfig) {
        this.changeDetectorRef = changeDetectorRef;
        this.formService = formService;
        this.formDataService = formDataService;
        this.formComponentService = formComponentService;
        this.formConfig = formConfig;
        //eslint-disable-next-line
        this.submit = new EventEmitter();
        this.subscription = new Subscription();
    }
    get changes() {
        return this.form.valueChanges;
    }
    get valid() {
        return this.form.valid;
    }
    get value() {
        return this.form.value;
    }
    ngOnInit() {
        this.populatedInvalid$ = this.formComponentService.isPopulatedFormInvalid;
        this.subscription.add(this.populatedInvalid$
            .pipe(map((isInvalid) => {
            if (isInvalid) {
                this.subscription.add(this.formComponentService.launchFormPopupError());
            }
        }))
            .subscribe());
        if (this.config) {
            this.form = this.formService.createForm(this.config);
        }
        this.addSubmitEvent();
        if (this.formData) {
            this.subscription.add(this.formData
                .pipe(map(formData => {
                if (formData.content) {
                    this.mapDataToFormControls(JSON.parse(formData.content));
                }
            }))
                .subscribe());
        }
    }
    mapDataToFormControls(formData) {
        for (const groupCode of Object.keys(formData)) {
            if (this.form.get(groupCode) &&
                GeneralHelpers.getObjectDepth(formData[groupCode]) === 0) {
                this.form.get(groupCode).setValue(formData[groupCode]);
            }
            else {
                for (const controlName of Object.keys(formData[groupCode])) {
                    const formGroup = this.form.get(groupCode);
                    if (formGroup && formData[groupCode][controlName] !== ' ') {
                        if (formGroup.get(controlName)) {
                            formGroup
                                .get(controlName)
                                .setValue(formData[groupCode][controlName]);
                        }
                        else {
                            formGroup.setValue(formData[groupCode][controlName]);
                        }
                    }
                }
            }
        }
    }
    addSubmitEvent() {
        this.subscription.add(this.formDataService
            .getSubmittedForm()
            .pipe(map(form => {
            if (this.checkInvalidControls(form)) {
                this.formComponentService.isPopulatedFormInvalidSource.next(true);
                this.markInvalidControls(this.form);
                this.changeDetectorRef.detectChanges();
            }
            else if (form &&
                form.content === undefined &&
                this.form &&
                this.value !== undefined &&
                this.valid) {
                //eslint-disable-next-line
                this.submit.emit({
                    id: form.id,
                    refId: form.refId,
                    content: this.value,
                });
            }
        }))
            .subscribe());
    }
    markInvalidControls(formGroup) {
        for (const key of Object.keys(formGroup.controls)) {
            const formControl = formGroup.get(key);
            if (formControl instanceof UntypedFormGroup) {
                this.markInvalidControls(formControl);
            }
            else {
                const control = formControl;
                if (!control.valid) {
                    control.markAsTouched({ onlySelf: true });
                }
            }
        }
    }
    checkInvalidControls(formData) {
        return !!(formData && !this.valid);
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
DynamicFormComponent.ɵfac = function DynamicFormComponent_Factory(t) { return new (t || DynamicFormComponent)(i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i1.FormBuilderService), i0.ɵɵdirectiveInject(i2.FormDataService), i0.ɵɵdirectiveInject(i3.FormComponentService), i0.ɵɵdirectiveInject(i4.DynamicFormsConfig)); };
DynamicFormComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DynamicFormComponent, selectors: [["cx-dynamic-form"]], inputs: { formData: "formData", config: "config" }, outputs: { submit: "submit" }, exportAs: ["cx-dynamicForm"], decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "ngClass", "formGroup"], [4, "ngFor", "ngForOf"], [1, "row", 3, "ngClass", "hidden"], ["cxFormComponent", "", 3, "config", "group", 4, "ngFor", "ngForOf"], ["cxFormComponent", "", 3, "config", "group"]], template: function DynamicFormComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, DynamicFormComponent_ng_container_0_Template, 3, 3, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.form && ctx.config);
    } }, dependencies: [i5.NgClass, i5.NgForOf, i5.NgIf, i6.ɵNgNoValidate, i6.NgControlStatusGroup, i6.FormGroupDirective, i7.FormComponentDirective], encapsulation: 2, changeDetection: 0 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DynamicFormComponent, [{
        type: Component,
        args: [{ exportAs: 'cx-dynamicForm', selector: 'cx-dynamic-form', changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-container *ngIf=\"form && config\">\n  <form [ngClass]=\"config.cssClass\" [formGroup]=\"form\">\n    <ng-container *ngFor=\"let formGroup of config.formGroups\">\n      <div\n        class=\"row\"\n        [ngClass]=\"formGroup.cssClass\"\n        [hidden]=\"formGroup.hidden\"\n      >\n        <ng-container\n          *ngFor=\"let field of formGroup.fieldConfigs\"\n          cxFormComponent\n          [config]=\"field\"\n          [group]=\"\n            formGroup.groupCode ? form.controls[formGroup.groupCode] : form\n          \"\n        >\n        </ng-container>\n      </div>\n    </ng-container>\n  </form>\n</ng-container>\n" }]
    }], function () { return [{ type: i0.ChangeDetectorRef }, { type: i1.FormBuilderService }, { type: i2.FormDataService }, { type: i3.FormComponentService }, { type: i4.DynamicFormsConfig }]; }, { formData: [{
            type: Input
        }], config: [{
            type: Input
        }], 
    //eslint-disable-next-line
    submit: [{
            type: Output
        }] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1pYy1mb3JtLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29yZS9mb3JtLWNvbnRhaW5lcnMvZHluYW1pYy1mb3JtL2R5bmFtaWMtZm9ybS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvZm9ybS1jb250YWluZXJzL2R5bmFtaWMtZm9ybS9keW5hbWljLWZvcm0uY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNMLHVCQUF1QixFQUN2QixpQkFBaUIsRUFDakIsU0FBUyxFQUNULFlBQVksRUFDWixLQUFLLEVBR0wsTUFBTSxHQUNQLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBc0IsZ0JBQWdCLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUN0RSxPQUFPLEVBQUUsVUFBVSxFQUFFLFlBQVksRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUNoRCxPQUFPLEVBQUUsR0FBRyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDckMsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDOUQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBRXZELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDZDQUE2QyxDQUFDO0FBQ2pGLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSx1Q0FBdUMsQ0FBQztBQUV4RSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSw0Q0FBNEMsQ0FBQzs7Ozs7Ozs7OztJQ1gxRSwyQkFRZTs7Ozs7SUFMYixpQ0FBZ0IsOEZBQUE7OztJQVR0Qiw2QkFBMEQ7SUFDeEQsOEJBSUM7SUFDQyxxSEFRZTtJQUNqQixpQkFBTTtJQUNSLDBCQUFlOzs7SUFiWCxlQUE4QjtJQUE5QiwrQ0FBOEIsK0JBQUE7SUFJVixlQUF5QjtJQUF6QixtREFBeUI7OztJQVRyRCw2QkFBcUM7SUFDbkMsK0JBQXFEO0lBQ25ELHNHQWdCZTtJQUNqQixpQkFBTztJQUNULDBCQUFlOzs7SUFuQlAsZUFBMkI7SUFBM0IsZ0RBQTJCLDBCQUFBO0lBQ0ssZUFBb0I7SUFBcEIsa0RBQW9COztBRHlCNUQsTUFBTSxPQUFPLG9CQUFvQjtJQXVCL0IsWUFDWSxpQkFBb0MsRUFDcEMsV0FBK0IsRUFDL0IsZUFBZ0MsRUFDaEMsb0JBQTBDLEVBQzdDLFVBQThCO1FBSjNCLHNCQUFpQixHQUFqQixpQkFBaUIsQ0FBbUI7UUFDcEMsZ0JBQVcsR0FBWCxXQUFXLENBQW9CO1FBQy9CLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQUNoQyx5QkFBb0IsR0FBcEIsb0JBQW9CLENBQXNCO1FBQzdDLGVBQVUsR0FBVixVQUFVLENBQW9CO1FBdEJ2QywwQkFBMEI7UUFDMUIsV0FBTSxHQUFzQixJQUFJLFlBQVksRUFBTyxDQUFDO1FBSXBELGlCQUFZLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQWtCL0IsQ0FBQztJQWhCSixJQUFJLE9BQU87UUFDVCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQ2hDLENBQUM7SUFDRCxJQUFJLEtBQUs7UUFDUCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQ3pCLENBQUM7SUFDRCxJQUFJLEtBQUs7UUFDUCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQ3pCLENBQUM7SUFVRCxRQUFRO1FBQ04sSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxzQkFBc0IsQ0FBQztRQUMxRSxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FDbkIsSUFBSSxDQUFDLGlCQUFpQjthQUNuQixJQUFJLENBQ0gsR0FBRyxDQUFDLENBQUMsU0FBa0IsRUFBRSxFQUFFO1lBQ3pCLElBQUksU0FBUyxFQUFFO2dCQUNiLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUNuQixJQUFJLENBQUMsb0JBQW9CLENBQUMsb0JBQW9CLEVBQUUsQ0FDakQsQ0FBQzthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQ0g7YUFDQSxTQUFTLEVBQUUsQ0FDZixDQUFDO1FBRUYsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDdEQ7UUFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2pCLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUNuQixJQUFJLENBQUMsUUFBUTtpQkFDVixJQUFJLENBQ0gsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUNiLElBQUksUUFBUSxDQUFDLE9BQU8sRUFBRTtvQkFDcEIsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7aUJBQzFEO1lBQ0gsQ0FBQyxDQUFDLENBQ0g7aUJBQ0EsU0FBUyxFQUFFLENBQ2YsQ0FBQztTQUNIO0lBQ0gsQ0FBQztJQUVELHFCQUFxQixDQUFDLFFBQVE7UUFDNUIsS0FBSyxNQUFNLFNBQVMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzdDLElBQ0UsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO2dCQUN4QixjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFDeEQ7Z0JBQ0EsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO2FBQ3hEO2lCQUFNO2dCQUNMLEtBQUssTUFBTSxXQUFXLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRTtvQkFDMUQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQzNDLElBQUksU0FBUyxJQUFJLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLEVBQUU7d0JBQ3pELElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRTs0QkFDOUIsU0FBUztpQ0FDTixHQUFHLENBQUMsV0FBVyxDQUFDO2lDQUNoQixRQUFRLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7eUJBQy9DOzZCQUFNOzRCQUNMLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7eUJBQ3REO3FCQUNGO2lCQUNGO2FBQ0Y7U0FDRjtJQUNILENBQUM7SUFFRCxjQUFjO1FBQ1osSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQ25CLElBQUksQ0FBQyxlQUFlO2FBQ2pCLGdCQUFnQixFQUFFO2FBQ2xCLElBQUksQ0FDSCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDVCxJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDbkMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbEUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDcEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3hDO2lCQUFNLElBQ0wsSUFBSTtnQkFDSixJQUFJLENBQUMsT0FBTyxLQUFLLFNBQVM7Z0JBQzFCLElBQUksQ0FBQyxJQUFJO2dCQUNULElBQUksQ0FBQyxLQUFLLEtBQUssU0FBUztnQkFDeEIsSUFBSSxDQUFDLEtBQUssRUFDVjtnQkFDQSwwQkFBMEI7Z0JBQzFCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO29CQUNmLEVBQUUsRUFBRSxJQUFJLENBQUMsRUFBRTtvQkFDWCxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7b0JBQ2pCLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FBSztpQkFDcEIsQ0FBQyxDQUFDO2FBQ0o7UUFDSCxDQUFDLENBQUMsQ0FDSDthQUNBLFNBQVMsRUFBRSxDQUNmLENBQUM7SUFDSixDQUFDO0lBRUQsbUJBQW1CLENBQUMsU0FBMkI7UUFDN0MsS0FBSyxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNqRCxNQUFNLFdBQVcsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZDLElBQUksV0FBVyxZQUFZLGdCQUFnQixFQUFFO2dCQUMzQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDdkM7aUJBQU07Z0JBQ0wsTUFBTSxPQUFPLEdBQXVCLFdBQVcsQ0FBQztnQkFDaEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUU7b0JBQ2xCLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztpQkFDM0M7YUFDRjtTQUNGO0lBQ0gsQ0FBQztJQUVPLG9CQUFvQixDQUFDLFFBQW1CO1FBQzlDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxXQUFXO1FBQ1QsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3JCLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDakM7SUFDSCxDQUFDOzt3RkE5SVUsb0JBQW9CO3VFQUFwQixvQkFBb0I7UUMzQmpDLHVGQW9CZTs7UUFwQkEsNkNBQW9COzt1RkQyQnRCLG9CQUFvQjtjQU5oQyxTQUFTOzJCQUNFLGdCQUFnQixZQUNoQixpQkFBaUIsbUJBRVYsdUJBQXVCLENBQUMsTUFBTTt1TUFJL0MsUUFBUTtrQkFEUCxLQUFLO1lBR04sTUFBTTtrQkFETCxLQUFLOztJQUdOLDBCQUEwQjtJQUMxQixNQUFNO2tCQUZMLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gIENvbXBvbmVudCxcbiAgRXZlbnRFbWl0dGVyLFxuICBJbnB1dCxcbiAgT25EZXN0cm95LFxuICBPbkluaXQsXG4gIE91dHB1dCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBVbnR5cGVkRm9ybUNvbnRyb2wsIFVudHlwZWRGb3JtR3JvdXAgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IER5bmFtaWNGb3Jtc0NvbmZpZyB9IGZyb20gJy4uLy4uL2NvbmZpZy9mb3JtLWNvbmZpZyc7XG5pbXBvcnQgeyBHZW5lcmFsSGVscGVycyB9IGZyb20gJy4uLy4uL2hlbHBlcnMvaGVscGVycyc7XG5pbXBvcnQgeyBGb3JtRGVmaW5pdGlvbiB9IGZyb20gJy4uLy4uL21vZGVscy9mb3JtLWNvbmZpZy5pbnRlcmZhY2UnO1xuaW1wb3J0IHsgRm9ybUJ1aWxkZXJTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYnVpbGRlci9mb3JtLWJ1aWxkZXIuc2VydmljZSc7XG5pbXBvcnQgeyBGb3JtRGF0YVNlcnZpY2UgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9kYXRhL2Zvcm0tZGF0YS5zZXJ2aWNlJztcbmltcG9ydCB7IFlGb3JtRGF0YSB9IGZyb20gJy4vLi4vLi4vbW9kZWxzL2Zvcm0tb2NjLm1vZGVscyc7XG5pbXBvcnQgeyBGb3JtQ29tcG9uZW50U2VydmljZSB9IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvZm9ybS1jb21wb25lbnQuc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICBleHBvcnRBczogJ2N4LWR5bmFtaWNGb3JtJyxcbiAgc2VsZWN0b3I6ICdjeC1keW5hbWljLWZvcm0nLFxuICB0ZW1wbGF0ZVVybDogJy4vZHluYW1pYy1mb3JtLmNvbXBvbmVudC5odG1sJyxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIER5bmFtaWNGb3JtQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuICBASW5wdXQoKVxuICBmb3JtRGF0YTogT2JzZXJ2YWJsZTxZRm9ybURhdGE+O1xuICBASW5wdXQoKVxuICBjb25maWc6IEZvcm1EZWZpbml0aW9uO1xuICBAT3V0cHV0KClcbiAgLy9lc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgc3VibWl0OiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xuXG4gIHBvcHVsYXRlZEludmFsaWQkOiBPYnNlcnZhYmxlPGJvb2xlYW4+O1xuICBmb3JtOiBVbnR5cGVkRm9ybUdyb3VwO1xuICBzdWJzY3JpcHRpb24gPSBuZXcgU3Vic2NyaXB0aW9uKCk7XG5cbiAgZ2V0IGNoYW5nZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybS52YWx1ZUNoYW5nZXM7XG4gIH1cbiAgZ2V0IHZhbGlkKCkge1xuICAgIHJldHVybiB0aGlzLmZvcm0udmFsaWQ7XG4gIH1cbiAgZ2V0IHZhbHVlKCkge1xuICAgIHJldHVybiB0aGlzLmZvcm0udmFsdWU7XG4gIH1cblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcm90ZWN0ZWQgY2hhbmdlRGV0ZWN0b3JSZWY6IENoYW5nZURldGVjdG9yUmVmLFxuICAgIHByb3RlY3RlZCBmb3JtU2VydmljZTogRm9ybUJ1aWxkZXJTZXJ2aWNlLFxuICAgIHByb3RlY3RlZCBmb3JtRGF0YVNlcnZpY2U6IEZvcm1EYXRhU2VydmljZSxcbiAgICBwcm90ZWN0ZWQgZm9ybUNvbXBvbmVudFNlcnZpY2U6IEZvcm1Db21wb25lbnRTZXJ2aWNlLFxuICAgIHB1YmxpYyBmb3JtQ29uZmlnOiBEeW5hbWljRm9ybXNDb25maWdcbiAgKSB7fVxuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMucG9wdWxhdGVkSW52YWxpZCQgPSB0aGlzLmZvcm1Db21wb25lbnRTZXJ2aWNlLmlzUG9wdWxhdGVkRm9ybUludmFsaWQ7XG4gICAgdGhpcy5zdWJzY3JpcHRpb24uYWRkKFxuICAgICAgdGhpcy5wb3B1bGF0ZWRJbnZhbGlkJFxuICAgICAgICAucGlwZShcbiAgICAgICAgICBtYXAoKGlzSW52YWxpZDogQm9vbGVhbikgPT4ge1xuICAgICAgICAgICAgaWYgKGlzSW52YWxpZCkge1xuICAgICAgICAgICAgICB0aGlzLnN1YnNjcmlwdGlvbi5hZGQoXG4gICAgICAgICAgICAgICAgdGhpcy5mb3JtQ29tcG9uZW50U2VydmljZS5sYXVuY2hGb3JtUG9wdXBFcnJvcigpXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSlcbiAgICAgICAgKVxuICAgICAgICAuc3Vic2NyaWJlKClcbiAgICApO1xuXG4gICAgaWYgKHRoaXMuY29uZmlnKSB7XG4gICAgICB0aGlzLmZvcm0gPSB0aGlzLmZvcm1TZXJ2aWNlLmNyZWF0ZUZvcm0odGhpcy5jb25maWcpO1xuICAgIH1cbiAgICB0aGlzLmFkZFN1Ym1pdEV2ZW50KCk7XG4gICAgaWYgKHRoaXMuZm9ybURhdGEpIHtcbiAgICAgIHRoaXMuc3Vic2NyaXB0aW9uLmFkZChcbiAgICAgICAgdGhpcy5mb3JtRGF0YVxuICAgICAgICAgIC5waXBlKFxuICAgICAgICAgICAgbWFwKGZvcm1EYXRhID0+IHtcbiAgICAgICAgICAgICAgaWYgKGZvcm1EYXRhLmNvbnRlbnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm1hcERhdGFUb0Zvcm1Db250cm9scyhKU09OLnBhcnNlKGZvcm1EYXRhLmNvbnRlbnQpKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICApXG4gICAgICAgICAgLnN1YnNjcmliZSgpXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIG1hcERhdGFUb0Zvcm1Db250cm9scyhmb3JtRGF0YSkge1xuICAgIGZvciAoY29uc3QgZ3JvdXBDb2RlIG9mIE9iamVjdC5rZXlzKGZvcm1EYXRhKSkge1xuICAgICAgaWYgKFxuICAgICAgICB0aGlzLmZvcm0uZ2V0KGdyb3VwQ29kZSkgJiZcbiAgICAgICAgR2VuZXJhbEhlbHBlcnMuZ2V0T2JqZWN0RGVwdGgoZm9ybURhdGFbZ3JvdXBDb2RlXSkgPT09IDBcbiAgICAgICkge1xuICAgICAgICB0aGlzLmZvcm0uZ2V0KGdyb3VwQ29kZSkuc2V0VmFsdWUoZm9ybURhdGFbZ3JvdXBDb2RlXSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmb3IgKGNvbnN0IGNvbnRyb2xOYW1lIG9mIE9iamVjdC5rZXlzKGZvcm1EYXRhW2dyb3VwQ29kZV0pKSB7XG4gICAgICAgICAgY29uc3QgZm9ybUdyb3VwID0gdGhpcy5mb3JtLmdldChncm91cENvZGUpO1xuICAgICAgICAgIGlmIChmb3JtR3JvdXAgJiYgZm9ybURhdGFbZ3JvdXBDb2RlXVtjb250cm9sTmFtZV0gIT09ICcgJykge1xuICAgICAgICAgICAgaWYgKGZvcm1Hcm91cC5nZXQoY29udHJvbE5hbWUpKSB7XG4gICAgICAgICAgICAgIGZvcm1Hcm91cFxuICAgICAgICAgICAgICAgIC5nZXQoY29udHJvbE5hbWUpXG4gICAgICAgICAgICAgICAgLnNldFZhbHVlKGZvcm1EYXRhW2dyb3VwQ29kZV1bY29udHJvbE5hbWVdKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGZvcm1Hcm91cC5zZXRWYWx1ZShmb3JtRGF0YVtncm91cENvZGVdW2NvbnRyb2xOYW1lXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgYWRkU3VibWl0RXZlbnQoKSB7XG4gICAgdGhpcy5zdWJzY3JpcHRpb24uYWRkKFxuICAgICAgdGhpcy5mb3JtRGF0YVNlcnZpY2VcbiAgICAgICAgLmdldFN1Ym1pdHRlZEZvcm0oKVxuICAgICAgICAucGlwZShcbiAgICAgICAgICBtYXAoZm9ybSA9PiB7XG4gICAgICAgICAgICBpZiAodGhpcy5jaGVja0ludmFsaWRDb250cm9scyhmb3JtKSkge1xuICAgICAgICAgICAgICB0aGlzLmZvcm1Db21wb25lbnRTZXJ2aWNlLmlzUG9wdWxhdGVkRm9ybUludmFsaWRTb3VyY2UubmV4dCh0cnVlKTtcbiAgICAgICAgICAgICAgdGhpcy5tYXJrSW52YWxpZENvbnRyb2xzKHRoaXMuZm9ybSk7XG4gICAgICAgICAgICAgIHRoaXMuY2hhbmdlRGV0ZWN0b3JSZWYuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgICAgZm9ybSAmJlxuICAgICAgICAgICAgICBmb3JtLmNvbnRlbnQgPT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICAgICB0aGlzLmZvcm0gJiZcbiAgICAgICAgICAgICAgdGhpcy52YWx1ZSAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICAgIHRoaXMudmFsaWRcbiAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAvL2VzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgICAgICAgICAgICB0aGlzLnN1Ym1pdC5lbWl0KHtcbiAgICAgICAgICAgICAgICBpZDogZm9ybS5pZCxcbiAgICAgICAgICAgICAgICByZWZJZDogZm9ybS5yZWZJZCxcbiAgICAgICAgICAgICAgICBjb250ZW50OiB0aGlzLnZhbHVlLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KVxuICAgICAgICApXG4gICAgICAgIC5zdWJzY3JpYmUoKVxuICAgICk7XG4gIH1cblxuICBtYXJrSW52YWxpZENvbnRyb2xzKGZvcm1Hcm91cDogVW50eXBlZEZvcm1Hcm91cCkge1xuICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGZvcm1Hcm91cC5jb250cm9scykpIHtcbiAgICAgIGNvbnN0IGZvcm1Db250cm9sID0gZm9ybUdyb3VwLmdldChrZXkpO1xuICAgICAgaWYgKGZvcm1Db250cm9sIGluc3RhbmNlb2YgVW50eXBlZEZvcm1Hcm91cCkge1xuICAgICAgICB0aGlzLm1hcmtJbnZhbGlkQ29udHJvbHMoZm9ybUNvbnRyb2wpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgY29udHJvbCA9IDxVbnR5cGVkRm9ybUNvbnRyb2w+Zm9ybUNvbnRyb2w7XG4gICAgICAgIGlmICghY29udHJvbC52YWxpZCkge1xuICAgICAgICAgIGNvbnRyb2wubWFya0FzVG91Y2hlZCh7IG9ubHlTZWxmOiB0cnVlIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBjaGVja0ludmFsaWRDb250cm9scyhmb3JtRGF0YTogWUZvcm1EYXRhKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuICEhKGZvcm1EYXRhICYmICF0aGlzLnZhbGlkKTtcbiAgfVxuXG4gIG5nT25EZXN0cm95KCkge1xuICAgIGlmICh0aGlzLnN1YnNjcmlwdGlvbikge1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICB9XG4gIH1cbn1cbiIsIjxuZy1jb250YWluZXIgKm5nSWY9XCJmb3JtICYmIGNvbmZpZ1wiPlxuICA8Zm9ybSBbbmdDbGFzc109XCJjb25maWcuY3NzQ2xhc3NcIiBbZm9ybUdyb3VwXT1cImZvcm1cIj5cbiAgICA8bmctY29udGFpbmVyICpuZ0Zvcj1cImxldCBmb3JtR3JvdXAgb2YgY29uZmlnLmZvcm1Hcm91cHNcIj5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3M9XCJyb3dcIlxuICAgICAgICBbbmdDbGFzc109XCJmb3JtR3JvdXAuY3NzQ2xhc3NcIlxuICAgICAgICBbaGlkZGVuXT1cImZvcm1Hcm91cC5oaWRkZW5cIlxuICAgICAgPlxuICAgICAgICA8bmctY29udGFpbmVyXG4gICAgICAgICAgKm5nRm9yPVwibGV0IGZpZWxkIG9mIGZvcm1Hcm91cC5maWVsZENvbmZpZ3NcIlxuICAgICAgICAgIGN4Rm9ybUNvbXBvbmVudFxuICAgICAgICAgIFtjb25maWddPVwiZmllbGRcIlxuICAgICAgICAgIFtncm91cF09XCJcbiAgICAgICAgICAgIGZvcm1Hcm91cC5ncm91cENvZGUgPyBmb3JtLmNvbnRyb2xzW2Zvcm1Hcm91cC5ncm91cENvZGVdIDogZm9ybVxuICAgICAgICAgIFwiXG4gICAgICAgID5cbiAgICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICA8L2Rpdj5cbiAgICA8L25nLWNvbnRhaW5lcj5cbiAgPC9mb3JtPlxuPC9uZy1jb250YWluZXI+XG4iXX0=