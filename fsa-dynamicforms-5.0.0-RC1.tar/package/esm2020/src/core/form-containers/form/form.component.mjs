import { ChangeDetectionStrategy, Component, Input, ViewChild, } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { FormDataService } from '../../services/data/form-data.service';
import { DynamicFormComponent } from '../dynamic-form/dynamic-form.component';
import { FormDataStorageService } from './../../services/storage/form-data-storage.service';
import * as i0 from "@angular/core";
import * as i1 from "../../services/data/form-data.service";
import * as i2 from "./../../services/storage/form-data-storage.service";
import * as i3 from "@angular/common";
import * as i4 from "../dynamic-form/dynamic-form.component";
function FormComponent_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "cx-dynamic-form", 2, 3);
    i0.ɵɵlistener("submit", function FormComponent_ng_container_2_Template_cx_dynamic_form_submit_1_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.submit($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("config", ctx_r0.formConfig)("formData", ctx_r0.formData);
} }
export class FormComponent {
    constructor(formDataService, formDataStorageService) {
        this.formDataService = formDataService;
        this.formDataStorageService = formDataStorageService;
        this.subscription = new Subscription();
    }
    submit(formData) {
        if (this.form && this.form.valid && formData.content) {
            this.formDataService.saveFormData({
                formDefinition: {
                    formId: this.formId,
                    applicationId: this.applicationId,
                },
                content: formData.content,
                refId: formData.refId,
                id: formData.id,
            });
            this.subscription.add(this.formDataService.getFormData().subscribe(response => {
                const savedForm = {
                    id: response.id,
                    formDefinition: {
                        formId: response.formDefinition.formId,
                    },
                    content: response.content,
                    categoryCode: this.formCategoryCode,
                };
                this.formDataStorageService.setFormDataToLocalStorage(savedForm);
                this.formDataService.submit(response);
            }));
        }
    }
    ngOnDestroy() {
        this.formDataService.submit(null);
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
FormComponent.ɵfac = function FormComponent_Factory(t) { return new (t || FormComponent)(i0.ɵɵdirectiveInject(i1.FormDataService), i0.ɵɵdirectiveInject(i2.FormDataStorageService)); };
FormComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FormComponent, selectors: [["cx-form-component"]], viewQuery: function FormComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(DynamicFormComponent, 5);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.form = _t.first);
    } }, inputs: { formCategoryCode: "formCategoryCode", formId: "formId", formSubject: "formSubject", formConfig: "formConfig", applicationId: "applicationId", formData: "formData" }, decls: 3, vars: 2, consts: [[1, "form-title"], [4, "ngIf"], [1, "dynamic-form", "container", 3, "config", "formData", "submit"], ["form", "cx-dynamicForm"]], template: function FormComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "h3", 0);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(2, FormComponent_ng_container_2_Template, 3, 2, "ng-container", 1);
    } if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx.formSubject, "\n");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.formConfig !== undefined);
    } }, dependencies: [i3.NgIf, i4.DynamicFormComponent], encapsulation: 2, changeDetection: 0 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormComponent, [{
        type: Component,
        args: [{ selector: 'cx-form-component', changeDetection: ChangeDetectionStrategy.OnPush, template: "<h3 class=\"form-title\">\n  {{ formSubject }}\n</h3>\n<ng-container *ngIf=\"formConfig !== undefined\">\n  <cx-dynamic-form\n    class=\"dynamic-form container\"\n    #form=\"cx-dynamicForm\"\n    [config]=\"formConfig\"\n    (submit)=\"submit($event)\"\n    [formData]=\"formData\"\n  >\n  </cx-dynamic-form>\n</ng-container>\n" }]
    }], function () { return [{ type: i1.FormDataService }, { type: i2.FormDataStorageService }]; }, { form: [{
            type: ViewChild,
            args: [DynamicFormComponent, { static: false }]
        }], formCategoryCode: [{
            type: Input
        }], formId: [{
            type: Input
        }], formSubject: [{
            type: Input
        }], formConfig: [{
            type: Input
        }], applicationId: [{
            type: Input
        }], formData: [{
            type: Input
        }] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvZm9ybS1jb250YWluZXJzL2Zvcm0vZm9ybS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvZm9ybS1jb250YWluZXJzL2Zvcm0vZm9ybS5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0wsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFDVCxLQUFLLEVBRUwsU0FBUyxHQUNWLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBRWhELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSx1Q0FBdUMsQ0FBQztBQUN4RSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSx3Q0FBd0MsQ0FBQztBQUU5RSxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSxvREFBb0QsQ0FBQzs7Ozs7Ozs7SUNUNUYsNkJBQStDO0lBQzdDLDZDQU1DO0lBRkMsb0xBQVUsZUFBQSxxQkFBYyxDQUFBLElBQUM7SUFHM0IsaUJBQWtCO0lBQ3BCLDBCQUFlOzs7SUFMWCxlQUFxQjtJQUFyQiwwQ0FBcUIsNkJBQUE7O0FEWXpCLE1BQU0sT0FBTyxhQUFhO0lBRXhCLFlBQ1ksZUFBZ0MsRUFDaEMsc0JBQThDO1FBRDlDLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQUNoQywyQkFBc0IsR0FBdEIsc0JBQXNCLENBQXdCO1FBSGxELGlCQUFZLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQUl2QyxDQUFDO0lBa0JKLE1BQU0sQ0FBQyxRQUFtQjtRQUN4QixJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksUUFBUSxDQUFDLE9BQU8sRUFBRTtZQUNwRCxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztnQkFDaEMsY0FBYyxFQUFFO29CQUNkLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtvQkFDbkIsYUFBYSxFQUFFLElBQUksQ0FBQyxhQUFhO2lCQUNsQztnQkFDRCxPQUFPLEVBQUUsUUFBUSxDQUFDLE9BQU87Z0JBQ3pCLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBSztnQkFDckIsRUFBRSxFQUFFLFFBQVEsQ0FBQyxFQUFFO2FBQ2hCLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUNuQixJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDdEQsTUFBTSxTQUFTLEdBQUc7b0JBQ2hCLEVBQUUsRUFBRSxRQUFRLENBQUMsRUFBRTtvQkFDZixjQUFjLEVBQUU7d0JBQ2QsTUFBTSxFQUFFLFFBQVEsQ0FBQyxjQUFjLENBQUMsTUFBTTtxQkFDdkM7b0JBQ0QsT0FBTyxFQUFFLFFBQVEsQ0FBQyxPQUFPO29CQUN6QixZQUFZLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjtpQkFDcEMsQ0FBQztnQkFDRixJQUFJLENBQUMsc0JBQXNCLENBQUMseUJBQXlCLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ2pFLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3hDLENBQUMsQ0FBQyxDQUNILENBQUM7U0FDSDtJQUNILENBQUM7SUFFRCxXQUFXO1FBQ1QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbEMsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3JCLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDakM7SUFDSCxDQUFDOzswRUF6RFUsYUFBYTtnRUFBYixhQUFhO3VCQU9iLG9CQUFvQjs7Ozs7UUMxQmpDLDZCQUF1QjtRQUNyQixZQUNGO1FBQUEsaUJBQUs7UUFDTCxnRkFTZTs7UUFYYixlQUNGO1FBREUsaURBQ0Y7UUFDZSxlQUE4QjtRQUE5QixtREFBOEI7O3VGRGdCaEMsYUFBYTtjQUx6QixTQUFTOzJCQUNFLG1CQUFtQixtQkFFWix1QkFBdUIsQ0FBQyxNQUFNO3VHQVUvQyxJQUFJO2tCQURILFNBQVM7bUJBQUMsb0JBQW9CLEVBQUUsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFO1lBSWxELGdCQUFnQjtrQkFEZixLQUFLO1lBR04sTUFBTTtrQkFETCxLQUFLO1lBR04sV0FBVztrQkFEVixLQUFLO1lBR04sVUFBVTtrQkFEVCxLQUFLO1lBR04sYUFBYTtrQkFEWixLQUFLO1lBR04sUUFBUTtrQkFEUCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENvbXBvbmVudCxcbiAgSW5wdXQsXG4gIE9uRGVzdHJveSxcbiAgVmlld0NoaWxkLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUsIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgRm9ybURlZmluaXRpb24gfSBmcm9tICcuLi8uLi9tb2RlbHMvZm9ybS1jb25maWcuaW50ZXJmYWNlJztcbmltcG9ydCB7IEZvcm1EYXRhU2VydmljZSB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2RhdGEvZm9ybS1kYXRhLnNlcnZpY2UnO1xuaW1wb3J0IHsgRHluYW1pY0Zvcm1Db21wb25lbnQgfSBmcm9tICcuLi9keW5hbWljLWZvcm0vZHluYW1pYy1mb3JtLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBZRm9ybURhdGEgfSBmcm9tICcuLy4uLy4uL21vZGVscy9mb3JtLW9jYy5tb2RlbHMnO1xuaW1wb3J0IHsgRm9ybURhdGFTdG9yYWdlU2VydmljZSB9IGZyb20gJy4vLi4vLi4vc2VydmljZXMvc3RvcmFnZS9mb3JtLWRhdGEtc3RvcmFnZS5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY3gtZm9ybS1jb21wb25lbnQnLFxuICB0ZW1wbGF0ZVVybDogJy4vZm9ybS5jb21wb25lbnQuaHRtbCcsXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBGb3JtQ29tcG9uZW50IGltcGxlbWVudHMgT25EZXN0cm95IHtcbiAgcHJpdmF0ZSBzdWJzY3JpcHRpb24gPSBuZXcgU3Vic2NyaXB0aW9uKCk7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByb3RlY3RlZCBmb3JtRGF0YVNlcnZpY2U6IEZvcm1EYXRhU2VydmljZSxcbiAgICBwcm90ZWN0ZWQgZm9ybURhdGFTdG9yYWdlU2VydmljZTogRm9ybURhdGFTdG9yYWdlU2VydmljZVxuICApIHt9XG5cbiAgQFZpZXdDaGlsZChEeW5hbWljRm9ybUNvbXBvbmVudCwgeyBzdGF0aWM6IGZhbHNlIH0pXG4gIGZvcm06IER5bmFtaWNGb3JtQ29tcG9uZW50O1xuXG4gIEBJbnB1dCgpXG4gIGZvcm1DYXRlZ29yeUNvZGU6IHN0cmluZztcbiAgQElucHV0KClcbiAgZm9ybUlkOiBzdHJpbmc7XG4gIEBJbnB1dCgpXG4gIGZvcm1TdWJqZWN0OiBzdHJpbmc7XG4gIEBJbnB1dCgpXG4gIGZvcm1Db25maWc6IEZvcm1EZWZpbml0aW9uO1xuICBASW5wdXQoKVxuICBhcHBsaWNhdGlvbklkOiBzdHJpbmc7XG4gIEBJbnB1dCgpXG4gIGZvcm1EYXRhOiBPYnNlcnZhYmxlPFlGb3JtRGF0YT47XG5cbiAgc3VibWl0KGZvcm1EYXRhOiBZRm9ybURhdGEpIHtcbiAgICBpZiAodGhpcy5mb3JtICYmIHRoaXMuZm9ybS52YWxpZCAmJiBmb3JtRGF0YS5jb250ZW50KSB7XG4gICAgICB0aGlzLmZvcm1EYXRhU2VydmljZS5zYXZlRm9ybURhdGEoe1xuICAgICAgICBmb3JtRGVmaW5pdGlvbjoge1xuICAgICAgICAgIGZvcm1JZDogdGhpcy5mb3JtSWQsXG4gICAgICAgICAgYXBwbGljYXRpb25JZDogdGhpcy5hcHBsaWNhdGlvbklkLFxuICAgICAgICB9LFxuICAgICAgICBjb250ZW50OiBmb3JtRGF0YS5jb250ZW50LFxuICAgICAgICByZWZJZDogZm9ybURhdGEucmVmSWQsXG4gICAgICAgIGlkOiBmb3JtRGF0YS5pZCxcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLnN1YnNjcmlwdGlvbi5hZGQoXG4gICAgICAgIHRoaXMuZm9ybURhdGFTZXJ2aWNlLmdldEZvcm1EYXRhKCkuc3Vic2NyaWJlKHJlc3BvbnNlID0+IHtcbiAgICAgICAgICBjb25zdCBzYXZlZEZvcm0gPSB7XG4gICAgICAgICAgICBpZDogcmVzcG9uc2UuaWQsXG4gICAgICAgICAgICBmb3JtRGVmaW5pdGlvbjoge1xuICAgICAgICAgICAgICBmb3JtSWQ6IHJlc3BvbnNlLmZvcm1EZWZpbml0aW9uLmZvcm1JZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjb250ZW50OiByZXNwb25zZS5jb250ZW50LFxuICAgICAgICAgICAgY2F0ZWdvcnlDb2RlOiB0aGlzLmZvcm1DYXRlZ29yeUNvZGUsXG4gICAgICAgICAgfTtcbiAgICAgICAgICB0aGlzLmZvcm1EYXRhU3RvcmFnZVNlcnZpY2Uuc2V0Rm9ybURhdGFUb0xvY2FsU3RvcmFnZShzYXZlZEZvcm0pO1xuICAgICAgICAgIHRoaXMuZm9ybURhdGFTZXJ2aWNlLnN1Ym1pdChyZXNwb25zZSk7XG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMuZm9ybURhdGFTZXJ2aWNlLnN1Ym1pdChudWxsKTtcbiAgICBpZiAodGhpcy5zdWJzY3JpcHRpb24pIHtcbiAgICAgIHRoaXMuc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgfVxuICB9XG59XG4iLCI8aDMgY2xhc3M9XCJmb3JtLXRpdGxlXCI+XG4gIHt7IGZvcm1TdWJqZWN0IH19XG48L2gzPlxuPG5nLWNvbnRhaW5lciAqbmdJZj1cImZvcm1Db25maWcgIT09IHVuZGVmaW5lZFwiPlxuICA8Y3gtZHluYW1pYy1mb3JtXG4gICAgY2xhc3M9XCJkeW5hbWljLWZvcm0gY29udGFpbmVyXCJcbiAgICAjZm9ybT1cImN4LWR5bmFtaWNGb3JtXCJcbiAgICBbY29uZmlnXT1cImZvcm1Db25maWdcIlxuICAgIChzdWJtaXQpPVwic3VibWl0KCRldmVudClcIlxuICAgIFtmb3JtRGF0YV09XCJmb3JtRGF0YVwiXG4gID5cbiAgPC9jeC1keW5hbWljLWZvcm0+XG48L25nLWNvbnRhaW5lcj5cbiJdfQ==