import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { I18nModule } from '@spartacus/core';
import { ComponentsModule } from '../../components/components.module';
import { FormConnector } from '../connectors/form.connector';
import { FormBuilderService } from '../services/builder/form-builder.service';
import { FormDataService } from '../services/data/form-data.service';
import { FormValidationService } from '../services/form-validation/form-validation.service';
import { FormService } from '../services/form/form.service';
import { FieldDependencyResolverService } from './../services/form-dependencies/field-dependency-resolver.service';
import { FormDataStorageService } from './../services/storage/form-data-storage.service';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';
import { FormComponent } from './form/form.component';
import { FileService } from '../services/file/file.service';
import * as i0 from "@angular/core";
export class FormContainerModule {
}
FormContainerModule.ɵfac = function FormContainerModule_Factory(t) { return new (t || FormContainerModule)(); };
FormContainerModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: FormContainerModule });
FormContainerModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        FormService,
        FormBuilderService,
        FormValidationService,
        FieldDependencyResolverService,
        FormDataStorageService,
        FormConnector,
        FormDataService,
        FileService,
    ], imports: [CommonModule,
        I18nModule,
        RouterModule,
        ReactiveFormsModule,
        ComponentsModule, ComponentsModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormContainerModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule,
                    I18nModule,
                    RouterModule,
                    ReactiveFormsModule,
                    ComponentsModule,
                ],
                declarations: [FormComponent, DynamicFormComponent],
                exports: [FormComponent, DynamicFormComponent, ComponentsModule],
                providers: [
                    FormService,
                    FormBuilderService,
                    FormValidationService,
                    FieldDependencyResolverService,
                    FormDataStorageService,
                    FormConnector,
                    FormDataService,
                    FileService,
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(FormContainerModule, { declarations: [FormComponent, DynamicFormComponent], imports: [CommonModule,
        I18nModule,
        RouterModule,
        ReactiveFormsModule,
        ComponentsModule], exports: [FormComponent, DynamicFormComponent, ComponentsModule] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1jb250YWluZXIubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb3JlL2Zvcm0tY29udGFpbmVycy9mb3JtLWNvbnRhaW5lci5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekMsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDckQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUM3QyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQUN0RSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sMENBQTBDLENBQUM7QUFDOUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBQ3JFLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLHFEQUFxRCxDQUFDO0FBQzVGLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUM1RCxPQUFPLEVBQUUsOEJBQThCLEVBQUUsTUFBTSxtRUFBbUUsQ0FBQztBQUNuSCxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSxpREFBaUQsQ0FBQztBQUN6RixPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSx1Q0FBdUMsQ0FBQztBQUM3RSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDdEQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLCtCQUErQixDQUFDOztBQXVCNUQsTUFBTSxPQUFPLG1CQUFtQjs7c0ZBQW5CLG1CQUFtQjtxRUFBbkIsbUJBQW1COzBFQVhuQjtRQUNULFdBQVc7UUFDWCxrQkFBa0I7UUFDbEIscUJBQXFCO1FBQ3JCLDhCQUE4QjtRQUM5QixzQkFBc0I7UUFDdEIsYUFBYTtRQUNiLGVBQWU7UUFDZixXQUFXO0tBQ1osWUFqQkMsWUFBWTtRQUNaLFVBQVU7UUFDVixZQUFZO1FBQ1osbUJBQW1CO1FBQ25CLGdCQUFnQixFQUc2QixnQkFBZ0I7dUZBWXBELG1CQUFtQjtjQXJCL0IsUUFBUTtlQUFDO2dCQUNSLE9BQU8sRUFBRTtvQkFDUCxZQUFZO29CQUNaLFVBQVU7b0JBQ1YsWUFBWTtvQkFDWixtQkFBbUI7b0JBQ25CLGdCQUFnQjtpQkFDakI7Z0JBQ0QsWUFBWSxFQUFFLENBQUMsYUFBYSxFQUFFLG9CQUFvQixDQUFDO2dCQUNuRCxPQUFPLEVBQUUsQ0FBQyxhQUFhLEVBQUUsb0JBQW9CLEVBQUUsZ0JBQWdCLENBQUM7Z0JBQ2hFLFNBQVMsRUFBRTtvQkFDVCxXQUFXO29CQUNYLGtCQUFrQjtvQkFDbEIscUJBQXFCO29CQUNyQiw4QkFBOEI7b0JBQzlCLHNCQUFzQjtvQkFDdEIsYUFBYTtvQkFDYixlQUFlO29CQUNmLFdBQVc7aUJBQ1o7YUFDRjs7d0ZBQ1ksbUJBQW1CLG1CQWJmLGFBQWEsRUFBRSxvQkFBb0IsYUFOaEQsWUFBWTtRQUNaLFVBQVU7UUFDVixZQUFZO1FBQ1osbUJBQW1CO1FBQ25CLGdCQUFnQixhQUdSLGFBQWEsRUFBRSxvQkFBb0IsRUFBRSxnQkFBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJlYWN0aXZlRm9ybXNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBSb3V0ZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgSTE4bk1vZHVsZSB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBDb21wb25lbnRzTW9kdWxlIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9jb21wb25lbnRzLm1vZHVsZSc7XG5pbXBvcnQgeyBGb3JtQ29ubmVjdG9yIH0gZnJvbSAnLi4vY29ubmVjdG9ycy9mb3JtLmNvbm5lY3Rvcic7XG5pbXBvcnQgeyBGb3JtQnVpbGRlclNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9idWlsZGVyL2Zvcm0tYnVpbGRlci5zZXJ2aWNlJztcbmltcG9ydCB7IEZvcm1EYXRhU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2RhdGEvZm9ybS1kYXRhLnNlcnZpY2UnO1xuaW1wb3J0IHsgRm9ybVZhbGlkYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvZm9ybS12YWxpZGF0aW9uL2Zvcm0tdmFsaWRhdGlvbi5zZXJ2aWNlJztcbmltcG9ydCB7IEZvcm1TZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvZm9ybS9mb3JtLnNlcnZpY2UnO1xuaW1wb3J0IHsgRmllbGREZXBlbmRlbmN5UmVzb2x2ZXJTZXJ2aWNlIH0gZnJvbSAnLi8uLi9zZXJ2aWNlcy9mb3JtLWRlcGVuZGVuY2llcy9maWVsZC1kZXBlbmRlbmN5LXJlc29sdmVyLnNlcnZpY2UnO1xuaW1wb3J0IHsgRm9ybURhdGFTdG9yYWdlU2VydmljZSB9IGZyb20gJy4vLi4vc2VydmljZXMvc3RvcmFnZS9mb3JtLWRhdGEtc3RvcmFnZS5zZXJ2aWNlJztcbmltcG9ydCB7IER5bmFtaWNGb3JtQ29tcG9uZW50IH0gZnJvbSAnLi9keW5hbWljLWZvcm0vZHluYW1pYy1mb3JtLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBGb3JtQ29tcG9uZW50IH0gZnJvbSAnLi9mb3JtL2Zvcm0uY29tcG9uZW50JztcbmltcG9ydCB7IEZpbGVTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvZmlsZS9maWxlLnNlcnZpY2UnO1xuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgQ29tbW9uTW9kdWxlLFxuICAgIEkxOG5Nb2R1bGUsXG4gICAgUm91dGVyTW9kdWxlLFxuICAgIFJlYWN0aXZlRm9ybXNNb2R1bGUsXG4gICAgQ29tcG9uZW50c01vZHVsZSxcbiAgXSxcbiAgZGVjbGFyYXRpb25zOiBbRm9ybUNvbXBvbmVudCwgRHluYW1pY0Zvcm1Db21wb25lbnRdLFxuICBleHBvcnRzOiBbRm9ybUNvbXBvbmVudCwgRHluYW1pY0Zvcm1Db21wb25lbnQsIENvbXBvbmVudHNNb2R1bGVdLFxuICBwcm92aWRlcnM6IFtcbiAgICBGb3JtU2VydmljZSxcbiAgICBGb3JtQnVpbGRlclNlcnZpY2UsXG4gICAgRm9ybVZhbGlkYXRpb25TZXJ2aWNlLFxuICAgIEZpZWxkRGVwZW5kZW5jeVJlc29sdmVyU2VydmljZSxcbiAgICBGb3JtRGF0YVN0b3JhZ2VTZXJ2aWNlLFxuICAgIEZvcm1Db25uZWN0b3IsXG4gICAgRm9ybURhdGFTZXJ2aWNlLFxuICAgIEZpbGVTZXJ2aWNlLFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBGb3JtQ29udGFpbmVyTW9kdWxlIHt9XG4iXX0=