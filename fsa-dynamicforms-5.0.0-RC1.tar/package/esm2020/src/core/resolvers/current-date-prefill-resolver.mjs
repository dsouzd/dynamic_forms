import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export class CurrentDatePrefillResolver {
    constructor(datePipe) {
        this.datePipe = datePipe;
    }
    getPrefillValue() {
        return of(this.datePipe.transform(Date.now(), 'yyyy-MM-dd'));
    }
}
CurrentDatePrefillResolver.ɵfac = function CurrentDatePrefillResolver_Factory(t) { return new (t || CurrentDatePrefillResolver)(i0.ɵɵinject(i1.DatePipe)); };
CurrentDatePrefillResolver.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: CurrentDatePrefillResolver, factory: CurrentDatePrefillResolver.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CurrentDatePrefillResolver, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: i1.DatePipe }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VycmVudC1kYXRlLXByZWZpbGwtcmVzb2x2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvcmVzb2x2ZXJzL2N1cnJlbnQtZGF0ZS1wcmVmaWxsLXJlc29sdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRTNDLE9BQU8sRUFBRSxFQUFFLEVBQUUsTUFBTSxNQUFNLENBQUM7OztBQUsxQixNQUFNLE9BQU8sMEJBQTBCO0lBQ3JDLFlBQW9CLFFBQWtCO1FBQWxCLGFBQVEsR0FBUixRQUFRLENBQVU7SUFBRyxDQUFDO0lBQzFDLGVBQWU7UUFDYixPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUMvRCxDQUFDOztvR0FKVSwwQkFBMEI7Z0ZBQTFCLDBCQUEwQixXQUExQiwwQkFBMEIsbUJBRnpCLE1BQU07dUZBRVAsMEJBQTBCO2NBSHRDLFVBQVU7ZUFBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IERhdGVQaXBlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IFByZWZpbGxSZXNvbHZlciB9IGZyb20gJy4vcHJlZmlsbC1yZXNvbHZlci5pbnRlcmZhY2UnO1xuaW1wb3J0IHsgb2YgfSBmcm9tICdyeGpzJztcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIEN1cnJlbnREYXRlUHJlZmlsbFJlc29sdmVyIGltcGxlbWVudHMgUHJlZmlsbFJlc29sdmVyIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBkYXRlUGlwZTogRGF0ZVBpcGUpIHt9XG4gIGdldFByZWZpbGxWYWx1ZSgpIHtcbiAgICByZXR1cm4gb2YodGhpcy5kYXRlUGlwZS50cmFuc2Zvcm0oRGF0ZS5ub3coKSwgJ3l5eXktTU0tZGQnKSk7XG4gIH1cbn1cbiJdfQ==