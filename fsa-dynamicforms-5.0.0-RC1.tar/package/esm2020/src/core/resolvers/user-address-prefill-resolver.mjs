import { UserAddressService } from '@spartacus/core';
import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/core";
export class UserAddressPrefillResolver {
    constructor(userAddressService) {
        this.userAddressService = userAddressService;
    }
    getPrefillValue(fieldPath) {
        const attributes = fieldPath.split('.');
        let currentValue;
        return this.userAddressService.getAddresses().pipe(map(address => {
            currentValue = address[0];
            if (!currentValue) {
                return ' ';
            }
            attributes.forEach(attribute => {
                currentValue = currentValue[attribute];
            });
            return currentValue;
        }));
    }
}
UserAddressPrefillResolver.ɵfac = function UserAddressPrefillResolver_Factory(t) { return new (t || UserAddressPrefillResolver)(i0.ɵɵinject(i1.UserAddressService)); };
UserAddressPrefillResolver.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: UserAddressPrefillResolver, factory: UserAddressPrefillResolver.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UserAddressPrefillResolver, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: i1.UserAddressService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci1hZGRyZXNzLXByZWZpbGwtcmVzb2x2ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvcmVzb2x2ZXJzL3VzZXItYWRkcmVzcy1wcmVmaWxsLXJlc29sdmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxHQUFHLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUNyQyxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDOzs7QUFNM0MsTUFBTSxPQUFPLDBCQUEwQjtJQUNyQyxZQUFzQixrQkFBc0M7UUFBdEMsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUFvQjtJQUFHLENBQUM7SUFFaEUsZUFBZSxDQUFDLFNBQWlCO1FBQy9CLE1BQU0sVUFBVSxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDeEMsSUFBSSxZQUFZLENBQUM7UUFDakIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUNoRCxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDWixZQUFZLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFCLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ2pCLE9BQU8sR0FBRyxDQUFDO2FBQ1o7WUFDRCxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUM3QixZQUFZLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3pDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxZQUFZLENBQUM7UUFDdEIsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUNKLENBQUM7O29HQWxCVSwwQkFBMEI7Z0ZBQTFCLDBCQUEwQixXQUExQiwwQkFBMEIsbUJBRnpCLE1BQU07dUZBRVAsMEJBQTBCO2NBSHRDLFVBQVU7ZUFBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFVzZXJBZGRyZXNzU2VydmljZSB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBtYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBQcmVmaWxsUmVzb2x2ZXIgfSBmcm9tICcuL3ByZWZpbGwtcmVzb2x2ZXIuaW50ZXJmYWNlJztcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIFVzZXJBZGRyZXNzUHJlZmlsbFJlc29sdmVyIGltcGxlbWVudHMgUHJlZmlsbFJlc29sdmVyIHtcbiAgY29uc3RydWN0b3IocHJvdGVjdGVkIHVzZXJBZGRyZXNzU2VydmljZTogVXNlckFkZHJlc3NTZXJ2aWNlKSB7fVxuXG4gIGdldFByZWZpbGxWYWx1ZShmaWVsZFBhdGg6IHN0cmluZykge1xuICAgIGNvbnN0IGF0dHJpYnV0ZXMgPSBmaWVsZFBhdGguc3BsaXQoJy4nKTtcbiAgICBsZXQgY3VycmVudFZhbHVlO1xuICAgIHJldHVybiB0aGlzLnVzZXJBZGRyZXNzU2VydmljZS5nZXRBZGRyZXNzZXMoKS5waXBlKFxuICAgICAgbWFwKGFkZHJlc3MgPT4ge1xuICAgICAgICBjdXJyZW50VmFsdWUgPSBhZGRyZXNzWzBdO1xuICAgICAgICBpZiAoIWN1cnJlbnRWYWx1ZSkge1xuICAgICAgICAgIHJldHVybiAnICc7XG4gICAgICAgIH1cbiAgICAgICAgYXR0cmlidXRlcy5mb3JFYWNoKGF0dHJpYnV0ZSA9PiB7XG4gICAgICAgICAgY3VycmVudFZhbHVlID0gY3VycmVudFZhbHVlW2F0dHJpYnV0ZV07XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gY3VycmVudFZhbHVlO1xuICAgICAgfSlcbiAgICApO1xuICB9XG59XG4iXX0=