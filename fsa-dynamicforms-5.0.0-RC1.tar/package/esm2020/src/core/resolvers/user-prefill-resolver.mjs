import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { FormsUtils } from './utils/forms-utils';
import { UserAccountFacade } from '@spartacus/user/account/root';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/user/account/root";
export class UserPrefillResolver {
    constructor(userAccountFacade) {
        this.userAccountFacade = userAccountFacade;
    }
    getPrefillValue(fieldPath) {
        let currentValue;
        return this.userAccountFacade.get().pipe(map(user => {
            currentValue = FormsUtils.getValueByPath(fieldPath, user);
            return currentValue;
        }));
    }
}
UserPrefillResolver.ɵfac = function UserPrefillResolver_Factory(t) { return new (t || UserPrefillResolver)(i0.ɵɵinject(i1.UserAccountFacade)); };
UserPrefillResolver.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: UserPrefillResolver, factory: UserPrefillResolver.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UserPrefillResolver, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: i1.UserAccountFacade }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci1wcmVmaWxsLXJlc29sdmVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb3JlL3Jlc29sdmVycy91c2VyLXByZWZpbGwtcmVzb2x2ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLEdBQUcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3JDLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ2pELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDOzs7QUFLakUsTUFBTSxPQUFPLG1CQUFtQjtJQUM5QixZQUFzQixpQkFBb0M7UUFBcEMsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFtQjtJQUFHLENBQUM7SUFFOUQsZUFBZSxDQUFDLFNBQWlCO1FBQy9CLElBQUksWUFBWSxDQUFDO1FBQ2pCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FDdEMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ1QsWUFBWSxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzFELE9BQU8sWUFBWSxDQUFDO1FBQ3RCLENBQUMsQ0FBQyxDQUNILENBQUM7SUFDSixDQUFDOztzRkFYVSxtQkFBbUI7eUVBQW5CLG1CQUFtQixXQUFuQixtQkFBbUIsbUJBRmxCLE1BQU07dUZBRVAsbUJBQW1CO2NBSC9CLFVBQVU7ZUFBQztnQkFDVixVQUFVLEVBQUUsTUFBTTthQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFByZWZpbGxSZXNvbHZlciB9IGZyb20gJy4vcHJlZmlsbC1yZXNvbHZlci5pbnRlcmZhY2UnO1xuaW1wb3J0IHsgRm9ybXNVdGlscyB9IGZyb20gJy4vdXRpbHMvZm9ybXMtdXRpbHMnO1xuaW1wb3J0IHsgVXNlckFjY291bnRGYWNhZGUgfSBmcm9tICdAc3BhcnRhY3VzL3VzZXIvYWNjb3VudC9yb290JztcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIFVzZXJQcmVmaWxsUmVzb2x2ZXIgaW1wbGVtZW50cyBQcmVmaWxsUmVzb2x2ZXIge1xuICBjb25zdHJ1Y3Rvcihwcm90ZWN0ZWQgdXNlckFjY291bnRGYWNhZGU6IFVzZXJBY2NvdW50RmFjYWRlKSB7fVxuXG4gIGdldFByZWZpbGxWYWx1ZShmaWVsZFBhdGg6IHN0cmluZykge1xuICAgIGxldCBjdXJyZW50VmFsdWU7XG4gICAgcmV0dXJuIHRoaXMudXNlckFjY291bnRGYWNhZGUuZ2V0KCkucGlwZShcbiAgICAgIG1hcCh1c2VyID0+IHtcbiAgICAgICAgY3VycmVudFZhbHVlID0gRm9ybXNVdGlscy5nZXRWYWx1ZUJ5UGF0aChmaWVsZFBhdGgsIHVzZXIpO1xuICAgICAgICByZXR1cm4gY3VycmVudFZhbHVlO1xuICAgICAgfSlcbiAgICApO1xuICB9XG59XG4iXX0=