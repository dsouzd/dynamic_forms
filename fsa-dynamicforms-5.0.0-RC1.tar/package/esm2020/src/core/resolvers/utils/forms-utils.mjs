import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class FormsUtils {
    static convertIfDate(value) {
        const dateRegex = /^\d{1,2}\-\d{1,2}\-\d{4}$/;
        if (dateRegex.test(value)) {
            value = value.split('-').reverse().join('-');
        }
        return value;
    }
    static getValueByPath(fieldPath, object) {
        let currentValue = object;
        const attributes = fieldPath.split('.');
        for (const attribute of attributes) {
            currentValue = this.getValueForAttribute(attribute, currentValue);
            if (!currentValue) {
                break;
            }
        }
        return currentValue;
    }
    static getValueForAttribute(attribute, objectValue) {
        if (attribute.indexOf('[') !== -1) {
            const attributeName = attribute.split('[')[0];
            const arrayPosition = attribute.split('[')[1].slice(0, 1);
            if (objectValue[attributeName]) {
                return objectValue[attributeName][arrayPosition];
            }
        }
        return objectValue[attribute];
    }
}
FormsUtils.ɵfac = function FormsUtils_Factory(t) { return new (t || FormsUtils)(); };
FormsUtils.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormsUtils, factory: FormsUtils.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormsUtils, [{
        type: Injectable
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybXMtdXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvcmUvcmVzb2x2ZXJzL3V0aWxzL2Zvcm1zLXV0aWxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBRzNDLE1BQU0sT0FBTyxVQUFVO0lBQ3JCLE1BQU0sQ0FBQyxhQUFhLENBQUMsS0FBSztRQUN4QixNQUFNLFNBQVMsR0FBRywyQkFBMkIsQ0FBQztRQUM5QyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDekIsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzlDO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBQ0QsTUFBTSxDQUFDLGNBQWMsQ0FBQyxTQUFpQixFQUFFLE1BQU07UUFDN0MsSUFBSSxZQUFZLEdBQUcsTUFBTSxDQUFDO1FBQzFCLE1BQU0sVUFBVSxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDeEMsS0FBSyxNQUFNLFNBQVMsSUFBSSxVQUFVLEVBQUU7WUFDbEMsWUFBWSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFDbEUsSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDakIsTUFBTTthQUNQO1NBQ0Y7UUFDRCxPQUFPLFlBQVksQ0FBQztJQUN0QixDQUFDO0lBRU8sTUFBTSxDQUFDLG9CQUFvQixDQUFDLFNBQWlCLEVBQUUsV0FBVztRQUNoRSxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDakMsTUFBTSxhQUFhLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM5QyxNQUFNLGFBQWEsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDMUQsSUFBSSxXQUFXLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQzlCLE9BQU8sV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDO2FBQ2xEO1NBQ0Y7UUFDRCxPQUFPLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNoQyxDQUFDOztvRUE3QlUsVUFBVTtnRUFBVixVQUFVLFdBQVYsVUFBVTt1RkFBVixVQUFVO2NBRHRCLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBGb3Jtc1V0aWxzIHtcbiAgc3RhdGljIGNvbnZlcnRJZkRhdGUodmFsdWUpIHtcbiAgICBjb25zdCBkYXRlUmVnZXggPSAvXlxcZHsxLDJ9XFwtXFxkezEsMn1cXC1cXGR7NH0kLztcbiAgICBpZiAoZGF0ZVJlZ2V4LnRlc3QodmFsdWUpKSB7XG4gICAgICB2YWx1ZSA9IHZhbHVlLnNwbGl0KCctJykucmV2ZXJzZSgpLmpvaW4oJy0nKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIHN0YXRpYyBnZXRWYWx1ZUJ5UGF0aChmaWVsZFBhdGg6IHN0cmluZywgb2JqZWN0KSB7XG4gICAgbGV0IGN1cnJlbnRWYWx1ZSA9IG9iamVjdDtcbiAgICBjb25zdCBhdHRyaWJ1dGVzID0gZmllbGRQYXRoLnNwbGl0KCcuJyk7XG4gICAgZm9yIChjb25zdCBhdHRyaWJ1dGUgb2YgYXR0cmlidXRlcykge1xuICAgICAgY3VycmVudFZhbHVlID0gdGhpcy5nZXRWYWx1ZUZvckF0dHJpYnV0ZShhdHRyaWJ1dGUsIGN1cnJlbnRWYWx1ZSk7XG4gICAgICBpZiAoIWN1cnJlbnRWYWx1ZSkge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGN1cnJlbnRWYWx1ZTtcbiAgfVxuXG4gIHByaXZhdGUgc3RhdGljIGdldFZhbHVlRm9yQXR0cmlidXRlKGF0dHJpYnV0ZTogc3RyaW5nLCBvYmplY3RWYWx1ZSkge1xuICAgIGlmIChhdHRyaWJ1dGUuaW5kZXhPZignWycpICE9PSAtMSkge1xuICAgICAgY29uc3QgYXR0cmlidXRlTmFtZSA9IGF0dHJpYnV0ZS5zcGxpdCgnWycpWzBdO1xuICAgICAgY29uc3QgYXJyYXlQb3NpdGlvbiA9IGF0dHJpYnV0ZS5zcGxpdCgnWycpWzFdLnNsaWNlKDAsIDEpO1xuICAgICAgaWYgKG9iamVjdFZhbHVlW2F0dHJpYnV0ZU5hbWVdKSB7XG4gICAgICAgIHJldHVybiBvYmplY3RWYWx1ZVthdHRyaWJ1dGVOYW1lXVthcnJheVBvc2l0aW9uXTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG9iamVjdFZhbHVlW2F0dHJpYnV0ZV07XG4gIH1cbn1cbiJdfQ==