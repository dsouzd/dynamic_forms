export const dynamicforms = {
    dynamicforms: {
        optional: '(Optional)',
        maxFileSize: 'Maximal zulässige Dateigröße',
        chooseFile: 'Datei(en) auswählen',
        startUpload: 'Upload starten',
        removeAll: 'Alles entfernen',
        upload: 'Hochladen',
        pleaseSelect: 'Wählen Sie:',
        enterValidValue: 'Bitte geben Sie einen gültigen Wert ein',
        validationErrors: 'Es liegen Validierungsfehler vor',
        definitionLoadError: 'Ein Fehler ist aufgetreten. Das Formular konnte nicht geladen werden.',
        documentUploadError: '[DE] An error occurred during the documents upload. Please try again.',
        fillOutProperly: 'Bitte Versuchen Sie es erneut, sobald alle Felder ordnugsgemäß',
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLmRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9hc3NldHMvdHJhbnNsYXRpb25zL2RlL2NvbW1vbi5kZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLENBQUMsTUFBTSxZQUFZLEdBQUc7SUFDMUIsWUFBWSxFQUFFO1FBQ1osUUFBUSxFQUFFLFlBQVk7UUFDdEIsV0FBVyxFQUFFLDhCQUE4QjtRQUMzQyxVQUFVLEVBQUUscUJBQXFCO1FBQ2pDLFdBQVcsRUFBRSxnQkFBZ0I7UUFDN0IsU0FBUyxFQUFFLGlCQUFpQjtRQUM1QixNQUFNLEVBQUUsV0FBVztRQUNuQixZQUFZLEVBQUUsYUFBYTtRQUMzQixlQUFlLEVBQUUseUNBQXlDO1FBQzFELGdCQUFnQixFQUFFLGtDQUFrQztRQUNwRCxtQkFBbUIsRUFDakIsdUVBQXVFO1FBQ3pFLG1CQUFtQixFQUNqQix1RUFBdUU7UUFDekUsZUFBZSxFQUNiLGdFQUFnRTtLQUNuRTtDQUNGLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgZHluYW1pY2Zvcm1zID0ge1xuICBkeW5hbWljZm9ybXM6IHtcbiAgICBvcHRpb25hbDogJyhPcHRpb25hbCknLFxuICAgIG1heEZpbGVTaXplOiAnTWF4aW1hbCB6dWzDpHNzaWdlIERhdGVpZ3LDtsOfZScsXG4gICAgY2hvb3NlRmlsZTogJ0RhdGVpKGVuKSBhdXN3w6RobGVuJyxcbiAgICBzdGFydFVwbG9hZDogJ1VwbG9hZCBzdGFydGVuJyxcbiAgICByZW1vdmVBbGw6ICdBbGxlcyBlbnRmZXJuZW4nLFxuICAgIHVwbG9hZDogJ0hvY2hsYWRlbicsXG4gICAgcGxlYXNlU2VsZWN0OiAnV8OkaGxlbiBTaWU6JyxcbiAgICBlbnRlclZhbGlkVmFsdWU6ICdCaXR0ZSBnZWJlbiBTaWUgZWluZW4gZ8O8bHRpZ2VuIFdlcnQgZWluJyxcbiAgICB2YWxpZGF0aW9uRXJyb3JzOiAnRXMgbGllZ2VuIFZhbGlkaWVydW5nc2ZlaGxlciB2b3InLFxuICAgIGRlZmluaXRpb25Mb2FkRXJyb3I6XG4gICAgICAnRWluIEZlaGxlciBpc3QgYXVmZ2V0cmV0ZW4uIERhcyBGb3JtdWxhciBrb25udGUgbmljaHQgZ2VsYWRlbiB3ZXJkZW4uJyxcbiAgICBkb2N1bWVudFVwbG9hZEVycm9yOlxuICAgICAgJ1tERV0gQW4gZXJyb3Igb2NjdXJyZWQgZHVyaW5nIHRoZSBkb2N1bWVudHMgdXBsb2FkLiBQbGVhc2UgdHJ5IGFnYWluLicsXG4gICAgZmlsbE91dFByb3Blcmx5OlxuICAgICAgJ0JpdHRlIFZlcnN1Y2hlbiBTaWUgZXMgZXJuZXV0LCBzb2JhbGQgYWxsZSBGZWxkZXIgb3JkbnVnc2dlbcOkw58nLFxuICB9LFxufTtcbiJdfQ==