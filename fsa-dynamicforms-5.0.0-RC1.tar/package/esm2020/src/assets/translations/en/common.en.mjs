export const dynamicforms = {
    dynamicforms: {
        optional: '(Optional)',
        maxFileSize: 'Maximum file size allowed',
        chooseFile: 'Choose file(s)',
        startUpload: 'Start upload',
        removeAll: 'Remove all',
        upload: 'Upload',
        pleaseSelect: 'Please select:',
        enterValidValue: 'Please enter valid value',
        validationErrors: 'There are validation errors',
        definitionLoadError: 'Error occurred. Form could not be loaded.',
        documentUploadError: 'An error occurred during the documents upload. Please try again.',
        fillOutProperly: 'Please retry once all of the fields have been properly filled-out.',
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLmVuLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9hc3NldHMvdHJhbnNsYXRpb25zL2VuL2NvbW1vbi5lbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLENBQUMsTUFBTSxZQUFZLEdBQUc7SUFDMUIsWUFBWSxFQUFFO1FBQ1osUUFBUSxFQUFFLFlBQVk7UUFDdEIsV0FBVyxFQUFFLDJCQUEyQjtRQUN4QyxVQUFVLEVBQUUsZ0JBQWdCO1FBQzVCLFdBQVcsRUFBRSxjQUFjO1FBQzNCLFNBQVMsRUFBRSxZQUFZO1FBQ3ZCLE1BQU0sRUFBRSxRQUFRO1FBQ2hCLFlBQVksRUFBRSxnQkFBZ0I7UUFDOUIsZUFBZSxFQUFFLDBCQUEwQjtRQUMzQyxnQkFBZ0IsRUFBRSw2QkFBNkI7UUFDL0MsbUJBQW1CLEVBQUUsMkNBQTJDO1FBQ2hFLG1CQUFtQixFQUNqQixrRUFBa0U7UUFDcEUsZUFBZSxFQUNiLG9FQUFvRTtLQUN2RTtDQUNGLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgZHluYW1pY2Zvcm1zID0ge1xuICBkeW5hbWljZm9ybXM6IHtcbiAgICBvcHRpb25hbDogJyhPcHRpb25hbCknLFxuICAgIG1heEZpbGVTaXplOiAnTWF4aW11bSBmaWxlIHNpemUgYWxsb3dlZCcsXG4gICAgY2hvb3NlRmlsZTogJ0Nob29zZSBmaWxlKHMpJyxcbiAgICBzdGFydFVwbG9hZDogJ1N0YXJ0IHVwbG9hZCcsXG4gICAgcmVtb3ZlQWxsOiAnUmVtb3ZlIGFsbCcsXG4gICAgdXBsb2FkOiAnVXBsb2FkJyxcbiAgICBwbGVhc2VTZWxlY3Q6ICdQbGVhc2Ugc2VsZWN0OicsXG4gICAgZW50ZXJWYWxpZFZhbHVlOiAnUGxlYXNlIGVudGVyIHZhbGlkIHZhbHVlJyxcbiAgICB2YWxpZGF0aW9uRXJyb3JzOiAnVGhlcmUgYXJlIHZhbGlkYXRpb24gZXJyb3JzJyxcbiAgICBkZWZpbml0aW9uTG9hZEVycm9yOiAnRXJyb3Igb2NjdXJyZWQuIEZvcm0gY291bGQgbm90IGJlIGxvYWRlZC4nLFxuICAgIGRvY3VtZW50VXBsb2FkRXJyb3I6XG4gICAgICAnQW4gZXJyb3Igb2NjdXJyZWQgZHVyaW5nIHRoZSBkb2N1bWVudHMgdXBsb2FkLiBQbGVhc2UgdHJ5IGFnYWluLicsXG4gICAgZmlsbE91dFByb3Blcmx5OlxuICAgICAgJ1BsZWFzZSByZXRyeSBvbmNlIGFsbCBvZiB0aGUgZmllbGRzIGhhdmUgYmVlbiBwcm9wZXJseSBmaWxsZWQtb3V0LicsXG4gIH0sXG59O1xuIl19