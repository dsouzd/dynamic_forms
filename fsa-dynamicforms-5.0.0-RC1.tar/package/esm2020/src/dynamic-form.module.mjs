import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { Config, ConfigModule, I18nModule } from '@spartacus/core';
import { ComponentsModule } from './components/components.module';
import { defaultFormConfig } from './core/config/default-form-config';
import { DynamicFormsConfig } from './core/config/form-config';
import { FormCMSModule } from './cms-components/form-cms/form-cms.module';
import { FormContainerModule } from './core/form-containers/form-container.module';
import { FormStoreModule } from './core/store/form-store.module';
import { FormOccModule } from './occ/adapters/form/form-occ.module';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/core";
export class DynamicFormModule {
}
DynamicFormModule.ɵfac = function DynamicFormModule_Factory(t) { return new (t || DynamicFormModule)(); };
DynamicFormModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: DynamicFormModule });
DynamicFormModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [{ provide: DynamicFormsConfig, useExisting: Config }, DatePipe], imports: [CommonModule,
        I18nModule,
        FormContainerModule,
        FormCMSModule,
        FormStoreModule,
        FormOccModule,
        ConfigModule.withConfig(defaultFormConfig),
        ComponentsModule, FormContainerModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DynamicFormModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule,
                    I18nModule,
                    FormContainerModule,
                    FormCMSModule,
                    FormStoreModule,
                    FormOccModule,
                    ConfigModule.withConfig(defaultFormConfig),
                    ComponentsModule,
                ],
                exports: [FormContainerModule],
                providers: [{ provide: DynamicFormsConfig, useExisting: Config }, DatePipe],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(DynamicFormModule, { imports: [CommonModule,
        I18nModule,
        FormContainerModule,
        FormCMSModule,
        FormStoreModule,
        FormOccModule, i1.ConfigModule, ComponentsModule], exports: [FormContainerModule] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1pYy1mb3JtLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvZHluYW1pYy1mb3JtLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsWUFBWSxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekMsT0FBTyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsVUFBVSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDbkUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sZ0NBQWdDLENBQUM7QUFDbEUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDdEUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDL0QsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDJDQUEyQyxDQUFDO0FBQzFFLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDhDQUE4QyxDQUFDO0FBQ25GLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUNqRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0scUNBQXFDLENBQUM7OztBQWdCcEUsTUFBTSxPQUFPLGlCQUFpQjs7a0ZBQWpCLGlCQUFpQjttRUFBakIsaUJBQWlCO3dFQUZqQixDQUFDLEVBQUUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLFdBQVcsRUFBRSxNQUFNLEVBQUUsRUFBRSxRQUFRLENBQUMsWUFWekUsWUFBWTtRQUNaLFVBQVU7UUFDVixtQkFBbUI7UUFDbkIsYUFBYTtRQUNiLGVBQWU7UUFDZixhQUFhO1FBQ2IsWUFBWSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQztRQUMxQyxnQkFBZ0IsRUFFUixtQkFBbUI7dUZBR2xCLGlCQUFpQjtjQWQ3QixRQUFRO2VBQUM7Z0JBQ1IsT0FBTyxFQUFFO29CQUNQLFlBQVk7b0JBQ1osVUFBVTtvQkFDVixtQkFBbUI7b0JBQ25CLGFBQWE7b0JBQ2IsZUFBZTtvQkFDZixhQUFhO29CQUNiLFlBQVksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUM7b0JBQzFDLGdCQUFnQjtpQkFDakI7Z0JBQ0QsT0FBTyxFQUFFLENBQUMsbUJBQW1CLENBQUM7Z0JBQzlCLFNBQVMsRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLFdBQVcsRUFBRSxNQUFNLEVBQUUsRUFBRSxRQUFRLENBQUM7YUFDNUU7O3dGQUNZLGlCQUFpQixjQVoxQixZQUFZO1FBQ1osVUFBVTtRQUNWLG1CQUFtQjtRQUNuQixhQUFhO1FBQ2IsZUFBZTtRQUNmLGFBQWEsbUJBRWIsZ0JBQWdCLGFBRVIsbUJBQW1CIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tbW9uTW9kdWxlLCBEYXRlUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29uZmlnLCBDb25maWdNb2R1bGUsIEkxOG5Nb2R1bGUgfSBmcm9tICdAc3BhcnRhY3VzL2NvcmUnO1xuaW1wb3J0IHsgQ29tcG9uZW50c01vZHVsZSB9IGZyb20gJy4vY29tcG9uZW50cy9jb21wb25lbnRzLm1vZHVsZSc7XG5pbXBvcnQgeyBkZWZhdWx0Rm9ybUNvbmZpZyB9IGZyb20gJy4vY29yZS9jb25maWcvZGVmYXVsdC1mb3JtLWNvbmZpZyc7XG5pbXBvcnQgeyBEeW5hbWljRm9ybXNDb25maWcgfSBmcm9tICcuL2NvcmUvY29uZmlnL2Zvcm0tY29uZmlnJztcbmltcG9ydCB7IEZvcm1DTVNNb2R1bGUgfSBmcm9tICcuL2Ntcy1jb21wb25lbnRzL2Zvcm0tY21zL2Zvcm0tY21zLm1vZHVsZSc7XG5pbXBvcnQgeyBGb3JtQ29udGFpbmVyTW9kdWxlIH0gZnJvbSAnLi9jb3JlL2Zvcm0tY29udGFpbmVycy9mb3JtLWNvbnRhaW5lci5tb2R1bGUnO1xuaW1wb3J0IHsgRm9ybVN0b3JlTW9kdWxlIH0gZnJvbSAnLi9jb3JlL3N0b3JlL2Zvcm0tc3RvcmUubW9kdWxlJztcbmltcG9ydCB7IEZvcm1PY2NNb2R1bGUgfSBmcm9tICcuL29jYy9hZGFwdGVycy9mb3JtL2Zvcm0tb2NjLm1vZHVsZSc7XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtcbiAgICBDb21tb25Nb2R1bGUsXG4gICAgSTE4bk1vZHVsZSxcbiAgICBGb3JtQ29udGFpbmVyTW9kdWxlLFxuICAgIEZvcm1DTVNNb2R1bGUsXG4gICAgRm9ybVN0b3JlTW9kdWxlLFxuICAgIEZvcm1PY2NNb2R1bGUsXG4gICAgQ29uZmlnTW9kdWxlLndpdGhDb25maWcoZGVmYXVsdEZvcm1Db25maWcpLFxuICAgIENvbXBvbmVudHNNb2R1bGUsXG4gIF0sXG4gIGV4cG9ydHM6IFtGb3JtQ29udGFpbmVyTW9kdWxlXSxcbiAgcHJvdmlkZXJzOiBbeyBwcm92aWRlOiBEeW5hbWljRm9ybXNDb25maWcsIHVzZUV4aXN0aW5nOiBDb25maWcgfSwgRGF0ZVBpcGVdLFxufSlcbmV4cG9ydCBjbGFzcyBEeW5hbWljRm9ybU1vZHVsZSB7fVxuIl19