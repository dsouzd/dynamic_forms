import { Component, Injector } from '@angular/core';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import { DynamicFormsConfig } from '../../core/config/form-config';
import { CurrencyService, LanguageService } from '@spartacus/core';
import { FormService } from '../../core/services/form/form.service';
import * as i0 from "@angular/core";
import * as i1 from "../../core/config/form-config";
import * as i2 from "@spartacus/core";
import * as i3 from "../../core/services/form/form.service";
import * as i4 from "@angular/common";
import * as i5 from "@angular/forms";
import * as i6 from "../error-notice/error-notice.component";
function CurrencyComponent_ng_container_0_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
} }
function CurrencyComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
    i0.ɵɵtext(4);
    i0.ɵɵtemplate(5, CurrencyComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "div", 4)(7, "div", 5)(8, "span", 6);
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "async");
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(11, "input", 7);
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(12, "cx-error-notice", 8);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 11, ctx_r0.currentCurrency$));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("formControlName", ctx_r0.config.name);
    i0.ɵɵattribute("placeholder", ctx_r0.placeHolder)("name", ctx_r0.config.name)("readonly", ctx_r0.config.readonly ? ctx_r0.config.readonly : null);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
} }
export class CurrencyComponent extends AbstractFormComponent {
    constructor(appConfig, languageService, injector, formService, currencyService) {
        super(appConfig, languageService, injector, formService);
        this.appConfig = appConfig;
        this.languageService = languageService;
        this.injector = injector;
        this.formService = formService;
        this.currencyService = currencyService;
        this.currentCurrency$ = this.currencyService.getActive();
    }
}
CurrencyComponent.ɵfac = function CurrencyComponent_Factory(t) { return new (t || CurrencyComponent)(i0.ɵɵdirectiveInject(i1.DynamicFormsConfig), i0.ɵɵdirectiveInject(i2.LanguageService), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i3.FormService), i0.ɵɵdirectiveInject(i2.CurrencyService)); };
CurrencyComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CurrencyComponent, selectors: [["cx-currency"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], [1, "input-group", "mb-3"], [1, "input-group-prepend"], [1, "input-group-text"], ["type", "text", 1, "form-control", 3, "formControlName"], [3, "warn", "parentConfig"]], template: function CurrencyComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, CurrencyComponent_ng_container_0_Template, 13, 13, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i4.NgIf, i5.DefaultValueAccessor, i5.NgControlStatus, i5.NgControlStatusGroup, i5.FormGroupDirective, i5.FormControlName, i6.ErrorNoticeComponent, i4.AsyncPipe, i2.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CurrencyComponent, [{
        type: Component,
        args: [{ selector: 'cx-currency', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <div class=\"input-group mb-3\">\n        <div class=\"input-group-prepend\">\n          <span class=\"input-group-text\">{{ currentCurrency$ | async }}</span>\n        </div>\n        <input\n          type=\"text\"\n          class=\"form-control\"\n          [attr.placeholder]=\"placeHolder\"\n          [formControlName]=\"config.name\"\n          [attr.name]=\"config.name\"\n          [attr.readonly]=\"config.readonly ? config.readonly : null\"\n        />\n      </div>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
    }], function () { return [{ type: i1.DynamicFormsConfig }, { type: i2.LanguageService }, { type: i0.Injector }, { type: i3.FormService }, { type: i2.CurrencyService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VycmVuY3kuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb21wb25lbnRzL2N1cnJlbmN5L2N1cnJlbmN5LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9jdXJyZW5jeS9jdXJyZW5jeS5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUVwRCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSwwQ0FBMEMsQ0FBQztBQUNqRixPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUNuRSxPQUFPLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ25FLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSx1Q0FBdUMsQ0FBQzs7Ozs7Ozs7O0lDQTVELDZCQUF1QztJQUNyQyxZQUNGOztJQUFBLDBCQUFlOztJQURiLGVBQ0Y7SUFERSw4RUFDRjs7O0lBUFIsNkJBQTRCO0lBQzFCLDhCQUF3RSxhQUFBLGVBQUE7SUFHbEUsWUFDQTtJQUFBLG1HQUVlO0lBQ2pCLGlCQUFRO0lBQ1IsOEJBQThCLGFBQUEsY0FBQTtJQUVLLFlBQThCOztJQUFBLGlCQUFPLEVBQUE7SUFFdEUsNEJBT0U7SUFDSixpQkFBTSxFQUFBO0lBRVIsc0NBR21CO0lBQ3JCLGlCQUFNO0lBQ1IsMEJBQWU7OztJQTNCYyxlQUFtQjtJQUFuQix3Q0FBbUIsZ0NBQUE7SUFHeEMsZUFDQTtJQURBLDZDQUNBO0lBQWUsZUFBc0I7SUFBdEIsOENBQXNCO0lBTUosZUFBOEI7SUFBOUIscUVBQThCO0lBTTdELGVBQStCO0lBQS9CLG9EQUErQjtJQUQvQixpREFBZ0MsNEJBQUEsb0VBQUE7SUFRcEMsZUFBb0M7SUFBcEMsZ0VBQW9DLCtCQUFBOztBRGIxQyxNQUFNLE9BQU8saUJBQWtCLFNBQVEscUJBQXFCO0lBRzFELFlBQ1ksU0FBNkIsRUFDN0IsZUFBZ0MsRUFDaEMsUUFBa0IsRUFDbEIsV0FBd0IsRUFDeEIsZUFBZ0M7UUFFMUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxlQUFlLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBTi9DLGNBQVMsR0FBVCxTQUFTLENBQW9CO1FBQzdCLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQUNoQyxhQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ2xCLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBQ3hCLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQVA1QyxxQkFBZ0IsR0FBdUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLEVBQUUsQ0FBQztJQVV4RSxDQUFDOztrRkFYVSxpQkFBaUI7b0VBQWpCLGlCQUFpQjtRQ1g5QixzRkE0QmU7O1FBNUJBLGdDQUFXOzt1RkRXYixpQkFBaUI7Y0FKN0IsU0FBUzsyQkFDRSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbmplY3RvciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgQWJzdHJhY3RGb3JtQ29tcG9uZW50IH0gZnJvbSAnLi4vYWJzdHJhY3QtZm9ybS9hYnN0cmFjdC1mb3JtLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBEeW5hbWljRm9ybXNDb25maWcgfSBmcm9tICcuLi8uLi9jb3JlL2NvbmZpZy9mb3JtLWNvbmZpZyc7XG5pbXBvcnQgeyBDdXJyZW5jeVNlcnZpY2UsIExhbmd1YWdlU2VydmljZSB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBGb3JtU2VydmljZSB9IGZyb20gJy4uLy4uL2NvcmUvc2VydmljZXMvZm9ybS9mb3JtLnNlcnZpY2UnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjeC1jdXJyZW5jeScsXG4gIHRlbXBsYXRlVXJsOiAnLi9jdXJyZW5jeS5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEN1cnJlbmN5Q29tcG9uZW50IGV4dGVuZHMgQWJzdHJhY3RGb3JtQ29tcG9uZW50IHtcbiAgY3VycmVudEN1cnJlbmN5JDogT2JzZXJ2YWJsZTxzdHJpbmc+ID0gdGhpcy5jdXJyZW5jeVNlcnZpY2UuZ2V0QWN0aXZlKCk7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJvdGVjdGVkIGFwcENvbmZpZzogRHluYW1pY0Zvcm1zQ29uZmlnLFxuICAgIHByb3RlY3RlZCBsYW5ndWFnZVNlcnZpY2U6IExhbmd1YWdlU2VydmljZSxcbiAgICBwcm90ZWN0ZWQgaW5qZWN0b3I6IEluamVjdG9yLFxuICAgIHByb3RlY3RlZCBmb3JtU2VydmljZTogRm9ybVNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIGN1cnJlbmN5U2VydmljZTogQ3VycmVuY3lTZXJ2aWNlXG4gICkge1xuICAgIHN1cGVyKGFwcENvbmZpZywgbGFuZ3VhZ2VTZXJ2aWNlLCBpbmplY3RvciwgZm9ybVNlcnZpY2UpO1xuICB9XG59XG4iLCI8bmctY29udGFpbmVyICpuZ0lmPVwiZ3JvdXBcIj5cbiAgPGRpdiBjbGFzcz1cImR5bmFtaWMtZmllbGRcIiBbZm9ybUdyb3VwXT1cImdyb3VwXCIgW2hpZGRlbl09XCJjb25maWcuaGlkZGVuXCI+XG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgIDxsYWJlbCBjbGFzcz1cImNvbC1mb3JtLWxhYmVsXCI+XG4gICAgICAgIHt7IGxhYmVsIH19XG4gICAgICAgIDxuZy1jb250YWluZXIgKm5nSWY9XCIhY29uZmlnLnJlcXVpcmVkXCI+XG4gICAgICAgICAge3sgJ2R5bmFtaWNmb3Jtcy5vcHRpb25hbCcgfCBjeFRyYW5zbGF0ZSB9fVxuICAgICAgICA8L25nLWNvbnRhaW5lcj5cbiAgICAgIDwvbGFiZWw+XG4gICAgICA8ZGl2IGNsYXNzPVwiaW5wdXQtZ3JvdXAgbWItM1wiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaW5wdXQtZ3JvdXAtcHJlcGVuZFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaW5wdXQtZ3JvdXAtdGV4dFwiPnt7IGN1cnJlbnRDdXJyZW5jeSQgfCBhc3luYyB9fTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICBjbGFzcz1cImZvcm0tY29udHJvbFwiXG4gICAgICAgICAgW2F0dHIucGxhY2Vob2xkZXJdPVwicGxhY2VIb2xkZXJcIlxuICAgICAgICAgIFtmb3JtQ29udHJvbE5hbWVdPVwiY29uZmlnLm5hbWVcIlxuICAgICAgICAgIFthdHRyLm5hbWVdPVwiY29uZmlnLm5hbWVcIlxuICAgICAgICAgIFthdHRyLnJlYWRvbmx5XT1cImNvbmZpZy5yZWFkb25seSA/IGNvbmZpZy5yZWFkb25seSA6IG51bGxcIlxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGN4LWVycm9yLW5vdGljZVxuICAgICAgW3dhcm5dPVwiZ3JvdXAuY29udHJvbHNbY29uZmlnLm5hbWVdXCJcbiAgICAgIFtwYXJlbnRDb25maWddPVwiY29uZmlnXCJcbiAgICA+PC9jeC1lcnJvci1ub3RpY2U+XG4gIDwvZGl2PlxuPC9uZy1jb250YWluZXI+XG4iXX0=