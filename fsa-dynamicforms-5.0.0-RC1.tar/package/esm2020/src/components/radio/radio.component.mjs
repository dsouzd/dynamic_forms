import { Component } from '@angular/core';
import { AbstractOptionsComponent } from '../abstract-options/abstract-options.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/forms";
import * as i3 from "../error-notice/error-notice.component";
import * as i4 from "@spartacus/core";
function RadioComponent_ng_container_0_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
} }
function RadioComponent_ng_container_0_div_6_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const activeLang_r5 = ctx.ngIf;
    const option_r3 = i0.ɵɵnextContext().$implicit;
    const ctx_r4 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", ctx_r4.getLocalizedOption(option_r3.label, activeLang_r5), " ");
} }
function RadioComponent_ng_container_0_div_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵelement(1, "input", 6);
    i0.ɵɵelementStart(2, "label", 7);
    i0.ɵɵtemplate(3, RadioComponent_ng_container_0_div_6_ng_container_3_Template, 2, 1, "ng-container", 0);
    i0.ɵɵpipe(4, "async");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const option_r3 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵpropertyInterpolate("value", option_r3.name);
    i0.ɵɵproperty("formControlName", ctx_r2.config.name);
    i0.ɵɵattribute("name", ctx_r2.config.name)("id", ctx_r2.config.name + option_r3.name)("readonly", ctx_r2.config.readonly ? ctx_r2.config.readonly : null);
    i0.ɵɵadvance(1);
    i0.ɵɵattribute("for", ctx_r2.config.name + option_r3.name);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(4, 7, ctx_r2.activeLang$));
} }
function RadioComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 1)(2, "label", 2);
    i0.ɵɵtext(3);
    i0.ɵɵtemplate(4, RadioComponent_ng_container_0_ng_container_4_Template, 3, 3, "ng-container", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "div", 3);
    i0.ɵɵtemplate(6, RadioComponent_ng_container_0_div_6_Template, 5, 9, "div", 4);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(7, "cx-error-notice", 5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r0.config.options);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
} }
export class RadioComponent extends AbstractOptionsComponent {
}
RadioComponent.ɵfac = /*@__PURE__*/ function () { let ɵRadioComponent_BaseFactory; return function RadioComponent_Factory(t) { return (ɵRadioComponent_BaseFactory || (ɵRadioComponent_BaseFactory = i0.ɵɵgetInheritedFactory(RadioComponent)))(t || RadioComponent); }; }();
RadioComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RadioComponent, selectors: [["cx-radio"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "col-form-label"], [1, "form-check"], [4, "ngFor", "ngForOf"], [3, "warn", "parentConfig"], ["type", "radio", 1, "form-check-input", 3, "value", "formControlName"], [1, "pl-3", "pt-1"]], template: function RadioComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, RadioComponent_ng_container_0_Template, 8, 7, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i1.NgForOf, i1.NgIf, i2.DefaultValueAccessor, i2.RadioControlValueAccessor, i2.NgControlStatus, i2.NgControlStatusGroup, i2.FormGroupDirective, i2.FormControlName, i3.ErrorNoticeComponent, i1.AsyncPipe, i4.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RadioComponent, [{
        type: Component,
        args: [{ selector: 'cx-radio', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <label class=\"col-form-label\">\n      {{ label }}\n      <ng-container *ngIf=\"!config.required\">\n        {{ 'dynamicforms.optional' | cxTranslate }}\n      </ng-container>\n    </label>\n    <div class=\"form-check\">\n      <div *ngFor=\"let option of config.options\">\n        <input\n          class=\"form-check-input\"\n          type=\"radio\"\n          [attr.name]=\"config.name\"\n          [attr.id]=\"config.name + option.name\"\n          value=\"{{ option.name }}\"\n          [formControlName]=\"config.name\"\n          [attr.readonly]=\"config.readonly ? config.readonly : null\"\n        />\n        <label class=\"pl-3 pt-1\" [attr.for]=\"config.name + option.name\">\n          <ng-container *ngIf=\"activeLang$ | async as activeLang\">\n            {{ getLocalizedOption(option.label, activeLang) }}\n          </ng-container>\n        </label>\n      </div>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmFkaW8uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb21wb25lbnRzL3JhZGlvL3JhZGlvLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9yYWRpby9yYWRpby5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFDLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLGdEQUFnRCxDQUFDOzs7Ozs7O0lDR3BGLDZCQUF1QztJQUNyQyxZQUNGOztJQUFBLDBCQUFlOztJQURiLGVBQ0Y7SUFERSw4RUFDRjs7O0lBY0ksNkJBQXdEO0lBQ3RELFlBQ0Y7SUFBQSwwQkFBZTs7Ozs7SUFEYixlQUNGO0lBREUsMEZBQ0Y7OztJQWJKLDJCQUEyQztJQUN6QywyQkFRRTtJQUNGLGdDQUFnRTtJQUM5RCxzR0FFZTs7SUFDakIsaUJBQVEsRUFBQTs7OztJQVJOLGVBQXlCO0lBQXpCLGlEQUF5QjtJQUN6QixvREFBK0I7SUFIL0IsMENBQXlCLDJDQUFBLG9FQUFBO0lBTUYsZUFBc0M7SUFBdEMsMERBQXNDO0lBQzlDLGVBQTBCO0lBQTFCLCtEQUEwQjs7O0lBcEJuRCw2QkFBNEI7SUFDMUIsOEJBQXdFLGVBQUE7SUFFcEUsWUFDQTtJQUFBLGdHQUVlO0lBQ2pCLGlCQUFRO0lBQ1IsOEJBQXdCO0lBQ3RCLDhFQWVNO0lBQ1IsaUJBQU07SUFDTixxQ0FHbUI7SUFDckIsaUJBQU07SUFDUiwwQkFBZTs7O0lBOUJjLGVBQW1CO0lBQW5CLHdDQUFtQixnQ0FBQTtJQUUxQyxlQUNBO0lBREEsNkNBQ0E7SUFBZSxlQUFzQjtJQUF0Qiw4Q0FBc0I7SUFLYixlQUFpQjtJQUFqQiwrQ0FBaUI7SUFrQnpDLGVBQW9DO0lBQXBDLGdFQUFvQywrQkFBQTs7QURwQjFDLE1BQU0sT0FBTyxjQUFlLFNBQVEsd0JBQXdCOzs4TkFBL0MsY0FBYyxTQUFkLGNBQWM7aUVBQWQsY0FBYztRQ1AzQixpRkErQmU7O1FBL0JBLGdDQUFXOzt1RkRPYixjQUFjO2NBSjFCLFNBQVM7MkJBQ0UsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWJzdHJhY3RPcHRpb25zQ29tcG9uZW50IH0gZnJvbSAnLi4vYWJzdHJhY3Qtb3B0aW9ucy9hYnN0cmFjdC1vcHRpb25zLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2N4LXJhZGlvJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3JhZGlvLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgUmFkaW9Db21wb25lbnQgZXh0ZW5kcyBBYnN0cmFjdE9wdGlvbnNDb21wb25lbnQge31cbiIsIjxuZy1jb250YWluZXIgKm5nSWY9XCJncm91cFwiPlxuICA8ZGl2IGNsYXNzPVwiZHluYW1pYy1maWVsZFwiIFtmb3JtR3JvdXBdPVwiZ3JvdXBcIiBbaGlkZGVuXT1cImNvbmZpZy5oaWRkZW5cIj5cbiAgICA8bGFiZWwgY2xhc3M9XCJjb2wtZm9ybS1sYWJlbFwiPlxuICAgICAge3sgbGFiZWwgfX1cbiAgICAgIDxuZy1jb250YWluZXIgKm5nSWY9XCIhY29uZmlnLnJlcXVpcmVkXCI+XG4gICAgICAgIHt7ICdkeW5hbWljZm9ybXMub3B0aW9uYWwnIHwgY3hUcmFuc2xhdGUgfX1cbiAgICAgIDwvbmctY29udGFpbmVyPlxuICAgIDwvbGFiZWw+XG4gICAgPGRpdiBjbGFzcz1cImZvcm0tY2hlY2tcIj5cbiAgICAgIDxkaXYgKm5nRm9yPVwibGV0IG9wdGlvbiBvZiBjb25maWcub3B0aW9uc1wiPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICBjbGFzcz1cImZvcm0tY2hlY2staW5wdXRcIlxuICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgW2F0dHIubmFtZV09XCJjb25maWcubmFtZVwiXG4gICAgICAgICAgW2F0dHIuaWRdPVwiY29uZmlnLm5hbWUgKyBvcHRpb24ubmFtZVwiXG4gICAgICAgICAgdmFsdWU9XCJ7eyBvcHRpb24ubmFtZSB9fVwiXG4gICAgICAgICAgW2Zvcm1Db250cm9sTmFtZV09XCJjb25maWcubmFtZVwiXG4gICAgICAgICAgW2F0dHIucmVhZG9ubHldPVwiY29uZmlnLnJlYWRvbmx5ID8gY29uZmlnLnJlYWRvbmx5IDogbnVsbFwiXG4gICAgICAgIC8+XG4gICAgICAgIDxsYWJlbCBjbGFzcz1cInBsLTMgcHQtMVwiIFthdHRyLmZvcl09XCJjb25maWcubmFtZSArIG9wdGlvbi5uYW1lXCI+XG4gICAgICAgICAgPG5nLWNvbnRhaW5lciAqbmdJZj1cImFjdGl2ZUxhbmckIHwgYXN5bmMgYXMgYWN0aXZlTGFuZ1wiPlxuICAgICAgICAgICAge3sgZ2V0TG9jYWxpemVkT3B0aW9uKG9wdGlvbi5sYWJlbCwgYWN0aXZlTGFuZykgfX1cbiAgICAgICAgICA8L25nLWNvbnRhaW5lcj5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxjeC1lcnJvci1ub3RpY2VcbiAgICAgIFt3YXJuXT1cImdyb3VwLmNvbnRyb2xzW2NvbmZpZy5uYW1lXVwiXG4gICAgICBbcGFyZW50Q29uZmlnXT1cImNvbmZpZ1wiXG4gICAgPjwvY3gtZXJyb3Itbm90aWNlPlxuICA8L2Rpdj5cbjwvbmctY29udGFpbmVyPlxuIl19