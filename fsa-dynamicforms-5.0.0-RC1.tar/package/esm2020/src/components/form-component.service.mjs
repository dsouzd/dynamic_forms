import { Injectable } from '@angular/core';
import { LaunchDialogService } from '@spartacus/storefront';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/storefront";
export class FormComponentService {
    constructor(launchDialogService) {
        this.launchDialogService = launchDialogService;
        this.isPopulatedFormInvalidSource = new BehaviorSubject(null);
        this.isPopulatedFormInvalid = this.isPopulatedFormInvalidSource.asObservable();
    }
    launchFormPopupError() {
        const dialog = this.launchDialogService.openDialog("FORM_POPUP_ERROR" /* LAUNCH_CALLER.FORM_POPUP_ERROR */);
        return dialog?.pipe(take(1)).subscribe();
    }
}
FormComponentService.ɵfac = function FormComponentService_Factory(t) { return new (t || FormComponentService)(i0.ɵɵinject(i1.LaunchDialogService)); };
FormComponentService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormComponentService, factory: FormComponentService.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormComponentService, [{
        type: Injectable
    }], function () { return [{ type: i1.LaunchDialogService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1jb21wb25lbnQuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9mb3JtLWNvbXBvbmVudC5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLG1CQUFtQixFQUFpQixNQUFNLHVCQUF1QixDQUFDO0FBQzNFLE9BQU8sRUFBRSxlQUFlLEVBQWdCLE1BQU0sTUFBTSxDQUFDO0FBQ3JELE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7O0FBR3RDLE1BQU0sT0FBTyxvQkFBb0I7SUFDL0IsWUFBc0IsbUJBQXdDO1FBQXhDLHdCQUFtQixHQUFuQixtQkFBbUIsQ0FBcUI7UUFFOUQsaUNBQTRCLEdBQUcsSUFBSSxlQUFlLENBQVUsSUFBSSxDQUFDLENBQUM7UUFDbEUsMkJBQXNCLEdBQUcsSUFBSSxDQUFDLDRCQUE0QixDQUFDLFlBQVksRUFBRSxDQUFDO0lBSFQsQ0FBQztJQUtsRSxvQkFBb0I7UUFDbEIsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUseURBRWpELENBQUM7UUFFRixPQUFPLE1BQU0sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDM0MsQ0FBQzs7d0ZBWlUsb0JBQW9COzBFQUFwQixvQkFBb0IsV0FBcEIsb0JBQW9CO3VGQUFwQixvQkFBb0I7Y0FEaEMsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IExhdW5jaERpYWxvZ1NlcnZpY2UsIExBVU5DSF9DQUxMRVIgfSBmcm9tICdAc3BhcnRhY3VzL3N0b3JlZnJvbnQnO1xuaW1wb3J0IHsgQmVoYXZpb3JTdWJqZWN0LCBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IHRha2UgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBGb3JtQ29tcG9uZW50U2VydmljZSB7XG4gIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBsYXVuY2hEaWFsb2dTZXJ2aWNlOiBMYXVuY2hEaWFsb2dTZXJ2aWNlKSB7fVxuXG4gIGlzUG9wdWxhdGVkRm9ybUludmFsaWRTb3VyY2UgPSBuZXcgQmVoYXZpb3JTdWJqZWN0PGJvb2xlYW4+KG51bGwpO1xuICBpc1BvcHVsYXRlZEZvcm1JbnZhbGlkID0gdGhpcy5pc1BvcHVsYXRlZEZvcm1JbnZhbGlkU291cmNlLmFzT2JzZXJ2YWJsZSgpO1xuXG4gIGxhdW5jaEZvcm1Qb3B1cEVycm9yKCk6IFN1YnNjcmlwdGlvbiB7XG4gICAgY29uc3QgZGlhbG9nID0gdGhpcy5sYXVuY2hEaWFsb2dTZXJ2aWNlLm9wZW5EaWFsb2coXG4gICAgICBMQVVOQ0hfQ0FMTEVSLkZPUk1fUE9QVVBfRVJST1JcbiAgICApO1xuXG4gICAgcmV0dXJuIGRpYWxvZz8ucGlwZSh0YWtlKDEpKS5zdWJzY3JpYmUoKTtcbiAgfVxufVxuIl19