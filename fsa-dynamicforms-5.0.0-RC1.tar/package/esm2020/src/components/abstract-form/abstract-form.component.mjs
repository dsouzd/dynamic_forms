import { Component, HostBinding, Injector, } from '@angular/core';
import { LanguageService } from '@spartacus/core';
import { Subscription } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { DynamicFormsConfig } from '../../core/config/form-config';
import { FormService } from '../../core/services/form/form.service';
import * as i0 from "@angular/core";
import * as i1 from "../../core/config/form-config";
import * as i2 from "@spartacus/core";
import * as i3 from "../../core/services/form/form.service";
export class AbstractFormComponent {
    constructor(appConfig, languageService, injector, formService) {
        this.appConfig = appConfig;
        this.languageService = languageService;
        this.injector = injector;
        this.formService = formService;
        this.subscription = new Subscription();
        this.activeLang$ = this.languageService.getActive();
    }
    ngOnInit() {
        this.setHostComponentClass();
        this.setLocalizedProperties();
        this.controlPrefill();
        this.interDependancyValueCheck();
    }
    setHostComponentClass() {
        this.hostComponentClass =
            this.config && this.config.gridClass ? this.config.gridClass : 'col-12';
        if (this.config && this.config.cssClass) {
            this.hostComponentClass = `${this.hostComponentClass} ${this.config.cssClass}`;
        }
    }
    setLocalizedProperties() {
        this.subscription.add(this.languageService
            .getActive()
            .pipe(map(lang => {
            if (this.config?.label) {
                this.label = this.config.label[lang]
                    ? this.config.label[lang]
                    : this.config.label.default;
            }
            if (this.config?.placeholder) {
                this.placeHolder = this.config.placeholder[lang]
                    ? this.config.placeholder[lang]
                    : this.config.placeholder.default;
            }
        }))
            .subscribe());
    }
    controlPrefill() {
        if (this.config.prefillValue) {
            const targetObject = this.appConfig.dynamicForms.prefill[this.config.prefillValue.targetObject];
            if (targetObject && targetObject.prefillResolver) {
                const prefillResolver = this.injector.get(targetObject.prefillResolver);
                this.subscription.add(prefillResolver
                    .getPrefillValue(this.config.prefillValue.targetValue)
                    .subscribe(value => {
                    if (value) {
                        this.group.get(this.config.name).setValue(value);
                    }
                }));
            }
        }
    }
    interDependancyValueCheck() {
        const triggeredControl = this.formService.getFormControlForCode(this.config.name, this.group.root);
        if (triggeredControl) {
            this.subscription.add(triggeredControl.valueChanges
                .pipe(filter(_ => !!this.config.validations), map(_ => {
                this.config.validations.forEach(validation => {
                    if (validation.arguments && validation.arguments.length > 1) {
                        const targetControl = this.formService.getFormControlForCode(validation.arguments[0].value, this.group.root);
                        targetControl.updateValueAndValidity({
                            onlySelf: true,
                            emitEvent: false,
                        });
                    }
                });
            }))
                .subscribe());
        }
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
AbstractFormComponent.ɵfac = function AbstractFormComponent_Factory(t) { return new (t || AbstractFormComponent)(i0.ɵɵdirectiveInject(i1.DynamicFormsConfig), i0.ɵɵdirectiveInject(i2.LanguageService), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i3.FormService)); };
AbstractFormComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AbstractFormComponent, selectors: [["ng-component"]], hostVars: 2, hostBindings: function AbstractFormComponent_HostBindings(rf, ctx) { if (rf & 2) {
        i0.ɵɵclassMap(ctx.hostComponentClass);
    } }, decls: 0, vars: 0, template: function AbstractFormComponent_Template(rf, ctx) { }, encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AbstractFormComponent, [{
        type: Component,
        args: [{ template: '' }]
    }], function () { return [{ type: i1.DynamicFormsConfig }, { type: i2.LanguageService }, { type: i0.Injector }, { type: i3.FormService }]; }, { hostComponentClass: [{
            type: HostBinding,
            args: ['class']
        }] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWJzdHJhY3QtZm9ybS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvbXBvbmVudHMvYWJzdHJhY3QtZm9ybS9hYnN0cmFjdC1mb3JtLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0wsU0FBUyxFQUNULFdBQVcsRUFDWCxRQUFRLEdBR1QsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDcEMsT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUM3QyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUduRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sdUNBQXVDLENBQUM7Ozs7O0FBR3BFLE1BQU0sT0FBTyxxQkFBcUI7SUFDaEMsWUFDWSxTQUE2QixFQUM3QixlQUFnQyxFQUNoQyxRQUFrQixFQUNsQixXQUF3QjtRQUh4QixjQUFTLEdBQVQsU0FBUyxDQUFvQjtRQUM3QixvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7UUFDaEMsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixnQkFBVyxHQUFYLFdBQVcsQ0FBYTtRQVFwQyxpQkFBWSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7UUFDbEMsZ0JBQVcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBUjVDLENBQUM7SUFVSixRQUFRO1FBQ04sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDOUIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFFUyxxQkFBcUI7UUFDN0IsSUFBSSxDQUFDLGtCQUFrQjtZQUNyQixJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQzFFLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRTtZQUN2QyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsR0FBRyxJQUFJLENBQUMsa0JBQWtCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNoRjtJQUNILENBQUM7SUFFUyxzQkFBc0I7UUFDOUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQ25CLElBQUksQ0FBQyxlQUFlO2FBQ2pCLFNBQVMsRUFBRTthQUNYLElBQUksQ0FDSCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDVCxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFO2dCQUN0QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztvQkFDbEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztvQkFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQzthQUMvQjtZQUNELElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO29CQUM5QyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO29CQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDO2FBQ3JDO1FBQ0gsQ0FBQyxDQUFDLENBQ0g7YUFDQSxTQUFTLEVBQUUsQ0FDZixDQUFDO0lBQ0osQ0FBQztJQUVTLGNBQWM7UUFDdEIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtZQUM1QixNQUFNLFlBQVksR0FDaEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUNqQyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQ3RDLENBQUM7WUFDSixJQUFJLFlBQVksSUFBSSxZQUFZLENBQUMsZUFBZSxFQUFFO2dCQUNoRCxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FDdkMsWUFBWSxDQUFDLGVBQWUsQ0FDN0IsQ0FBQztnQkFDRixJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FDbkIsZUFBZTtxQkFDWixlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDO3FCQUNyRCxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ2pCLElBQUksS0FBSyxFQUFFO3dCQUNULElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUNsRDtnQkFDSCxDQUFDLENBQUMsQ0FDTCxDQUFDO2FBQ0g7U0FDRjtJQUNILENBQUM7SUFFUyx5QkFBeUI7UUFDakMsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLHFCQUFxQixDQUM3RCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFDaEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQ2hCLENBQUM7UUFDRixJQUFJLGdCQUFnQixFQUFFO1lBQ3BCLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUNuQixnQkFBZ0IsQ0FBQyxZQUFZO2lCQUMxQixJQUFJLENBQ0gsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQ3RDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDTixJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEVBQUU7b0JBQzNDLElBQUksVUFBVSxDQUFDLFNBQVMsSUFBSSxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQzNELE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMscUJBQXFCLENBQzFELFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUM3QixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FDaEIsQ0FBQzt3QkFDRixhQUFhLENBQUMsc0JBQXNCLENBQUM7NEJBQ25DLFFBQVEsRUFBRSxJQUFJOzRCQUNkLFNBQVMsRUFBRSxLQUFLO3lCQUNqQixDQUFDLENBQUM7cUJBQ0o7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FDSDtpQkFDQSxTQUFTLEVBQUUsQ0FDZixDQUFDO1NBQ0g7SUFDSCxDQUFDO0lBRUQsV0FBVztRQUNULElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtZQUNyQixJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ2pDO0lBQ0gsQ0FBQzs7MEZBOUdVLHFCQUFxQjt3RUFBckIscUJBQXFCOzs7dUZBQXJCLHFCQUFxQjtjQURqQyxTQUFTO2VBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFO29KQVNILGtCQUFrQjtrQkFBdkMsV0FBVzttQkFBQyxPQUFPIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQ29tcG9uZW50LFxuICBIb3N0QmluZGluZyxcbiAgSW5qZWN0b3IsXG4gIE9uRGVzdHJveSxcbiAgT25Jbml0LFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFVudHlwZWRGb3JtR3JvdXAgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBMYW5ndWFnZVNlcnZpY2UgfSBmcm9tICdAc3BhcnRhY3VzL2NvcmUnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBmaWx0ZXIsIG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IER5bmFtaWNGb3Jtc0NvbmZpZyB9IGZyb20gJy4uLy4uL2NvcmUvY29uZmlnL2Zvcm0tY29uZmlnJztcbmltcG9ydCB7IEZpZWxkQ29uZmlnIH0gZnJvbSAnLi4vLi4vY29yZS9tb2RlbHMvZm9ybS1jb25maWcuaW50ZXJmYWNlJztcbmltcG9ydCB7IFByZWZpbGxSZXNvbHZlciB9IGZyb20gJy4uLy4uL2NvcmUvcmVzb2x2ZXJzL3ByZWZpbGwtcmVzb2x2ZXIuaW50ZXJmYWNlJztcbmltcG9ydCB7IEZvcm1TZXJ2aWNlIH0gZnJvbSAnLi4vLi4vY29yZS9zZXJ2aWNlcy9mb3JtL2Zvcm0uc2VydmljZSc7XG5cbkBDb21wb25lbnQoeyB0ZW1wbGF0ZTogJycgfSlcbmV4cG9ydCBjbGFzcyBBYnN0cmFjdEZvcm1Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByb3RlY3RlZCBhcHBDb25maWc6IER5bmFtaWNGb3Jtc0NvbmZpZyxcbiAgICBwcm90ZWN0ZWQgbGFuZ3VhZ2VTZXJ2aWNlOiBMYW5ndWFnZVNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIGluamVjdG9yOiBJbmplY3RvcixcbiAgICBwcm90ZWN0ZWQgZm9ybVNlcnZpY2U6IEZvcm1TZXJ2aWNlXG4gICkge31cblxuICBASG9zdEJpbmRpbmcoJ2NsYXNzJykgaG9zdENvbXBvbmVudENsYXNzOiBzdHJpbmc7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIHBsYWNlSG9sZGVyOiBzdHJpbmc7XG4gIGNvbmZpZzogRmllbGRDb25maWc7XG4gIGdyb3VwOiBVbnR5cGVkRm9ybUdyb3VwO1xuICBzdWJzY3JpcHRpb24gPSBuZXcgU3Vic2NyaXB0aW9uKCk7XG4gIGFjdGl2ZUxhbmckID0gdGhpcy5sYW5ndWFnZVNlcnZpY2UuZ2V0QWN0aXZlKCk7XG5cbiAgbmdPbkluaXQoKSB7XG4gICAgdGhpcy5zZXRIb3N0Q29tcG9uZW50Q2xhc3MoKTtcbiAgICB0aGlzLnNldExvY2FsaXplZFByb3BlcnRpZXMoKTtcbiAgICB0aGlzLmNvbnRyb2xQcmVmaWxsKCk7XG4gICAgdGhpcy5pbnRlckRlcGVuZGFuY3lWYWx1ZUNoZWNrKCk7XG4gIH1cblxuICBwcm90ZWN0ZWQgc2V0SG9zdENvbXBvbmVudENsYXNzKCkge1xuICAgIHRoaXMuaG9zdENvbXBvbmVudENsYXNzID1cbiAgICAgIHRoaXMuY29uZmlnICYmIHRoaXMuY29uZmlnLmdyaWRDbGFzcyA/IHRoaXMuY29uZmlnLmdyaWRDbGFzcyA6ICdjb2wtMTInO1xuICAgIGlmICh0aGlzLmNvbmZpZyAmJiB0aGlzLmNvbmZpZy5jc3NDbGFzcykge1xuICAgICAgdGhpcy5ob3N0Q29tcG9uZW50Q2xhc3MgPSBgJHt0aGlzLmhvc3RDb21wb25lbnRDbGFzc30gJHt0aGlzLmNvbmZpZy5jc3NDbGFzc31gO1xuICAgIH1cbiAgfVxuXG4gIHByb3RlY3RlZCBzZXRMb2NhbGl6ZWRQcm9wZXJ0aWVzKCkge1xuICAgIHRoaXMuc3Vic2NyaXB0aW9uLmFkZChcbiAgICAgIHRoaXMubGFuZ3VhZ2VTZXJ2aWNlXG4gICAgICAgIC5nZXRBY3RpdmUoKVxuICAgICAgICAucGlwZShcbiAgICAgICAgICBtYXAobGFuZyA9PiB7XG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWc/LmxhYmVsKSB7XG4gICAgICAgICAgICAgIHRoaXMubGFiZWwgPSB0aGlzLmNvbmZpZy5sYWJlbFtsYW5nXVxuICAgICAgICAgICAgICAgID8gdGhpcy5jb25maWcubGFiZWxbbGFuZ11cbiAgICAgICAgICAgICAgICA6IHRoaXMuY29uZmlnLmxhYmVsLmRlZmF1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWc/LnBsYWNlaG9sZGVyKSB7XG4gICAgICAgICAgICAgIHRoaXMucGxhY2VIb2xkZXIgPSB0aGlzLmNvbmZpZy5wbGFjZWhvbGRlcltsYW5nXVxuICAgICAgICAgICAgICAgID8gdGhpcy5jb25maWcucGxhY2Vob2xkZXJbbGFuZ11cbiAgICAgICAgICAgICAgICA6IHRoaXMuY29uZmlnLnBsYWNlaG9sZGVyLmRlZmF1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSlcbiAgICAgICAgKVxuICAgICAgICAuc3Vic2NyaWJlKClcbiAgICApO1xuICB9XG5cbiAgcHJvdGVjdGVkIGNvbnRyb2xQcmVmaWxsKCkge1xuICAgIGlmICh0aGlzLmNvbmZpZy5wcmVmaWxsVmFsdWUpIHtcbiAgICAgIGNvbnN0IHRhcmdldE9iamVjdCA9XG4gICAgICAgIHRoaXMuYXBwQ29uZmlnLmR5bmFtaWNGb3Jtcy5wcmVmaWxsW1xuICAgICAgICAgIHRoaXMuY29uZmlnLnByZWZpbGxWYWx1ZS50YXJnZXRPYmplY3RcbiAgICAgICAgXTtcbiAgICAgIGlmICh0YXJnZXRPYmplY3QgJiYgdGFyZ2V0T2JqZWN0LnByZWZpbGxSZXNvbHZlcikge1xuICAgICAgICBjb25zdCBwcmVmaWxsUmVzb2x2ZXIgPSB0aGlzLmluamVjdG9yLmdldDxQcmVmaWxsUmVzb2x2ZXI+KFxuICAgICAgICAgIHRhcmdldE9iamVjdC5wcmVmaWxsUmVzb2x2ZXJcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5zdWJzY3JpcHRpb24uYWRkKFxuICAgICAgICAgIHByZWZpbGxSZXNvbHZlclxuICAgICAgICAgICAgLmdldFByZWZpbGxWYWx1ZSh0aGlzLmNvbmZpZy5wcmVmaWxsVmFsdWUudGFyZ2V0VmFsdWUpXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHZhbHVlID0+IHtcbiAgICAgICAgICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ncm91cC5nZXQodGhpcy5jb25maWcubmFtZSkuc2V0VmFsdWUodmFsdWUpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHByb3RlY3RlZCBpbnRlckRlcGVuZGFuY3lWYWx1ZUNoZWNrKCkge1xuICAgIGNvbnN0IHRyaWdnZXJlZENvbnRyb2wgPSB0aGlzLmZvcm1TZXJ2aWNlLmdldEZvcm1Db250cm9sRm9yQ29kZShcbiAgICAgIHRoaXMuY29uZmlnLm5hbWUsXG4gICAgICB0aGlzLmdyb3VwLnJvb3RcbiAgICApO1xuICAgIGlmICh0cmlnZ2VyZWRDb250cm9sKSB7XG4gICAgICB0aGlzLnN1YnNjcmlwdGlvbi5hZGQoXG4gICAgICAgIHRyaWdnZXJlZENvbnRyb2wudmFsdWVDaGFuZ2VzXG4gICAgICAgICAgLnBpcGUoXG4gICAgICAgICAgICBmaWx0ZXIoXyA9PiAhIXRoaXMuY29uZmlnLnZhbGlkYXRpb25zKSxcbiAgICAgICAgICAgIG1hcChfID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5jb25maWcudmFsaWRhdGlvbnMuZm9yRWFjaCh2YWxpZGF0aW9uID0+IHtcbiAgICAgICAgICAgICAgICBpZiAodmFsaWRhdGlvbi5hcmd1bWVudHMgJiYgdmFsaWRhdGlvbi5hcmd1bWVudHMubGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgdGFyZ2V0Q29udHJvbCA9IHRoaXMuZm9ybVNlcnZpY2UuZ2V0Rm9ybUNvbnRyb2xGb3JDb2RlKFxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0aW9uLmFyZ3VtZW50c1swXS52YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ncm91cC5yb290XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgdGFyZ2V0Q29udHJvbC51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KHtcbiAgICAgICAgICAgICAgICAgICAgb25seVNlbGY6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGVtaXRFdmVudDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICApXG4gICAgICAgICAgLnN1YnNjcmliZSgpXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIG5nT25EZXN0cm95KCkge1xuICAgIGlmICh0aGlzLnN1YnNjcmlwdGlvbikge1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==