import { Component } from '@angular/core';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/forms";
import * as i3 from "../error-notice/error-notice.component";
import * as i4 from "@spartacus/core";
function InputComponent_ng_container_0_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
} }
function InputComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
    i0.ɵɵtext(4);
    i0.ɵɵtemplate(5, InputComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(6, "input", 4);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(7, "cx-error-notice", 5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formControlName", ctx_r0.config.name);
    i0.ɵɵattribute("placeholder", ctx_r0.placeHolder)("name", ctx_r0.config.name)("readonly", ctx_r0.config.readonly ? ctx_r0.config.readonly : null);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
} }
export class InputComponent extends AbstractFormComponent {
}
InputComponent.ɵfac = /*@__PURE__*/ function () { let ɵInputComponent_BaseFactory; return function InputComponent_Factory(t) { return (ɵInputComponent_BaseFactory || (ɵInputComponent_BaseFactory = i0.ɵɵgetInheritedFactory(InputComponent)))(t || InputComponent); }; }();
InputComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: InputComponent, selectors: [["cx-input"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], ["type", "text", 1, "form-control", 3, "formControlName"], [3, "warn", "parentConfig"]], template: function InputComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, InputComponent_ng_container_0_Template, 8, 10, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i1.NgIf, i2.DefaultValueAccessor, i2.NgControlStatus, i2.NgControlStatusGroup, i2.FormGroupDirective, i2.FormControlName, i3.ErrorNoticeComponent, i4.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InputComponent, [{
        type: Component,
        args: [{ selector: 'cx-input', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        [attr.placeholder]=\"placeHolder\"\n        [formControlName]=\"config.name\"\n        [attr.name]=\"config.name\"\n        [attr.readonly]=\"config.readonly ? config.readonly : null\"\n      />\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5wdXQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb21wb25lbnRzL2lucHV0L2lucHV0LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9pbnB1dC9pbnB1dC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFDLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDBDQUEwQyxDQUFDOzs7Ozs7O0lDSXpFLDZCQUF1QztJQUNyQyxZQUNGOztJQUFBLDBCQUFlOztJQURiLGVBQ0Y7SUFERSw4RUFDRjs7O0lBUFIsNkJBQTRCO0lBQzFCLDhCQUF3RSxhQUFBLGVBQUE7SUFHbEUsWUFDQTtJQUFBLGdHQUVlO0lBQ2pCLGlCQUFRO0lBQ1IsMkJBT0U7SUFDSixpQkFBTTtJQUNOLHFDQUdtQjtJQUNyQixpQkFBTTtJQUNSLDBCQUFlOzs7SUF0QmMsZUFBbUI7SUFBbkIsd0NBQW1CLGdDQUFBO0lBR3hDLGVBQ0E7SUFEQSw2Q0FDQTtJQUFlLGVBQXNCO0lBQXRCLDhDQUFzQjtJQVFyQyxlQUErQjtJQUEvQixvREFBK0I7SUFEL0IsaURBQWdDLDRCQUFBLG9FQUFBO0lBT2xDLGVBQW9DO0lBQXBDLGdFQUFvQywrQkFBQTs7QURaMUMsTUFBTSxPQUFPLGNBQWUsU0FBUSxxQkFBcUI7OzhOQUE1QyxjQUFjLFNBQWQsY0FBYztpRUFBZCxjQUFjO1FDUDNCLGtGQXVCZTs7UUF2QkEsZ0NBQVc7O3VGRE9iLGNBQWM7Y0FKMUIsU0FBUzsyQkFDRSxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBYnN0cmFjdEZvcm1Db21wb25lbnQgfSBmcm9tICcuLi9hYnN0cmFjdC1mb3JtL2Fic3RyYWN0LWZvcm0uY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY3gtaW5wdXQnLFxuICB0ZW1wbGF0ZVVybDogJy4vaW5wdXQuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBJbnB1dENvbXBvbmVudCBleHRlbmRzIEFic3RyYWN0Rm9ybUNvbXBvbmVudCB7fVxuIiwiPG5nLWNvbnRhaW5lciAqbmdJZj1cImdyb3VwXCI+XG4gIDxkaXYgY2xhc3M9XCJkeW5hbWljLWZpZWxkXCIgW2Zvcm1Hcm91cF09XCJncm91cFwiIFtoaWRkZW5dPVwiY29uZmlnLmhpZGRlblwiPlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICA8bGFiZWwgY2xhc3M9XCJjb2wtZm9ybS1sYWJlbFwiPlxuICAgICAgICB7eyBsYWJlbCB9fVxuICAgICAgICA8bmctY29udGFpbmVyICpuZ0lmPVwiIWNvbmZpZy5yZXF1aXJlZFwiPlxuICAgICAgICAgIHt7ICdkeW5hbWljZm9ybXMub3B0aW9uYWwnIHwgY3hUcmFuc2xhdGUgfX1cbiAgICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICA8L2xhYmVsPlxuICAgICAgPGlucHV0XG4gICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICBbYXR0ci5wbGFjZWhvbGRlcl09XCJwbGFjZUhvbGRlclwiXG4gICAgICAgIFtmb3JtQ29udHJvbE5hbWVdPVwiY29uZmlnLm5hbWVcIlxuICAgICAgICBbYXR0ci5uYW1lXT1cImNvbmZpZy5uYW1lXCJcbiAgICAgICAgW2F0dHIucmVhZG9ubHldPVwiY29uZmlnLnJlYWRvbmx5ID8gY29uZmlnLnJlYWRvbmx5IDogbnVsbFwiXG4gICAgICAvPlxuICAgIDwvZGl2PlxuICAgIDxjeC1lcnJvci1ub3RpY2VcbiAgICAgIFt3YXJuXT1cImdyb3VwLmNvbnRyb2xzW2NvbmZpZy5uYW1lXVwiXG4gICAgICBbcGFyZW50Q29uZmlnXT1cImNvbmZpZ1wiXG4gICAgPjwvY3gtZXJyb3Itbm90aWNlPlxuICA8L2Rpdj5cbjwvbmctY29udGFpbmVyPlxuIl19