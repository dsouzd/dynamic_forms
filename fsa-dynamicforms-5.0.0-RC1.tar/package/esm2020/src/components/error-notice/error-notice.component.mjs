import { Component, Input } from '@angular/core';
import { map } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { LanguageService } from '@spartacus/core';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/core";
import * as i2 from "@angular/common";
function ErrorNoticeComponent_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 2);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "cxTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "dynamicforms.enterValidValue"), " ");
} }
function ErrorNoticeComponent_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 2);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r1.errorMessage, " ");
} }
export class ErrorNoticeComponent {
    constructor(languageService) {
        this.languageService = languageService;
        this.subscription = new Subscription();
    }
    ngOnInit() {
        this.subscription.add(this.languageService
            .getActive()
            .pipe(map(lang => {
            if (this.parentConfig && this.parentConfig.error) {
                this.errorMessage = this.parentConfig.error[lang]
                    ? this.parentConfig.error[lang]
                    : this.parentConfig.error.default;
            }
        }))
            .subscribe());
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
ErrorNoticeComponent.ɵfac = function ErrorNoticeComponent_Factory(t) { return new (t || ErrorNoticeComponent)(i0.ɵɵdirectiveInject(i1.LanguageService)); };
ErrorNoticeComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ErrorNoticeComponent, selectors: [["cx-error-notice"]], inputs: { warn: "warn", parentConfig: "parentConfig" }, decls: 3, vars: 2, consts: [[1, "px-2"], [4, "ngIf"], [1, "text-danger", "mb-2"]], template: function ErrorNoticeComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0);
        i0.ɵɵtemplate(1, ErrorNoticeComponent_ng_container_1_Template, 4, 3, "ng-container", 1);
        i0.ɵɵtemplate(2, ErrorNoticeComponent_ng_container_2_Template, 3, 1, "ng-container", 1);
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", (ctx.warn == null ? null : ctx.warn.touched) && (ctx.warn == null ? null : ctx.warn.errors == null ? null : ctx.warn.errors.required) || (ctx.warn == null ? null : ctx.warn.errors == null ? null : ctx.warn.errors.pattern));
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", (ctx.warn == null ? null : ctx.warn.invalid) && (ctx.warn == null ? null : ctx.warn.touched) && !(ctx.warn == null ? null : ctx.warn.errors == null ? null : ctx.warn.errors.required) && (ctx.parentConfig == null ? null : ctx.parentConfig.error));
    } }, dependencies: [i2.NgIf, i1.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ErrorNoticeComponent, [{
        type: Component,
        args: [{ selector: 'cx-error-notice', template: "<div class=\"px-2\">\n  <ng-container\n    *ngIf=\"(warn?.touched && warn?.errors?.required) || warn?.errors?.pattern\"\n  >\n    <div class=\"text-danger mb-2\">\n      {{ 'dynamicforms.enterValidValue' | cxTranslate }}\n    </div>\n  </ng-container>\n  <ng-container\n    *ngIf=\"\n      warn?.invalid &&\n      warn?.touched &&\n      !warn?.errors?.required &&\n      parentConfig?.error\n    \"\n  >\n    <div class=\"text-danger mb-2\">\n      {{ errorMessage }}\n    </div>\n  </ng-container>\n</div>\n" }]
    }], function () { return [{ type: i1.LanguageService }]; }, { warn: [{
            type: Input
        }], parentConfig: [{
            type: Input
        }] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3Itbm90aWNlLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9lcnJvci1ub3RpY2UvZXJyb3Itbm90aWNlLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9lcnJvci1ub3RpY2UvZXJyb3Itbm90aWNlLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFxQixNQUFNLGVBQWUsQ0FBQztBQUNwRSxPQUFPLEVBQUUsR0FBRyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDckMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUNwQyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0saUJBQWlCLENBQUM7Ozs7O0lDRmhELDZCQUVDO0lBQ0MsOEJBQThCO0lBQzVCLFlBQ0Y7O0lBQUEsaUJBQU07SUFDUiwwQkFBZTs7SUFGWCxlQUNGO0lBREUscUZBQ0Y7OztJQUVGLDZCQU9DO0lBQ0MsOEJBQThCO0lBQzVCLFlBQ0Y7SUFBQSxpQkFBTTtJQUNSLDBCQUFlOzs7SUFGWCxlQUNGO0lBREUsb0RBQ0Y7O0FEVEosTUFBTSxPQUFPLG9CQUFvQjtJQUMvQixZQUFvQixlQUFnQztRQUFoQyxvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7UUFNNUMsaUJBQVksR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO0lBTmEsQ0FBQztJQVF4RCxRQUFRO1FBQ04sSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQ25CLElBQUksQ0FBQyxlQUFlO2FBQ2pCLFNBQVMsRUFBRTthQUNYLElBQUksQ0FDSCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDVCxJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUU7Z0JBQ2hELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO29CQUMvQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO29CQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2FBQ3JDO1FBQ0gsQ0FBQyxDQUFDLENBQ0g7YUFDQSxTQUFTLEVBQUUsQ0FDZixDQUFDO0lBQ0osQ0FBQztJQUVELFdBQVc7UUFDVCxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDckIsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUNqQztJQUNILENBQUM7O3dGQTlCVSxvQkFBb0I7dUVBQXBCLG9CQUFvQjtRQ1RqQyw4QkFBa0I7UUFDaEIsdUZBTWU7UUFDZix1RkFXZTtRQUNqQixpQkFBTTs7UUFsQkQsZUFBd0U7UUFBeEUsb1BBQXdFO1FBT3hFLGVBTUw7UUFOSywyUUFNTDs7dUZETmEsb0JBQW9CO2NBSmhDLFNBQVM7MkJBQ0UsaUJBQWlCO2tFQU1sQixJQUFJO2tCQUFaLEtBQUs7WUFDRyxZQUFZO2tCQUFwQixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBPbkRlc3Ryb3kgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgTGFuZ3VhZ2VTZXJ2aWNlIH0gZnJvbSAnQHNwYXJ0YWN1cy9jb3JlJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY3gtZXJyb3Itbm90aWNlJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2Vycm9yLW5vdGljZS5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEVycm9yTm90aWNlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGxhbmd1YWdlU2VydmljZTogTGFuZ3VhZ2VTZXJ2aWNlKSB7fVxuXG4gIEBJbnB1dCgpIHdhcm46IGFueTtcbiAgQElucHV0KCkgcGFyZW50Q29uZmlnOiBhbnk7XG4gIGVycm9yTWVzc2FnZTogc3RyaW5nO1xuXG4gIHByaXZhdGUgc3Vic2NyaXB0aW9uID0gbmV3IFN1YnNjcmlwdGlvbigpO1xuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMuc3Vic2NyaXB0aW9uLmFkZChcbiAgICAgIHRoaXMubGFuZ3VhZ2VTZXJ2aWNlXG4gICAgICAgIC5nZXRBY3RpdmUoKVxuICAgICAgICAucGlwZShcbiAgICAgICAgICBtYXAobGFuZyA9PiB7XG4gICAgICAgICAgICBpZiAodGhpcy5wYXJlbnRDb25maWcgJiYgdGhpcy5wYXJlbnRDb25maWcuZXJyb3IpIHtcbiAgICAgICAgICAgICAgdGhpcy5lcnJvck1lc3NhZ2UgPSB0aGlzLnBhcmVudENvbmZpZy5lcnJvcltsYW5nXVxuICAgICAgICAgICAgICAgID8gdGhpcy5wYXJlbnRDb25maWcuZXJyb3JbbGFuZ11cbiAgICAgICAgICAgICAgICA6IHRoaXMucGFyZW50Q29uZmlnLmVycm9yLmRlZmF1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSlcbiAgICAgICAgKVxuICAgICAgICAuc3Vic2NyaWJlKClcbiAgICApO1xuICB9XG5cbiAgbmdPbkRlc3Ryb3koKSB7XG4gICAgaWYgKHRoaXMuc3Vic2NyaXB0aW9uKSB7XG4gICAgICB0aGlzLnN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgIH1cbiAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInB4LTJcIj5cbiAgPG5nLWNvbnRhaW5lclxuICAgICpuZ0lmPVwiKHdhcm4/LnRvdWNoZWQgJiYgd2Fybj8uZXJyb3JzPy5yZXF1aXJlZCkgfHwgd2Fybj8uZXJyb3JzPy5wYXR0ZXJuXCJcbiAgPlxuICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWRhbmdlciBtYi0yXCI+XG4gICAgICB7eyAnZHluYW1pY2Zvcm1zLmVudGVyVmFsaWRWYWx1ZScgfCBjeFRyYW5zbGF0ZSB9fVxuICAgIDwvZGl2PlxuICA8L25nLWNvbnRhaW5lcj5cbiAgPG5nLWNvbnRhaW5lclxuICAgICpuZ0lmPVwiXG4gICAgICB3YXJuPy5pbnZhbGlkICYmXG4gICAgICB3YXJuPy50b3VjaGVkICYmXG4gICAgICAhd2Fybj8uZXJyb3JzPy5yZXF1aXJlZCAmJlxuICAgICAgcGFyZW50Q29uZmlnPy5lcnJvclxuICAgIFwiXG4gID5cbiAgICA8ZGl2IGNsYXNzPVwidGV4dC1kYW5nZXIgbWItMlwiPlxuICAgICAge3sgZXJyb3JNZXNzYWdlIH19XG4gICAgPC9kaXY+XG4gIDwvbmctY29udGFpbmVyPlxuPC9kaXY+XG4iXX0=