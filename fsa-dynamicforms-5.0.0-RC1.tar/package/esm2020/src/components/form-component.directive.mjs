import { ComponentFactoryResolver, Directive, Input, ViewContainerRef, } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { DynamicFormsConfig } from '../core/config/form-config';
import * as i0 from "@angular/core";
import * as i1 from "../core/config/form-config";
export class FormComponentDirective {
    constructor(resolver, container, formConfig) {
        this.resolver = resolver;
        this.container = container;
        this.formConfig = formConfig;
        this.components = {};
    }
    ngOnInit() {
        for (const [name, obj] of Object.entries(this.formConfig.dynamicForms.components)) {
            this.components[name] = obj.component;
        }
        if (!this.components[this.config.fieldType]) {
            const supportedTypes = Object.keys(this.components).join(', ');
            throw new Error(`Trying to use an unsupported type (${this.config.fieldType}).
        Supported types: ${supportedTypes}`);
        }
        const component = this.resolver.resolveComponentFactory(this.components[this.config.fieldType]);
        this.component = this.container.createComponent(component);
        this.component.instance.config = this.config;
        this.component.instance.group = this.group;
    }
}
FormComponentDirective.ɵfac = function FormComponentDirective_Factory(t) { return new (t || FormComponentDirective)(i0.ɵɵdirectiveInject(i0.ComponentFactoryResolver), i0.ɵɵdirectiveInject(i0.ViewContainerRef), i0.ɵɵdirectiveInject(i1.DynamicFormsConfig)); };
FormComponentDirective.ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: FormComponentDirective, selectors: [["", "cxFormComponent", ""]], inputs: { config: "config", group: "group" } });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormComponentDirective, [{
        type: Directive,
        args: [{
                selector: '[cxFormComponent]',
            }]
    }], function () { return [{ type: i0.ComponentFactoryResolver }, { type: i0.ViewContainerRef }, { type: i1.DynamicFormsConfig }]; }, { config: [{
            type: Input
        }], group: [{
            type: Input
        }] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1jb21wb25lbnQuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb21wb25lbnRzL2Zvcm0tY29tcG9uZW50LmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0wsd0JBQXdCLEVBRXhCLFNBQVMsRUFDVCxLQUFLLEVBR0wsZ0JBQWdCLEdBQ2pCLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDOzs7QUFPaEUsTUFBTSxPQUFPLHNCQUFzQjtJQVFqQyxZQUNZLFFBQWtDLEVBQ2xDLFNBQTJCLEVBQzNCLFVBQThCO1FBRjlCLGFBQVEsR0FBUixRQUFRLENBQTBCO1FBQ2xDLGNBQVMsR0FBVCxTQUFTLENBQWtCO1FBQzNCLGVBQVUsR0FBVixVQUFVLENBQW9CO1FBTDFDLGVBQVUsR0FBeUQsRUFBRSxDQUFDO0lBTW5FLENBQUM7SUFFSixRQUFRO1FBQ04sS0FBSyxNQUFNLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQ3RDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FDeEMsRUFBRTtZQUNELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztTQUN2QztRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDM0MsTUFBTSxjQUFjLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQy9ELE1BQU0sSUFBSSxLQUFLLENBQ2Isc0NBQXNDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUzsyQkFDeEMsY0FBYyxFQUFFLENBQ3BDLENBQUM7U0FDSDtRQUNELE1BQU0sU0FBUyxHQUNiLElBQUksQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FDdkMsQ0FBQztRQUNKLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDN0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDN0MsQ0FBQzs7NEZBbENVLHNCQUFzQjt5RUFBdEIsc0JBQXNCO3VGQUF0QixzQkFBc0I7Y0FIbEMsU0FBUztlQUFDO2dCQUNULFFBQVEsRUFBRSxtQkFBbUI7YUFDOUI7MklBR0MsTUFBTTtrQkFETCxLQUFLO1lBR04sS0FBSztrQkFESixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQ29tcG9uZW50RmFjdG9yeVJlc29sdmVyLFxuICBDb21wb25lbnRSZWYsXG4gIERpcmVjdGl2ZSxcbiAgSW5wdXQsXG4gIE9uSW5pdCxcbiAgVHlwZSxcbiAgVmlld0NvbnRhaW5lclJlZixcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBVbnR5cGVkRm9ybUdyb3VwIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgRHluYW1pY0Zvcm1zQ29uZmlnIH0gZnJvbSAnLi4vY29yZS9jb25maWcvZm9ybS1jb25maWcnO1xuaW1wb3J0IHsgRmllbGRDb25maWcgfSBmcm9tICcuLi9jb3JlL21vZGVscy9mb3JtLWNvbmZpZy5pbnRlcmZhY2UnO1xuaW1wb3J0IHsgQWJzdHJhY3RGb3JtQ29tcG9uZW50IH0gZnJvbSAnLi9hYnN0cmFjdC1mb3JtL2Fic3RyYWN0LWZvcm0uY29tcG9uZW50JztcblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW2N4Rm9ybUNvbXBvbmVudF0nLFxufSlcbmV4cG9ydCBjbGFzcyBGb3JtQ29tcG9uZW50RGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0IHtcbiAgQElucHV0KClcbiAgY29uZmlnOiBGaWVsZENvbmZpZztcbiAgQElucHV0KClcbiAgZ3JvdXA6IFVudHlwZWRGb3JtR3JvdXA7XG4gIGNvbXBvbmVudDogQ29tcG9uZW50UmVmPEFic3RyYWN0Rm9ybUNvbXBvbmVudD47XG4gIGNvbXBvbmVudHM6IHsgW2ZpZWxkVHlwZTogc3RyaW5nXTogVHlwZTxBYnN0cmFjdEZvcm1Db21wb25lbnQ+IH0gPSB7fTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcm90ZWN0ZWQgcmVzb2x2ZXI6IENvbXBvbmVudEZhY3RvcnlSZXNvbHZlcixcbiAgICBwcm90ZWN0ZWQgY29udGFpbmVyOiBWaWV3Q29udGFpbmVyUmVmLFxuICAgIHByb3RlY3RlZCBmb3JtQ29uZmlnOiBEeW5hbWljRm9ybXNDb25maWdcbiAgKSB7fVxuXG4gIG5nT25Jbml0KCkge1xuICAgIGZvciAoY29uc3QgW25hbWUsIG9ial0gb2YgT2JqZWN0LmVudHJpZXMoXG4gICAgICB0aGlzLmZvcm1Db25maWcuZHluYW1pY0Zvcm1zLmNvbXBvbmVudHNcbiAgICApKSB7XG4gICAgICB0aGlzLmNvbXBvbmVudHNbbmFtZV0gPSBvYmouY29tcG9uZW50O1xuICAgIH1cbiAgICBpZiAoIXRoaXMuY29tcG9uZW50c1t0aGlzLmNvbmZpZy5maWVsZFR5cGVdKSB7XG4gICAgICBjb25zdCBzdXBwb3J0ZWRUeXBlcyA9IE9iamVjdC5rZXlzKHRoaXMuY29tcG9uZW50cykuam9pbignLCAnKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYFRyeWluZyB0byB1c2UgYW4gdW5zdXBwb3J0ZWQgdHlwZSAoJHt0aGlzLmNvbmZpZy5maWVsZFR5cGV9KS5cbiAgICAgICAgU3VwcG9ydGVkIHR5cGVzOiAke3N1cHBvcnRlZFR5cGVzfWBcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IGNvbXBvbmVudCA9XG4gICAgICB0aGlzLnJlc29sdmVyLnJlc29sdmVDb21wb25lbnRGYWN0b3J5PEFic3RyYWN0Rm9ybUNvbXBvbmVudD4oXG4gICAgICAgIHRoaXMuY29tcG9uZW50c1t0aGlzLmNvbmZpZy5maWVsZFR5cGVdXG4gICAgICApO1xuICAgIHRoaXMuY29tcG9uZW50ID0gdGhpcy5jb250YWluZXIuY3JlYXRlQ29tcG9uZW50KGNvbXBvbmVudCk7XG4gICAgdGhpcy5jb21wb25lbnQuaW5zdGFuY2UuY29uZmlnID0gdGhpcy5jb25maWc7XG4gICAgdGhpcy5jb21wb25lbnQuaW5zdGFuY2UuZ3JvdXAgPSB0aGlzLmdyb3VwO1xuICB9XG59XG4iXX0=