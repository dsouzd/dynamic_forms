import { Component } from '@angular/core';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
export class AbstractOptionsComponent extends AbstractFormComponent {
    ngOnInit() {
        super.ngOnInit();
        if (this.config.options) {
            const selectedOption = this.config.options.find(option => option.selected);
            if (selectedOption) {
                this.group.get(this.config.name).setValue(selectedOption.name);
            }
        }
    }
    getLocalizedOption(localizationObj, activelanguage) {
        return localizationObj[activelanguage]
            ? localizationObj[activelanguage]
            : localizationObj.default;
    }
}
AbstractOptionsComponent.ɵfac = /*@__PURE__*/ function () { let ɵAbstractOptionsComponent_BaseFactory; return function AbstractOptionsComponent_Factory(t) { return (ɵAbstractOptionsComponent_BaseFactory || (ɵAbstractOptionsComponent_BaseFactory = i0.ɵɵgetInheritedFactory(AbstractOptionsComponent)))(t || AbstractOptionsComponent); }; }();
AbstractOptionsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AbstractOptionsComponent, selectors: [["ng-component"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 0, vars: 0, template: function AbstractOptionsComponent_Template(rf, ctx) { }, encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AbstractOptionsComponent, [{
        type: Component,
        args: [{ template: '' }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWJzdHJhY3Qtb3B0aW9ucy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvbXBvbmVudHMvYWJzdHJhY3Qtb3B0aW9ucy9hYnN0cmFjdC1vcHRpb25zLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFVLE1BQU0sZUFBZSxDQUFDO0FBQ2xELE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDBDQUEwQyxDQUFDOztBQUlqRixNQUFNLE9BQU8sd0JBQ1gsU0FBUSxxQkFBcUI7SUFHN0IsUUFBUTtRQUNOLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNqQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ3ZCLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FDN0MsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUMxQixDQUFDO1lBQ0YsSUFBSSxjQUFjLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNoRTtTQUNGO0lBQ0gsQ0FBQztJQUNELGtCQUFrQixDQUFDLGVBQWdDLEVBQUUsY0FBc0I7UUFDekUsT0FBTyxlQUFlLENBQUMsY0FBYyxDQUFDO1lBQ3BDLENBQUMsQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDO1lBQ2pDLENBQUMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDO0lBQzlCLENBQUM7O2dSQW5CVSx3QkFBd0IsU0FBeEIsd0JBQXdCOzJFQUF4Qix3QkFBd0I7dUZBQXhCLHdCQUF3QjtjQURwQyxTQUFTO2VBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFic3RyYWN0Rm9ybUNvbXBvbmVudCB9IGZyb20gJy4uL2Fic3RyYWN0LWZvcm0vYWJzdHJhY3QtZm9ybS5jb21wb25lbnQnO1xuaW1wb3J0IHsgTG9jYWxpemVkU3RyaW5nIH0gZnJvbSAnLi4vLi4vY29yZS9tb2RlbHMvZm9ybS1jb25maWcuaW50ZXJmYWNlJztcblxuQENvbXBvbmVudCh7IHRlbXBsYXRlOiAnJyB9KVxuZXhwb3J0IGNsYXNzIEFic3RyYWN0T3B0aW9uc0NvbXBvbmVudFxuICBleHRlbmRzIEFic3RyYWN0Rm9ybUNvbXBvbmVudFxuICBpbXBsZW1lbnRzIE9uSW5pdFxue1xuICBuZ09uSW5pdCgpIHtcbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICAgIGlmICh0aGlzLmNvbmZpZy5vcHRpb25zKSB7XG4gICAgICBjb25zdCBzZWxlY3RlZE9wdGlvbiA9IHRoaXMuY29uZmlnLm9wdGlvbnMuZmluZChcbiAgICAgICAgb3B0aW9uID0+IG9wdGlvbi5zZWxlY3RlZFxuICAgICAgKTtcbiAgICAgIGlmIChzZWxlY3RlZE9wdGlvbikge1xuICAgICAgICB0aGlzLmdyb3VwLmdldCh0aGlzLmNvbmZpZy5uYW1lKS5zZXRWYWx1ZShzZWxlY3RlZE9wdGlvbi5uYW1lKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgZ2V0TG9jYWxpemVkT3B0aW9uKGxvY2FsaXphdGlvbk9iajogTG9jYWxpemVkU3RyaW5nLCBhY3RpdmVsYW5ndWFnZTogc3RyaW5nKSB7XG4gICAgcmV0dXJuIGxvY2FsaXphdGlvbk9ialthY3RpdmVsYW5ndWFnZV1cbiAgICAgID8gbG9jYWxpemF0aW9uT2JqW2FjdGl2ZWxhbmd1YWdlXVxuICAgICAgOiBsb2NhbGl6YXRpb25PYmouZGVmYXVsdDtcbiAgfVxufVxuIl19