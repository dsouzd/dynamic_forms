import { HttpEventType, HttpResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, HostListener, Injector, } from '@angular/core';
import { GlobalMessageService, GlobalMessageType, LanguageService, UserIdService, } from '@spartacus/core';
import { saveAs } from 'file-saver';
import { map, take } from 'rxjs/operators';
import { DynamicFormsConfig } from '../../core/config/form-config';
import { FileService } from '../../core/services/file/file.service';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import { FormService } from './../../core/services/form/form.service';
import { FormDataService } from '../../core/services/data/form-data.service';
import * as i0 from "@angular/core";
import * as i1 from "../../core/config/form-config";
import * as i2 from "@spartacus/core";
import * as i3 from "./../../core/services/form/form.service";
import * as i4 from "../../core/services/data/form-data.service";
import * as i5 from "../../core/services/file/file.service";
import * as i6 from "@angular/common";
import * as i7 from "@angular/forms";
import * as i8 from "../error-notice/error-notice.component";
function UploadComponent_ng_container_0_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
} }
function UploadComponent_ng_container_0_ng_container_17_li_2_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 24);
    i0.ɵɵelement(1, "i", 25);
    i0.ɵɵelementEnd();
} }
function UploadComponent_ng_container_0_ng_container_17_li_2_span_11_Template(rf, ctx) { if (rf & 1) {
    const _r14 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "span", 26);
    i0.ɵɵlistener("click", function UploadComponent_ng_container_0_ng_container_17_li_2_span_11_Template_span_click_0_listener() { i0.ɵɵrestoreView(_r14); const file_r6 = i0.ɵɵnextContext().$implicit; const ctx_r12 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r12.downloadFile(file_r6)); });
    i0.ɵɵelement(1, "i", 27);
    i0.ɵɵelementEnd();
} }
function UploadComponent_ng_container_0_ng_container_17_li_2_span_12_Template(rf, ctx) { if (rf & 1) {
    const _r17 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "span", 28);
    i0.ɵɵlistener("click", function UploadComponent_ng_container_0_ng_container_17_li_2_span_12_Template_span_click_0_listener() { i0.ɵɵrestoreView(_r17); const i_r7 = i0.ɵɵnextContext().index; i0.ɵɵnextContext(2); const _r2 = i0.ɵɵreference(12); const ctx_r15 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r15.removeFile(i_r7, _r2)); });
    i0.ɵɵelement(1, "i", 29);
    i0.ɵɵelementEnd();
} }
function UploadComponent_ng_container_0_ng_container_17_li_2_div_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 30)(1, "div", 31);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const i_r7 = i0.ɵɵnextContext().index;
    const ctx_r11 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(1);
    i0.ɵɵstyleProp("width", ctx_r11.individualProgress[i_r7] + "%");
    i0.ɵɵattribute("aria-valuenow", ctx_r11.individualProgress[i_r7]);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", ctx_r11.individualProgress[i_r7], " ");
} }
function UploadComponent_ng_container_0_ng_container_17_li_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 13)(1, "div", 14)(2, "div", 15)(3, "div", 14);
    i0.ɵɵtemplate(4, UploadComponent_ng_container_0_ng_container_17_li_2_span_4_Template, 2, 0, "span", 16);
    i0.ɵɵelementStart(5, "span", 17);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "span", 18);
    i0.ɵɵtext(8);
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(9, "div", 19)(10, "div", 14);
    i0.ɵɵtemplate(11, UploadComponent_ng_container_0_ng_container_17_li_2_span_11_Template, 2, 0, "span", 20);
    i0.ɵɵtemplate(12, UploadComponent_ng_container_0_ng_container_17_li_2_span_12_Template, 2, 0, "span", 21);
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(13, "div", 14)(14, "div", 22);
    i0.ɵɵtemplate(15, UploadComponent_ng_container_0_ng_container_17_li_2_div_15_Template, 3, 4, "div", 23);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const file_r6 = ctx.$implicit;
    const i_r7 = ctx.index;
    const ctx_r4 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(4);
    i0.ɵɵproperty("ngIf", file_r6 == null ? null : file_r6.code);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(file_r6 == null ? null : file_r6.name);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r4.convertFileSize(file_r6.size), "");
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", file_r6 == null ? null : file_r6.code);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r4.removeAllDisable);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r4.individualProgress[i_r7] > 0 && ctx_r4.individualProgress[i_r7] !== 100);
} }
function UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_3_Template(rf, ctx) { if (rf & 1) {
    const _r22 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 37);
    i0.ɵɵlistener("click", function UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_3_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r22); i0.ɵɵnextContext(3); const _r2 = i0.ɵɵreference(12); const ctx_r21 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r21.removeAll(_r2)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.removeAll"), " ");
} }
function UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_5_Template(rf, ctx) { if (rf & 1) {
    const _r24 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 38);
    i0.ɵɵlistener("click", function UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_5_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r24); const ctx_r23 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r23.uploadFiles(ctx_r23.fileList)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.upload"), " ");
} }
function UploadComponent_ng_container_0_ng_container_17_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 32)(2, "div", 33);
    i0.ɵɵtemplate(3, UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_3_Template, 3, 3, "button", 34);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div", 35);
    i0.ɵɵtemplate(5, UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_5_Template, 3, 3, "button", 36);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r5 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r5.fileList.length > 1 && !ctx_r5.removeAllDisable);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", !ctx_r5.uploadDisable);
} }
function UploadComponent_ng_container_0_ng_container_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "ul", 11);
    i0.ɵɵtemplate(2, UploadComponent_ng_container_0_ng_container_17_li_2_Template, 16, 6, "li", 12);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, UploadComponent_ng_container_0_ng_container_17_ng_container_3_Template, 6, 2, "ng-container", 0);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r3.fileList);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", (ctx_r3.fileList == null ? null : ctx_r3.fileList.length) > 0);
} }
function UploadComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
    i0.ɵɵtext(4);
    i0.ɵɵtemplate(5, UploadComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "p");
    i0.ɵɵtext(7);
    i0.ɵɵpipe(8, "cxTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(9, "div", 4)(10, "div", 5);
    i0.ɵɵelement(11, "input", 6, 7)(13, "input", 8);
    i0.ɵɵelementStart(14, "label", 9);
    i0.ɵɵtext(15);
    i0.ɵɵpipe(16, "cxTranslate");
    i0.ɵɵelementEnd()()();
    i0.ɵɵtemplate(17, UploadComponent_ng_container_0_ng_container_17_Template, 4, 2, "ng-container", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(18, "cx-error-notice", 10);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate2(" ", i0.ɵɵpipeBind1(8, 17, "dynamicforms.maxFileSize"), " ", ctx_r0.convertFileSize(ctx_r0.config.maxFileSize), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵattribute("aria-describedby", ctx_r0.config.name)("name", ctx_r0.config.name)("multiple", ctx_r0.config.multiple ? ctx_r0.config.multiple : null)("accept", ctx_r0.config.accept);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("formControlName", ctx_r0.config.name);
    i0.ɵɵattribute("name", ctx_r0.config.name + "_hidden");
    i0.ɵɵadvance(1);
    i0.ɵɵattribute("for", ctx_r0.config.name);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(16, 19, "dynamicforms.chooseFile"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r0.fileList.length > 0);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
} }
export class UploadComponent extends AbstractFormComponent {
    constructor(appConfig, languageService, injector, formService, formDataService, fileUploadService, cd, userIdService, globalMessageService) {
        super(appConfig, languageService, injector, formService);
        this.appConfig = appConfig;
        this.languageService = languageService;
        this.injector = injector;
        this.formService = formService;
        this.formDataService = formDataService;
        this.fileUploadService = fileUploadService;
        this.cd = cd;
        this.userIdService = userIdService;
        this.globalMessageService = globalMessageService;
        this.fileList = [];
        this.individualProgress = {};
        this.files = [];
        this.uploadDisable = false;
        this.removeAllDisable = false;
    }
    handleFiles(event) {
        // Reset when user is choosing files again
        this.resetFileList();
        this.individualProgress = {};
        this.uploadDisable = false;
        const filteredFiles = this.filterFiles(this.config, event.target.files);
        if (this.config.accept.toString() === event.target.accept &&
            this.config.multiple === event.target.multiple) {
            this.fileList = Array.from(filteredFiles);
            this.fileList.splice(this.config.maxUploads);
            if (this.fileList.length === 0) {
                this.setValueAndValidate(null);
            }
        }
        else {
            // triggering reset and validation if something was manipulated through DOM inspector
            // or files are violating config rules
            this.setValueAndValidate(null);
        }
    }
    ngOnInit() {
        super.ngOnInit();
        this.uploadControl = this.group.get(this.config.name);
        this.populateUploadedFiles();
    }
    populateUploadedFiles() {
        this.subscription.add(this.fileUploadService
            .getUploadedDocuments()
            .pipe(map(filesObj => {
            if (Object.keys(filesObj?.files).length > 0) {
                this.fileList = Array.from(Object.values(filesObj?.files));
                this.fileList.forEach((file) => {
                    if (!this.files.includes(file.code)) {
                        this.files.push(file.code);
                    }
                });
                this.uploadControl?.setValue(this.files);
                this.uploadDisable = true;
                this.cd.detectChanges();
            }
            else {
                this.uploadControl?.setValue(null);
            }
        }))
            .subscribe());
    }
    filterFiles(config, files) {
        const filtedFiles = [];
        Array.from(files).forEach(file => {
            if (config.accept.includes(file.type) &&
                file.size <= this.config.maxFileSize) {
                filtedFiles.push(file);
            }
        });
        return filtedFiles;
    }
    convertFileSize(bytes) {
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Number(Math.floor(Math.log(bytes) / Math.log(1024)));
        if (i === 0) {
            return `${bytes} ${sizes[i]}`;
        }
        return `${(bytes / 1024 ** i).toFixed(1)} ${sizes[i]}`;
    }
    uploadFiles(files) {
        this.uploadDisable = true;
        this.removeAllDisable = true;
        this.setValueAndValidate(this.fileList);
        files.forEach((file, index) => {
            this.subscription.add(this.fileUploadService.uploadFile(file).subscribe(event => {
                if (event?.type === HttpEventType.UploadProgress) {
                    this.individualProgress[index] = Math.round((100 * event.loaded) / event.total);
                    this.cd.detectChanges();
                }
                if (event instanceof HttpResponse) {
                    this.handleFileResponse(event);
                }
                // when all files are finished uploading show the remove all button
                this.removeAllDisable = !!this.overallProgressFinished(this.individualProgress);
            }, error => {
                this.globalMessageService.add({
                    key: 'dynamicforms.documentUploadError',
                }, GlobalMessageType.MSG_TYPE_ERROR);
            }));
        });
    }
    removeFile(index, uploadField) {
        this.removeFromStorage(index);
        this.fileList.splice(index, 1);
        if (this.files.length !== 0) {
            this.files.splice(index, 1);
            this.setValueAndValidate(this.files);
        }
        // reset DOM File element to sync it with reactive control
        if (this.fileList.length === 0) {
            uploadField.value = null;
        }
    }
    removeAll(uploadField) {
        this.removeFromStorage();
        this.fileList = [];
        uploadField.value = null;
        this.setValueAndValidate(this.fileList);
    }
    downloadFile(file) {
        this.subscription.add(this.fileUploadService
            .getFile(file.code, file.type ? file.type : file.mime)
            .pipe(map(downloadedFile => {
            saveAs(downloadedFile, file.name);
        }))
            .subscribe());
    }
    removeFromStorage(index) {
        // Execute Http.Delete request to backend
        this.subscription.add(this.userIdService
            .getUserId()
            .pipe(take(1), map(occUserId => {
            const fileCode = this.fileList[index]?.code;
            if (fileCode) {
                this.fileUploadService.removeFileForCode(occUserId, fileCode);
                this.setValueAndValidate(null);
            }
            else {
                this.fileUploadService.removeAllFiles(occUserId, this.fileList);
                this.fileUploadService.resetFiles();
            }
        }))
            .subscribe());
    }
    overallProgressFinished(progress) {
        return (Object.keys(progress).filter((_k, i) => progress[i] !== 100).length !== 0);
    }
    setValueAndValidate(value) {
        this.uploadControl.setValue(value);
        this.uploadControl.markAsTouched({ onlySelf: true });
    }
    handleFileResponse(event) {
        this.fileUploadService.setFileInStore(event.body);
        const fileCode = event.body.code;
        if (!this.files.includes(fileCode)) {
            this.files.push(fileCode);
        }
        this.uploadControl.setValue(this.files);
    }
    resetFileList() {
        this.fileList = [];
        this.files = [];
        this.fileUploadService.resetFiles();
    }
    setFileCode(file, event) {
        if (event.body?.code) {
            file.code = event.body?.code;
        }
        this.cd.detectChanges();
    }
}
UploadComponent.ɵfac = function UploadComponent_Factory(t) { return new (t || UploadComponent)(i0.ɵɵdirectiveInject(i1.DynamicFormsConfig), i0.ɵɵdirectiveInject(i2.LanguageService), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i3.FormService), i0.ɵɵdirectiveInject(i4.FormDataService), i0.ɵɵdirectiveInject(i5.FileService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i2.UserIdService), i0.ɵɵdirectiveInject(i2.GlobalMessageService)); };
UploadComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: UploadComponent, selectors: [["cx-upload"]], hostBindings: function UploadComponent_HostBindings(rf, ctx) { if (rf & 1) {
        i0.ɵɵlistener("change", function UploadComponent_change_HostBindingHandler($event) { return ctx.handleFiles($event); });
    } }, features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], [1, "input-group"], [1, "custom-file"], ["type", "file", 1, "custom-file-input"], ["uploadField", ""], ["type", "hidden", 3, "formControlName"], [1, "custom-file-label"], [3, "warn", "parentConfig"], [1, "mb-4"], ["class", "pt-4", 4, "ngFor", "ngForOf"], [1, "pt-4"], [1, "row", "no-gutters"], [1, "col-10"], ["class", "col-1", 4, "ngIf"], [1, "col-8", "text-break"], [1, "col-3"], [1, "col-2"], ["class", "col-6 text-right", "role", "button", 3, "click", 4, "ngIf"], ["class", "col-6 text-right ml-auto", "role", "button", 3, "click", 4, "ngIf"], [1, "col-12"], ["class", "progress", 4, "ngIf"], [1, "col-1"], [1, "fas", "fa-check"], ["role", "button", 1, "col-6", "text-right", 3, "click"], [1, "fas", "fa-download"], ["role", "button", 1, "col-6", "text-right", "ml-auto", 3, "click"], [1, "fas", "fa-trash"], [1, "progress"], ["role", "progressbar", "aria-valuemin", "0", "aria-valuemax", "100", 1, "progress-bar"], [1, "row", "justify-content-between"], [1, "col-md-3", "col-sm-3", "col-12", "mb-3", "mb-sm-0"], ["class", "action-button btn-block", 3, "click", 4, "ngIf"], [1, "col-md-3", "col-sm-3", "col-12"], ["class", "btn-primary btn-block", 3, "click", 4, "ngIf"], [1, "action-button", "btn-block", 3, "click"], [1, "btn-primary", "btn-block", 3, "click"]], template: function UploadComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, UploadComponent_ng_container_0_Template, 19, 21, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i6.NgForOf, i6.NgIf, i7.DefaultValueAccessor, i7.NgControlStatus, i7.NgControlStatusGroup, i7.FormGroupDirective, i7.FormControlName, i8.ErrorNoticeComponent, i2.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UploadComponent, [{
        type: Component,
        args: [{ selector: 'cx-upload', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <p>\n        {{ 'dynamicforms.maxFileSize' | cxTranslate }}\n        {{ convertFileSize(config.maxFileSize) }}\n      </p>\n      <div class=\"input-group\">\n        <div class=\"custom-file\">\n          <input\n            #uploadField\n            type=\"file\"\n            class=\"custom-file-input\"\n            [attr.aria-describedby]=\"config.name\"\n            [attr.name]=\"config.name\"\n            [attr.multiple]=\"config.multiple ? config.multiple : null\"\n            [attr.accept]=\"config.accept\"\n          />\n          <input\n            type=\"hidden\"\n            [attr.name]=\"config.name + '_hidden'\"\n            [formControlName]=\"config.name\"\n          />\n          <label class=\"custom-file-label\" [attr.for]=\"config.name\">{{\n            'dynamicforms.chooseFile' | cxTranslate\n          }}</label>\n        </div>\n      </div>\n\n      <ng-container *ngIf=\"fileList.length > 0\">\n        <ul class=\"mb-4\">\n          <li class=\"pt-4\" *ngFor=\"let file of fileList; let i = index\">\n            <div class=\"row no-gutters\">\n              <div class=\"col-10\">\n                <div class=\"row no-gutters\">\n                  <span class=\"col-1\" *ngIf=\"file?.code\"\n                    ><i class=\"fas fa-check\"></i\n                  ></span>\n                  <span class=\"col-8 text-break\">{{ file?.name }}</span>\n                  <span class=\"col-3\"> {{ convertFileSize(file.size) }}</span>\n                </div>\n              </div>\n              <div class=\"col-2\">\n                <div class=\"row no-gutters\">\n                  <span\n                    class=\"col-6 text-right\"\n                    *ngIf=\"file?.code\"\n                    role=\"button\"\n                    (click)=\"downloadFile(file)\"\n                    ><i class=\"fas fa-download\"></i\n                  ></span>\n                  <span\n                    *ngIf=\"!removeAllDisable\"\n                    class=\"col-6 text-right ml-auto\"\n                    role=\"button\"\n                    (click)=\"removeFile(i, uploadField)\"\n                    ><i class=\"fas fa-trash\"></i\n                  ></span>\n                </div>\n              </div>\n            </div>\n            <div class=\"row no-gutters\">\n              <div class=\"col-12\">\n                <div\n                  class=\"progress\"\n                  *ngIf=\"\n                    individualProgress[i] > 0 && individualProgress[i] !== 100\n                  \"\n                >\n                  <div\n                    class=\"progress-bar\"\n                    [style.width]=\"individualProgress[i] + '%'\"\n                    role=\"progressbar\"\n                    [attr.aria-valuenow]=\"individualProgress[i]\"\n                    aria-valuemin=\"0\"\n                    aria-valuemax=\"100\"\n                  >\n                    {{ individualProgress[i] }}\n                  </div>\n                </div>\n              </div>\n            </div>\n          </li>\n        </ul>\n        <ng-container *ngIf=\"fileList?.length > 0\">\n          <div class=\"row justify-content-between\">\n            <div class=\"col-md-3 col-sm-3 col-12 mb-3 mb-sm-0\">\n              <button\n                *ngIf=\"fileList.length > 1 && !removeAllDisable\"\n                class=\"action-button btn-block\"\n                (click)=\"removeAll(uploadField)\"\n              >\n                {{ 'dynamicforms.removeAll' | cxTranslate }}\n              </button>\n            </div>\n            <div class=\"col-md-3 col-sm-3 col-12\">\n              <button\n                *ngIf=\"!uploadDisable\"\n                class=\"btn-primary btn-block\"\n                (click)=\"uploadFiles(fileList)\"\n              >\n                {{ 'dynamicforms.upload' | cxTranslate }}\n              </button>\n            </div>\n          </div>\n        </ng-container>\n      </ng-container>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
    }], function () { return [{ type: i1.DynamicFormsConfig }, { type: i2.LanguageService }, { type: i0.Injector }, { type: i3.FormService }, { type: i4.FormDataService }, { type: i5.FileService }, { type: i0.ChangeDetectorRef }, { type: i2.UserIdService }, { type: i2.GlobalMessageService }]; }, { handleFiles: [{
            type: HostListener,
            args: ['change', ['$event']]
        }] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBsb2FkLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy91cGxvYWQvdXBsb2FkLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy91cGxvYWQvdXBsb2FkLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxhQUFhLEVBQUUsWUFBWSxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDbkUsT0FBTyxFQUNMLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsWUFBWSxFQUNaLFFBQVEsR0FFVCxNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQ0wsb0JBQW9CLEVBQ3BCLGlCQUFpQixFQUNqQixlQUFlLEVBQ2YsYUFBYSxHQUNkLE1BQU0saUJBQWlCLENBQUM7QUFDekIsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLFlBQVksQ0FBQztBQUNwQyxPQUFPLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzNDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLCtCQUErQixDQUFDO0FBQ25FLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSx1Q0FBdUMsQ0FBQztBQUNwRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSwwQ0FBMEMsQ0FBQztBQUNqRixPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0seUNBQXlDLENBQUM7QUFDdEUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDRDQUE0QyxDQUFDOzs7Ozs7Ozs7OztJQ2hCckUsNkJBQXVDO0lBQ3JDLFlBQ0Y7O0lBQUEsMEJBQWU7O0lBRGIsZUFDRjtJQURFLDhFQUNGOzs7SUFrQ1UsZ0NBQ0c7SUFBQSx3QkFDRjtJQUFBLGlCQUFPOzs7O0lBT1IsZ0NBS0c7SUFERCxpUEFBUyxlQUFBLDZCQUFrQixDQUFBLElBQUM7SUFDM0Isd0JBQ0Y7SUFBQSxpQkFBTzs7OztJQUNSLGdDQUtHO0lBREQsOFJBQVMsZUFBQSw2QkFBMEIsQ0FBQSxJQUFDO0lBQ25DLHdCQUNGO0lBQUEsaUJBQU87OztJQU1WLCtCQUtDLGNBQUE7SUFTRyxZQUNGO0lBQUEsaUJBQU0sRUFBQTs7OztJQVBKLGVBQTJDO0lBQTNDLCtEQUEyQztJQUUzQyxpRUFBNEM7SUFJNUMsZUFDRjtJQURFLGlFQUNGOzs7SUEvQ1IsOEJBQThELGNBQUEsY0FBQSxjQUFBO0lBSXRELHVHQUVRO0lBQ1IsZ0NBQStCO0lBQUEsWUFBZ0I7SUFBQSxpQkFBTztJQUN0RCxnQ0FBb0I7SUFBQyxZQUFnQztJQUFBLGlCQUFPLEVBQUEsRUFBQTtJQUdoRSwrQkFBbUIsZUFBQTtJQUVmLHlHQU1RO0lBQ1IseUdBTVE7SUFDVixpQkFBTSxFQUFBLEVBQUE7SUFHVixnQ0FBNEIsZUFBQTtJQUV4Qix1R0FnQk07SUFDUixpQkFBTSxFQUFBLEVBQUE7Ozs7O0lBN0NtQixlQUFnQjtJQUFoQiw0REFBZ0I7SUFHTixlQUFnQjtJQUFoQiwyREFBZ0I7SUFDMUIsZUFBZ0M7SUFBaEMsb0VBQWdDO0lBT2xELGVBQWdCO0lBQWhCLDREQUFnQjtJQU1oQixlQUF1QjtJQUF2QiwrQ0FBdUI7SUFhekIsZUFHbkI7SUFIbUIscUdBR25COzs7O0lBbUJjLGtDQUlDO0lBREMsb1FBQVMsZUFBQSxzQkFBc0IsQ0FBQSxJQUFDO0lBRWhDLFlBQ0Y7O0lBQUEsaUJBQVM7O0lBRFAsZUFDRjtJQURFLCtFQUNGOzs7O0lBR0Esa0NBSUM7SUFEQyxnTkFBUyxlQUFBLHFDQUFxQixDQUFBLElBQUM7SUFFL0IsWUFDRjs7SUFBQSxpQkFBUzs7SUFEUCxlQUNGO0lBREUsNEVBQ0Y7OztJQWxCTiw2QkFBMkM7SUFDekMsK0JBQXlDLGNBQUE7SUFFckMscUhBTVM7SUFDWCxpQkFBTTtJQUNOLCtCQUFzQztJQUNwQyxxSEFNUztJQUNYLGlCQUFNLEVBQUE7SUFFViwwQkFBZTs7O0lBakJOLGVBQThDO0lBQTlDLDZFQUE4QztJQVM5QyxlQUFvQjtJQUFwQiw0Q0FBb0I7OztJQXBFL0IsNkJBQTBDO0lBQ3hDLDhCQUFpQjtJQUNmLCtGQW1ESztJQUNQLGlCQUFLO0lBQ0wsaUhBcUJlO0lBQ2pCLDBCQUFlOzs7SUEzRXVCLGVBQWE7SUFBYix5Q0FBYTtJQXFEbEMsZUFBMEI7SUFBMUIsb0ZBQTBCOzs7SUExRmpELDZCQUE0QjtJQUMxQiw4QkFBd0UsYUFBQSxlQUFBO0lBR2xFLFlBQ0E7SUFBQSxpR0FFZTtJQUNqQixpQkFBUTtJQUNSLHlCQUFHO0lBQ0QsWUFFRjs7SUFBQSxpQkFBSTtJQUNKLDhCQUF5QixjQUFBO0lBRXJCLCtCQVFFLGdCQUFBO0lBTUYsaUNBQTBEO0lBQUEsYUFFeEQ7O0lBQUEsaUJBQVEsRUFBQSxFQUFBO0lBSWQsbUdBNkVlO0lBQ2pCLGlCQUFNO0lBQ04sdUNBR21CO0lBQ3JCLGlCQUFNO0lBQ1IsMEJBQWU7OztJQXRIYyxlQUFtQjtJQUFuQix3Q0FBbUIsZ0NBQUE7SUFHeEMsZUFDQTtJQURBLDZDQUNBO0lBQWUsZUFBc0I7SUFBdEIsOENBQXNCO0lBS3JDLGVBRUY7SUFGRSwwSUFFRjtJQU9NLGVBQXFDO0lBQXJDLHNEQUFxQyw0QkFBQSxvRUFBQSxnQ0FBQTtJQVFyQyxlQUErQjtJQUEvQixvREFBK0I7SUFEL0Isc0RBQXFDO0lBR04sZUFBd0I7SUFBeEIseUNBQXdCO0lBQUMsZUFFeEQ7SUFGd0QsdUVBRXhEO0lBSVMsZUFBeUI7SUFBekIsaURBQXlCO0lBZ0Z4QyxlQUFvQztJQUFwQyxnRUFBb0MsK0JBQUE7O0FEdEYxQyxNQUFNLE9BQU8sZUFBZ0IsU0FBUSxxQkFBcUI7SUFReEQsWUFDWSxTQUE2QixFQUM3QixlQUFnQyxFQUNoQyxRQUFrQixFQUNsQixXQUF3QixFQUN4QixlQUFnQyxFQUNoQyxpQkFBOEIsRUFDOUIsRUFBcUIsRUFDckIsYUFBNEIsRUFDNUIsb0JBQTBDO1FBRXBELEtBQUssQ0FBQyxTQUFTLEVBQUUsZUFBZSxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztRQVYvQyxjQUFTLEdBQVQsU0FBUyxDQUFvQjtRQUM3QixvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7UUFDaEMsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixnQkFBVyxHQUFYLFdBQVcsQ0FBYTtRQUN4QixvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7UUFDaEMsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFhO1FBQzlCLE9BQUUsR0FBRixFQUFFLENBQW1CO1FBQ3JCLGtCQUFhLEdBQWIsYUFBYSxDQUFlO1FBQzVCLHlCQUFvQixHQUFwQixvQkFBb0IsQ0FBc0I7UUFoQnRELGFBQVEsR0FBbUIsRUFBRSxDQUFDO1FBRTlCLHVCQUFrQixHQUFHLEVBQUUsQ0FBQztRQUN4QixVQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ1gsa0JBQWEsR0FBRyxLQUFLLENBQUM7UUFDdEIscUJBQWdCLEdBQUcsS0FBSyxDQUFDO0lBY3pCLENBQUM7SUFHRCxXQUFXLENBQUMsS0FBSztRQUNmLDBDQUEwQztRQUMxQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUMzQixNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4RSxJQUNFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTTtZQUNyRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxLQUFLLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFDOUM7WUFDQSxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDMUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUM3QyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDOUIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ2hDO1NBQ0Y7YUFBTTtZQUNMLHFGQUFxRjtZQUNyRixzQ0FBc0M7WUFDdEMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ2hDO0lBQ0gsQ0FBQztJQUVELFFBQVE7UUFDTixLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDakIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFUyxxQkFBcUI7UUFDN0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQ25CLElBQUksQ0FBQyxpQkFBaUI7YUFDbkIsb0JBQW9CLEVBQUU7YUFDdEIsSUFBSSxDQUNILEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNiLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQzNELElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBa0IsRUFBRSxFQUFFO29CQUMzQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO3dCQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQzVCO2dCQUNILENBQUMsQ0FBQyxDQUFDO2dCQUNILElBQUksQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDekMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDekI7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDcEM7UUFDSCxDQUFDLENBQUMsQ0FDSDthQUNBLFNBQVMsRUFBRSxDQUNmLENBQUM7SUFDSixDQUFDO0lBRVMsV0FBVyxDQUFDLE1BQW1CLEVBQUUsS0FBZTtRQUN4RCxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFDdkIsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDL0IsSUFDRSxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2dCQUNqQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUNwQztnQkFDQSxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3hCO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLFdBQVcsQ0FBQztJQUNyQixDQUFDO0lBRUQsZUFBZSxDQUFDLEtBQWE7UUFDM0IsTUFBTSxLQUFLLEdBQUcsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDL0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ1gsT0FBTyxHQUFHLEtBQUssSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztTQUMvQjtRQUNELE9BQU8sR0FBRyxDQUFDLEtBQUssR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQ3pELENBQUM7SUFFRCxXQUFXLENBQUMsS0FBcUI7UUFDL0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7UUFDMUIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztRQUM3QixJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3hDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUU7WUFDNUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQ25CLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUMvQyxLQUFLLENBQUMsRUFBRTtnQkFDTixJQUFJLEtBQUssRUFBRSxJQUFJLEtBQUssYUFBYSxDQUFDLGNBQWMsRUFBRTtvQkFDaEQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQ3pDLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUNuQyxDQUFDO29CQUNGLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7aUJBQ3pCO2dCQUNELElBQUksS0FBSyxZQUFZLFlBQVksRUFBRTtvQkFDakMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUNoQztnQkFDRCxtRUFBbUU7Z0JBQ25FLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUNwRCxJQUFJLENBQUMsa0JBQWtCLENBQ3hCLENBQUM7WUFDSixDQUFDLEVBQ0QsS0FBSyxDQUFDLEVBQUU7Z0JBQ04sSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FDM0I7b0JBQ0UsR0FBRyxFQUFFLGtDQUFrQztpQkFDeEMsRUFDRCxpQkFBaUIsQ0FBQyxjQUFjLENBQ2pDLENBQUM7WUFDSixDQUFDLENBQ0YsQ0FDRixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsVUFBVSxDQUFDLEtBQWEsRUFBRSxXQUF3QjtRQUNoRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQy9CLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzNCLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM1QixJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ3RDO1FBRUQsMERBQTBEO1FBQzFELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzlCLFdBQVcsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1NBQzFCO0lBQ0gsQ0FBQztJQUVELFNBQVMsQ0FBQyxXQUF3QjtRQUNoQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztRQUNuQixXQUFXLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUN6QixJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFRCxZQUFZLENBQUMsSUFBSTtRQUNmLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUNuQixJQUFJLENBQUMsaUJBQWlCO2FBQ25CLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDckQsSUFBSSxDQUNILEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUNuQixNQUFNLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FDSDthQUNBLFNBQVMsRUFBRSxDQUNmLENBQUM7SUFDSixDQUFDO0lBRVMsaUJBQWlCLENBQUMsS0FBYztRQUN4Qyx5Q0FBeUM7UUFDekMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQ25CLElBQUksQ0FBQyxhQUFhO2FBQ2YsU0FBUyxFQUFFO2FBQ1gsSUFBSSxDQUNILElBQUksQ0FBQyxDQUFDLENBQUMsRUFDUCxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDZCxNQUFNLFFBQVEsR0FBUyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBRSxFQUFFLElBQUksQ0FBQztZQUNuRCxJQUFJLFFBQVEsRUFBRTtnQkFDWixJQUFJLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUM5RCxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDaEM7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNoRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBVSxFQUFFLENBQUM7YUFDckM7UUFDSCxDQUFDLENBQUMsQ0FDSDthQUNBLFNBQVMsRUFBRSxDQUNmLENBQUM7SUFDSixDQUFDO0lBRVMsdUJBQXVCLENBQUMsUUFBUTtRQUN4QyxPQUFPLENBQ0wsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FDMUUsQ0FBQztJQUNKLENBQUM7SUFFUyxtQkFBbUIsQ0FBQyxLQUFxQjtRQUNqRCxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNuQyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFUyxrQkFBa0IsQ0FBQyxLQUFLO1FBQ2hDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xELE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNsQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMzQjtRQUNELElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRVMsYUFBYTtRQUNyQixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEMsQ0FBQztJQUVTLFdBQVcsQ0FBQyxJQUFJLEVBQUUsS0FBSztRQUMvQixJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO1lBQ3BCLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUM7U0FDOUI7UUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQzFCLENBQUM7OzhFQTVOVSxlQUFlO2tFQUFmLGVBQWU7b0dBQWYsdUJBQW1COztRQzdCaEMsb0ZBdUhlOztRQXZIQSxnQ0FBVzs7dUZENkJiLGVBQWU7Y0FKM0IsU0FBUzsyQkFDRSxXQUFXOzJTQTBCckIsV0FBVztrQkFEVixZQUFZO21CQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEh0dHBFdmVudFR5cGUsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7XG4gIENoYW5nZURldGVjdG9yUmVmLFxuICBDb21wb25lbnQsXG4gIEhvc3RMaXN0ZW5lcixcbiAgSW5qZWN0b3IsXG4gIE9uSW5pdCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBYnN0cmFjdENvbnRyb2wgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQge1xuICBHbG9iYWxNZXNzYWdlU2VydmljZSxcbiAgR2xvYmFsTWVzc2FnZVR5cGUsXG4gIExhbmd1YWdlU2VydmljZSxcbiAgVXNlcklkU2VydmljZSxcbn0gZnJvbSAnQHNwYXJ0YWN1cy9jb3JlJztcbmltcG9ydCB7IHNhdmVBcyB9IGZyb20gJ2ZpbGUtc2F2ZXInO1xuaW1wb3J0IHsgbWFwLCB0YWtlIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgRHluYW1pY0Zvcm1zQ29uZmlnIH0gZnJvbSAnLi4vLi4vY29yZS9jb25maWcvZm9ybS1jb25maWcnO1xuaW1wb3J0IHsgRmlsZVNlcnZpY2UgfSBmcm9tICcuLi8uLi9jb3JlL3NlcnZpY2VzL2ZpbGUvZmlsZS5zZXJ2aWNlJztcbmltcG9ydCB7IEFic3RyYWN0Rm9ybUNvbXBvbmVudCB9IGZyb20gJy4uL2Fic3RyYWN0LWZvcm0vYWJzdHJhY3QtZm9ybS5jb21wb25lbnQnO1xuaW1wb3J0IHsgRm9ybVNlcnZpY2UgfSBmcm9tICcuLy4uLy4uL2NvcmUvc2VydmljZXMvZm9ybS9mb3JtLnNlcnZpY2UnO1xuaW1wb3J0IHsgRm9ybURhdGFTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vY29yZS9zZXJ2aWNlcy9kYXRhL2Zvcm0tZGF0YS5zZXJ2aWNlJztcbmltcG9ydCB7IEZpZWxkQ29uZmlnIH0gZnJvbSAnLi4vLi4vY29yZSc7XG5pbXBvcnQgeyBEb2N1bWVudEZpbGUgfSBmcm9tICcuLi8uLi9jb3JlL21vZGVscy9mb3JtLW9jYy5tb2RlbHMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjeC11cGxvYWQnLFxuICB0ZW1wbGF0ZVVybDogJy4vdXBsb2FkLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgVXBsb2FkQ29tcG9uZW50IGV4dGVuZHMgQWJzdHJhY3RGb3JtQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgZmlsZUxpc3Q6IERvY3VtZW50RmlsZVtdID0gW107XG4gIHVwbG9hZENvbnRyb2w6IEFic3RyYWN0Q29udHJvbDtcbiAgaW5kaXZpZHVhbFByb2dyZXNzID0ge307XG4gIGZpbGVzID0gW107XG4gIHVwbG9hZERpc2FibGUgPSBmYWxzZTtcbiAgcmVtb3ZlQWxsRGlzYWJsZSA9IGZhbHNlO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByb3RlY3RlZCBhcHBDb25maWc6IER5bmFtaWNGb3Jtc0NvbmZpZyxcbiAgICBwcm90ZWN0ZWQgbGFuZ3VhZ2VTZXJ2aWNlOiBMYW5ndWFnZVNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIGluamVjdG9yOiBJbmplY3RvcixcbiAgICBwcm90ZWN0ZWQgZm9ybVNlcnZpY2U6IEZvcm1TZXJ2aWNlLFxuICAgIHByb3RlY3RlZCBmb3JtRGF0YVNlcnZpY2U6IEZvcm1EYXRhU2VydmljZSxcbiAgICBwcm90ZWN0ZWQgZmlsZVVwbG9hZFNlcnZpY2U6IEZpbGVTZXJ2aWNlLFxuICAgIHByb3RlY3RlZCBjZDogQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gICAgcHJvdGVjdGVkIHVzZXJJZFNlcnZpY2U6IFVzZXJJZFNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIGdsb2JhbE1lc3NhZ2VTZXJ2aWNlOiBHbG9iYWxNZXNzYWdlU2VydmljZVxuICApIHtcbiAgICBzdXBlcihhcHBDb25maWcsIGxhbmd1YWdlU2VydmljZSwgaW5qZWN0b3IsIGZvcm1TZXJ2aWNlKTtcbiAgfVxuXG4gIEBIb3N0TGlzdGVuZXIoJ2NoYW5nZScsIFsnJGV2ZW50J10pXG4gIGhhbmRsZUZpbGVzKGV2ZW50KSB7XG4gICAgLy8gUmVzZXQgd2hlbiB1c2VyIGlzIGNob29zaW5nIGZpbGVzIGFnYWluXG4gICAgdGhpcy5yZXNldEZpbGVMaXN0KCk7XG4gICAgdGhpcy5pbmRpdmlkdWFsUHJvZ3Jlc3MgPSB7fTtcbiAgICB0aGlzLnVwbG9hZERpc2FibGUgPSBmYWxzZTtcbiAgICBjb25zdCBmaWx0ZXJlZEZpbGVzID0gdGhpcy5maWx0ZXJGaWxlcyh0aGlzLmNvbmZpZywgZXZlbnQudGFyZ2V0LmZpbGVzKTtcbiAgICBpZiAoXG4gICAgICB0aGlzLmNvbmZpZy5hY2NlcHQudG9TdHJpbmcoKSA9PT0gZXZlbnQudGFyZ2V0LmFjY2VwdCAmJlxuICAgICAgdGhpcy5jb25maWcubXVsdGlwbGUgPT09IGV2ZW50LnRhcmdldC5tdWx0aXBsZVxuICAgICkge1xuICAgICAgdGhpcy5maWxlTGlzdCA9IEFycmF5LmZyb20oZmlsdGVyZWRGaWxlcyk7XG4gICAgICB0aGlzLmZpbGVMaXN0LnNwbGljZSh0aGlzLmNvbmZpZy5tYXhVcGxvYWRzKTtcbiAgICAgIGlmICh0aGlzLmZpbGVMaXN0Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICB0aGlzLnNldFZhbHVlQW5kVmFsaWRhdGUobnVsbCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIHRyaWdnZXJpbmcgcmVzZXQgYW5kIHZhbGlkYXRpb24gaWYgc29tZXRoaW5nIHdhcyBtYW5pcHVsYXRlZCB0aHJvdWdoIERPTSBpbnNwZWN0b3JcbiAgICAgIC8vIG9yIGZpbGVzIGFyZSB2aW9sYXRpbmcgY29uZmlnIHJ1bGVzXG4gICAgICB0aGlzLnNldFZhbHVlQW5kVmFsaWRhdGUobnVsbCk7XG4gICAgfVxuICB9XG5cbiAgbmdPbkluaXQoKSB7XG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgICB0aGlzLnVwbG9hZENvbnRyb2wgPSB0aGlzLmdyb3VwLmdldCh0aGlzLmNvbmZpZy5uYW1lKTtcbiAgICB0aGlzLnBvcHVsYXRlVXBsb2FkZWRGaWxlcygpO1xuICB9XG5cbiAgcHJvdGVjdGVkIHBvcHVsYXRlVXBsb2FkZWRGaWxlcygpIHtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbi5hZGQoXG4gICAgICB0aGlzLmZpbGVVcGxvYWRTZXJ2aWNlXG4gICAgICAgIC5nZXRVcGxvYWRlZERvY3VtZW50cygpXG4gICAgICAgIC5waXBlKFxuICAgICAgICAgIG1hcChmaWxlc09iaiA9PiB7XG4gICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoZmlsZXNPYmo/LmZpbGVzKS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgIHRoaXMuZmlsZUxpc3QgPSBBcnJheS5mcm9tKE9iamVjdC52YWx1ZXMoZmlsZXNPYmo/LmZpbGVzKSk7XG4gICAgICAgICAgICAgIHRoaXMuZmlsZUxpc3QuZm9yRWFjaCgoZmlsZTogRG9jdW1lbnRGaWxlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLmZpbGVzLmluY2x1ZGVzKGZpbGUuY29kZSkpIHtcbiAgICAgICAgICAgICAgICAgIHRoaXMuZmlsZXMucHVzaChmaWxlLmNvZGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHRoaXMudXBsb2FkQ29udHJvbD8uc2V0VmFsdWUodGhpcy5maWxlcyk7XG4gICAgICAgICAgICAgIHRoaXMudXBsb2FkRGlzYWJsZSA9IHRydWU7XG4gICAgICAgICAgICAgIHRoaXMuY2QuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgdGhpcy51cGxvYWRDb250cm9sPy5zZXRWYWx1ZShudWxsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KVxuICAgICAgICApXG4gICAgICAgIC5zdWJzY3JpYmUoKVxuICAgICk7XG4gIH1cblxuICBwcm90ZWN0ZWQgZmlsdGVyRmlsZXMoY29uZmlnOiBGaWVsZENvbmZpZywgZmlsZXM6IEZpbGVMaXN0KSB7XG4gICAgY29uc3QgZmlsdGVkRmlsZXMgPSBbXTtcbiAgICBBcnJheS5mcm9tKGZpbGVzKS5mb3JFYWNoKGZpbGUgPT4ge1xuICAgICAgaWYgKFxuICAgICAgICBjb25maWcuYWNjZXB0LmluY2x1ZGVzKGZpbGUudHlwZSkgJiZcbiAgICAgICAgZmlsZS5zaXplIDw9IHRoaXMuY29uZmlnLm1heEZpbGVTaXplXG4gICAgICApIHtcbiAgICAgICAgZmlsdGVkRmlsZXMucHVzaChmaWxlKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gZmlsdGVkRmlsZXM7XG4gIH1cblxuICBjb252ZXJ0RmlsZVNpemUoYnl0ZXM6IG51bWJlcikge1xuICAgIGNvbnN0IHNpemVzID0gWydCeXRlcycsICdLQicsICdNQiddO1xuICAgIGNvbnN0IGkgPSBOdW1iZXIoTWF0aC5mbG9vcihNYXRoLmxvZyhieXRlcykgLyBNYXRoLmxvZygxMDI0KSkpO1xuICAgIGlmIChpID09PSAwKSB7XG4gICAgICByZXR1cm4gYCR7Ynl0ZXN9ICR7c2l6ZXNbaV19YDtcbiAgICB9XG4gICAgcmV0dXJuIGAkeyhieXRlcyAvIDEwMjQgKiogaSkudG9GaXhlZCgxKX0gJHtzaXplc1tpXX1gO1xuICB9XG5cbiAgdXBsb2FkRmlsZXMoZmlsZXM6IERvY3VtZW50RmlsZVtdKSB7XG4gICAgdGhpcy51cGxvYWREaXNhYmxlID0gdHJ1ZTtcbiAgICB0aGlzLnJlbW92ZUFsbERpc2FibGUgPSB0cnVlO1xuICAgIHRoaXMuc2V0VmFsdWVBbmRWYWxpZGF0ZSh0aGlzLmZpbGVMaXN0KTtcbiAgICBmaWxlcy5mb3JFYWNoKChmaWxlLCBpbmRleCkgPT4ge1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb24uYWRkKFxuICAgICAgICB0aGlzLmZpbGVVcGxvYWRTZXJ2aWNlLnVwbG9hZEZpbGUoZmlsZSkuc3Vic2NyaWJlKFxuICAgICAgICAgIGV2ZW50ID0+IHtcbiAgICAgICAgICAgIGlmIChldmVudD8udHlwZSA9PT0gSHR0cEV2ZW50VHlwZS5VcGxvYWRQcm9ncmVzcykge1xuICAgICAgICAgICAgICB0aGlzLmluZGl2aWR1YWxQcm9ncmVzc1tpbmRleF0gPSBNYXRoLnJvdW5kKFxuICAgICAgICAgICAgICAgICgxMDAgKiBldmVudC5sb2FkZWQpIC8gZXZlbnQudG90YWxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgdGhpcy5jZC5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBIdHRwUmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgdGhpcy5oYW5kbGVGaWxlUmVzcG9uc2UoZXZlbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gd2hlbiBhbGwgZmlsZXMgYXJlIGZpbmlzaGVkIHVwbG9hZGluZyBzaG93IHRoZSByZW1vdmUgYWxsIGJ1dHRvblxuICAgICAgICAgICAgdGhpcy5yZW1vdmVBbGxEaXNhYmxlID0gISF0aGlzLm92ZXJhbGxQcm9ncmVzc0ZpbmlzaGVkKFxuICAgICAgICAgICAgICB0aGlzLmluZGl2aWR1YWxQcm9ncmVzc1xuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIGVycm9yID0+IHtcbiAgICAgICAgICAgIHRoaXMuZ2xvYmFsTWVzc2FnZVNlcnZpY2UuYWRkKFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAga2V5OiAnZHluYW1pY2Zvcm1zLmRvY3VtZW50VXBsb2FkRXJyb3InLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBHbG9iYWxNZXNzYWdlVHlwZS5NU0dfVFlQRV9FUlJPUlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfSk7XG4gIH1cblxuICByZW1vdmVGaWxlKGluZGV4OiBudW1iZXIsIHVwbG9hZEZpZWxkOiBGaWVsZENvbmZpZykge1xuICAgIHRoaXMucmVtb3ZlRnJvbVN0b3JhZ2UoaW5kZXgpO1xuICAgIHRoaXMuZmlsZUxpc3Quc3BsaWNlKGluZGV4LCAxKTtcbiAgICBpZiAodGhpcy5maWxlcy5sZW5ndGggIT09IDApIHtcbiAgICAgIHRoaXMuZmlsZXMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgIHRoaXMuc2V0VmFsdWVBbmRWYWxpZGF0ZSh0aGlzLmZpbGVzKTtcbiAgICB9XG5cbiAgICAvLyByZXNldCBET00gRmlsZSBlbGVtZW50IHRvIHN5bmMgaXQgd2l0aCByZWFjdGl2ZSBjb250cm9sXG4gICAgaWYgKHRoaXMuZmlsZUxpc3QubGVuZ3RoID09PSAwKSB7XG4gICAgICB1cGxvYWRGaWVsZC52YWx1ZSA9IG51bGw7XG4gICAgfVxuICB9XG5cbiAgcmVtb3ZlQWxsKHVwbG9hZEZpZWxkOiBGaWVsZENvbmZpZykge1xuICAgIHRoaXMucmVtb3ZlRnJvbVN0b3JhZ2UoKTtcbiAgICB0aGlzLmZpbGVMaXN0ID0gW107XG4gICAgdXBsb2FkRmllbGQudmFsdWUgPSBudWxsO1xuICAgIHRoaXMuc2V0VmFsdWVBbmRWYWxpZGF0ZSh0aGlzLmZpbGVMaXN0KTtcbiAgfVxuXG4gIGRvd25sb2FkRmlsZShmaWxlKSB7XG4gICAgdGhpcy5zdWJzY3JpcHRpb24uYWRkKFxuICAgICAgdGhpcy5maWxlVXBsb2FkU2VydmljZVxuICAgICAgICAuZ2V0RmlsZShmaWxlLmNvZGUsIGZpbGUudHlwZSA/IGZpbGUudHlwZSA6IGZpbGUubWltZSlcbiAgICAgICAgLnBpcGUoXG4gICAgICAgICAgbWFwKGRvd25sb2FkZWRGaWxlID0+IHtcbiAgICAgICAgICAgIHNhdmVBcyhkb3dubG9hZGVkRmlsZSwgZmlsZS5uYW1lKTtcbiAgICAgICAgICB9KVxuICAgICAgICApXG4gICAgICAgIC5zdWJzY3JpYmUoKVxuICAgICk7XG4gIH1cblxuICBwcm90ZWN0ZWQgcmVtb3ZlRnJvbVN0b3JhZ2UoaW5kZXg/OiBudW1iZXIpIHtcbiAgICAvLyBFeGVjdXRlIEh0dHAuRGVsZXRlIHJlcXVlc3QgdG8gYmFja2VuZFxuICAgIHRoaXMuc3Vic2NyaXB0aW9uLmFkZChcbiAgICAgIHRoaXMudXNlcklkU2VydmljZVxuICAgICAgICAuZ2V0VXNlcklkKClcbiAgICAgICAgLnBpcGUoXG4gICAgICAgICAgdGFrZSgxKSxcbiAgICAgICAgICBtYXAob2NjVXNlcklkID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGZpbGVDb2RlID0gKDxhbnk+dGhpcy5maWxlTGlzdFtpbmRleF0pPy5jb2RlO1xuICAgICAgICAgICAgaWYgKGZpbGVDb2RlKSB7XG4gICAgICAgICAgICAgIHRoaXMuZmlsZVVwbG9hZFNlcnZpY2UucmVtb3ZlRmlsZUZvckNvZGUob2NjVXNlcklkLCBmaWxlQ29kZSk7XG4gICAgICAgICAgICAgIHRoaXMuc2V0VmFsdWVBbmRWYWxpZGF0ZShudWxsKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHRoaXMuZmlsZVVwbG9hZFNlcnZpY2UucmVtb3ZlQWxsRmlsZXMob2NjVXNlcklkLCB0aGlzLmZpbGVMaXN0KTtcbiAgICAgICAgICAgICAgdGhpcy5maWxlVXBsb2FkU2VydmljZS5yZXNldEZpbGVzKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSlcbiAgICAgICAgKVxuICAgICAgICAuc3Vic2NyaWJlKClcbiAgICApO1xuICB9XG5cbiAgcHJvdGVjdGVkIG92ZXJhbGxQcm9ncmVzc0ZpbmlzaGVkKHByb2dyZXNzKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIE9iamVjdC5rZXlzKHByb2dyZXNzKS5maWx0ZXIoKF9rLCBpKSA9PiBwcm9ncmVzc1tpXSAhPT0gMTAwKS5sZW5ndGggIT09IDBcbiAgICApO1xuICB9XG5cbiAgcHJvdGVjdGVkIHNldFZhbHVlQW5kVmFsaWRhdGUodmFsdWU6IERvY3VtZW50RmlsZVtdKSB7XG4gICAgdGhpcy51cGxvYWRDb250cm9sLnNldFZhbHVlKHZhbHVlKTtcbiAgICB0aGlzLnVwbG9hZENvbnRyb2wubWFya0FzVG91Y2hlZCh7IG9ubHlTZWxmOiB0cnVlIH0pO1xuICB9XG5cbiAgcHJvdGVjdGVkIGhhbmRsZUZpbGVSZXNwb25zZShldmVudCkge1xuICAgIHRoaXMuZmlsZVVwbG9hZFNlcnZpY2Uuc2V0RmlsZUluU3RvcmUoZXZlbnQuYm9keSk7XG4gICAgY29uc3QgZmlsZUNvZGUgPSBldmVudC5ib2R5LmNvZGU7XG4gICAgaWYgKCF0aGlzLmZpbGVzLmluY2x1ZGVzKGZpbGVDb2RlKSkge1xuICAgICAgdGhpcy5maWxlcy5wdXNoKGZpbGVDb2RlKTtcbiAgICB9XG4gICAgdGhpcy51cGxvYWRDb250cm9sLnNldFZhbHVlKHRoaXMuZmlsZXMpO1xuICB9XG5cbiAgcHJvdGVjdGVkIHJlc2V0RmlsZUxpc3QoKSB7XG4gICAgdGhpcy5maWxlTGlzdCA9IFtdO1xuICAgIHRoaXMuZmlsZXMgPSBbXTtcbiAgICB0aGlzLmZpbGVVcGxvYWRTZXJ2aWNlLnJlc2V0RmlsZXMoKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBzZXRGaWxlQ29kZShmaWxlLCBldmVudCkge1xuICAgIGlmIChldmVudC5ib2R5Py5jb2RlKSB7XG4gICAgICBmaWxlLmNvZGUgPSBldmVudC5ib2R5Py5jb2RlO1xuICAgIH1cbiAgICB0aGlzLmNkLmRldGVjdENoYW5nZXMoKTtcbiAgfVxufVxuIiwiPG5nLWNvbnRhaW5lciAqbmdJZj1cImdyb3VwXCI+XG4gIDxkaXYgY2xhc3M9XCJkeW5hbWljLWZpZWxkXCIgW2Zvcm1Hcm91cF09XCJncm91cFwiIFtoaWRkZW5dPVwiY29uZmlnLmhpZGRlblwiPlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICA8bGFiZWwgY2xhc3M9XCJjb2wtZm9ybS1sYWJlbFwiPlxuICAgICAgICB7eyBsYWJlbCB9fVxuICAgICAgICA8bmctY29udGFpbmVyICpuZ0lmPVwiIWNvbmZpZy5yZXF1aXJlZFwiPlxuICAgICAgICAgIHt7ICdkeW5hbWljZm9ybXMub3B0aW9uYWwnIHwgY3hUcmFuc2xhdGUgfX1cbiAgICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICA8L2xhYmVsPlxuICAgICAgPHA+XG4gICAgICAgIHt7ICdkeW5hbWljZm9ybXMubWF4RmlsZVNpemUnIHwgY3hUcmFuc2xhdGUgfX1cbiAgICAgICAge3sgY29udmVydEZpbGVTaXplKGNvbmZpZy5tYXhGaWxlU2l6ZSkgfX1cbiAgICAgIDwvcD5cbiAgICAgIDxkaXYgY2xhc3M9XCJpbnB1dC1ncm91cFwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY3VzdG9tLWZpbGVcIj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICN1cGxvYWRGaWVsZFxuICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgY2xhc3M9XCJjdXN0b20tZmlsZS1pbnB1dFwiXG4gICAgICAgICAgICBbYXR0ci5hcmlhLWRlc2NyaWJlZGJ5XT1cImNvbmZpZy5uYW1lXCJcbiAgICAgICAgICAgIFthdHRyLm5hbWVdPVwiY29uZmlnLm5hbWVcIlxuICAgICAgICAgICAgW2F0dHIubXVsdGlwbGVdPVwiY29uZmlnLm11bHRpcGxlID8gY29uZmlnLm11bHRpcGxlIDogbnVsbFwiXG4gICAgICAgICAgICBbYXR0ci5hY2NlcHRdPVwiY29uZmlnLmFjY2VwdFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgW2F0dHIubmFtZV09XCJjb25maWcubmFtZSArICdfaGlkZGVuJ1wiXG4gICAgICAgICAgICBbZm9ybUNvbnRyb2xOYW1lXT1cImNvbmZpZy5uYW1lXCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImN1c3RvbS1maWxlLWxhYmVsXCIgW2F0dHIuZm9yXT1cImNvbmZpZy5uYW1lXCI+e3tcbiAgICAgICAgICAgICdkeW5hbWljZm9ybXMuY2hvb3NlRmlsZScgfCBjeFRyYW5zbGF0ZVxuICAgICAgICAgIH19PC9sYWJlbD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPG5nLWNvbnRhaW5lciAqbmdJZj1cImZpbGVMaXN0Lmxlbmd0aCA+IDBcIj5cbiAgICAgICAgPHVsIGNsYXNzPVwibWItNFwiPlxuICAgICAgICAgIDxsaSBjbGFzcz1cInB0LTRcIiAqbmdGb3I9XCJsZXQgZmlsZSBvZiBmaWxlTGlzdDsgbGV0IGkgPSBpbmRleFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvdyBuby1ndXR0ZXJzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicm93IG5vLWd1dHRlcnNcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY29sLTFcIiAqbmdJZj1cImZpbGU/LmNvZGVcIlxuICAgICAgICAgICAgICAgICAgICA+PGkgY2xhc3M9XCJmYXMgZmEtY2hlY2tcIj48L2lcbiAgICAgICAgICAgICAgICAgID48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImNvbC04IHRleHQtYnJlYWtcIj57eyBmaWxlPy5uYW1lIH19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJjb2wtM1wiPiB7eyBjb252ZXJ0RmlsZVNpemUoZmlsZS5zaXplKSB9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyb3cgbm8tZ3V0dGVyc1wiPlxuICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJjb2wtNiB0ZXh0LXJpZ2h0XCJcbiAgICAgICAgICAgICAgICAgICAgKm5nSWY9XCJmaWxlPy5jb2RlXCJcbiAgICAgICAgICAgICAgICAgICAgcm9sZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJkb3dubG9hZEZpbGUoZmlsZSlcIlxuICAgICAgICAgICAgICAgICAgICA+PGkgY2xhc3M9XCJmYXMgZmEtZG93bmxvYWRcIj48L2lcbiAgICAgICAgICAgICAgICAgID48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAqbmdJZj1cIiFyZW1vdmVBbGxEaXNhYmxlXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJjb2wtNiB0ZXh0LXJpZ2h0IG1sLWF1dG9cIlxuICAgICAgICAgICAgICAgICAgICByb2xlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cInJlbW92ZUZpbGUoaSwgdXBsb2FkRmllbGQpXCJcbiAgICAgICAgICAgICAgICAgICAgPjxpIGNsYXNzPVwiZmFzIGZhLXRyYXNoXCI+PC9pXG4gICAgICAgICAgICAgICAgICA+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvdyBuby1ndXR0ZXJzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtMTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBjbGFzcz1cInByb2dyZXNzXCJcbiAgICAgICAgICAgICAgICAgICpuZ0lmPVwiXG4gICAgICAgICAgICAgICAgICAgIGluZGl2aWR1YWxQcm9ncmVzc1tpXSA+IDAgJiYgaW5kaXZpZHVhbFByb2dyZXNzW2ldICE9PSAxMDBcbiAgICAgICAgICAgICAgICAgIFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInByb2dyZXNzLWJhclwiXG4gICAgICAgICAgICAgICAgICAgIFtzdHlsZS53aWR0aF09XCJpbmRpdmlkdWFsUHJvZ3Jlc3NbaV0gKyAnJSdcIlxuICAgICAgICAgICAgICAgICAgICByb2xlPVwicHJvZ3Jlc3NiYXJcIlxuICAgICAgICAgICAgICAgICAgICBbYXR0ci5hcmlhLXZhbHVlbm93XT1cImluZGl2aWR1YWxQcm9ncmVzc1tpXVwiXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtdmFsdWVtaW49XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS12YWx1ZW1heD1cIjEwMFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHt7IGluZGl2aWR1YWxQcm9ncmVzc1tpXSB9fVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgPC91bD5cbiAgICAgICAgPG5nLWNvbnRhaW5lciAqbmdJZj1cImZpbGVMaXN0Py5sZW5ndGggPiAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cInJvdyBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlblwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1tZC0zIGNvbC1zbS0zIGNvbC0xMiBtYi0zIG1iLXNtLTBcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICpuZ0lmPVwiZmlsZUxpc3QubGVuZ3RoID4gMSAmJiAhcmVtb3ZlQWxsRGlzYWJsZVwiXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJhY3Rpb24tYnV0dG9uIGJ0bi1ibG9ja1wiXG4gICAgICAgICAgICAgICAgKGNsaWNrKT1cInJlbW92ZUFsbCh1cGxvYWRGaWVsZClcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3sgJ2R5bmFtaWNmb3Jtcy5yZW1vdmVBbGwnIHwgY3hUcmFuc2xhdGUgfX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtbWQtMyBjb2wtc20tMyBjb2wtMTJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICpuZ0lmPVwiIXVwbG9hZERpc2FibGVcIlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiYnRuLXByaW1hcnkgYnRuLWJsb2NrXCJcbiAgICAgICAgICAgICAgICAoY2xpY2spPVwidXBsb2FkRmlsZXMoZmlsZUxpc3QpXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt7ICdkeW5hbWljZm9ybXMudXBsb2FkJyB8IGN4VHJhbnNsYXRlIH19XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvbmctY29udGFpbmVyPlxuICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgPC9kaXY+XG4gICAgPGN4LWVycm9yLW5vdGljZVxuICAgICAgW3dhcm5dPVwiZ3JvdXAuY29udHJvbHNbY29uZmlnLm5hbWVdXCJcbiAgICAgIFtwYXJlbnRDb25maWddPVwiY29uZmlnXCJcbiAgICA+PC9jeC1lcnJvci1ub3RpY2U+XG4gIDwvZGl2PlxuPC9uZy1jb250YWluZXI+XG4iXX0=