import { Component } from '@angular/core';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
function SeparatorComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelement(1, "hr", 1);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("hidden", ctx_r0.config.hidden);
} }
export class SeparatorComponent extends AbstractFormComponent {
}
SeparatorComponent.ɵfac = /*@__PURE__*/ function () { let ɵSeparatorComponent_BaseFactory; return function SeparatorComponent_Factory(t) { return (ɵSeparatorComponent_BaseFactory || (ɵSeparatorComponent_BaseFactory = i0.ɵɵgetInheritedFactory(SeparatorComponent)))(t || SeparatorComponent); }; }();
SeparatorComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SeparatorComponent, selectors: [["cx-separator"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "hidden"]], template: function SeparatorComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, SeparatorComponent_ng_container_0_Template, 2, 1, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i1.NgIf], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SeparatorComponent, [{
        type: Component,
        args: [{ selector: 'cx-separator', template: "<ng-container *ngIf=\"group\">\n  <hr [hidden]=\"config.hidden\" />\n</ng-container>\n" }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VwYXJhdG9yLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9zZXBhcmF0b3Ivc2VwYXJhdG9yLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9zZXBhcmF0b3Ivc2VwYXJhdG9yLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUMsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sMENBQTBDLENBQUM7Ozs7SUNEakYsNkJBQTRCO0lBQzFCLHdCQUErQjtJQUNqQywwQkFBZTs7O0lBRFQsZUFBd0I7SUFBeEIsNkNBQXdCOztBRE05QixNQUFNLE9BQU8sa0JBQW1CLFNBQVEscUJBQXFCOztrUEFBaEQsa0JBQWtCLFNBQWxCLGtCQUFrQjtxRUFBbEIsa0JBQWtCO1FDUC9CLHFGQUVlOztRQUZBLGdDQUFXOzt1RkRPYixrQkFBa0I7Y0FKOUIsU0FBUzsyQkFDRSxjQUFjIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBYnN0cmFjdEZvcm1Db21wb25lbnQgfSBmcm9tICcuLi9hYnN0cmFjdC1mb3JtL2Fic3RyYWN0LWZvcm0uY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY3gtc2VwYXJhdG9yJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3NlcGFyYXRvci5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIFNlcGFyYXRvckNvbXBvbmVudCBleHRlbmRzIEFic3RyYWN0Rm9ybUNvbXBvbmVudCB7fVxuIiwiPG5nLWNvbnRhaW5lciAqbmdJZj1cImdyb3VwXCI+XG4gIDxociBbaGlkZGVuXT1cImNvbmZpZy5oaWRkZW5cIiAvPlxuPC9uZy1jb250YWluZXI+XG4iXX0=