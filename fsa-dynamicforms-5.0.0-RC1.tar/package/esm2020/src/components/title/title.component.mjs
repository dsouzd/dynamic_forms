import { Component } from '@angular/core';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
export class TitleComponent extends AbstractFormComponent {
}
TitleComponent.ɵfac = /*@__PURE__*/ function () { let ɵTitleComponent_BaseFactory; return function TitleComponent_Factory(t) { return (ɵTitleComponent_BaseFactory || (ɵTitleComponent_BaseFactory = i0.ɵɵgetInheritedFactory(TitleComponent)))(t || TitleComponent); }; }();
TitleComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TitleComponent, selectors: [["cx-title"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 3, vars: 3, consts: [[1, "mt-3", 3, "formGroup", "hidden"]], template: function TitleComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "h4");
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd()();
    } if (rf & 2) {
        i0.ɵɵproperty("formGroup", ctx.group)("hidden", ctx.config.hidden);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(ctx.label);
    } }, dependencies: [i1.NgControlStatusGroup, i1.FormGroupDirective], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TitleComponent, [{
        type: Component,
        args: [{ selector: 'cx-title', template: "<div class=\"mt-3\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n  <h4>{{ label }}</h4>\n</div>\n" }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGl0bGUuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb21wb25lbnRzL3RpdGxlL3RpdGxlLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy90aXRsZS90aXRsZS5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFDLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDBDQUEwQyxDQUFDOzs7QUFNakYsTUFBTSxPQUFPLGNBQWUsU0FBUSxxQkFBcUI7OzhOQUE1QyxjQUFjLFNBQWQsY0FBYztpRUFBZCxjQUFjO1FDUDNCLDhCQUErRCxTQUFBO1FBQ3pELFlBQVc7UUFBQSxpQkFBSyxFQUFBOztRQURKLHFDQUFtQiw2QkFBQTtRQUMvQixlQUFXO1FBQVgsK0JBQVc7O3VGRE1KLGNBQWM7Y0FKMUIsU0FBUzsyQkFDRSxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBYnN0cmFjdEZvcm1Db21wb25lbnQgfSBmcm9tICcuLi9hYnN0cmFjdC1mb3JtL2Fic3RyYWN0LWZvcm0uY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY3gtdGl0bGUnLFxuICB0ZW1wbGF0ZVVybDogJy4vdGl0bGUuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBUaXRsZUNvbXBvbmVudCBleHRlbmRzIEFic3RyYWN0Rm9ybUNvbXBvbmVudCB7fVxuIiwiPGRpdiBjbGFzcz1cIm10LTNcIiBbZm9ybUdyb3VwXT1cImdyb3VwXCIgW2hpZGRlbl09XCJjb25maWcuaGlkZGVuXCI+XG4gIDxoND57eyBsYWJlbCB9fTwvaDQ+XG48L2Rpdj5cbiJdfQ==