import { Component } from '@angular/core';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
export class DataHolderComponent extends AbstractFormComponent {
}
DataHolderComponent.ɵfac = /*@__PURE__*/ function () { let ɵDataHolderComponent_BaseFactory; return function DataHolderComponent_Factory(t) { return (ɵDataHolderComponent_BaseFactory || (ɵDataHolderComponent_BaseFactory = i0.ɵɵgetInheritedFactory(DataHolderComponent)))(t || DataHolderComponent); }; }();
DataHolderComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataHolderComponent, selectors: [["ng-component"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 0, vars: 0, template: function DataHolderComponent_Template(rf, ctx) { }, encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataHolderComponent, [{
        type: Component,
        args: [{
                template: '',
            }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YS1ob2xkZXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb21wb25lbnRzL2RhdGEtaG9sZGVyL2RhdGEtaG9sZGVyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFDLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDBDQUEwQyxDQUFDOztBQUtqRixNQUFNLE9BQU8sbUJBQW9CLFNBQVEscUJBQXFCOzt1UEFBakQsbUJBQW1CLFNBQW5CLG1CQUFtQjtzRUFBbkIsbUJBQW1CO3VGQUFuQixtQkFBbUI7Y0FIL0IsU0FBUztlQUFDO2dCQUNULFFBQVEsRUFBRSxFQUFFO2FBQ2IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFic3RyYWN0Rm9ybUNvbXBvbmVudCB9IGZyb20gJy4uL2Fic3RyYWN0LWZvcm0vYWJzdHJhY3QtZm9ybS5jb21wb25lbnQnO1xuXG5AQ29tcG9uZW50KHtcbiAgdGVtcGxhdGU6ICcnLFxufSlcbmV4cG9ydCBjbGFzcyBEYXRhSG9sZGVyQ29tcG9uZW50IGV4dGVuZHMgQWJzdHJhY3RGb3JtQ29tcG9uZW50IHt9XG4iXX0=