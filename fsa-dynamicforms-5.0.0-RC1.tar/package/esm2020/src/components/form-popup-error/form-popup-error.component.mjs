import { Component, ElementRef, HostListener } from '@angular/core';
import { LaunchDialogService } from '@spartacus/storefront';
import { FormComponentService } from '../form-component.service';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/storefront";
import * as i2 from "../form-component.service";
import * as i3 from "@spartacus/core";
export class FormPopupErrorComponent {
    constructor(launchDialogService, formComponentService, el) {
        this.launchDialogService = launchDialogService;
        this.formComponentService = formComponentService;
        this.el = el;
    }
    handleClick(event) {
        if (event.target.tagName === this.el.nativeElement.tagName) {
            this.dismissModal('Cross click');
        }
    }
    dismissModal(reason) {
        this.launchDialogService.closeDialog(reason);
        this.formComponentService.isPopulatedFormInvalidSource.next(false);
    }
}
FormPopupErrorComponent.ɵfac = function FormPopupErrorComponent_Factory(t) { return new (t || FormPopupErrorComponent)(i0.ɵɵdirectiveInject(i1.LaunchDialogService), i0.ɵɵdirectiveInject(i2.FormComponentService), i0.ɵɵdirectiveInject(i0.ElementRef)); };
FormPopupErrorComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FormPopupErrorComponent, selectors: [["cx-form-popup-error"]], hostBindings: function FormPopupErrorComponent_HostBindings(rf, ctx) { if (rf & 1) {
        i0.ɵɵlistener("click", function FormPopupErrorComponent_click_HostBindingHandler($event) { return ctx.handleClick($event); });
    } }, decls: 10, vars: 6, consts: [[1, "popup-content-wrapper"], [1, "modal-header"], ["type", "button", "aria-label", "Close", 1, "close", 3, "click"], [1, "modal-body"]], template: function FormPopupErrorComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "h3");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "cxTranslate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "button", 2);
        i0.ɵɵlistener("click", function FormPopupErrorComponent_Template_button_click_5_listener() { return ctx.dismissModal("Cross click"); });
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(6, "div", 3)(7, "h6");
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "cxTranslate");
        i0.ɵɵelementEnd()()();
    } if (rf & 2) {
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "dynamicforms.validationErrors"), " ");
        i0.ɵɵadvance(5);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 4, "dynamicforms.fillOutProperly"), " ");
    } }, dependencies: [i3.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormPopupErrorComponent, [{
        type: Component,
        args: [{ selector: 'cx-form-popup-error', template: "<div class=\"popup-content-wrapper\">\n  <div class=\"modal-header\">\n    <h3>\n      {{ 'dynamicforms.validationErrors' | cxTranslate }}\n    </h3>\n    <button\n      type=\"button\"\n      class=\"close\"\n      aria-label=\"Close\"\n      (click)=\"dismissModal('Cross click')\"\n    ></button>\n  </div>\n  <div class=\"modal-body\">\n    <h6>\n      {{ 'dynamicforms.fillOutProperly' | cxTranslate }}\n    </h6>\n  </div>\n</div>\n" }]
    }], function () { return [{ type: i1.LaunchDialogService }, { type: i2.FormComponentService }, { type: i0.ElementRef }]; }, { handleClick: [{
            type: HostListener,
            args: ['click', ['$event']]
        }] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1wb3B1cC1lcnJvci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvbXBvbmVudHMvZm9ybS1wb3B1cC1lcnJvci9mb3JtLXBvcHVwLWVycm9yLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9mb3JtLXBvcHVwLWVycm9yL2Zvcm0tcG9wdXAtZXJyb3IuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRXBFLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzVELE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLDJCQUEyQixDQUFDOzs7OztBQU1qRSxNQUFNLE9BQU8sdUJBQXVCO0lBQ2xDLFlBQ1ksbUJBQXdDLEVBQ3hDLG9CQUEwQyxFQUMxQyxFQUFjO1FBRmQsd0JBQW1CLEdBQW5CLG1CQUFtQixDQUFxQjtRQUN4Qyx5QkFBb0IsR0FBcEIsb0JBQW9CLENBQXNCO1FBQzFDLE9BQUUsR0FBRixFQUFFLENBQVk7SUFDdkIsQ0FBQztJQUdKLFdBQVcsQ0FBQyxLQUFjO1FBQ3hCLElBQUssS0FBSyxDQUFDLE1BQWMsQ0FBQyxPQUFPLEtBQUssSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFO1lBQ25FLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDbEM7SUFDSCxDQUFDO0lBRUQsWUFBWSxDQUFDLE1BQVk7UUFDdkIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsb0JBQW9CLENBQUMsNEJBQTRCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3JFLENBQUM7OzhGQWpCVSx1QkFBdUI7MEVBQXZCLHVCQUF1QjswR0FBdkIsdUJBQW1COztRQ1RoQyw4QkFBbUMsYUFBQSxTQUFBO1FBRzdCLFlBQ0Y7O1FBQUEsaUJBQUs7UUFDTCxpQ0FLQztRQURDLG9HQUFTLGlCQUFhLGFBQWEsQ0FBQyxJQUFDO1FBQ3RDLGlCQUFTLEVBQUE7UUFFWiw4QkFBd0IsU0FBQTtRQUVwQixZQUNGOztRQUFBLGlCQUFLLEVBQUEsRUFBQTs7UUFaSCxlQUNGO1FBREUsc0ZBQ0Y7UUFVRSxlQUNGO1FBREUscUZBQ0Y7O3VGRE5TLHVCQUF1QjtjQUpuQyxTQUFTOzJCQUNFLHFCQUFxQjtrSUFXL0IsV0FBVztrQkFEVixZQUFZO21CQUFDLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgRWxlbWVudFJlZiwgSG9zdExpc3RlbmVyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IExhdW5jaERpYWxvZ1NlcnZpY2UgfSBmcm9tICdAc3BhcnRhY3VzL3N0b3JlZnJvbnQnO1xuaW1wb3J0IHsgRm9ybUNvbXBvbmVudFNlcnZpY2UgfSBmcm9tICcuLi9mb3JtLWNvbXBvbmVudC5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY3gtZm9ybS1wb3B1cC1lcnJvcicsXG4gIHRlbXBsYXRlVXJsOiAnLi9mb3JtLXBvcHVwLWVycm9yLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgRm9ybVBvcHVwRXJyb3JDb21wb25lbnQge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcm90ZWN0ZWQgbGF1bmNoRGlhbG9nU2VydmljZTogTGF1bmNoRGlhbG9nU2VydmljZSxcbiAgICBwcm90ZWN0ZWQgZm9ybUNvbXBvbmVudFNlcnZpY2U6IEZvcm1Db21wb25lbnRTZXJ2aWNlLFxuICAgIHByb3RlY3RlZCBlbDogRWxlbWVudFJlZlxuICApIHt9XG5cbiAgQEhvc3RMaXN0ZW5lcignY2xpY2snLCBbJyRldmVudCddKVxuICBoYW5kbGVDbGljayhldmVudDogVUlFdmVudCk6IHZvaWQge1xuICAgIGlmICgoZXZlbnQudGFyZ2V0IGFzIGFueSkudGFnTmFtZSA9PT0gdGhpcy5lbC5uYXRpdmVFbGVtZW50LnRhZ05hbWUpIHtcbiAgICAgIHRoaXMuZGlzbWlzc01vZGFsKCdDcm9zcyBjbGljaycpO1xuICAgIH1cbiAgfVxuXG4gIGRpc21pc3NNb2RhbChyZWFzb24/OiBhbnkpOiB2b2lkIHtcbiAgICB0aGlzLmxhdW5jaERpYWxvZ1NlcnZpY2UuY2xvc2VEaWFsb2cocmVhc29uKTtcbiAgICB0aGlzLmZvcm1Db21wb25lbnRTZXJ2aWNlLmlzUG9wdWxhdGVkRm9ybUludmFsaWRTb3VyY2UubmV4dChmYWxzZSk7XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJwb3B1cC1jb250ZW50LXdyYXBwZXJcIj5cbiAgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxuICAgIDxoMz5cbiAgICAgIHt7ICdkeW5hbWljZm9ybXMudmFsaWRhdGlvbkVycm9ycycgfCBjeFRyYW5zbGF0ZSB9fVxuICAgIDwvaDM+XG4gICAgPGJ1dHRvblxuICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICBjbGFzcz1cImNsb3NlXCJcbiAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZVwiXG4gICAgICAoY2xpY2spPVwiZGlzbWlzc01vZGFsKCdDcm9zcyBjbGljaycpXCJcbiAgICA+PC9idXR0b24+XG4gIDwvZGl2PlxuICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgIDxoNj5cbiAgICAgIHt7ICdkeW5hbWljZm9ybXMuZmlsbE91dFByb3Blcmx5JyB8IGN4VHJhbnNsYXRlIH19XG4gICAgPC9oNj5cbiAgPC9kaXY+XG48L2Rpdj5cbiJdfQ==