import { Component } from '@angular/core';
import { AbstractOptionsComponent } from '../abstract-options/abstract-options.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/forms";
import * as i3 from "../error-notice/error-notice.component";
import * as i4 from "@spartacus/core";
function CheckboxComponent_ng_container_0_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
} }
function CheckboxComponent_ng_container_0_div_6_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const activeLang_r5 = ctx.ngIf;
    const option_r3 = i0.ɵɵnextContext().$implicit;
    const ctx_r4 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", ctx_r4.getLocalizedOption(option_r3.label, activeLang_r5), " ");
} }
function CheckboxComponent_ng_container_0_div_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵelement(1, "input", 6);
    i0.ɵɵelementStart(2, "label", 7);
    i0.ɵɵtemplate(3, CheckboxComponent_ng_container_0_div_6_ng_container_3_Template, 2, 1, "ng-container", 0);
    i0.ɵɵpipe(4, "async");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const option_r3 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵpropertyInterpolate("value", option_r3.name);
    i0.ɵɵproperty("formControlName", ctx_r2.config.name);
    i0.ɵɵattribute("name", option_r3.name)("id", ctx_r2.config.name + option_r3.name);
    i0.ɵɵadvance(1);
    i0.ɵɵattribute("for", ctx_r2.config.name + option_r3.name);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(4, 6, ctx_r2.activeLang$));
} }
function CheckboxComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 1)(2, "label", 2);
    i0.ɵɵtext(3);
    i0.ɵɵtemplate(4, CheckboxComponent_ng_container_0_ng_container_4_Template, 3, 3, "ng-container", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "div", 3);
    i0.ɵɵtemplate(6, CheckboxComponent_ng_container_0_div_6_Template, 5, 8, "div", 4);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(7, "cx-error-notice", 5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r0.config.options);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
} }
export class CheckboxComponent extends AbstractOptionsComponent {
}
CheckboxComponent.ɵfac = /*@__PURE__*/ function () { let ɵCheckboxComponent_BaseFactory; return function CheckboxComponent_Factory(t) { return (ɵCheckboxComponent_BaseFactory || (ɵCheckboxComponent_BaseFactory = i0.ɵɵgetInheritedFactory(CheckboxComponent)))(t || CheckboxComponent); }; }();
CheckboxComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CheckboxComponent, selectors: [["cx-checkbox"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "col-form-label"], [1, "form-check"], [4, "ngFor", "ngForOf"], [3, "warn", "parentConfig"], ["type", "checkbox", 1, "form-check-input", 3, "value", "formControlName"], [1, "pl-3", "pt-1"]], template: function CheckboxComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, CheckboxComponent_ng_container_0_Template, 8, 7, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i1.NgForOf, i1.NgIf, i2.CheckboxControlValueAccessor, i2.NgControlStatus, i2.NgControlStatusGroup, i2.FormGroupDirective, i2.FormControlName, i3.ErrorNoticeComponent, i1.AsyncPipe, i4.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CheckboxComponent, [{
        type: Component,
        args: [{ selector: 'cx-checkbox', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <label class=\"col-form-label\">\n      {{ label }}\n      <ng-container *ngIf=\"!config.required\">\n        {{ 'dynamicforms.optional' | cxTranslate }}\n      </ng-container>\n    </label>\n    <div class=\"form-check\">\n      <div *ngFor=\"let option of config.options\">\n        <input\n          class=\"form-check-input\"\n          type=\"checkbox\"\n          [attr.name]=\"option.name\"\n          [attr.id]=\"config.name + option.name\"\n          value=\"{{ option.name }}\"\n          [formControlName]=\"config.name\"\n        />\n        <label class=\"pl-3 pt-1\" [attr.for]=\"config.name + option.name\"\n          ><ng-container *ngIf=\"activeLang$ | async as activeLang\">\n            {{ getLocalizedOption(option.label, activeLang) }}\n          </ng-container></label\n        >\n      </div>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2tib3guY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jb21wb25lbnRzL2NoZWNrYm94L2NoZWNrYm94LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9jaGVja2JveC9jaGVja2JveC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFDLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLGdEQUFnRCxDQUFDOzs7Ozs7O0lDR3BGLDZCQUF1QztJQUNyQyxZQUNGOztJQUFBLDBCQUFlOztJQURiLGVBQ0Y7SUFERSw4RUFDRjs7O0lBYUssNkJBQXdEO0lBQ3ZELFlBQ0Y7SUFBQSwwQkFBZTs7Ozs7SUFEYixlQUNGO0lBREUsMEZBQ0Y7OztJQVpKLDJCQUEyQztJQUN6QywyQkFPRTtJQUNGLGdDQUNHO0lBQUEseUdBRWM7O0lBQUEsaUJBQ2hCLEVBQUE7Ozs7SUFQQyxlQUF5QjtJQUF6QixpREFBeUI7SUFDekIsb0RBQStCO0lBSC9CLHNDQUF5QiwyQ0FBQTtJQUtGLGVBQXNDO0lBQXRDLDBEQUFzQztJQUM3QyxlQUEwQjtJQUExQiwrREFBMEI7OztJQW5CcEQsNkJBQTRCO0lBQzFCLDhCQUF3RSxlQUFBO0lBRXBFLFlBQ0E7SUFBQSxtR0FFZTtJQUNqQixpQkFBUTtJQUNSLDhCQUF3QjtJQUN0QixpRkFjTTtJQUNSLGlCQUFNO0lBQ04scUNBR21CO0lBQ3JCLGlCQUFNO0lBQ1IsMEJBQWU7OztJQTdCYyxlQUFtQjtJQUFuQix3Q0FBbUIsZ0NBQUE7SUFFMUMsZUFDQTtJQURBLDZDQUNBO0lBQWUsZUFBc0I7SUFBdEIsOENBQXNCO0lBS2IsZUFBaUI7SUFBakIsK0NBQWlCO0lBaUJ6QyxlQUFvQztJQUFwQyxnRUFBb0MsK0JBQUE7O0FEbkIxQyxNQUFNLE9BQU8saUJBQWtCLFNBQVEsd0JBQXdCOzs2T0FBbEQsaUJBQWlCLFNBQWpCLGlCQUFpQjtvRUFBakIsaUJBQWlCO1FDUDlCLG9GQThCZTs7UUE5QkEsZ0NBQVc7O3VGRE9iLGlCQUFpQjtjQUo3QixTQUFTOzJCQUNFLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFic3RyYWN0T3B0aW9uc0NvbXBvbmVudCB9IGZyb20gJy4uL2Fic3RyYWN0LW9wdGlvbnMvYWJzdHJhY3Qtb3B0aW9ucy5jb21wb25lbnQnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjeC1jaGVja2JveCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9jaGVja2JveC5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIENoZWNrYm94Q29tcG9uZW50IGV4dGVuZHMgQWJzdHJhY3RPcHRpb25zQ29tcG9uZW50IHt9XG4iLCI8bmctY29udGFpbmVyICpuZ0lmPVwiZ3JvdXBcIj5cbiAgPGRpdiBjbGFzcz1cImR5bmFtaWMtZmllbGRcIiBbZm9ybUdyb3VwXT1cImdyb3VwXCIgW2hpZGRlbl09XCJjb25maWcuaGlkZGVuXCI+XG4gICAgPGxhYmVsIGNsYXNzPVwiY29sLWZvcm0tbGFiZWxcIj5cbiAgICAgIHt7IGxhYmVsIH19XG4gICAgICA8bmctY29udGFpbmVyICpuZ0lmPVwiIWNvbmZpZy5yZXF1aXJlZFwiPlxuICAgICAgICB7eyAnZHluYW1pY2Zvcm1zLm9wdGlvbmFsJyB8IGN4VHJhbnNsYXRlIH19XG4gICAgICA8L25nLWNvbnRhaW5lcj5cbiAgICA8L2xhYmVsPlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWNoZWNrXCI+XG4gICAgICA8ZGl2ICpuZ0Zvcj1cImxldCBvcHRpb24gb2YgY29uZmlnLm9wdGlvbnNcIj5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgY2xhc3M9XCJmb3JtLWNoZWNrLWlucHV0XCJcbiAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgIFthdHRyLm5hbWVdPVwib3B0aW9uLm5hbWVcIlxuICAgICAgICAgIFthdHRyLmlkXT1cImNvbmZpZy5uYW1lICsgb3B0aW9uLm5hbWVcIlxuICAgICAgICAgIHZhbHVlPVwie3sgb3B0aW9uLm5hbWUgfX1cIlxuICAgICAgICAgIFtmb3JtQ29udHJvbE5hbWVdPVwiY29uZmlnLm5hbWVcIlxuICAgICAgICAvPlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJwbC0zIHB0LTFcIiBbYXR0ci5mb3JdPVwiY29uZmlnLm5hbWUgKyBvcHRpb24ubmFtZVwiXG4gICAgICAgICAgPjxuZy1jb250YWluZXIgKm5nSWY9XCJhY3RpdmVMYW5nJCB8IGFzeW5jIGFzIGFjdGl2ZUxhbmdcIj5cbiAgICAgICAgICAgIHt7IGdldExvY2FsaXplZE9wdGlvbihvcHRpb24ubGFiZWwsIGFjdGl2ZUxhbmcpIH19XG4gICAgICAgICAgPC9uZy1jb250YWluZXI+PC9sYWJlbFxuICAgICAgICA+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8Y3gtZXJyb3Itbm90aWNlXG4gICAgICBbd2Fybl09XCJncm91cC5jb250cm9sc1tjb25maWcubmFtZV1cIlxuICAgICAgW3BhcmVudENvbmZpZ109XCJjb25maWdcIlxuICAgID48L2N4LWVycm9yLW5vdGljZT5cbiAgPC9kaXY+XG48L25nLWNvbnRhaW5lcj5cbiJdfQ==