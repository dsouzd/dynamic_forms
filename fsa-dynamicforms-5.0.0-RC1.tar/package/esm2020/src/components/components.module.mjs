import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { I18nModule, provideDefaultConfig } from '@spartacus/core';
import { AbstractFormComponent } from './abstract-form/abstract-form.component';
import { ButtonComponent } from './button/button.component';
import { DatePickerComponent } from './datepicker/datepicker.component';
import { ErrorNoticeComponent } from './error-notice/error-notice.component';
import { FormComponentDirective } from './form-component.directive';
import { InputComponent } from './input/input.component';
import { RadioComponent } from './radio/radio.component';
import { SelectComponent } from './select/select.component';
import { TextAreaComponent } from './text-area/text-area.component';
import { TimeComponent } from './time/time.component';
import { TitleComponent } from './title/title.component';
import { SeparatorComponent } from './separator/separator.component';
import { CheckboxComponent } from './checkbox/checkbox.component';
import { AbstractOptionsComponent } from './abstract-options/abstract-options.component';
import { FormPopupErrorComponent } from './form-popup-error/form-popup-error.component';
import { DataHolderComponent } from './data-holder/data-holder.component';
import { UploadComponent } from './upload/upload.component';
import { FormComponentService } from './form-component.service';
import { CurrencyComponent } from './currency/currency.component';
import { defaultFormPopupErrorDialogLayoutConfig } from './form-popup-error/default-form-popup-error-dialog-layout.config';
import * as i0 from "@angular/core";
export class ComponentsModule {
}
ComponentsModule.ɵfac = function ComponentsModule_Factory(t) { return new (t || ComponentsModule)(); };
ComponentsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ComponentsModule });
ComponentsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        FormComponentService,
        provideDefaultConfig(defaultFormPopupErrorDialogLayoutConfig),
    ], imports: [CommonModule, ReactiveFormsModule, I18nModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ComponentsModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, ReactiveFormsModule, I18nModule],
                declarations: [
                    FormComponentDirective,
                    AbstractFormComponent,
                    AbstractOptionsComponent,
                    ButtonComponent,
                    DatePickerComponent,
                    ErrorNoticeComponent,
                    DataHolderComponent,
                    InputComponent,
                    RadioComponent,
                    SelectComponent,
                    TextAreaComponent,
                    TimeComponent,
                    TitleComponent,
                    SeparatorComponent,
                    CheckboxComponent,
                    FormPopupErrorComponent,
                    UploadComponent,
                    CurrencyComponent,
                ],
                exports: [
                    FormComponentDirective,
                    AbstractFormComponent,
                    AbstractOptionsComponent,
                    ButtonComponent,
                    DatePickerComponent,
                    ErrorNoticeComponent,
                    DataHolderComponent,
                    InputComponent,
                    RadioComponent,
                    SelectComponent,
                    TextAreaComponent,
                    TimeComponent,
                    TitleComponent,
                    SeparatorComponent,
                    CheckboxComponent,
                    FormPopupErrorComponent,
                    UploadComponent,
                    CurrencyComponent,
                ],
                providers: [
                    FormComponentService,
                    provideDefaultConfig(defaultFormPopupErrorDialogLayoutConfig),
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ComponentsModule, { declarations: [FormComponentDirective,
        AbstractFormComponent,
        AbstractOptionsComponent,
        ButtonComponent,
        DatePickerComponent,
        ErrorNoticeComponent,
        DataHolderComponent,
        InputComponent,
        RadioComponent,
        SelectComponent,
        TextAreaComponent,
        TimeComponent,
        TitleComponent,
        SeparatorComponent,
        CheckboxComponent,
        FormPopupErrorComponent,
        UploadComponent,
        CurrencyComponent], imports: [CommonModule, ReactiveFormsModule, I18nModule], exports: [FormComponentDirective,
        AbstractFormComponent,
        AbstractOptionsComponent,
        ButtonComponent,
        DatePickerComponent,
        ErrorNoticeComponent,
        DataHolderComponent,
        InputComponent,
        RadioComponent,
        SelectComponent,
        TextAreaComponent,
        TimeComponent,
        TitleComponent,
        SeparatorComponent,
        CheckboxComponent,
        FormPopupErrorComponent,
        UploadComponent,
        CurrencyComponent] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tcG9uZW50cy5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvbXBvbmVudHMvY29tcG9uZW50cy5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekMsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDckQsT0FBTyxFQUFFLFVBQVUsRUFBRSxvQkFBb0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ25FLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLHlDQUF5QyxDQUFDO0FBQ2hGLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM1RCxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQztBQUN4RSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSx1Q0FBdUMsQ0FBQztBQUM3RSxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUNwRSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDekQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3pELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM1RCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQztBQUNwRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDdEQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3pELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGlDQUFpQyxDQUFDO0FBQ3JFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLCtCQUErQixDQUFDO0FBQ2xFLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLCtDQUErQyxDQUFDO0FBQ3pGLE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxNQUFNLCtDQUErQyxDQUFDO0FBQ3hGLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLHFDQUFxQyxDQUFDO0FBQzFFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM1RCxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUNoRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUNsRSxPQUFPLEVBQUUsdUNBQXVDLEVBQUUsTUFBTSxrRUFBa0UsQ0FBQzs7QUFpRDNILE1BQU0sT0FBTyxnQkFBZ0I7O2dGQUFoQixnQkFBZ0I7a0VBQWhCLGdCQUFnQjt1RUFMaEI7UUFDVCxvQkFBb0I7UUFDcEIsb0JBQW9CLENBQUMsdUNBQXVDLENBQUM7S0FDOUQsWUE1Q1MsWUFBWSxFQUFFLG1CQUFtQixFQUFFLFVBQVU7dUZBOEM1QyxnQkFBZ0I7Y0EvQzVCLFFBQVE7ZUFBQztnQkFDUixPQUFPLEVBQUUsQ0FBQyxZQUFZLEVBQUUsbUJBQW1CLEVBQUUsVUFBVSxDQUFDO2dCQUN4RCxZQUFZLEVBQUU7b0JBQ1osc0JBQXNCO29CQUN0QixxQkFBcUI7b0JBQ3JCLHdCQUF3QjtvQkFDeEIsZUFBZTtvQkFDZixtQkFBbUI7b0JBQ25CLG9CQUFvQjtvQkFDcEIsbUJBQW1CO29CQUNuQixjQUFjO29CQUNkLGNBQWM7b0JBQ2QsZUFBZTtvQkFDZixpQkFBaUI7b0JBQ2pCLGFBQWE7b0JBQ2IsY0FBYztvQkFDZCxrQkFBa0I7b0JBQ2xCLGlCQUFpQjtvQkFDakIsdUJBQXVCO29CQUN2QixlQUFlO29CQUNmLGlCQUFpQjtpQkFDbEI7Z0JBQ0QsT0FBTyxFQUFFO29CQUNQLHNCQUFzQjtvQkFDdEIscUJBQXFCO29CQUNyQix3QkFBd0I7b0JBQ3hCLGVBQWU7b0JBQ2YsbUJBQW1CO29CQUNuQixvQkFBb0I7b0JBQ3BCLG1CQUFtQjtvQkFDbkIsY0FBYztvQkFDZCxjQUFjO29CQUNkLGVBQWU7b0JBQ2YsaUJBQWlCO29CQUNqQixhQUFhO29CQUNiLGNBQWM7b0JBQ2Qsa0JBQWtCO29CQUNsQixpQkFBaUI7b0JBQ2pCLHVCQUF1QjtvQkFDdkIsZUFBZTtvQkFDZixpQkFBaUI7aUJBQ2xCO2dCQUNELFNBQVMsRUFBRTtvQkFDVCxvQkFBb0I7b0JBQ3BCLG9CQUFvQixDQUFDLHVDQUF1QyxDQUFDO2lCQUM5RDthQUNGOzt3RkFDWSxnQkFBZ0IsbUJBNUN6QixzQkFBc0I7UUFDdEIscUJBQXFCO1FBQ3JCLHdCQUF3QjtRQUN4QixlQUFlO1FBQ2YsbUJBQW1CO1FBQ25CLG9CQUFvQjtRQUNwQixtQkFBbUI7UUFDbkIsY0FBYztRQUNkLGNBQWM7UUFDZCxlQUFlO1FBQ2YsaUJBQWlCO1FBQ2pCLGFBQWE7UUFDYixjQUFjO1FBQ2Qsa0JBQWtCO1FBQ2xCLGlCQUFpQjtRQUNqQix1QkFBdUI7UUFDdkIsZUFBZTtRQUNmLGlCQUFpQixhQW5CVCxZQUFZLEVBQUUsbUJBQW1CLEVBQUUsVUFBVSxhQXNCckQsc0JBQXNCO1FBQ3RCLHFCQUFxQjtRQUNyQix3QkFBd0I7UUFDeEIsZUFBZTtRQUNmLG1CQUFtQjtRQUNuQixvQkFBb0I7UUFDcEIsbUJBQW1CO1FBQ25CLGNBQWM7UUFDZCxjQUFjO1FBQ2QsZUFBZTtRQUNmLGlCQUFpQjtRQUNqQixhQUFhO1FBQ2IsY0FBYztRQUNkLGtCQUFrQjtRQUNsQixpQkFBaUI7UUFDakIsdUJBQXVCO1FBQ3ZCLGVBQWU7UUFDZixpQkFBaUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJlYWN0aXZlRm9ybXNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBJMThuTW9kdWxlLCBwcm92aWRlRGVmYXVsdENvbmZpZyB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBBYnN0cmFjdEZvcm1Db21wb25lbnQgfSBmcm9tICcuL2Fic3RyYWN0LWZvcm0vYWJzdHJhY3QtZm9ybS5jb21wb25lbnQnO1xuaW1wb3J0IHsgQnV0dG9uQ29tcG9uZW50IH0gZnJvbSAnLi9idXR0b24vYnV0dG9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBEYXRlUGlja2VyQ29tcG9uZW50IH0gZnJvbSAnLi9kYXRlcGlja2VyL2RhdGVwaWNrZXIuY29tcG9uZW50JztcbmltcG9ydCB7IEVycm9yTm90aWNlQ29tcG9uZW50IH0gZnJvbSAnLi9lcnJvci1ub3RpY2UvZXJyb3Itbm90aWNlLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBGb3JtQ29tcG9uZW50RGlyZWN0aXZlIH0gZnJvbSAnLi9mb3JtLWNvbXBvbmVudC5kaXJlY3RpdmUnO1xuaW1wb3J0IHsgSW5wdXRDb21wb25lbnQgfSBmcm9tICcuL2lucHV0L2lucHV0LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBSYWRpb0NvbXBvbmVudCB9IGZyb20gJy4vcmFkaW8vcmFkaW8uY29tcG9uZW50JztcbmltcG9ydCB7IFNlbGVjdENvbXBvbmVudCB9IGZyb20gJy4vc2VsZWN0L3NlbGVjdC5jb21wb25lbnQnO1xuaW1wb3J0IHsgVGV4dEFyZWFDb21wb25lbnQgfSBmcm9tICcuL3RleHQtYXJlYS90ZXh0LWFyZWEuY29tcG9uZW50JztcbmltcG9ydCB7IFRpbWVDb21wb25lbnQgfSBmcm9tICcuL3RpbWUvdGltZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgVGl0bGVDb21wb25lbnQgfSBmcm9tICcuL3RpdGxlL3RpdGxlLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBTZXBhcmF0b3JDb21wb25lbnQgfSBmcm9tICcuL3NlcGFyYXRvci9zZXBhcmF0b3IuY29tcG9uZW50JztcbmltcG9ydCB7IENoZWNrYm94Q29tcG9uZW50IH0gZnJvbSAnLi9jaGVja2JveC9jaGVja2JveC5jb21wb25lbnQnO1xuaW1wb3J0IHsgQWJzdHJhY3RPcHRpb25zQ29tcG9uZW50IH0gZnJvbSAnLi9hYnN0cmFjdC1vcHRpb25zL2Fic3RyYWN0LW9wdGlvbnMuY29tcG9uZW50JztcbmltcG9ydCB7IEZvcm1Qb3B1cEVycm9yQ29tcG9uZW50IH0gZnJvbSAnLi9mb3JtLXBvcHVwLWVycm9yL2Zvcm0tcG9wdXAtZXJyb3IuY29tcG9uZW50JztcbmltcG9ydCB7IERhdGFIb2xkZXJDb21wb25lbnQgfSBmcm9tICcuL2RhdGEtaG9sZGVyL2RhdGEtaG9sZGVyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBVcGxvYWRDb21wb25lbnQgfSBmcm9tICcuL3VwbG9hZC91cGxvYWQuY29tcG9uZW50JztcbmltcG9ydCB7IEZvcm1Db21wb25lbnRTZXJ2aWNlIH0gZnJvbSAnLi9mb3JtLWNvbXBvbmVudC5zZXJ2aWNlJztcbmltcG9ydCB7IEN1cnJlbmN5Q29tcG9uZW50IH0gZnJvbSAnLi9jdXJyZW5jeS9jdXJyZW5jeS5jb21wb25lbnQnO1xuaW1wb3J0IHsgZGVmYXVsdEZvcm1Qb3B1cEVycm9yRGlhbG9nTGF5b3V0Q29uZmlnIH0gZnJvbSAnLi9mb3JtLXBvcHVwLWVycm9yL2RlZmF1bHQtZm9ybS1wb3B1cC1lcnJvci1kaWFsb2ctbGF5b3V0LmNvbmZpZyc7XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIFJlYWN0aXZlRm9ybXNNb2R1bGUsIEkxOG5Nb2R1bGVdLFxuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBGb3JtQ29tcG9uZW50RGlyZWN0aXZlLFxuICAgIEFic3RyYWN0Rm9ybUNvbXBvbmVudCxcbiAgICBBYnN0cmFjdE9wdGlvbnNDb21wb25lbnQsXG4gICAgQnV0dG9uQ29tcG9uZW50LFxuICAgIERhdGVQaWNrZXJDb21wb25lbnQsXG4gICAgRXJyb3JOb3RpY2VDb21wb25lbnQsXG4gICAgRGF0YUhvbGRlckNvbXBvbmVudCxcbiAgICBJbnB1dENvbXBvbmVudCxcbiAgICBSYWRpb0NvbXBvbmVudCxcbiAgICBTZWxlY3RDb21wb25lbnQsXG4gICAgVGV4dEFyZWFDb21wb25lbnQsXG4gICAgVGltZUNvbXBvbmVudCxcbiAgICBUaXRsZUNvbXBvbmVudCxcbiAgICBTZXBhcmF0b3JDb21wb25lbnQsXG4gICAgQ2hlY2tib3hDb21wb25lbnQsXG4gICAgRm9ybVBvcHVwRXJyb3JDb21wb25lbnQsXG4gICAgVXBsb2FkQ29tcG9uZW50LFxuICAgIEN1cnJlbmN5Q29tcG9uZW50LFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRm9ybUNvbXBvbmVudERpcmVjdGl2ZSxcbiAgICBBYnN0cmFjdEZvcm1Db21wb25lbnQsXG4gICAgQWJzdHJhY3RPcHRpb25zQ29tcG9uZW50LFxuICAgIEJ1dHRvbkNvbXBvbmVudCxcbiAgICBEYXRlUGlja2VyQ29tcG9uZW50LFxuICAgIEVycm9yTm90aWNlQ29tcG9uZW50LFxuICAgIERhdGFIb2xkZXJDb21wb25lbnQsXG4gICAgSW5wdXRDb21wb25lbnQsXG4gICAgUmFkaW9Db21wb25lbnQsXG4gICAgU2VsZWN0Q29tcG9uZW50LFxuICAgIFRleHRBcmVhQ29tcG9uZW50LFxuICAgIFRpbWVDb21wb25lbnQsXG4gICAgVGl0bGVDb21wb25lbnQsXG4gICAgU2VwYXJhdG9yQ29tcG9uZW50LFxuICAgIENoZWNrYm94Q29tcG9uZW50LFxuICAgIEZvcm1Qb3B1cEVycm9yQ29tcG9uZW50LFxuICAgIFVwbG9hZENvbXBvbmVudCxcbiAgICBDdXJyZW5jeUNvbXBvbmVudCxcbiAgXSxcbiAgcHJvdmlkZXJzOiBbXG4gICAgRm9ybUNvbXBvbmVudFNlcnZpY2UsXG4gICAgcHJvdmlkZURlZmF1bHRDb25maWcoZGVmYXVsdEZvcm1Qb3B1cEVycm9yRGlhbG9nTGF5b3V0Q29uZmlnKSxcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgQ29tcG9uZW50c01vZHVsZSB7fVxuIl19