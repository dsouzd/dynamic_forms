import { Component } from '@angular/core';
import { AbstractOptionsComponent } from '../abstract-options/abstract-options.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/forms";
import * as i3 from "../error-notice/error-notice.component";
import * as i4 from "@spartacus/core";
function SelectComponent_ng_container_0_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
} }
function SelectComponent_ng_container_0_option_10_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const activeLang_r5 = ctx.ngIf;
    const option_r3 = i0.ɵɵnextContext().$implicit;
    const ctx_r4 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", ctx_r4.getLocalizedOption(option_r3.label, activeLang_r5), " ");
} }
function SelectComponent_ng_container_0_option_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "option", 8);
    i0.ɵɵtemplate(1, SelectComponent_ng_container_0_option_10_ng_container_1_Template, 2, 1, "ng-container", 0);
    i0.ɵɵpipe(2, "async");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r3 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("value", option_r3.name);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(2, 2, ctx_r2.activeLang$));
} }
function SelectComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
    i0.ɵɵtext(4);
    i0.ɵɵtemplate(5, SelectComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "select", 4)(7, "option", 5);
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "cxTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(10, SelectComponent_ng_container_0_option_10_Template, 3, 4, "option", 6);
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(11, "cx-error-notice", 7);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formControlName", ctx_r0.config.name);
    i0.ɵɵattribute("name", ctx_r0.config.name);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("value", undefined);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 11, "dynamicforms.pleaseSelect"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r0.config.options);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
} }
export class SelectComponent extends AbstractOptionsComponent {
}
SelectComponent.ɵfac = /*@__PURE__*/ function () { let ɵSelectComponent_BaseFactory; return function SelectComponent_Factory(t) { return (ɵSelectComponent_BaseFactory || (ɵSelectComponent_BaseFactory = i0.ɵɵgetInheritedFactory(SelectComponent)))(t || SelectComponent); }; }();
SelectComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SelectComponent, selectors: [["cx-select"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], [1, "form-control", 3, "formControlName"], ["disabled", "", 3, "value"], [3, "value", 4, "ngFor", "ngForOf"], [3, "warn", "parentConfig"], [3, "value"]], template: function SelectComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, SelectComponent_ng_container_0_Template, 12, 13, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i1.NgForOf, i1.NgIf, i2.NgSelectOption, i2.ɵNgSelectMultipleOption, i2.SelectControlValueAccessor, i2.NgControlStatus, i2.NgControlStatusGroup, i2.FormGroupDirective, i2.FormControlName, i3.ErrorNoticeComponent, i1.AsyncPipe, i4.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SelectComponent, [{
        type: Component,
        args: [{ selector: 'cx-select', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <select\n        class=\"form-control\"\n        [attr.name]=\"config.name\"\n        [formControlName]=\"config.name\"\n      >\n        <option disabled [value]=\"undefined\">\n          {{ 'dynamicforms.pleaseSelect' | cxTranslate }}\n        </option>\n        <option *ngFor=\"let option of config.options\" [value]=\"option.name\">\n          <ng-container *ngIf=\"activeLang$ | async as activeLang\">\n            {{ getLocalizedOption(option.label, activeLang) }}\n          </ng-container>\n        </option>\n      </select>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VsZWN0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9zZWxlY3Qvc2VsZWN0LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9zZWxlY3Qvc2VsZWN0LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUMsT0FBTyxFQUFFLHdCQUF3QixFQUFFLE1BQU0sZ0RBQWdELENBQUM7Ozs7Ozs7SUNJbEYsNkJBQXVDO0lBQ3JDLFlBQ0Y7O0lBQUEsMEJBQWU7O0lBRGIsZUFDRjtJQURFLDhFQUNGOzs7SUFXRSw2QkFBd0Q7SUFDdEQsWUFDRjtJQUFBLDBCQUFlOzs7OztJQURiLGVBQ0Y7SUFERSwwRkFDRjs7O0lBSEYsaUNBQW9FO0lBQ2xFLDJHQUVlOztJQUNqQixpQkFBUzs7OztJQUpxQyxzQ0FBcUI7SUFDbEQsZUFBMEI7SUFBMUIsK0RBQTBCOzs7SUFsQm5ELDZCQUE0QjtJQUMxQiw4QkFBd0UsYUFBQSxlQUFBO0lBR2xFLFlBQ0E7SUFBQSxpR0FFZTtJQUNqQixpQkFBUTtJQUNSLGlDQUlDLGdCQUFBO0lBRUcsWUFDRjs7SUFBQSxpQkFBUztJQUNULHVGQUlTO0lBQ1gsaUJBQVMsRUFBQTtJQUVYLHNDQUdtQjtJQUNyQixpQkFBTTtJQUNSLDBCQUFlOzs7SUE1QmMsZUFBbUI7SUFBbkIsd0NBQW1CLGdDQUFBO0lBR3hDLGVBQ0E7SUFEQSw2Q0FDQTtJQUFlLGVBQXNCO0lBQXRCLDhDQUFzQjtJQU9yQyxlQUErQjtJQUEvQixvREFBK0I7SUFEL0IsMENBQXlCO0lBR1IsZUFBbUI7SUFBbkIsaUNBQW1CO0lBQ2xDLGVBQ0Y7SUFERSxtRkFDRjtJQUMyQixlQUFpQjtJQUFqQiwrQ0FBaUI7SUFROUMsZUFBb0M7SUFBcEMsZ0VBQW9DLCtCQUFBOztBRGxCMUMsTUFBTSxPQUFPLGVBQWdCLFNBQVEsd0JBQXdCOzttT0FBaEQsZUFBZSxTQUFmLGVBQWU7a0VBQWYsZUFBZTtRQ1A1QixvRkE2QmU7O1FBN0JBLGdDQUFXOzt1RkRPYixlQUFlO2NBSjNCLFNBQVM7MkJBQ0UsV0FBVyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWJzdHJhY3RPcHRpb25zQ29tcG9uZW50IH0gZnJvbSAnLi4vYWJzdHJhY3Qtb3B0aW9ucy9hYnN0cmFjdC1vcHRpb25zLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2N4LXNlbGVjdCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9zZWxlY3QuY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBTZWxlY3RDb21wb25lbnQgZXh0ZW5kcyBBYnN0cmFjdE9wdGlvbnNDb21wb25lbnQge31cbiIsIjxuZy1jb250YWluZXIgKm5nSWY9XCJncm91cFwiPlxuICA8ZGl2IGNsYXNzPVwiZHluYW1pYy1maWVsZFwiIFtmb3JtR3JvdXBdPVwiZ3JvdXBcIiBbaGlkZGVuXT1cImNvbmZpZy5oaWRkZW5cIj5cbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgPGxhYmVsIGNsYXNzPVwiY29sLWZvcm0tbGFiZWxcIj5cbiAgICAgICAge3sgbGFiZWwgfX1cbiAgICAgICAgPG5nLWNvbnRhaW5lciAqbmdJZj1cIiFjb25maWcucmVxdWlyZWRcIj5cbiAgICAgICAgICB7eyAnZHluYW1pY2Zvcm1zLm9wdGlvbmFsJyB8IGN4VHJhbnNsYXRlIH19XG4gICAgICAgIDwvbmctY29udGFpbmVyPlxuICAgICAgPC9sYWJlbD5cbiAgICAgIDxzZWxlY3RcbiAgICAgICAgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIlxuICAgICAgICBbYXR0ci5uYW1lXT1cImNvbmZpZy5uYW1lXCJcbiAgICAgICAgW2Zvcm1Db250cm9sTmFtZV09XCJjb25maWcubmFtZVwiXG4gICAgICA+XG4gICAgICAgIDxvcHRpb24gZGlzYWJsZWQgW3ZhbHVlXT1cInVuZGVmaW5lZFwiPlxuICAgICAgICAgIHt7ICdkeW5hbWljZm9ybXMucGxlYXNlU2VsZWN0JyB8IGN4VHJhbnNsYXRlIH19XG4gICAgICAgIDwvb3B0aW9uPlxuICAgICAgICA8b3B0aW9uICpuZ0Zvcj1cImxldCBvcHRpb24gb2YgY29uZmlnLm9wdGlvbnNcIiBbdmFsdWVdPVwib3B0aW9uLm5hbWVcIj5cbiAgICAgICAgICA8bmctY29udGFpbmVyICpuZ0lmPVwiYWN0aXZlTGFuZyQgfCBhc3luYyBhcyBhY3RpdmVMYW5nXCI+XG4gICAgICAgICAgICB7eyBnZXRMb2NhbGl6ZWRPcHRpb24ob3B0aW9uLmxhYmVsLCBhY3RpdmVMYW5nKSB9fVxuICAgICAgICAgIDwvbmctY29udGFpbmVyPlxuICAgICAgICA8L29wdGlvbj5cbiAgICAgIDwvc2VsZWN0PlxuICAgIDwvZGl2PlxuICAgIDxjeC1lcnJvci1ub3RpY2VcbiAgICAgIFt3YXJuXT1cImdyb3VwLmNvbnRyb2xzW2NvbmZpZy5uYW1lXVwiXG4gICAgICBbcGFyZW50Q29uZmlnXT1cImNvbmZpZ1wiXG4gICAgPjwvY3gtZXJyb3Itbm90aWNlPlxuICA8L2Rpdj5cbjwvbmctY29udGFpbmVyPlxuIl19