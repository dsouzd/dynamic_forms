import { Component } from '@angular/core';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/forms";
function ButtonComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 1)(2, "button", 2);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("disabled", ctx_r0.config.disabled);
    i0.ɵɵattribute("name", ctx_r0.config.name);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
} }
export class ButtonComponent extends AbstractFormComponent {
}
ButtonComponent.ɵfac = /*@__PURE__*/ function () { let ɵButtonComponent_BaseFactory; return function ButtonComponent_Factory(t) { return (ɵButtonComponent_BaseFactory || (ɵButtonComponent_BaseFactory = i0.ɵɵgetInheritedFactory(ButtonComponent)))(t || ButtonComponent); }; }();
ButtonComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ButtonComponent, selectors: [["cx-button"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], ["type", "submit", 1, "btn", "btn-primary", 3, "disabled"]], template: function ButtonComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, ButtonComponent_ng_container_0_Template, 4, 5, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i1.NgIf, i2.NgControlStatusGroup, i2.FormGroupDirective], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ButtonComponent, [{
        type: Component,
        args: [{ selector: 'cx-button', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <button\n      class=\"btn btn-primary\"\n      [disabled]=\"config.disabled\"\n      type=\"submit\"\n      [attr.name]=\"config.name\"\n    >\n      {{ label }}\n    </button>\n  </div>\n</ng-container>\n" }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnV0dG9uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9idXR0b24vYnV0dG9uLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9idXR0b24vYnV0dG9uLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUMsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sMENBQTBDLENBQUM7Ozs7O0lDRGpGLDZCQUE0QjtJQUMxQiw4QkFBd0UsZ0JBQUE7SUFPcEUsWUFDRjtJQUFBLGlCQUFTLEVBQUE7SUFFYiwwQkFBZTs7O0lBVmMsZUFBbUI7SUFBbkIsd0NBQW1CLGdDQUFBO0lBRzFDLGVBQTRCO0lBQTVCLGlEQUE0QjtJQUU1QiwwQ0FBeUI7SUFFekIsZUFDRjtJQURFLDZDQUNGOztBREZKLE1BQU0sT0FBTyxlQUFnQixTQUFRLHFCQUFxQjs7bU9BQTdDLGVBQWUsU0FBZixlQUFlO2tFQUFmLGVBQWU7UUNQNUIsa0ZBV2U7O1FBWEEsZ0NBQVc7O3VGRE9iLGVBQWU7Y0FKM0IsU0FBUzsyQkFDRSxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBYnN0cmFjdEZvcm1Db21wb25lbnQgfSBmcm9tICcuLi9hYnN0cmFjdC1mb3JtL2Fic3RyYWN0LWZvcm0uY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY3gtYnV0dG9uJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2J1dHRvbi5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEJ1dHRvbkNvbXBvbmVudCBleHRlbmRzIEFic3RyYWN0Rm9ybUNvbXBvbmVudCB7fVxuIiwiPG5nLWNvbnRhaW5lciAqbmdJZj1cImdyb3VwXCI+XG4gIDxkaXYgY2xhc3M9XCJkeW5hbWljLWZpZWxkXCIgW2Zvcm1Hcm91cF09XCJncm91cFwiIFtoaWRkZW5dPVwiY29uZmlnLmhpZGRlblwiPlxuICAgIDxidXR0b25cbiAgICAgIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5XCJcbiAgICAgIFtkaXNhYmxlZF09XCJjb25maWcuZGlzYWJsZWRcIlxuICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICBbYXR0ci5uYW1lXT1cImNvbmZpZy5uYW1lXCJcbiAgICA+XG4gICAgICB7eyBsYWJlbCB9fVxuICAgIDwvYnV0dG9uPlxuICA8L2Rpdj5cbjwvbmctY29udGFpbmVyPlxuIl19