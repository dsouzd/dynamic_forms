import { Component, Injector } from '@angular/core';
import { LanguageService } from '@spartacus/core';
import { FormDateConfig } from '../../core/config/date-config/date-config';
import { DynamicFormsConfig } from '../../core/config/form-config';
import { FormService } from '../../core/services/form/form.service';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
import * as i1 from "../../core/config/form-config";
import * as i2 from "@spartacus/core";
import * as i3 from "../../core/services/form/form.service";
import * as i4 from "../../core/config/date-config/date-config";
import * as i5 from "@angular/common";
import * as i6 from "@angular/forms";
import * as i7 from "../error-notice/error-notice.component";
function DatePickerComponent_ng_container_0_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
} }
function DatePickerComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
    i0.ɵɵtemplate(4, DatePickerComponent_ng_container_0_ng_container_4_Template, 3, 3, "ng-container", 0);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(6, "input", 4);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(7, "cx-error-notice", 5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
    i0.ɵɵadvance(1);
    i0.ɵɵpropertyInterpolate("placeholder", ctx_r0.getDateFormat());
    i0.ɵɵproperty("formControlName", ctx_r0.config.name);
    i0.ɵɵattribute("name", ctx_r0.config.name)("readonly", ctx_r0.config.readonly ? ctx_r0.config.readonly : null);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
} }
export class DatePickerComponent extends AbstractFormComponent {
    constructor(appConfig, languageService, injector, formService, dateConfig) {
        super(appConfig, languageService, injector, formService);
        this.appConfig = appConfig;
        this.languageService = languageService;
        this.injector = injector;
        this.formService = formService;
        this.dateConfig = dateConfig;
    }
    getDateFormat() {
        return this.dateConfig?.date?.format || '';
    }
}
DatePickerComponent.ɵfac = function DatePickerComponent_Factory(t) { return new (t || DatePickerComponent)(i0.ɵɵdirectiveInject(i1.DynamicFormsConfig), i0.ɵɵdirectiveInject(i2.LanguageService), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i3.FormService), i0.ɵɵdirectiveInject(i4.FormDateConfig)); };
DatePickerComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DatePickerComponent, selectors: [["cx-datepicker"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], ["type", "date", 1, "form-control", 3, "placeholder", "formControlName"], [3, "warn", "parentConfig"]], template: function DatePickerComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, DatePickerComponent_ng_container_0_Template, 8, 10, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i5.NgIf, i6.DefaultValueAccessor, i6.NgControlStatus, i6.NgControlStatusGroup, i6.FormGroupDirective, i6.FormControlName, i7.ErrorNoticeComponent, i2.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DatePickerComponent, [{
        type: Component,
        args: [{ selector: 'cx-datepicker', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n        {{ label }}\n      </label>\n      <input\n        class=\"form-control\"\n        type=\"date\"\n        placeholder=\"{{ getDateFormat() }}\"\n        [formControlName]=\"config.name\"\n        [attr.name]=\"config.name\"\n        [attr.readonly]=\"config.readonly ? config.readonly : null\"\n      />\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
    }], function () { return [{ type: i1.DynamicFormsConfig }, { type: i2.LanguageService }, { type: i0.Injector }, { type: i3.FormService }, { type: i4.FormDateConfig }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZXBpY2tlci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvbXBvbmVudHMvZGF0ZXBpY2tlci9kYXRlcGlja2VyLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy9kYXRlcGlja2VyL2RhdGVwaWNrZXIuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDcEQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSwyQ0FBMkMsQ0FBQztBQUMzRSxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUNuRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sdUNBQXVDLENBQUM7QUFDcEUsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sMENBQTBDLENBQUM7Ozs7Ozs7Ozs7SUNEekUsNkJBQXVDO0lBQ3JDLFlBQ0Y7O0lBQUEsMEJBQWU7O0lBRGIsZUFDRjtJQURFLDhFQUNGOzs7SUFOUiw2QkFBNEI7SUFDMUIsOEJBQXdFLGFBQUEsZUFBQTtJQUdsRSxxR0FFZTtJQUNmLFlBQ0Y7SUFBQSxpQkFBUTtJQUNSLDJCQU9FO0lBQ0osaUJBQU07SUFDTixxQ0FHbUI7SUFDckIsaUJBQU07SUFDUiwwQkFBZTs7O0lBdEJjLGVBQW1CO0lBQW5CLHdDQUFtQixnQ0FBQTtJQUd6QixlQUFzQjtJQUF0Qiw4Q0FBc0I7SUFHckMsZUFDRjtJQURFLDZDQUNGO0lBSUUsZUFBbUM7SUFBbkMsK0RBQW1DO0lBQ25DLG9EQUErQjtJQUMvQiwwQ0FBeUIsb0VBQUE7SUFLM0IsZUFBb0M7SUFBcEMsZ0VBQW9DLCtCQUFBOztBRFIxQyxNQUFNLE9BQU8sbUJBQW9CLFNBQVEscUJBQXFCO0lBQzVELFlBQ1ksU0FBNkIsRUFDN0IsZUFBZ0MsRUFDaEMsUUFBa0IsRUFDbEIsV0FBd0IsRUFDeEIsVUFBMEI7UUFFcEMsS0FBSyxDQUFDLFNBQVMsRUFBRSxlQUFlLEVBQUUsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBTi9DLGNBQVMsR0FBVCxTQUFTLENBQW9CO1FBQzdCLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQUNoQyxhQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ2xCLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBQ3hCLGVBQVUsR0FBVixVQUFVLENBQWdCO0lBR3RDLENBQUM7SUFFRCxhQUFhO1FBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxDQUFDO0lBQzdDLENBQUM7O3NGQWJVLG1CQUFtQjtzRUFBbkIsbUJBQW1CO1FDWGhDLHVGQXVCZTs7UUF2QkEsZ0NBQVc7O3VGRFdiLG1CQUFtQjtjQUovQixTQUFTOzJCQUNFLGVBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEluamVjdG9yIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBMYW5ndWFnZVNlcnZpY2UgfSBmcm9tICdAc3BhcnRhY3VzL2NvcmUnO1xuaW1wb3J0IHsgRm9ybURhdGVDb25maWcgfSBmcm9tICcuLi8uLi9jb3JlL2NvbmZpZy9kYXRlLWNvbmZpZy9kYXRlLWNvbmZpZyc7XG5pbXBvcnQgeyBEeW5hbWljRm9ybXNDb25maWcgfSBmcm9tICcuLi8uLi9jb3JlL2NvbmZpZy9mb3JtLWNvbmZpZyc7XG5pbXBvcnQgeyBGb3JtU2VydmljZSB9IGZyb20gJy4uLy4uL2NvcmUvc2VydmljZXMvZm9ybS9mb3JtLnNlcnZpY2UnO1xuaW1wb3J0IHsgQWJzdHJhY3RGb3JtQ29tcG9uZW50IH0gZnJvbSAnLi4vYWJzdHJhY3QtZm9ybS9hYnN0cmFjdC1mb3JtLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2N4LWRhdGVwaWNrZXInLFxuICB0ZW1wbGF0ZVVybDogJy4vZGF0ZXBpY2tlci5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIERhdGVQaWNrZXJDb21wb25lbnQgZXh0ZW5kcyBBYnN0cmFjdEZvcm1Db21wb25lbnQge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcm90ZWN0ZWQgYXBwQ29uZmlnOiBEeW5hbWljRm9ybXNDb25maWcsXG4gICAgcHJvdGVjdGVkIGxhbmd1YWdlU2VydmljZTogTGFuZ3VhZ2VTZXJ2aWNlLFxuICAgIHByb3RlY3RlZCBpbmplY3RvcjogSW5qZWN0b3IsXG4gICAgcHJvdGVjdGVkIGZvcm1TZXJ2aWNlOiBGb3JtU2VydmljZSxcbiAgICBwcm90ZWN0ZWQgZGF0ZUNvbmZpZzogRm9ybURhdGVDb25maWdcbiAgKSB7XG4gICAgc3VwZXIoYXBwQ29uZmlnLCBsYW5ndWFnZVNlcnZpY2UsIGluamVjdG9yLCBmb3JtU2VydmljZSk7XG4gIH1cblxuICBnZXREYXRlRm9ybWF0KCkge1xuICAgIHJldHVybiB0aGlzLmRhdGVDb25maWc/LmRhdGU/LmZvcm1hdCB8fCAnJztcbiAgfVxufVxuIiwiPG5nLWNvbnRhaW5lciAqbmdJZj1cImdyb3VwXCI+XG4gIDxkaXYgY2xhc3M9XCJkeW5hbWljLWZpZWxkXCIgW2Zvcm1Hcm91cF09XCJncm91cFwiIFtoaWRkZW5dPVwiY29uZmlnLmhpZGRlblwiPlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICA8bGFiZWwgY2xhc3M9XCJjb2wtZm9ybS1sYWJlbFwiPlxuICAgICAgICA8bmctY29udGFpbmVyICpuZ0lmPVwiIWNvbmZpZy5yZXF1aXJlZFwiPlxuICAgICAgICAgIHt7ICdkeW5hbWljZm9ybXMub3B0aW9uYWwnIHwgY3hUcmFuc2xhdGUgfX1cbiAgICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICAgIHt7IGxhYmVsIH19XG4gICAgICA8L2xhYmVsPlxuICAgICAgPGlucHV0XG4gICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICBwbGFjZWhvbGRlcj1cInt7IGdldERhdGVGb3JtYXQoKSB9fVwiXG4gICAgICAgIFtmb3JtQ29udHJvbE5hbWVdPVwiY29uZmlnLm5hbWVcIlxuICAgICAgICBbYXR0ci5uYW1lXT1cImNvbmZpZy5uYW1lXCJcbiAgICAgICAgW2F0dHIucmVhZG9ubHldPVwiY29uZmlnLnJlYWRvbmx5ID8gY29uZmlnLnJlYWRvbmx5IDogbnVsbFwiXG4gICAgICAvPlxuICAgIDwvZGl2PlxuICAgIDxjeC1lcnJvci1ub3RpY2VcbiAgICAgIFt3YXJuXT1cImdyb3VwLmNvbnRyb2xzW2NvbmZpZy5uYW1lXVwiXG4gICAgICBbcGFyZW50Q29uZmlnXT1cImNvbmZpZ1wiXG4gICAgPjwvY3gtZXJyb3Itbm90aWNlPlxuICA8L2Rpdj5cbjwvbmctY29udGFpbmVyPlxuIl19