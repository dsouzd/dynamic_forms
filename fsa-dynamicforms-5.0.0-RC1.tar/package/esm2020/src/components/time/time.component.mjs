import { Component } from '@angular/core';
import { AbstractFormComponent } from '../abstract-form/abstract-form.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/forms";
import * as i3 from "../error-notice/error-notice.component";
import * as i4 from "@spartacus/core";
function TimeComponent_ng_container_0_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "cxTranslate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
} }
function TimeComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
    i0.ɵɵtext(4);
    i0.ɵɵtemplate(5, TimeComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(6, "input", 4);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(7, "cx-error-notice", 5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
    i0.ɵɵadvance(1);
    i0.ɵɵpropertyInterpolate("formControlName", ctx_r0.config.name);
    i0.ɵɵproperty("step", 1);
    i0.ɵɵattribute("name", ctx_r0.config.name)("readonly", ctx_r0.config.readonly ? ctx_r0.config.readonly : null);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
} }
export class TimeComponent extends AbstractFormComponent {
}
TimeComponent.ɵfac = /*@__PURE__*/ function () { let ɵTimeComponent_BaseFactory; return function TimeComponent_Factory(t) { return (ɵTimeComponent_BaseFactory || (ɵTimeComponent_BaseFactory = i0.ɵɵgetInheritedFactory(TimeComponent)))(t || TimeComponent); }; }();
TimeComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TimeComponent, selectors: [["cx-time"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], ["type", "time", 1, "form-control", 3, "formControlName", "step"], [3, "warn", "parentConfig"]], template: function TimeComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, TimeComponent_ng_container_0_Template, 8, 10, "ng-container", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.group);
    } }, dependencies: [i1.NgIf, i2.DefaultValueAccessor, i2.NgControlStatus, i2.NgControlStatusGroup, i2.FormGroupDirective, i2.FormControlName, i3.ErrorNoticeComponent, i4.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TimeComponent, [{
        type: Component,
        args: [{ selector: 'cx-time', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <input\n        class=\"form-control\"\n        type=\"time\"\n        formControlName=\"{{ config.name }}\"\n        [attr.name]=\"config.name\"\n        [step]=\"1\"\n        [attr.readonly]=\"config.readonly ? config.readonly : null\"\n      />\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
    }], null, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2NvbXBvbmVudHMvdGltZS90aW1lLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvY29tcG9uZW50cy90aW1lL3RpbWUuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMxQyxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSwwQ0FBMEMsQ0FBQzs7Ozs7OztJQ0l6RSw2QkFBdUM7SUFDckMsWUFDRjs7SUFBQSwwQkFBZTs7SUFEYixlQUNGO0lBREUsOEVBQ0Y7OztJQVBSLDZCQUE0QjtJQUMxQiw4QkFBd0UsYUFBQSxlQUFBO0lBR2xFLFlBQ0E7SUFBQSwrRkFFZTtJQUNqQixpQkFBUTtJQUNSLDJCQU9FO0lBQ0osaUJBQU07SUFDTixxQ0FHbUI7SUFDckIsaUJBQU07SUFDUiwwQkFBZTs7O0lBdEJjLGVBQW1CO0lBQW5CLHdDQUFtQixnQ0FBQTtJQUd4QyxlQUNBO0lBREEsNkNBQ0E7SUFBZSxlQUFzQjtJQUF0Qiw4Q0FBc0I7SUFPckMsZUFBbUM7SUFBbkMsK0RBQW1DO0lBRW5DLHdCQUFVO0lBRFYsMENBQXlCLG9FQUFBO0lBTTNCLGVBQW9DO0lBQXBDLGdFQUFvQywrQkFBQTs7QURaMUMsTUFBTSxPQUFPLGFBQWMsU0FBUSxxQkFBcUI7O3lOQUEzQyxhQUFhLFNBQWIsYUFBYTtnRUFBYixhQUFhO1FDUDFCLGlGQXVCZTs7UUF2QkEsZ0NBQVc7O3VGRE9iLGFBQWE7Y0FKekIsU0FBUzsyQkFDRSxTQUFTIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBYnN0cmFjdEZvcm1Db21wb25lbnQgfSBmcm9tICcuLi9hYnN0cmFjdC1mb3JtL2Fic3RyYWN0LWZvcm0uY29tcG9uZW50JztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY3gtdGltZScsXG4gIHRlbXBsYXRlVXJsOiAnLi90aW1lLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgVGltZUNvbXBvbmVudCBleHRlbmRzIEFic3RyYWN0Rm9ybUNvbXBvbmVudCB7fVxuIiwiPG5nLWNvbnRhaW5lciAqbmdJZj1cImdyb3VwXCI+XG4gIDxkaXYgY2xhc3M9XCJkeW5hbWljLWZpZWxkXCIgW2Zvcm1Hcm91cF09XCJncm91cFwiIFtoaWRkZW5dPVwiY29uZmlnLmhpZGRlblwiPlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICA8bGFiZWwgY2xhc3M9XCJjb2wtZm9ybS1sYWJlbFwiPlxuICAgICAgICB7eyBsYWJlbCB9fVxuICAgICAgICA8bmctY29udGFpbmVyICpuZ0lmPVwiIWNvbmZpZy5yZXF1aXJlZFwiPlxuICAgICAgICAgIHt7ICdkeW5hbWljZm9ybXMub3B0aW9uYWwnIHwgY3hUcmFuc2xhdGUgfX1cbiAgICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICA8L2xhYmVsPlxuICAgICAgPGlucHV0XG4gICAgICAgIGNsYXNzPVwiZm9ybS1jb250cm9sXCJcbiAgICAgICAgdHlwZT1cInRpbWVcIlxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJ7eyBjb25maWcubmFtZSB9fVwiXG4gICAgICAgIFthdHRyLm5hbWVdPVwiY29uZmlnLm5hbWVcIlxuICAgICAgICBbc3RlcF09XCIxXCJcbiAgICAgICAgW2F0dHIucmVhZG9ubHldPVwiY29uZmlnLnJlYWRvbmx5ID8gY29uZmlnLnJlYWRvbmx5IDogbnVsbFwiXG4gICAgICAvPlxuICAgIDwvZGl2PlxuICAgIDxjeC1lcnJvci1ub3RpY2VcbiAgICAgIFt3YXJuXT1cImdyb3VwLmNvbnRyb2xzW2NvbmZpZy5uYW1lXVwiXG4gICAgICBbcGFyZW50Q29uZmlnXT1cImNvbmZpZ1wiXG4gICAgPjwvY3gtZXJyb3Itbm90aWNlPlxuICA8L2Rpdj5cbjwvbmctY29udGFpbmVyPlxuIl19