import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormCMSComponent } from './form-cms.component';
import { ConfigModule } from '@spartacus/core';
import { SpinnerModule } from '@spartacus/storefront';
import { FormContainerModule } from '../../core/form-containers/form-container.module';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/core";
export class FormCMSModule {
}
FormCMSModule.ɵfac = function FormCMSModule_Factory(t) { return new (t || FormCMSModule)(); };
FormCMSModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: FormCMSModule });
FormCMSModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        SpinnerModule,
        FormContainerModule,
        ConfigModule.withConfig({
            cmsComponents: {
                YFormCMSComponent: {
                    component: FormCMSComponent,
                },
            },
        })] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormCMSModule, [{
        type: NgModule,
        args: [{
                declarations: [FormCMSComponent],
                imports: [
                    CommonModule,
                    SpinnerModule,
                    FormContainerModule,
                    ConfigModule.withConfig({
                        cmsComponents: {
                            YFormCMSComponent: {
                                component: FormCMSComponent,
                            },
                        },
                    }),
                ],
                exports: [FormCMSComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(FormCMSModule, { declarations: [FormCMSComponent], imports: [CommonModule,
        SpinnerModule,
        FormContainerModule, i1.ConfigModule], exports: [FormCMSComponent] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1jbXMubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jbXMtY29tcG9uZW50cy9mb3JtLWNtcy9mb3JtLWNtcy5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDL0MsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDeEQsT0FBTyxFQUFFLFlBQVksRUFBYSxNQUFNLGlCQUFpQixDQUFDO0FBQzFELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUN0RCxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxrREFBa0QsQ0FBQzs7O0FBa0J2RixNQUFNLE9BQU8sYUFBYTs7MEVBQWIsYUFBYTsrREFBYixhQUFhO21FQWJ0QixZQUFZO1FBQ1osYUFBYTtRQUNiLG1CQUFtQjtRQUNuQixZQUFZLENBQUMsVUFBVSxDQUFZO1lBQ2pDLGFBQWEsRUFBRTtnQkFDYixpQkFBaUIsRUFBRTtvQkFDakIsU0FBUyxFQUFFLGdCQUFnQjtpQkFDNUI7YUFDRjtTQUNGLENBQUM7dUZBSU8sYUFBYTtjQWhCekIsUUFBUTtlQUFDO2dCQUNSLFlBQVksRUFBRSxDQUFDLGdCQUFnQixDQUFDO2dCQUNoQyxPQUFPLEVBQUU7b0JBQ1AsWUFBWTtvQkFDWixhQUFhO29CQUNiLG1CQUFtQjtvQkFDbkIsWUFBWSxDQUFDLFVBQVUsQ0FBWTt3QkFDakMsYUFBYSxFQUFFOzRCQUNiLGlCQUFpQixFQUFFO2dDQUNqQixTQUFTLEVBQUUsZ0JBQWdCOzZCQUM1Qjt5QkFDRjtxQkFDRixDQUFDO2lCQUNIO2dCQUNELE9BQU8sRUFBRSxDQUFDLGdCQUFnQixDQUFDO2FBQzVCOzt3RkFDWSxhQUFhLG1CQWZULGdCQUFnQixhQUU3QixZQUFZO1FBQ1osYUFBYTtRQUNiLG1CQUFtQiw4QkFTWCxnQkFBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IEZvcm1DTVNDb21wb25lbnQgfSBmcm9tICcuL2Zvcm0tY21zLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb25maWdNb2R1bGUsIENtc0NvbmZpZyB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBTcGlubmVyTW9kdWxlIH0gZnJvbSAnQHNwYXJ0YWN1cy9zdG9yZWZyb250JztcbmltcG9ydCB7IEZvcm1Db250YWluZXJNb2R1bGUgfSBmcm9tICcuLi8uLi9jb3JlL2Zvcm0tY29udGFpbmVycy9mb3JtLWNvbnRhaW5lci5tb2R1bGUnO1xuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtGb3JtQ01TQ29tcG9uZW50XSxcbiAgaW1wb3J0czogW1xuICAgIENvbW1vbk1vZHVsZSxcbiAgICBTcGlubmVyTW9kdWxlLFxuICAgIEZvcm1Db250YWluZXJNb2R1bGUsXG4gICAgQ29uZmlnTW9kdWxlLndpdGhDb25maWcoPENtc0NvbmZpZz57XG4gICAgICBjbXNDb21wb25lbnRzOiB7XG4gICAgICAgIFlGb3JtQ01TQ29tcG9uZW50OiB7XG4gICAgICAgICAgY29tcG9uZW50OiBGb3JtQ01TQ29tcG9uZW50LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9KSxcbiAgXSxcbiAgZXhwb3J0czogW0Zvcm1DTVNDb21wb25lbnRdLFxufSlcbmV4cG9ydCBjbGFzcyBGb3JtQ01TTW9kdWxlIHt9XG4iXX0=