import { Component } from '@angular/core';
import { CmsComponentData } from '@spartacus/storefront';
import { Subscription } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { FormDataService } from '../../core/services/data/form-data.service';
import { FormDataStorageService } from './../../core/services/storage/form-data-storage.service';
import * as i0 from "@angular/core";
import * as i1 from "@spartacus/storefront";
import * as i2 from "../../core/services/data/form-data.service";
import * as i3 from "./../../core/services/storage/form-data-storage.service";
import * as i4 from "@angular/common";
import * as i5 from "../../core/form-containers/form/form.component";
function FormCMSComponent_ng_container_0_ng_container_1_cx_form_component_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "cx-form-component", 3);
} if (rf & 2) {
    const component_r3 = i0.ɵɵnextContext(2).ngIf;
    const ctx_r6 = i0.ɵɵnextContext();
    i0.ɵɵproperty("formId", component_r3.formId)("formSubject", component_r3.subject)("formConfig", ctx_r6.formConfig)("applicationId", component_r3.applicationId)("formData", ctx_r6.formData$);
} }
function FormCMSComponent_ng_container_0_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, FormCMSComponent_ng_container_0_ng_container_1_cx_form_component_1_Template, 1, 5, "cx-form-component", 2);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r4 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r4.formConfig);
} }
function FormCMSComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, FormCMSComponent_ng_container_0_ng_container_1_Template, 2, 1, "ng-container", 0);
    i0.ɵɵpipe(2, "async");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    const _r1 = i0.ɵɵreference(3);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(2, 2, ctx_r0.formDefinition$))("ngIfElse", _r1);
} }
function FormCMSComponent_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "cx-spinner");
} }
export class FormCMSComponent {
    constructor(componentData, formDataService, formDataStorageService) {
        this.componentData = componentData;
        this.formDataService = formDataService;
        this.formDataStorageService = formDataStorageService;
        this.subscription = new Subscription();
    }
    ngOnInit() {
        this.component$ = this.componentData.data$;
        this.loadForm();
    }
    loadForm() {
        this.formDefinition$ = this.formDataService.getFormDefinition().pipe(map(definition => {
            if (definition.content) {
                this.formConfig = JSON.parse(definition.content);
            }
            this.formDataId =
                this.formDataStorageService.getFormDataIdByDefinitionCode(definition.formId);
            if (this.formDataId) {
                this.formDataService.loadFormData(this.formDataId);
                this.formData$ = this.formDataService.getFormData();
            }
            return definition;
        }));
        this.subscription.add(this.component$
            .pipe(take(1), map(component => {
            this.loadFormDefinition(component);
        }))
            .subscribe());
    }
    loadFormDefinition(component) {
        this.formDataService.loadFormDefinition(component.applicationId, component.formId);
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
FormCMSComponent.ɵfac = function FormCMSComponent_Factory(t) { return new (t || FormCMSComponent)(i0.ɵɵdirectiveInject(i1.CmsComponentData), i0.ɵɵdirectiveInject(i2.FormDataService), i0.ɵɵdirectiveInject(i3.FormDataStorageService)); };
FormCMSComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FormCMSComponent, selectors: [["cx-form-cms"]], decls: 4, vars: 4, consts: [[4, "ngIf", "ngIfElse"], ["loading", ""], [3, "formId", "formSubject", "formConfig", "applicationId", "formData", 4, "ngIf"], [3, "formId", "formSubject", "formConfig", "applicationId", "formData"]], template: function FormCMSComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, FormCMSComponent_ng_container_0_Template, 3, 4, "ng-container", 0);
        i0.ɵɵpipe(1, "async");
        i0.ɵɵtemplate(2, FormCMSComponent_ng_template_2_Template, 1, 0, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
    } if (rf & 2) {
        const _r1 = i0.ɵɵreference(3);
        i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(1, 2, ctx.component$))("ngIfElse", _r1);
    } }, dependencies: [i4.NgIf, i1.SpinnerComponent, i5.FormComponent, i4.AsyncPipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormCMSComponent, [{
        type: Component,
        args: [{ selector: 'cx-form-cms', template: "<ng-container *ngIf=\"component$ | async as component; else loading\">\n  <ng-container *ngIf=\"formDefinition$ | async as formDefinition; else loading\">\n    <cx-form-component\n      *ngIf=\"formConfig\"\n      [formId]=\"component.formId\"\n      [formSubject]=\"component.subject\"\n      [formConfig]=\"formConfig\"\n      [applicationId]=\"component.applicationId\"\n      [formData]=\"formData$\"\n    ></cx-form-component>\n  </ng-container>\n</ng-container>\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n" }]
    }], function () { return [{ type: i1.CmsComponentData }, { type: i2.FormDataService }, { type: i3.FormDataStorageService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1jbXMuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9jbXMtY29tcG9uZW50cy9mb3JtLWNtcy9mb3JtLWNtcy5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL2Ntcy1jb21wb25lbnRzL2Zvcm0tY21zL2Zvcm0tY21zLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQXFCLE1BQU0sZUFBZSxDQUFDO0FBQzdELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3pELE9BQU8sRUFBYyxZQUFZLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDaEQsT0FBTyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUczQyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNENBQTRDLENBQUM7QUFFN0UsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0seURBQXlELENBQUM7Ozs7Ozs7O0lDTjdGLHVDQU9xQjs7OztJQUxuQiw0Q0FBMkIscUNBQUEsaUNBQUEsNkNBQUEsOEJBQUE7OztJQUgvQiw2QkFBOEU7SUFDNUUsMkhBT3FCO0lBQ3ZCLDBCQUFlOzs7SUFQVixlQUFnQjtJQUFoQix3Q0FBZ0I7OztJQUh2Qiw2QkFBb0U7SUFDbEUsa0dBU2U7O0lBQ2pCLDBCQUFlOzs7O0lBVkUsZUFBOEI7SUFBOUIsbUVBQThCLGlCQUFBOzs7SUFZN0MsNkJBQXlCOztBREMzQixNQUFNLE9BQU8sZ0JBQWdCO0lBQzNCLFlBQ1ksYUFBa0QsRUFDbEQsZUFBZ0MsRUFDaEMsc0JBQThDO1FBRjlDLGtCQUFhLEdBQWIsYUFBYSxDQUFxQztRQUNsRCxvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7UUFDaEMsMkJBQXNCLEdBQXRCLHNCQUFzQixDQUF3QjtRQVExRCxpQkFBWSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFQL0IsQ0FBQztJQVNKLFFBQVE7UUFDTixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO1FBQzNDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNsQixDQUFDO0lBRUQsUUFBUTtRQUNOLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLElBQUksQ0FDbEUsR0FBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQ2YsSUFBSSxVQUFVLENBQUMsT0FBTyxFQUFFO2dCQUN0QixJQUFJLENBQUMsVUFBVSxHQUFtQixJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUNsRTtZQUNELElBQUksQ0FBQyxVQUFVO2dCQUNiLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyw2QkFBNkIsQ0FDdkQsVUFBVSxDQUFDLE1BQU0sQ0FDbEIsQ0FBQztZQUNKLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUNuRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDckQ7WUFDRCxPQUFPLFVBQVUsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FDSCxDQUFDO1FBRUYsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQ25CLElBQUksQ0FBQyxVQUFVO2FBQ1osSUFBSSxDQUNILElBQUksQ0FBQyxDQUFDLENBQUMsRUFDUCxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDZCxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDckMsQ0FBQyxDQUFDLENBQ0g7YUFDQSxTQUFTLEVBQUUsQ0FDZixDQUFDO0lBQ0osQ0FBQztJQUVELGtCQUFrQixDQUFDLFNBQWM7UUFDL0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FDckMsU0FBUyxDQUFDLGFBQWEsRUFDdkIsU0FBUyxDQUFDLE1BQU0sQ0FDakIsQ0FBQztJQUNKLENBQUM7SUFFRCxXQUFXO1FBQ1QsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3JCLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDakM7SUFDSCxDQUFDOztnRkE1RFUsZ0JBQWdCO21FQUFoQixnQkFBZ0I7UUNkN0IsbUZBV2U7O1FBQ2Ysa0hBRWM7OztRQWRDLDJEQUF5QixpQkFBQTs7dUZEYzNCLGdCQUFnQjtjQUo1QixTQUFTOzJCQUNFLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uRGVzdHJveSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDbXNDb21wb25lbnREYXRhIH0gZnJvbSAnQHNwYXJ0YWN1cy9zdG9yZWZyb250JztcbmltcG9ydCB7IE9ic2VydmFibGUsIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgbWFwLCB0YWtlIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgRm9ybURlZmluaXRpb24gfSBmcm9tICcuLi8uLi9jb3JlL21vZGVscy9mb3JtLWNvbmZpZy5pbnRlcmZhY2UnO1xuaW1wb3J0IHsgWUZvcm1EYXRhLCBZRm9ybURlZmluaXRpb24gfSBmcm9tICcuLi8uLi9jb3JlL21vZGVscy9mb3JtLW9jYy5tb2RlbHMnO1xuaW1wb3J0IHsgRm9ybURhdGFTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vY29yZS9zZXJ2aWNlcy9kYXRhL2Zvcm0tZGF0YS5zZXJ2aWNlJztcbmltcG9ydCB7IFlGb3JtQ21zQ29tcG9uZW50IH0gZnJvbSAnLi4vY21zLWNvbXBvbmVudC5tb2RlbHMnO1xuaW1wb3J0IHsgRm9ybURhdGFTdG9yYWdlU2VydmljZSB9IGZyb20gJy4vLi4vLi4vY29yZS9zZXJ2aWNlcy9zdG9yYWdlL2Zvcm0tZGF0YS1zdG9yYWdlLnNlcnZpY2UnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdjeC1mb3JtLWNtcycsXG4gIHRlbXBsYXRlVXJsOiAnLi9mb3JtLWNtcy5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIEZvcm1DTVNDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByb3RlY3RlZCBjb21wb25lbnREYXRhOiBDbXNDb21wb25lbnREYXRhPFlGb3JtQ21zQ29tcG9uZW50PixcbiAgICBwcm90ZWN0ZWQgZm9ybURhdGFTZXJ2aWNlOiBGb3JtRGF0YVNlcnZpY2UsXG4gICAgcHJvdGVjdGVkIGZvcm1EYXRhU3RvcmFnZVNlcnZpY2U6IEZvcm1EYXRhU3RvcmFnZVNlcnZpY2VcbiAgKSB7fVxuXG4gIGNvbXBvbmVudCQ6IE9ic2VydmFibGU8WUZvcm1DbXNDb21wb25lbnQ+O1xuICBmb3JtRGVmaW5pdGlvbiQ6IE9ic2VydmFibGU8WUZvcm1EZWZpbml0aW9uPjtcbiAgZm9ybURhdGEkOiBPYnNlcnZhYmxlPFlGb3JtRGF0YT47XG4gIGZvcm1Db25maWc6IEZvcm1EZWZpbml0aW9uO1xuICBmb3JtRGF0YUlkOiBzdHJpbmc7XG4gIHN1YnNjcmlwdGlvbiA9IG5ldyBTdWJzY3JpcHRpb24oKTtcblxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLmNvbXBvbmVudCQgPSB0aGlzLmNvbXBvbmVudERhdGEuZGF0YSQ7XG4gICAgdGhpcy5sb2FkRm9ybSgpO1xuICB9XG5cbiAgbG9hZEZvcm0oKSB7XG4gICAgdGhpcy5mb3JtRGVmaW5pdGlvbiQgPSB0aGlzLmZvcm1EYXRhU2VydmljZS5nZXRGb3JtRGVmaW5pdGlvbigpLnBpcGUoXG4gICAgICBtYXAoZGVmaW5pdGlvbiA9PiB7XG4gICAgICAgIGlmIChkZWZpbml0aW9uLmNvbnRlbnQpIHtcbiAgICAgICAgICB0aGlzLmZvcm1Db25maWcgPSA8Rm9ybURlZmluaXRpb24+SlNPTi5wYXJzZShkZWZpbml0aW9uLmNvbnRlbnQpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZm9ybURhdGFJZCA9XG4gICAgICAgICAgdGhpcy5mb3JtRGF0YVN0b3JhZ2VTZXJ2aWNlLmdldEZvcm1EYXRhSWRCeURlZmluaXRpb25Db2RlKFxuICAgICAgICAgICAgZGVmaW5pdGlvbi5mb3JtSWRcbiAgICAgICAgICApO1xuICAgICAgICBpZiAodGhpcy5mb3JtRGF0YUlkKSB7XG4gICAgICAgICAgdGhpcy5mb3JtRGF0YVNlcnZpY2UubG9hZEZvcm1EYXRhKHRoaXMuZm9ybURhdGFJZCk7XG4gICAgICAgICAgdGhpcy5mb3JtRGF0YSQgPSB0aGlzLmZvcm1EYXRhU2VydmljZS5nZXRGb3JtRGF0YSgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkZWZpbml0aW9uO1xuICAgICAgfSlcbiAgICApO1xuXG4gICAgdGhpcy5zdWJzY3JpcHRpb24uYWRkKFxuICAgICAgdGhpcy5jb21wb25lbnQkXG4gICAgICAgIC5waXBlKFxuICAgICAgICAgIHRha2UoMSksXG4gICAgICAgICAgbWFwKGNvbXBvbmVudCA9PiB7XG4gICAgICAgICAgICB0aGlzLmxvYWRGb3JtRGVmaW5pdGlvbihjb21wb25lbnQpO1xuICAgICAgICAgIH0pXG4gICAgICAgIClcbiAgICAgICAgLnN1YnNjcmliZSgpXG4gICAgKTtcbiAgfVxuXG4gIGxvYWRGb3JtRGVmaW5pdGlvbihjb21wb25lbnQ6IGFueSkge1xuICAgIHRoaXMuZm9ybURhdGFTZXJ2aWNlLmxvYWRGb3JtRGVmaW5pdGlvbihcbiAgICAgIGNvbXBvbmVudC5hcHBsaWNhdGlvbklkLFxuICAgICAgY29tcG9uZW50LmZvcm1JZFxuICAgICk7XG4gIH1cblxuICBuZ09uRGVzdHJveSgpIHtcbiAgICBpZiAodGhpcy5zdWJzY3JpcHRpb24pIHtcbiAgICAgIHRoaXMuc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgfVxuICB9XG59XG4iLCI8bmctY29udGFpbmVyICpuZ0lmPVwiY29tcG9uZW50JCB8IGFzeW5jIGFzIGNvbXBvbmVudDsgZWxzZSBsb2FkaW5nXCI+XG4gIDxuZy1jb250YWluZXIgKm5nSWY9XCJmb3JtRGVmaW5pdGlvbiQgfCBhc3luYyBhcyBmb3JtRGVmaW5pdGlvbjsgZWxzZSBsb2FkaW5nXCI+XG4gICAgPGN4LWZvcm0tY29tcG9uZW50XG4gICAgICAqbmdJZj1cImZvcm1Db25maWdcIlxuICAgICAgW2Zvcm1JZF09XCJjb21wb25lbnQuZm9ybUlkXCJcbiAgICAgIFtmb3JtU3ViamVjdF09XCJjb21wb25lbnQuc3ViamVjdFwiXG4gICAgICBbZm9ybUNvbmZpZ109XCJmb3JtQ29uZmlnXCJcbiAgICAgIFthcHBsaWNhdGlvbklkXT1cImNvbXBvbmVudC5hcHBsaWNhdGlvbklkXCJcbiAgICAgIFtmb3JtRGF0YV09XCJmb3JtRGF0YSRcIlxuICAgID48L2N4LWZvcm0tY29tcG9uZW50PlxuICA8L25nLWNvbnRhaW5lcj5cbjwvbmctY29udGFpbmVyPlxuPG5nLXRlbXBsYXRlICNsb2FkaW5nPlxuICA8Y3gtc3Bpbm5lcj48L2N4LXNwaW5uZXI+XG48L25nLXRlbXBsYXRlPlxuIl19