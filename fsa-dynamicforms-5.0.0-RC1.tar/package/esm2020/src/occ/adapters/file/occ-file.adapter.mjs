import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OccEndpointsService } from '@spartacus/core';
import { throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { base64StringToBlob } from 'blob-util';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common/http";
import * as i2 from "@spartacus/core";
const FULL_PARAMS = 'FULL';
export class OccFileAdapter {
    constructor(http, occEndpointService) {
        this.http = http;
        this.occEndpointService = occEndpointService;
    }
    uploadFile(userId, file) {
        const url = this.occEndpointService.buildUrl('uploadFile', {
            urlParams: {
                userId: userId,
            },
        });
        const params = new HttpParams()
            .set('fileSize', file.size.toString())
            .set('fields', FULL_PARAMS);
        const data = new FormData();
        data.append('file', file);
        return this.http
            .post(url, data, {
            reportProgress: true,
            observe: 'events',
            params: params,
        })
            .pipe(catchError((error) => throwError(error.json())));
    }
    removeFileForUserAndCode(userId, fileCode) {
        const url = this.occEndpointService.buildUrl('removeFile', {
            urlParams: {
                userId,
                fileCode,
            },
        });
        const headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded',
        });
        return this.http
            .delete(url, { headers })
            .pipe(catchError((error) => throwError(error.json())));
    }
    getFileForCodeAndType(userId, fileCode, fileType) {
        const url = this.occEndpointService.buildUrl('getFile', {
            urlParams: {
                userId,
                fileCode,
            },
        });
        return this.http.get(url).pipe(map(document => base64StringToBlob(document, fileType)), catchError((error) => throwError(error.json())));
    }
    getFilesForUser(userId, fileCodes) {
        const url = this.occEndpointService.buildUrl('getFiles', {
            urlParams: {
                userId,
            },
        });
        let params = new HttpParams().set('fields', FULL_PARAMS);
        if (fileCodes) {
            params = params.set('documentCodes', fileCodes.toString());
        }
        return this.http
            .get(url, { params })
            .pipe(catchError((error) => throwError(error.json())));
    }
}
OccFileAdapter.ɵfac = function OccFileAdapter_Factory(t) { return new (t || OccFileAdapter)(i0.ɵɵinject(i1.HttpClient), i0.ɵɵinject(i2.OccEndpointsService)); };
OccFileAdapter.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: OccFileAdapter, factory: OccFileAdapter.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OccFileAdapter, [{
        type: Injectable
    }], function () { return [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib2NjLWZpbGUuYWRhcHRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvb2NjL2FkYXB0ZXJzL2ZpbGUvb2NjLWZpbGUuYWRhcHRlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUMzRSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3RELE9BQU8sRUFBYyxVQUFVLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDOUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUVqRCxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxXQUFXLENBQUM7Ozs7QUFFL0MsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDO0FBRzNCLE1BQU0sT0FBTyxjQUFjO0lBQ3pCLFlBQ1ksSUFBZ0IsRUFDaEIsa0JBQXVDO1FBRHZDLFNBQUksR0FBSixJQUFJLENBQVk7UUFDaEIsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUFxQjtJQUNoRCxDQUFDO0lBRUosVUFBVSxDQUFDLE1BQU0sRUFBRSxJQUFVO1FBQzNCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFO1lBQ3pELFNBQVMsRUFBRTtnQkFDVCxNQUFNLEVBQUUsTUFBTTthQUNmO1NBQ0YsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxNQUFNLEdBQWUsSUFBSSxVQUFVLEVBQUU7YUFDeEMsR0FBRyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQ3JDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFFOUIsTUFBTSxJQUFJLEdBQWEsSUFBSSxRQUFRLEVBQUUsQ0FBQztRQUN0QyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUUxQixPQUFPLElBQUksQ0FBQyxJQUFJO2FBQ2IsSUFBSSxDQUFNLEdBQUcsRUFBRSxJQUFJLEVBQUU7WUFDcEIsY0FBYyxFQUFFLElBQUk7WUFDcEIsT0FBTyxFQUFFLFFBQVE7WUFDakIsTUFBTSxFQUFFLE1BQU07U0FDZixDQUFDO2FBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRUQsd0JBQXdCLENBQUMsTUFBYyxFQUFFLFFBQWdCO1FBQ3ZELE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFO1lBQ3pELFNBQVMsRUFBRTtnQkFDVCxNQUFNO2dCQUNOLFFBQVE7YUFDVDtTQUNGLENBQUMsQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHLElBQUksV0FBVyxDQUFDO1lBQzlCLGNBQWMsRUFBRSxtQ0FBbUM7U0FDcEQsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxJQUFJLENBQUMsSUFBSTthQUNiLE1BQU0sQ0FBQyxHQUFHLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQzthQUN4QixJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRCxxQkFBcUIsQ0FBQyxNQUFjLEVBQUUsUUFBZ0IsRUFBRSxRQUFnQjtRQUN0RSxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRTtZQUN0RCxTQUFTLEVBQUU7Z0JBQ1QsTUFBTTtnQkFDTixRQUFRO2FBQ1Q7U0FDRixDQUFDLENBQUM7UUFDSCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FDcEMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsa0JBQWtCLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQ3ZELFVBQVUsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQ3JELENBQUM7SUFDSixDQUFDO0lBRUQsZUFBZSxDQUFDLE1BQWMsRUFBRSxTQUF5QjtRQUN2RCxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRTtZQUN2RCxTQUFTLEVBQUU7Z0JBQ1QsTUFBTTthQUNQO1NBQ0YsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxNQUFNLEdBQWUsSUFBSSxVQUFVLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRXJFLElBQUksU0FBUyxFQUFFO1lBQ2IsTUFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQzVEO1FBQ0QsT0FBTyxJQUFJLENBQUMsSUFBSTthQUNiLEdBQUcsQ0FBTSxHQUFHLEVBQUUsRUFBRSxNQUFNLEVBQUUsQ0FBQzthQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7OzRFQXRFVSxjQUFjO29FQUFkLGNBQWMsV0FBZCxjQUFjO3VGQUFkLGNBQWM7Y0FEMUIsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBQYXJhbXMsIEh0dHBIZWFkZXJzIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT2NjRW5kcG9pbnRzU2VydmljZSB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCB0aHJvd0Vycm9yIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBtYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBGaWxlQWRhcHRlciB9IGZyb20gJy4uLy4uLy4uL2NvcmUvY29ubmVjdG9ycy9maWxlLmFkYXB0ZXInO1xuaW1wb3J0IHsgYmFzZTY0U3RyaW5nVG9CbG9iIH0gZnJvbSAnYmxvYi11dGlsJztcblxuY29uc3QgRlVMTF9QQVJBTVMgPSAnRlVMTCc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBPY2NGaWxlQWRhcHRlciBpbXBsZW1lbnRzIEZpbGVBZGFwdGVyIHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJvdGVjdGVkIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgcHJvdGVjdGVkIG9jY0VuZHBvaW50U2VydmljZTogT2NjRW5kcG9pbnRzU2VydmljZVxuICApIHt9XG5cbiAgdXBsb2FkRmlsZSh1c2VySWQsIGZpbGU6IEZpbGUpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIGNvbnN0IHVybCA9IHRoaXMub2NjRW5kcG9pbnRTZXJ2aWNlLmJ1aWxkVXJsKCd1cGxvYWRGaWxlJywge1xuICAgICAgdXJsUGFyYW1zOiB7XG4gICAgICAgIHVzZXJJZDogdXNlcklkLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICBjb25zdCBwYXJhbXM6IEh0dHBQYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpXG4gICAgICAuc2V0KCdmaWxlU2l6ZScsIGZpbGUuc2l6ZS50b1N0cmluZygpKVxuICAgICAgLnNldCgnZmllbGRzJywgRlVMTF9QQVJBTVMpO1xuXG4gICAgY29uc3QgZGF0YTogRm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcbiAgICBkYXRhLmFwcGVuZCgnZmlsZScsIGZpbGUpO1xuXG4gICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgLnBvc3Q8YW55Pih1cmwsIGRhdGEsIHtcbiAgICAgICAgcmVwb3J0UHJvZ3Jlc3M6IHRydWUsXG4gICAgICAgIG9ic2VydmU6ICdldmVudHMnLFxuICAgICAgICBwYXJhbXM6IHBhcmFtcyxcbiAgICAgIH0pXG4gICAgICAucGlwZShjYXRjaEVycm9yKChlcnJvcjogYW55KSA9PiB0aHJvd0Vycm9yKGVycm9yLmpzb24oKSkpKTtcbiAgfVxuXG4gIHJlbW92ZUZpbGVGb3JVc2VyQW5kQ29kZSh1c2VySWQ6IHN0cmluZywgZmlsZUNvZGU6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgY29uc3QgdXJsID0gdGhpcy5vY2NFbmRwb2ludFNlcnZpY2UuYnVpbGRVcmwoJ3JlbW92ZUZpbGUnLCB7XG4gICAgICB1cmxQYXJhbXM6IHtcbiAgICAgICAgdXNlcklkLFxuICAgICAgICBmaWxlQ29kZSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgY29uc3QgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7XG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCcsXG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgLmRlbGV0ZSh1cmwsIHsgaGVhZGVycyB9KVxuICAgICAgLnBpcGUoY2F0Y2hFcnJvcigoZXJyb3I6IGFueSkgPT4gdGhyb3dFcnJvcihlcnJvci5qc29uKCkpKSk7XG4gIH1cblxuICBnZXRGaWxlRm9yQ29kZUFuZFR5cGUodXNlcklkOiBzdHJpbmcsIGZpbGVDb2RlOiBzdHJpbmcsIGZpbGVUeXBlOiBzdHJpbmcpIHtcbiAgICBjb25zdCB1cmwgPSB0aGlzLm9jY0VuZHBvaW50U2VydmljZS5idWlsZFVybCgnZ2V0RmlsZScsIHtcbiAgICAgIHVybFBhcmFtczoge1xuICAgICAgICB1c2VySWQsXG4gICAgICAgIGZpbGVDb2RlLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxzdHJpbmc+KHVybCkucGlwZShcbiAgICAgIG1hcChkb2N1bWVudCA9PiBiYXNlNjRTdHJpbmdUb0Jsb2IoZG9jdW1lbnQsIGZpbGVUeXBlKSksXG4gICAgICBjYXRjaEVycm9yKChlcnJvcjogYW55KSA9PiB0aHJvd0Vycm9yKGVycm9yLmpzb24oKSkpXG4gICAgKTtcbiAgfVxuXG4gIGdldEZpbGVzRm9yVXNlcih1c2VySWQ6IHN0cmluZywgZmlsZUNvZGVzPzogQXJyYXk8c3RyaW5nPikge1xuICAgIGNvbnN0IHVybCA9IHRoaXMub2NjRW5kcG9pbnRTZXJ2aWNlLmJ1aWxkVXJsKCdnZXRGaWxlcycsIHtcbiAgICAgIHVybFBhcmFtczoge1xuICAgICAgICB1c2VySWQsXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGxldCBwYXJhbXM6IEh0dHBQYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpLnNldCgnZmllbGRzJywgRlVMTF9QQVJBTVMpO1xuXG4gICAgaWYgKGZpbGVDb2Rlcykge1xuICAgICAgcGFyYW1zID0gcGFyYW1zLnNldCgnZG9jdW1lbnRDb2RlcycsIGZpbGVDb2Rlcy50b1N0cmluZygpKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgLmdldDxhbnk+KHVybCwgeyBwYXJhbXMgfSlcbiAgICAgIC5waXBlKGNhdGNoRXJyb3IoKGVycm9yOiBhbnkpID0+IHRocm93RXJyb3IoZXJyb3IuanNvbigpKSkpO1xuICB9XG59XG4iXX0=