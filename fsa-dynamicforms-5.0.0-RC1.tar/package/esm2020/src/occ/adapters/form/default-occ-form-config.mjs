export const defaultOccFormConfig = {
    backend: {
        occ: {
            endpoints: {
                formDefinitions: 'formDefinitions',
                formDefinition: 'formDefinitions/${formDefinitionId}',
                formData: 'users/${userId}/formData/${formDataId}',
                createFormData: 'users/${userId}/formData',
                getFile: 'users/${userId}/documents/${fileCode}',
                getFiles: 'users/${userId}/documents',
                uploadFile: 'users/${userId}/documents',
                removeFile: 'users/${userId}/documents/${fileCode}',
            },
        },
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVmYXVsdC1vY2MtZm9ybS1jb25maWcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9keW5hbWljZm9ybXMvc3JjL29jYy9hZGFwdGVycy9mb3JtL2RlZmF1bHQtb2NjLWZvcm0tY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBLE1BQU0sQ0FBQyxNQUFNLG9CQUFvQixHQUFrQjtJQUNqRCxPQUFPLEVBQUU7UUFDUCxHQUFHLEVBQUU7WUFDSCxTQUFTLEVBQUU7Z0JBQ1QsZUFBZSxFQUFFLGlCQUFpQjtnQkFDbEMsY0FBYyxFQUFFLHFDQUFxQztnQkFDckQsUUFBUSxFQUFFLHdDQUF3QztnQkFDbEQsY0FBYyxFQUFFLDBCQUEwQjtnQkFDMUMsT0FBTyxFQUFFLHVDQUF1QztnQkFDaEQsUUFBUSxFQUFFLDJCQUEyQjtnQkFDckMsVUFBVSxFQUFFLDJCQUEyQjtnQkFDdkMsVUFBVSxFQUFFLHVDQUF1QzthQUNwRDtTQUNGO0tBQ0Y7Q0FDRixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRm9ybU9jY0NvbmZpZyB9IGZyb20gJy4uLy4uL2NvbmZpZy9mb3JtLW9jYy1jb25maWcnO1xuXG5leHBvcnQgY29uc3QgZGVmYXVsdE9jY0Zvcm1Db25maWc6IEZvcm1PY2NDb25maWcgPSB7XG4gIGJhY2tlbmQ6IHtcbiAgICBvY2M6IHtcbiAgICAgIGVuZHBvaW50czoge1xuICAgICAgICBmb3JtRGVmaW5pdGlvbnM6ICdmb3JtRGVmaW5pdGlvbnMnLFxuICAgICAgICBmb3JtRGVmaW5pdGlvbjogJ2Zvcm1EZWZpbml0aW9ucy8ke2Zvcm1EZWZpbml0aW9uSWR9JyxcbiAgICAgICAgZm9ybURhdGE6ICd1c2Vycy8ke3VzZXJJZH0vZm9ybURhdGEvJHtmb3JtRGF0YUlkfScsXG4gICAgICAgIGNyZWF0ZUZvcm1EYXRhOiAndXNlcnMvJHt1c2VySWR9L2Zvcm1EYXRhJyxcbiAgICAgICAgZ2V0RmlsZTogJ3VzZXJzLyR7dXNlcklkfS9kb2N1bWVudHMvJHtmaWxlQ29kZX0nLFxuICAgICAgICBnZXRGaWxlczogJ3VzZXJzLyR7dXNlcklkfS9kb2N1bWVudHMnLFxuICAgICAgICB1cGxvYWRGaWxlOiAndXNlcnMvJHt1c2VySWR9L2RvY3VtZW50cycsXG4gICAgICAgIHJlbW92ZUZpbGU6ICd1c2Vycy8ke3VzZXJJZH0vZG9jdW1lbnRzLyR7ZmlsZUNvZGV9JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn07XG4iXX0=