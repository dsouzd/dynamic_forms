import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { provideConfig } from '@spartacus/core';
import { defaultOccFormConfig } from './default-occ-form-config';
import { OccFormAdapter } from './occ-form.adapter';
import { FormAdapter } from '../../../core/connectors';
import { FileAdapter } from '../../../core/connectors/file.adapter';
import { OccFileAdapter } from '../file/occ-file.adapter';
import * as i0 from "@angular/core";
export class FormOccModule {
}
FormOccModule.ɵfac = function FormOccModule_Factory(t) { return new (t || FormOccModule)(); };
FormOccModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: FormOccModule });
FormOccModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        {
            provide: FormAdapter,
            useClass: OccFormAdapter,
        },
        {
            provide: FileAdapter,
            useClass: OccFileAdapter,
        },
        provideConfig(defaultOccFormConfig),
    ], imports: [CommonModule, HttpClientModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormOccModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, HttpClientModule],
                providers: [
                    {
                        provide: FormAdapter,
                        useClass: OccFormAdapter,
                    },
                    {
                        provide: FileAdapter,
                        useClass: OccFileAdapter,
                    },
                    provideConfig(defaultOccFormConfig),
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(FormOccModule, { imports: [CommonModule, HttpClientModule] }); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1vY2MubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHluYW1pY2Zvcm1zL3NyYy9vY2MvYWRhcHRlcnMvZm9ybS9mb3JtLW9jYy5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekMsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ2hELE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ2pFLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNwRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDdkQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHVDQUF1QyxDQUFDO0FBQ3BFLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQzs7QUFnQjFELE1BQU0sT0FBTyxhQUFhOzswRUFBYixhQUFhOytEQUFiLGFBQWE7b0VBWmI7UUFDVDtZQUNFLE9BQU8sRUFBRSxXQUFXO1lBQ3BCLFFBQVEsRUFBRSxjQUFjO1NBQ3pCO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsV0FBVztZQUNwQixRQUFRLEVBQUUsY0FBYztTQUN6QjtRQUNELGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQztLQUNwQyxZQVhTLFlBQVksRUFBRSxnQkFBZ0I7dUZBYTdCLGFBQWE7Y0FkekIsUUFBUTtlQUFDO2dCQUNSLE9BQU8sRUFBRSxDQUFDLFlBQVksRUFBRSxnQkFBZ0IsQ0FBQztnQkFDekMsU0FBUyxFQUFFO29CQUNUO3dCQUNFLE9BQU8sRUFBRSxXQUFXO3dCQUNwQixRQUFRLEVBQUUsY0FBYztxQkFDekI7b0JBQ0Q7d0JBQ0UsT0FBTyxFQUFFLFdBQVc7d0JBQ3BCLFFBQVEsRUFBRSxjQUFjO3FCQUN6QjtvQkFDRCxhQUFhLENBQUMsb0JBQW9CLENBQUM7aUJBQ3BDO2FBQ0Y7O3dGQUNZLGFBQWEsY0FiZCxZQUFZLEVBQUUsZ0JBQWdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IEh0dHBDbGllbnRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgcHJvdmlkZUNvbmZpZyB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBkZWZhdWx0T2NjRm9ybUNvbmZpZyB9IGZyb20gJy4vZGVmYXVsdC1vY2MtZm9ybS1jb25maWcnO1xuaW1wb3J0IHsgT2NjRm9ybUFkYXB0ZXIgfSBmcm9tICcuL29jYy1mb3JtLmFkYXB0ZXInO1xuaW1wb3J0IHsgRm9ybUFkYXB0ZXIgfSBmcm9tICcuLi8uLi8uLi9jb3JlL2Nvbm5lY3RvcnMnO1xuaW1wb3J0IHsgRmlsZUFkYXB0ZXIgfSBmcm9tICcuLi8uLi8uLi9jb3JlL2Nvbm5lY3RvcnMvZmlsZS5hZGFwdGVyJztcbmltcG9ydCB7IE9jY0ZpbGVBZGFwdGVyIH0gZnJvbSAnLi4vZmlsZS9vY2MtZmlsZS5hZGFwdGVyJztcblxuQE5nTW9kdWxlKHtcbiAgaW1wb3J0czogW0NvbW1vbk1vZHVsZSwgSHR0cENsaWVudE1vZHVsZV0sXG4gIHByb3ZpZGVyczogW1xuICAgIHtcbiAgICAgIHByb3ZpZGU6IEZvcm1BZGFwdGVyLFxuICAgICAgdXNlQ2xhc3M6IE9jY0Zvcm1BZGFwdGVyLFxuICAgIH0sXG4gICAge1xuICAgICAgcHJvdmlkZTogRmlsZUFkYXB0ZXIsXG4gICAgICB1c2VDbGFzczogT2NjRmlsZUFkYXB0ZXIsXG4gICAgfSxcbiAgICBwcm92aWRlQ29uZmlnKGRlZmF1bHRPY2NGb3JtQ29uZmlnKSxcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgRm9ybU9jY01vZHVsZSB7fVxuIl19