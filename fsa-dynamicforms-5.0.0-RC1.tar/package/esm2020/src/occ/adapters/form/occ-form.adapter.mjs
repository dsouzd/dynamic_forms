import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OccEndpointsService } from '@spartacus/core';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common/http";
import * as i2 from "@spartacus/core";
const FULL_PARAMS = 'FULL';
export class OccFormAdapter {
    constructor(http, occEndpointService) {
        this.http = http;
        this.occEndpointService = occEndpointService;
    }
    saveFormData(formData, userId) {
        const url = this.occEndpointService.buildUrl('createFormData', {
            urlParams: {
                userId: userId,
            },
        });
        let params = new HttpParams()
            .set('definitionId', formData.formDefinition.formId)
            .set('applicationId', formData.formDefinition.applicationId)
            .set('fields', FULL_PARAMS);
        if (formData.refId) {
            params = params.set('refId', formData.refId);
        }
        if (formData.id) {
            const formDataId = formData.id;
            const updateUrl = this.occEndpointService.buildUrl('formData', {
                urlParams: {
                    userId: userId,
                    formDataId,
                },
            });
            return this.http
                .put(updateUrl, formData.content, { params: params })
                .pipe(catchError((error) => throwError(error.json())));
        }
        return this.http
            .post(url, formData.content, { params: params })
            .pipe(catchError((error) => throwError(error.json())));
    }
    getFormData(formDataId, userId) {
        const url = this.occEndpointService.buildUrl('formData', {
            urlParams: {
                userId: userId,
                formDataId,
            },
        });
        return this.http
            .get(url)
            .pipe(catchError((error) => throwError(error.json())));
    }
    getFormDefinitions(categoryCode, formDefinitionType) {
        const url = this.occEndpointService.buildUrl('formDefinitions');
        const params = new HttpParams()
            .set('categoryCode', categoryCode)
            .set('yFormDefinitionType', formDefinitionType)
            .set('fields', FULL_PARAMS);
        return this.http
            .get(url, { params: params })
            .pipe(catchError((error) => throwError(error.json())));
    }
    getFormDefinition(applicationId, formDefinitionId) {
        const url = this.occEndpointService.buildUrl('formDefinition', {
            urlParams: {
                formDefinitionId,
            },
        });
        const params = new HttpParams()
            .set('applicationId', applicationId)
            .set('fields', FULL_PARAMS);
        return this.http.get(url, { params: params });
    }
}
OccFormAdapter.ɵfac = function OccFormAdapter_Factory(t) { return new (t || OccFormAdapter)(i0.ɵɵinject(i1.HttpClient), i0.ɵɵinject(i2.OccEndpointsService)); };
OccFormAdapter.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: OccFormAdapter, factory: OccFormAdapter.ɵfac });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OccFormAdapter, [{
        type: Injectable
    }], function () { return [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }]; }, null); })();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib2NjLWZvcm0uYWRhcHRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R5bmFtaWNmb3Jtcy9zcmMvb2NjL2FkYXB0ZXJzL2Zvcm0vb2NjLWZvcm0uYWRhcHRlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQzlELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDdEQsT0FBTyxFQUFjLFVBQVUsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUM5QyxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7Ozs7QUFRNUMsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDO0FBRzNCLE1BQU0sT0FBTyxjQUFjO0lBQ3pCLFlBQ1ksSUFBZ0IsRUFDaEIsa0JBQXVDO1FBRHZDLFNBQUksR0FBSixJQUFJLENBQVk7UUFDaEIsdUJBQWtCLEdBQWxCLGtCQUFrQixDQUFxQjtJQUNoRCxDQUFDO0lBRUosWUFBWSxDQUFDLFFBQW1CLEVBQUUsTUFBYztRQUM5QyxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLGdCQUFnQixFQUFFO1lBQzdELFNBQVMsRUFBRTtnQkFDVCxNQUFNLEVBQUUsTUFBTTthQUNmO1NBQ0YsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxNQUFNLEdBQWUsSUFBSSxVQUFVLEVBQUU7YUFDdEMsR0FBRyxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQzthQUNuRCxHQUFHLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDO2FBQzNELEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDOUIsSUFBSSxRQUFRLENBQUMsS0FBSyxFQUFFO1lBQ2xCLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDOUM7UUFFRCxJQUFJLFFBQVEsQ0FBQyxFQUFFLEVBQUU7WUFDZixNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsRUFBRSxDQUFDO1lBQy9CLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFO2dCQUM3RCxTQUFTLEVBQUU7b0JBQ1QsTUFBTSxFQUFFLE1BQU07b0JBQ2QsVUFBVTtpQkFDWDthQUNGLENBQUMsQ0FBQztZQUNILE9BQU8sSUFBSSxDQUFDLElBQUk7aUJBQ2IsR0FBRyxDQUFZLFNBQVMsRUFBRSxRQUFRLENBQUMsT0FBTyxFQUFFLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDO2lCQUMvRCxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQy9EO1FBRUQsT0FBTyxJQUFJLENBQUMsSUFBSTthQUNiLElBQUksQ0FBWSxHQUFHLEVBQUUsUUFBUSxDQUFDLE9BQU8sRUFBRSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQzthQUMxRCxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRCxXQUFXLENBQUMsVUFBa0IsRUFBRSxNQUFjO1FBQzVDLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFO1lBQ3ZELFNBQVMsRUFBRTtnQkFDVCxNQUFNLEVBQUUsTUFBTTtnQkFDZCxVQUFVO2FBQ1g7U0FDRixDQUFDLENBQUM7UUFDSCxPQUFPLElBQUksQ0FBQyxJQUFJO2FBQ2IsR0FBRyxDQUFZLEdBQUcsQ0FBQzthQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRCxrQkFBa0IsQ0FDaEIsWUFBb0IsRUFDcEIsa0JBQTBCO1FBRTFCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUNoRSxNQUFNLE1BQU0sR0FBZSxJQUFJLFVBQVUsRUFBRTthQUN4QyxHQUFHLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQzthQUNqQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsa0JBQWtCLENBQUM7YUFDOUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUM5QixPQUFPLElBQUksQ0FBQyxJQUFJO2FBQ2IsR0FBRyxDQUFzQixHQUFHLEVBQUUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUM7YUFDakQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRUQsaUJBQWlCLENBQ2YsYUFBcUIsRUFDckIsZ0JBQXdCO1FBRXhCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUU7WUFDN0QsU0FBUyxFQUFFO2dCQUNULGdCQUFnQjthQUNqQjtTQUNGLENBQUMsQ0FBQztRQUNILE1BQU0sTUFBTSxHQUFlLElBQUksVUFBVSxFQUFFO2FBQ3hDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDO2FBQ25DLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDOUIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBa0IsR0FBRyxFQUFFLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7SUFDakUsQ0FBQzs7NEVBN0VVLGNBQWM7b0VBQWQsY0FBYyxXQUFkLGNBQWM7dUZBQWQsY0FBYztjQUQxQixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cFBhcmFtcyB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE9jY0VuZHBvaW50c1NlcnZpY2UgfSBmcm9tICdAc3BhcnRhY3VzL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgdGhyb3dFcnJvciB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgY2F0Y2hFcnJvciB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEZvcm1BZGFwdGVyIH0gZnJvbSAnLi4vLi4vLi4vY29yZS9jb25uZWN0b3JzL2Zvcm0uYWRhcHRlcic7XG5pbXBvcnQge1xuICBZRm9ybURhdGEsXG4gIFlGb3JtRGVmaW5pdGlvbixcbiAgWUZvcm1EZWZpbml0aW9uTGlzdCxcbn0gZnJvbSAnLi4vLi4vLi4vY29yZS9tb2RlbHMvZm9ybS1vY2MubW9kZWxzJztcblxuY29uc3QgRlVMTF9QQVJBTVMgPSAnRlVMTCc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBPY2NGb3JtQWRhcHRlciBpbXBsZW1lbnRzIEZvcm1BZGFwdGVyIHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJvdGVjdGVkIGh0dHA6IEh0dHBDbGllbnQsXG4gICAgcHJvdGVjdGVkIG9jY0VuZHBvaW50U2VydmljZTogT2NjRW5kcG9pbnRzU2VydmljZVxuICApIHt9XG5cbiAgc2F2ZUZvcm1EYXRhKGZvcm1EYXRhOiBZRm9ybURhdGEsIHVzZXJJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxZRm9ybURhdGE+IHtcbiAgICBjb25zdCB1cmwgPSB0aGlzLm9jY0VuZHBvaW50U2VydmljZS5idWlsZFVybCgnY3JlYXRlRm9ybURhdGEnLCB7XG4gICAgICB1cmxQYXJhbXM6IHtcbiAgICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGxldCBwYXJhbXM6IEh0dHBQYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpXG4gICAgICAuc2V0KCdkZWZpbml0aW9uSWQnLCBmb3JtRGF0YS5mb3JtRGVmaW5pdGlvbi5mb3JtSWQpXG4gICAgICAuc2V0KCdhcHBsaWNhdGlvbklkJywgZm9ybURhdGEuZm9ybURlZmluaXRpb24uYXBwbGljYXRpb25JZClcbiAgICAgIC5zZXQoJ2ZpZWxkcycsIEZVTExfUEFSQU1TKTtcbiAgICBpZiAoZm9ybURhdGEucmVmSWQpIHtcbiAgICAgIHBhcmFtcyA9IHBhcmFtcy5zZXQoJ3JlZklkJywgZm9ybURhdGEucmVmSWQpO1xuICAgIH1cblxuICAgIGlmIChmb3JtRGF0YS5pZCkge1xuICAgICAgY29uc3QgZm9ybURhdGFJZCA9IGZvcm1EYXRhLmlkO1xuICAgICAgY29uc3QgdXBkYXRlVXJsID0gdGhpcy5vY2NFbmRwb2ludFNlcnZpY2UuYnVpbGRVcmwoJ2Zvcm1EYXRhJywge1xuICAgICAgICB1cmxQYXJhbXM6IHtcbiAgICAgICAgICB1c2VySWQ6IHVzZXJJZCxcbiAgICAgICAgICBmb3JtRGF0YUlkLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgIC5wdXQ8WUZvcm1EYXRhPih1cGRhdGVVcmwsIGZvcm1EYXRhLmNvbnRlbnQsIHsgcGFyYW1zOiBwYXJhbXMgfSlcbiAgICAgICAgLnBpcGUoY2F0Y2hFcnJvcigoZXJyb3I6IGFueSkgPT4gdGhyb3dFcnJvcihlcnJvci5qc29uKCkpKSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuaHR0cFxuICAgICAgLnBvc3Q8WUZvcm1EYXRhPih1cmwsIGZvcm1EYXRhLmNvbnRlbnQsIHsgcGFyYW1zOiBwYXJhbXMgfSlcbiAgICAgIC5waXBlKGNhdGNoRXJyb3IoKGVycm9yOiBhbnkpID0+IHRocm93RXJyb3IoZXJyb3IuanNvbigpKSkpO1xuICB9XG5cbiAgZ2V0Rm9ybURhdGEoZm9ybURhdGFJZDogc3RyaW5nLCB1c2VySWQ6IHN0cmluZyk6IE9ic2VydmFibGU8WUZvcm1EYXRhPiB7XG4gICAgY29uc3QgdXJsID0gdGhpcy5vY2NFbmRwb2ludFNlcnZpY2UuYnVpbGRVcmwoJ2Zvcm1EYXRhJywge1xuICAgICAgdXJsUGFyYW1zOiB7XG4gICAgICAgIHVzZXJJZDogdXNlcklkLFxuICAgICAgICBmb3JtRGF0YUlkLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAuZ2V0PFlGb3JtRGF0YT4odXJsKVxuICAgICAgLnBpcGUoY2F0Y2hFcnJvcigoZXJyb3I6IGFueSkgPT4gdGhyb3dFcnJvcihlcnJvci5qc29uKCkpKSk7XG4gIH1cblxuICBnZXRGb3JtRGVmaW5pdGlvbnMoXG4gICAgY2F0ZWdvcnlDb2RlOiBzdHJpbmcsXG4gICAgZm9ybURlZmluaXRpb25UeXBlOiBzdHJpbmdcbiAgKTogT2JzZXJ2YWJsZTxhbnk+IHtcbiAgICBjb25zdCB1cmwgPSB0aGlzLm9jY0VuZHBvaW50U2VydmljZS5idWlsZFVybCgnZm9ybURlZmluaXRpb25zJyk7XG4gICAgY29uc3QgcGFyYW1zOiBIdHRwUGFyYW1zID0gbmV3IEh0dHBQYXJhbXMoKVxuICAgICAgLnNldCgnY2F0ZWdvcnlDb2RlJywgY2F0ZWdvcnlDb2RlKVxuICAgICAgLnNldCgneUZvcm1EZWZpbml0aW9uVHlwZScsIGZvcm1EZWZpbml0aW9uVHlwZSlcbiAgICAgIC5zZXQoJ2ZpZWxkcycsIEZVTExfUEFSQU1TKTtcbiAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAuZ2V0PFlGb3JtRGVmaW5pdGlvbkxpc3Q+KHVybCwgeyBwYXJhbXM6IHBhcmFtcyB9KVxuICAgICAgLnBpcGUoY2F0Y2hFcnJvcigoZXJyb3I6IGFueSkgPT4gdGhyb3dFcnJvcihlcnJvci5qc29uKCkpKSk7XG4gIH1cblxuICBnZXRGb3JtRGVmaW5pdGlvbihcbiAgICBhcHBsaWNhdGlvbklkOiBzdHJpbmcsXG4gICAgZm9ybURlZmluaXRpb25JZDogc3RyaW5nXG4gICk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgY29uc3QgdXJsID0gdGhpcy5vY2NFbmRwb2ludFNlcnZpY2UuYnVpbGRVcmwoJ2Zvcm1EZWZpbml0aW9uJywge1xuICAgICAgdXJsUGFyYW1zOiB7XG4gICAgICAgIGZvcm1EZWZpbml0aW9uSWQsXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGNvbnN0IHBhcmFtczogSHR0cFBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKClcbiAgICAgIC5zZXQoJ2FwcGxpY2F0aW9uSWQnLCBhcHBsaWNhdGlvbklkKVxuICAgICAgLnNldCgnZmllbGRzJywgRlVMTF9QQVJBTVMpO1xuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFlGb3JtRGVmaW5pdGlvbj4odXJsLCB7IHBhcmFtczogcGFyYW1zIH0pO1xuICB9XG59XG4iXX0=