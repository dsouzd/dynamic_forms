# Spartacus Dynamic Forms

Dynamic Forms is a library for creating forms designed to work with Spartacus application.
It allows customers to define forms meta data in JSON format and render them on UI.

For more information, see [Spartacus Documentation](https://sap.github.io/spartacus-docs/dynamicforms).
