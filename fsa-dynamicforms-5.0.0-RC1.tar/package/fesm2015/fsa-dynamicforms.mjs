import * as i1 from '@angular/common';
import { CommonModule, DatePipe } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, HostBinding, Input, Directive, HostListener, NgModule, EventEmitter, ChangeDetectionStrategy, Output, ViewChild, InjectionToken, APP_INITIALIZER } from '@angular/core';
import * as i2$1 from '@angular/forms';
import { UntypedFormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import * as i2 from '@spartacus/core';
import { Config, LogoutEvent, GlobalMessageType, provideDefaultConfig, I18nModule, provideConfig, OccConfig, ConfigModule, AuthActions, StateModule } from '@spartacus/core';
import { Subscription, BehaviorSubject, combineLatest, of, throwError } from 'rxjs';
import { map, filter, take, tap, switchMap, catchError, mergeMap } from 'rxjs/operators';
import * as i1$1 from '@spartacus/storefront';
import { DIALOG_TYPE, SpinnerModule } from '@spartacus/storefront';
import * as i1$4 from '@angular/common/http';
import { HttpEventType, HttpResponse, HttpParams, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { saveAs } from 'file-saver';
import * as i1$2 from '@ngrx/store';
import { createFeatureSelector, createSelector, select, StoreModule } from '@ngrx/store';
import * as i1$3 from '@spartacus/user/account/root';
import { RouterModule } from '@angular/router';
import { base64StringToBlob } from 'blob-util';
import * as i1$5 from '@ngrx/effects';
import { createEffect, ofType, EffectsModule } from '@ngrx/effects';

class FormComponentConfig {
}
class ValidatorConfig {
}
class PrefillConfig {
}
class DynamicFormsConfig extends Config {
}

class FormService {
    constructor() { }
    /**
     * Method used to recursively find form control by its code in specified form group
     *
     * @param formControlCode The form control code
     * @param formGroup The form group
     */
    getFormControlForCode(formControlCode, formGroup) {
        let abstractFormControl;
        for (const key of Object.keys(formGroup.controls)) {
            const nestedFormGroup = formGroup.get(key);
            if (key === formControlCode) {
                abstractFormControl = formGroup.get(key);
                break;
            }
            else if (nestedFormGroup instanceof UntypedFormGroup) {
                abstractFormControl = this.getFormControlForCode(formControlCode, nestedFormGroup);
                if (abstractFormControl !== undefined) {
                    break;
                }
            }
        }
        return abstractFormControl;
    }
}
FormService.ɵfac = function FormService_Factory(t) { return new (t || FormService)(); };
FormService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormService, factory: FormService.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormService, [{
            type: Injectable
        }], function () { return []; }, null);
})();

class AbstractFormComponent {
    constructor(appConfig, languageService, injector, formService) {
        this.appConfig = appConfig;
        this.languageService = languageService;
        this.injector = injector;
        this.formService = formService;
        this.subscription = new Subscription();
        this.activeLang$ = this.languageService.getActive();
    }
    ngOnInit() {
        this.setHostComponentClass();
        this.setLocalizedProperties();
        this.controlPrefill();
        this.interDependancyValueCheck();
    }
    setHostComponentClass() {
        this.hostComponentClass =
            this.config && this.config.gridClass ? this.config.gridClass : 'col-12';
        if (this.config && this.config.cssClass) {
            this.hostComponentClass = `${this.hostComponentClass} ${this.config.cssClass}`;
        }
    }
    setLocalizedProperties() {
        this.subscription.add(this.languageService
            .getActive()
            .pipe(map(lang => {
            var _a, _b;
            if ((_a = this.config) === null || _a === void 0 ? void 0 : _a.label) {
                this.label = this.config.label[lang]
                    ? this.config.label[lang]
                    : this.config.label.default;
            }
            if ((_b = this.config) === null || _b === void 0 ? void 0 : _b.placeholder) {
                this.placeHolder = this.config.placeholder[lang]
                    ? this.config.placeholder[lang]
                    : this.config.placeholder.default;
            }
        }))
            .subscribe());
    }
    controlPrefill() {
        if (this.config.prefillValue) {
            const targetObject = this.appConfig.dynamicForms.prefill[this.config.prefillValue.targetObject];
            if (targetObject && targetObject.prefillResolver) {
                const prefillResolver = this.injector.get(targetObject.prefillResolver);
                this.subscription.add(prefillResolver
                    .getPrefillValue(this.config.prefillValue.targetValue)
                    .subscribe(value => {
                    if (value) {
                        this.group.get(this.config.name).setValue(value);
                    }
                }));
            }
        }
    }
    interDependancyValueCheck() {
        const triggeredControl = this.formService.getFormControlForCode(this.config.name, this.group.root);
        if (triggeredControl) {
            this.subscription.add(triggeredControl.valueChanges
                .pipe(filter(_ => !!this.config.validations), map(_ => {
                this.config.validations.forEach(validation => {
                    if (validation.arguments && validation.arguments.length > 1) {
                        const targetControl = this.formService.getFormControlForCode(validation.arguments[0].value, this.group.root);
                        targetControl.updateValueAndValidity({
                            onlySelf: true,
                            emitEvent: false,
                        });
                    }
                });
            }))
                .subscribe());
        }
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
AbstractFormComponent.ɵfac = function AbstractFormComponent_Factory(t) { return new (t || AbstractFormComponent)(i0.ɵɵdirectiveInject(DynamicFormsConfig), i0.ɵɵdirectiveInject(i2.LanguageService), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(FormService)); };
AbstractFormComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AbstractFormComponent, selectors: [["ng-component"]], hostVars: 2, hostBindings: function AbstractFormComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
            i0.ɵɵclassMap(ctx.hostComponentClass);
        }
    }, decls: 0, vars: 0, template: function AbstractFormComponent_Template(rf, ctx) { }, encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AbstractFormComponent, [{
            type: Component,
            args: [{ template: '' }]
        }], function () { return [{ type: DynamicFormsConfig }, { type: i2.LanguageService }, { type: i0.Injector }, { type: FormService }]; }, { hostComponentClass: [{
                type: HostBinding,
                args: ['class']
            }] });
})();

function ButtonComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "button", 2);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("disabled", ctx_r0.config.disabled);
        i0.ɵɵattribute("name", ctx_r0.config.name);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
    }
}
class ButtonComponent extends AbstractFormComponent {
}
ButtonComponent.ɵfac = /*@__PURE__*/ function () { let ɵButtonComponent_BaseFactory; return function ButtonComponent_Factory(t) { return (ɵButtonComponent_BaseFactory || (ɵButtonComponent_BaseFactory = i0.ɵɵgetInheritedFactory(ButtonComponent)))(t || ButtonComponent); }; }();
ButtonComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ButtonComponent, selectors: [["cx-button"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], ["type", "submit", 1, "btn", "btn-primary", 3, "disabled"]], template: function ButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, ButtonComponent_ng_container_0_Template, 4, 5, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgIf, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ButtonComponent, [{
            type: Component,
            args: [{ selector: 'cx-button', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <button\n      class=\"btn btn-primary\"\n      [disabled]=\"config.disabled\"\n      type=\"submit\"\n      [attr.name]=\"config.name\"\n    >\n      {{ label }}\n    </button>\n  </div>\n</ng-container>\n" }]
        }], null, null);
})();

class FormDateConfig {
}
FormDateConfig.ɵfac = function FormDateConfig_Factory(t) { return new (t || FormDateConfig)(); };
FormDateConfig.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormDateConfig, factory: function FormDateConfig_Factory(t) {
        let r = null;
        if (t) {
            r = new (t || FormDateConfig)();
        }
        else {
            r = i0.ɵɵinject(Config);
        }
        return r;
    }, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormDateConfig, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }], null, null);
})();

function ErrorNoticeComponent_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 2);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "cxTranslate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "dynamicforms.enterValidValue"), " ");
    }
}
function ErrorNoticeComponent_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 2);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", ctx_r1.errorMessage, " ");
    }
}
class ErrorNoticeComponent {
    constructor(languageService) {
        this.languageService = languageService;
        this.subscription = new Subscription();
    }
    ngOnInit() {
        this.subscription.add(this.languageService
            .getActive()
            .pipe(map(lang => {
            if (this.parentConfig && this.parentConfig.error) {
                this.errorMessage = this.parentConfig.error[lang]
                    ? this.parentConfig.error[lang]
                    : this.parentConfig.error.default;
            }
        }))
            .subscribe());
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
ErrorNoticeComponent.ɵfac = function ErrorNoticeComponent_Factory(t) { return new (t || ErrorNoticeComponent)(i0.ɵɵdirectiveInject(i2.LanguageService)); };
ErrorNoticeComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ErrorNoticeComponent, selectors: [["cx-error-notice"]], inputs: { warn: "warn", parentConfig: "parentConfig" }, decls: 3, vars: 2, consts: [[1, "px-2"], [4, "ngIf"], [1, "text-danger", "mb-2"]], template: function ErrorNoticeComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, ErrorNoticeComponent_ng_container_1_Template, 4, 3, "ng-container", 1);
            i0.ɵɵtemplate(2, ErrorNoticeComponent_ng_container_2_Template, 3, 1, "ng-container", 1);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", (ctx.warn == null ? null : ctx.warn.touched) && (ctx.warn == null ? null : ctx.warn.errors == null ? null : ctx.warn.errors.required) || (ctx.warn == null ? null : ctx.warn.errors == null ? null : ctx.warn.errors.pattern));
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", (ctx.warn == null ? null : ctx.warn.invalid) && (ctx.warn == null ? null : ctx.warn.touched) && !(ctx.warn == null ? null : ctx.warn.errors == null ? null : ctx.warn.errors.required) && (ctx.parentConfig == null ? null : ctx.parentConfig.error));
        }
    }, dependencies: [i1.NgIf, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ErrorNoticeComponent, [{
            type: Component,
            args: [{ selector: 'cx-error-notice', template: "<div class=\"px-2\">\n  <ng-container\n    *ngIf=\"(warn?.touched && warn?.errors?.required) || warn?.errors?.pattern\"\n  >\n    <div class=\"text-danger mb-2\">\n      {{ 'dynamicforms.enterValidValue' | cxTranslate }}\n    </div>\n  </ng-container>\n  <ng-container\n    *ngIf=\"\n      warn?.invalid &&\n      warn?.touched &&\n      !warn?.errors?.required &&\n      parentConfig?.error\n    \"\n  >\n    <div class=\"text-danger mb-2\">\n      {{ errorMessage }}\n    </div>\n  </ng-container>\n</div>\n" }]
        }], function () { return [{ type: i2.LanguageService }]; }, { warn: [{
                type: Input
            }], parentConfig: [{
                type: Input
            }] });
})();

function DatePickerComponent_ng_container_0_ng_container_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
    }
}
function DatePickerComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
        i0.ɵɵtemplate(4, DatePickerComponent_ng_container_0_ng_container_4_Template, 3, 3, "ng-container", 0);
        i0.ɵɵtext(5);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(6, "input", 4);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(7, "cx-error-notice", 5);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵpropertyInterpolate("placeholder", ctx_r0.getDateFormat());
        i0.ɵɵproperty("formControlName", ctx_r0.config.name);
        i0.ɵɵattribute("name", ctx_r0.config.name)("readonly", ctx_r0.config.readonly ? ctx_r0.config.readonly : null);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
    }
}
class DatePickerComponent extends AbstractFormComponent {
    constructor(appConfig, languageService, injector, formService, dateConfig) {
        super(appConfig, languageService, injector, formService);
        this.appConfig = appConfig;
        this.languageService = languageService;
        this.injector = injector;
        this.formService = formService;
        this.dateConfig = dateConfig;
    }
    getDateFormat() {
        var _a, _b;
        return ((_b = (_a = this.dateConfig) === null || _a === void 0 ? void 0 : _a.date) === null || _b === void 0 ? void 0 : _b.format) || '';
    }
}
DatePickerComponent.ɵfac = function DatePickerComponent_Factory(t) { return new (t || DatePickerComponent)(i0.ɵɵdirectiveInject(DynamicFormsConfig), i0.ɵɵdirectiveInject(i2.LanguageService), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(FormService), i0.ɵɵdirectiveInject(FormDateConfig)); };
DatePickerComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DatePickerComponent, selectors: [["cx-datepicker"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], ["type", "date", 1, "form-control", 3, "placeholder", "formControlName"], [3, "warn", "parentConfig"]], template: function DatePickerComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, DatePickerComponent_ng_container_0_Template, 8, 10, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgIf, i2$1.DefaultValueAccessor, i2$1.NgControlStatus, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, i2$1.FormControlName, ErrorNoticeComponent, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DatePickerComponent, [{
            type: Component,
            args: [{ selector: 'cx-datepicker', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n        {{ label }}\n      </label>\n      <input\n        class=\"form-control\"\n        type=\"date\"\n        placeholder=\"{{ getDateFormat() }}\"\n        [formControlName]=\"config.name\"\n        [attr.name]=\"config.name\"\n        [attr.readonly]=\"config.readonly ? config.readonly : null\"\n      />\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
        }], function () { return [{ type: DynamicFormsConfig }, { type: i2.LanguageService }, { type: i0.Injector }, { type: FormService }, { type: FormDateConfig }]; }, null);
})();

class FormComponentDirective {
    constructor(resolver, container, formConfig) {
        this.resolver = resolver;
        this.container = container;
        this.formConfig = formConfig;
        this.components = {};
    }
    ngOnInit() {
        for (const [name, obj] of Object.entries(this.formConfig.dynamicForms.components)) {
            this.components[name] = obj.component;
        }
        if (!this.components[this.config.fieldType]) {
            const supportedTypes = Object.keys(this.components).join(', ');
            throw new Error(`Trying to use an unsupported type (${this.config.fieldType}).
        Supported types: ${supportedTypes}`);
        }
        const component = this.resolver.resolveComponentFactory(this.components[this.config.fieldType]);
        this.component = this.container.createComponent(component);
        this.component.instance.config = this.config;
        this.component.instance.group = this.group;
    }
}
FormComponentDirective.ɵfac = function FormComponentDirective_Factory(t) { return new (t || FormComponentDirective)(i0.ɵɵdirectiveInject(i0.ComponentFactoryResolver), i0.ɵɵdirectiveInject(i0.ViewContainerRef), i0.ɵɵdirectiveInject(DynamicFormsConfig)); };
FormComponentDirective.ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: FormComponentDirective, selectors: [["", "cxFormComponent", ""]], inputs: { config: "config", group: "group" } });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormComponentDirective, [{
            type: Directive,
            args: [{
                    selector: '[cxFormComponent]',
                }]
        }], function () { return [{ type: i0.ComponentFactoryResolver }, { type: i0.ViewContainerRef }, { type: DynamicFormsConfig }]; }, { config: [{
                type: Input
            }], group: [{
                type: Input
            }] });
})();

function InputComponent_ng_container_0_ng_container_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
    }
}
function InputComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
        i0.ɵɵtext(4);
        i0.ɵɵtemplate(5, InputComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(6, "input", 4);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(7, "cx-error-notice", 5);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formControlName", ctx_r0.config.name);
        i0.ɵɵattribute("placeholder", ctx_r0.placeHolder)("name", ctx_r0.config.name)("readonly", ctx_r0.config.readonly ? ctx_r0.config.readonly : null);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
    }
}
class InputComponent extends AbstractFormComponent {
}
InputComponent.ɵfac = /*@__PURE__*/ function () { let ɵInputComponent_BaseFactory; return function InputComponent_Factory(t) { return (ɵInputComponent_BaseFactory || (ɵInputComponent_BaseFactory = i0.ɵɵgetInheritedFactory(InputComponent)))(t || InputComponent); }; }();
InputComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: InputComponent, selectors: [["cx-input"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], ["type", "text", 1, "form-control", 3, "formControlName"], [3, "warn", "parentConfig"]], template: function InputComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, InputComponent_ng_container_0_Template, 8, 10, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgIf, i2$1.DefaultValueAccessor, i2$1.NgControlStatus, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, i2$1.FormControlName, ErrorNoticeComponent, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InputComponent, [{
            type: Component,
            args: [{ selector: 'cx-input', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        [attr.placeholder]=\"placeHolder\"\n        [formControlName]=\"config.name\"\n        [attr.name]=\"config.name\"\n        [attr.readonly]=\"config.readonly ? config.readonly : null\"\n      />\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
        }], null, null);
})();

class AbstractOptionsComponent extends AbstractFormComponent {
    ngOnInit() {
        super.ngOnInit();
        if (this.config.options) {
            const selectedOption = this.config.options.find(option => option.selected);
            if (selectedOption) {
                this.group.get(this.config.name).setValue(selectedOption.name);
            }
        }
    }
    getLocalizedOption(localizationObj, activelanguage) {
        return localizationObj[activelanguage]
            ? localizationObj[activelanguage]
            : localizationObj.default;
    }
}
AbstractOptionsComponent.ɵfac = /*@__PURE__*/ function () { let ɵAbstractOptionsComponent_BaseFactory; return function AbstractOptionsComponent_Factory(t) { return (ɵAbstractOptionsComponent_BaseFactory || (ɵAbstractOptionsComponent_BaseFactory = i0.ɵɵgetInheritedFactory(AbstractOptionsComponent)))(t || AbstractOptionsComponent); }; }();
AbstractOptionsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AbstractOptionsComponent, selectors: [["ng-component"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 0, vars: 0, template: function AbstractOptionsComponent_Template(rf, ctx) { }, encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AbstractOptionsComponent, [{
            type: Component,
            args: [{ template: '' }]
        }], null, null);
})();

function RadioComponent_ng_container_0_ng_container_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
    }
}
function RadioComponent_ng_container_0_div_6_ng_container_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const activeLang_r5 = ctx.ngIf;
        const option_r3 = i0.ɵɵnextContext().$implicit;
        const ctx_r4 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r4.getLocalizedOption(option_r3.label, activeLang_r5), " ");
    }
}
function RadioComponent_ng_container_0_div_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵelement(1, "input", 6);
        i0.ɵɵelementStart(2, "label", 7);
        i0.ɵɵtemplate(3, RadioComponent_ng_container_0_div_6_ng_container_3_Template, 2, 1, "ng-container", 0);
        i0.ɵɵpipe(4, "async");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const option_r3 = ctx.$implicit;
        const ctx_r2 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵpropertyInterpolate("value", option_r3.name);
        i0.ɵɵproperty("formControlName", ctx_r2.config.name);
        i0.ɵɵattribute("name", ctx_r2.config.name)("id", ctx_r2.config.name + option_r3.name)("readonly", ctx_r2.config.readonly ? ctx_r2.config.readonly : null);
        i0.ɵɵadvance(1);
        i0.ɵɵattribute("for", ctx_r2.config.name + option_r3.name);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(4, 7, ctx_r2.activeLang$));
    }
}
function RadioComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "label", 2);
        i0.ɵɵtext(3);
        i0.ɵɵtemplate(4, RadioComponent_ng_container_0_ng_container_4_Template, 3, 3, "ng-container", 0);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "div", 3);
        i0.ɵɵtemplate(6, RadioComponent_ng_container_0_div_6_Template, 5, 9, "div", 4);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(7, "cx-error-notice", 5);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", ctx_r0.config.options);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
    }
}
class RadioComponent extends AbstractOptionsComponent {
}
RadioComponent.ɵfac = /*@__PURE__*/ function () { let ɵRadioComponent_BaseFactory; return function RadioComponent_Factory(t) { return (ɵRadioComponent_BaseFactory || (ɵRadioComponent_BaseFactory = i0.ɵɵgetInheritedFactory(RadioComponent)))(t || RadioComponent); }; }();
RadioComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RadioComponent, selectors: [["cx-radio"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "col-form-label"], [1, "form-check"], [4, "ngFor", "ngForOf"], [3, "warn", "parentConfig"], ["type", "radio", 1, "form-check-input", 3, "value", "formControlName"], [1, "pl-3", "pt-1"]], template: function RadioComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, RadioComponent_ng_container_0_Template, 8, 7, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgForOf, i1.NgIf, i2$1.DefaultValueAccessor, i2$1.RadioControlValueAccessor, i2$1.NgControlStatus, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, i2$1.FormControlName, ErrorNoticeComponent, i1.AsyncPipe, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RadioComponent, [{
            type: Component,
            args: [{ selector: 'cx-radio', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <label class=\"col-form-label\">\n      {{ label }}\n      <ng-container *ngIf=\"!config.required\">\n        {{ 'dynamicforms.optional' | cxTranslate }}\n      </ng-container>\n    </label>\n    <div class=\"form-check\">\n      <div *ngFor=\"let option of config.options\">\n        <input\n          class=\"form-check-input\"\n          type=\"radio\"\n          [attr.name]=\"config.name\"\n          [attr.id]=\"config.name + option.name\"\n          value=\"{{ option.name }}\"\n          [formControlName]=\"config.name\"\n          [attr.readonly]=\"config.readonly ? config.readonly : null\"\n        />\n        <label class=\"pl-3 pt-1\" [attr.for]=\"config.name + option.name\">\n          <ng-container *ngIf=\"activeLang$ | async as activeLang\">\n            {{ getLocalizedOption(option.label, activeLang) }}\n          </ng-container>\n        </label>\n      </div>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
        }], null, null);
})();

function SelectComponent_ng_container_0_ng_container_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
    }
}
function SelectComponent_ng_container_0_option_10_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const activeLang_r5 = ctx.ngIf;
        const option_r3 = i0.ɵɵnextContext().$implicit;
        const ctx_r4 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r4.getLocalizedOption(option_r3.label, activeLang_r5), " ");
    }
}
function SelectComponent_ng_container_0_option_10_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "option", 8);
        i0.ɵɵtemplate(1, SelectComponent_ng_container_0_option_10_ng_container_1_Template, 2, 1, "ng-container", 0);
        i0.ɵɵpipe(2, "async");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const option_r3 = ctx.$implicit;
        const ctx_r2 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("value", option_r3.name);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(2, 2, ctx_r2.activeLang$));
    }
}
function SelectComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
        i0.ɵɵtext(4);
        i0.ɵɵtemplate(5, SelectComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(6, "select", 4)(7, "option", 5);
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "cxTranslate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(10, SelectComponent_ng_container_0_option_10_Template, 3, 4, "option", 6);
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(11, "cx-error-notice", 7);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formControlName", ctx_r0.config.name);
        i0.ɵɵattribute("name", ctx_r0.config.name);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("value", undefined);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 11, "dynamicforms.pleaseSelect"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", ctx_r0.config.options);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
    }
}
class SelectComponent extends AbstractOptionsComponent {
}
SelectComponent.ɵfac = /*@__PURE__*/ function () { let ɵSelectComponent_BaseFactory; return function SelectComponent_Factory(t) { return (ɵSelectComponent_BaseFactory || (ɵSelectComponent_BaseFactory = i0.ɵɵgetInheritedFactory(SelectComponent)))(t || SelectComponent); }; }();
SelectComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SelectComponent, selectors: [["cx-select"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], [1, "form-control", 3, "formControlName"], ["disabled", "", 3, "value"], [3, "value", 4, "ngFor", "ngForOf"], [3, "warn", "parentConfig"], [3, "value"]], template: function SelectComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, SelectComponent_ng_container_0_Template, 12, 13, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgForOf, i1.NgIf, i2$1.NgSelectOption, i2$1.ɵNgSelectMultipleOption, i2$1.SelectControlValueAccessor, i2$1.NgControlStatus, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, i2$1.FormControlName, ErrorNoticeComponent, i1.AsyncPipe, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SelectComponent, [{
            type: Component,
            args: [{ selector: 'cx-select', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <select\n        class=\"form-control\"\n        [attr.name]=\"config.name\"\n        [formControlName]=\"config.name\"\n      >\n        <option disabled [value]=\"undefined\">\n          {{ 'dynamicforms.pleaseSelect' | cxTranslate }}\n        </option>\n        <option *ngFor=\"let option of config.options\" [value]=\"option.name\">\n          <ng-container *ngIf=\"activeLang$ | async as activeLang\">\n            {{ getLocalizedOption(option.label, activeLang) }}\n          </ng-container>\n        </option>\n      </select>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
        }], null, null);
})();

function TextAreaComponent_ng_container_0_ng_container_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
    }
}
function TextAreaComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
        i0.ɵɵtext(4);
        i0.ɵɵtemplate(5, TextAreaComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(6, "textarea", 4);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(7, "cx-error-notice", 5);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formControlName", ctx_r0.config.name);
        i0.ɵɵattribute("placeholder", ctx_r0.placeHolder)("name", ctx_r0.config.name)("readonly", ctx_r0.config.readonly ? ctx_r0.config.readonly : null);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
    }
}
class TextAreaComponent extends AbstractFormComponent {
}
TextAreaComponent.ɵfac = /*@__PURE__*/ function () { let ɵTextAreaComponent_BaseFactory; return function TextAreaComponent_Factory(t) { return (ɵTextAreaComponent_BaseFactory || (ɵTextAreaComponent_BaseFactory = i0.ɵɵgetInheritedFactory(TextAreaComponent)))(t || TextAreaComponent); }; }();
TextAreaComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TextAreaComponent, selectors: [["cx-text-area"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], ["rows", "10", 1, "form-control", 3, "formControlName"], [3, "warn", "parentConfig"]], template: function TextAreaComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, TextAreaComponent_ng_container_0_Template, 8, 10, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgIf, i2$1.DefaultValueAccessor, i2$1.NgControlStatus, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, i2$1.FormControlName, ErrorNoticeComponent, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TextAreaComponent, [{
            type: Component,
            args: [{ selector: 'cx-text-area', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <textarea\n        class=\"form-control\"\n        [attr.placeholder]=\"placeHolder\"\n        [formControlName]=\"config.name\"\n        rows=\"10\"\n        [attr.name]=\"config.name\"\n        [attr.readonly]=\"config.readonly ? config.readonly : null\"\n      ></textarea>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
        }], null, null);
})();

function TimeComponent_ng_container_0_ng_container_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
    }
}
function TimeComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
        i0.ɵɵtext(4);
        i0.ɵɵtemplate(5, TimeComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(6, "input", 4);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(7, "cx-error-notice", 5);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
        i0.ɵɵadvance(1);
        i0.ɵɵpropertyInterpolate("formControlName", ctx_r0.config.name);
        i0.ɵɵproperty("step", 1);
        i0.ɵɵattribute("name", ctx_r0.config.name)("readonly", ctx_r0.config.readonly ? ctx_r0.config.readonly : null);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
    }
}
class TimeComponent extends AbstractFormComponent {
}
TimeComponent.ɵfac = /*@__PURE__*/ function () { let ɵTimeComponent_BaseFactory; return function TimeComponent_Factory(t) { return (ɵTimeComponent_BaseFactory || (ɵTimeComponent_BaseFactory = i0.ɵɵgetInheritedFactory(TimeComponent)))(t || TimeComponent); }; }();
TimeComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TimeComponent, selectors: [["cx-time"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], ["type", "time", 1, "form-control", 3, "formControlName", "step"], [3, "warn", "parentConfig"]], template: function TimeComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, TimeComponent_ng_container_0_Template, 8, 10, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgIf, i2$1.DefaultValueAccessor, i2$1.NgControlStatus, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, i2$1.FormControlName, ErrorNoticeComponent, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TimeComponent, [{
            type: Component,
            args: [{ selector: 'cx-time', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <input\n        class=\"form-control\"\n        type=\"time\"\n        formControlName=\"{{ config.name }}\"\n        [attr.name]=\"config.name\"\n        [step]=\"1\"\n        [attr.readonly]=\"config.readonly ? config.readonly : null\"\n      />\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
        }], null, null);
})();

class TitleComponent extends AbstractFormComponent {
}
TitleComponent.ɵfac = /*@__PURE__*/ function () { let ɵTitleComponent_BaseFactory; return function TitleComponent_Factory(t) { return (ɵTitleComponent_BaseFactory || (ɵTitleComponent_BaseFactory = i0.ɵɵgetInheritedFactory(TitleComponent)))(t || TitleComponent); }; }();
TitleComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TitleComponent, selectors: [["cx-title"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 3, vars: 3, consts: [[1, "mt-3", 3, "formGroup", "hidden"]], template: function TitleComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h4");
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵproperty("formGroup", ctx.group)("hidden", ctx.config.hidden);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.label);
        }
    }, dependencies: [i2$1.NgControlStatusGroup, i2$1.FormGroupDirective], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TitleComponent, [{
            type: Component,
            args: [{ selector: 'cx-title', template: "<div class=\"mt-3\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n  <h4>{{ label }}</h4>\n</div>\n" }]
        }], null, null);
})();

function SeparatorComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelement(1, "hr", 1);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("hidden", ctx_r0.config.hidden);
    }
}
class SeparatorComponent extends AbstractFormComponent {
}
SeparatorComponent.ɵfac = /*@__PURE__*/ function () { let ɵSeparatorComponent_BaseFactory; return function SeparatorComponent_Factory(t) { return (ɵSeparatorComponent_BaseFactory || (ɵSeparatorComponent_BaseFactory = i0.ɵɵgetInheritedFactory(SeparatorComponent)))(t || SeparatorComponent); }; }();
SeparatorComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SeparatorComponent, selectors: [["cx-separator"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "hidden"]], template: function SeparatorComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, SeparatorComponent_ng_container_0_Template, 2, 1, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgIf], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SeparatorComponent, [{
            type: Component,
            args: [{ selector: 'cx-separator', template: "<ng-container *ngIf=\"group\">\n  <hr [hidden]=\"config.hidden\" />\n</ng-container>\n" }]
        }], null, null);
})();

function CheckboxComponent_ng_container_0_ng_container_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
    }
}
function CheckboxComponent_ng_container_0_div_6_ng_container_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const activeLang_r5 = ctx.ngIf;
        const option_r3 = i0.ɵɵnextContext().$implicit;
        const ctx_r4 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r4.getLocalizedOption(option_r3.label, activeLang_r5), " ");
    }
}
function CheckboxComponent_ng_container_0_div_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵelement(1, "input", 6);
        i0.ɵɵelementStart(2, "label", 7);
        i0.ɵɵtemplate(3, CheckboxComponent_ng_container_0_div_6_ng_container_3_Template, 2, 1, "ng-container", 0);
        i0.ɵɵpipe(4, "async");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const option_r3 = ctx.$implicit;
        const ctx_r2 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵpropertyInterpolate("value", option_r3.name);
        i0.ɵɵproperty("formControlName", ctx_r2.config.name);
        i0.ɵɵattribute("name", option_r3.name)("id", ctx_r2.config.name + option_r3.name);
        i0.ɵɵadvance(1);
        i0.ɵɵattribute("for", ctx_r2.config.name + option_r3.name);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(4, 6, ctx_r2.activeLang$));
    }
}
function CheckboxComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "label", 2);
        i0.ɵɵtext(3);
        i0.ɵɵtemplate(4, CheckboxComponent_ng_container_0_ng_container_4_Template, 3, 3, "ng-container", 0);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "div", 3);
        i0.ɵɵtemplate(6, CheckboxComponent_ng_container_0_div_6_Template, 5, 8, "div", 4);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(7, "cx-error-notice", 5);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", ctx_r0.config.options);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
    }
}
class CheckboxComponent extends AbstractOptionsComponent {
}
CheckboxComponent.ɵfac = /*@__PURE__*/ function () { let ɵCheckboxComponent_BaseFactory; return function CheckboxComponent_Factory(t) { return (ɵCheckboxComponent_BaseFactory || (ɵCheckboxComponent_BaseFactory = i0.ɵɵgetInheritedFactory(CheckboxComponent)))(t || CheckboxComponent); }; }();
CheckboxComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CheckboxComponent, selectors: [["cx-checkbox"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "col-form-label"], [1, "form-check"], [4, "ngFor", "ngForOf"], [3, "warn", "parentConfig"], ["type", "checkbox", 1, "form-check-input", 3, "value", "formControlName"], [1, "pl-3", "pt-1"]], template: function CheckboxComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, CheckboxComponent_ng_container_0_Template, 8, 7, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgForOf, i1.NgIf, i2$1.CheckboxControlValueAccessor, i2$1.NgControlStatus, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, i2$1.FormControlName, ErrorNoticeComponent, i1.AsyncPipe, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CheckboxComponent, [{
            type: Component,
            args: [{ selector: 'cx-checkbox', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <label class=\"col-form-label\">\n      {{ label }}\n      <ng-container *ngIf=\"!config.required\">\n        {{ 'dynamicforms.optional' | cxTranslate }}\n      </ng-container>\n    </label>\n    <div class=\"form-check\">\n      <div *ngFor=\"let option of config.options\">\n        <input\n          class=\"form-check-input\"\n          type=\"checkbox\"\n          [attr.name]=\"option.name\"\n          [attr.id]=\"config.name + option.name\"\n          value=\"{{ option.name }}\"\n          [formControlName]=\"config.name\"\n        />\n        <label class=\"pl-3 pt-1\" [attr.for]=\"config.name + option.name\"\n          ><ng-container *ngIf=\"activeLang$ | async as activeLang\">\n            {{ getLocalizedOption(option.label, activeLang) }}\n          </ng-container></label\n        >\n      </div>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
        }], null, null);
})();

class FormComponentService {
    constructor(launchDialogService) {
        this.launchDialogService = launchDialogService;
        this.isPopulatedFormInvalidSource = new BehaviorSubject(null);
        this.isPopulatedFormInvalid = this.isPopulatedFormInvalidSource.asObservable();
    }
    launchFormPopupError() {
        const dialog = this.launchDialogService.openDialog("FORM_POPUP_ERROR" /* LAUNCH_CALLER.FORM_POPUP_ERROR */);
        return dialog === null || dialog === void 0 ? void 0 : dialog.pipe(take(1)).subscribe();
    }
}
FormComponentService.ɵfac = function FormComponentService_Factory(t) { return new (t || FormComponentService)(i0.ɵɵinject(i1$1.LaunchDialogService)); };
FormComponentService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormComponentService, factory: FormComponentService.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormComponentService, [{
            type: Injectable
        }], function () { return [{ type: i1$1.LaunchDialogService }]; }, null);
})();

class FormPopupErrorComponent {
    constructor(launchDialogService, formComponentService, el) {
        this.launchDialogService = launchDialogService;
        this.formComponentService = formComponentService;
        this.el = el;
    }
    handleClick(event) {
        if (event.target.tagName === this.el.nativeElement.tagName) {
            this.dismissModal('Cross click');
        }
    }
    dismissModal(reason) {
        this.launchDialogService.closeDialog(reason);
        this.formComponentService.isPopulatedFormInvalidSource.next(false);
    }
}
FormPopupErrorComponent.ɵfac = function FormPopupErrorComponent_Factory(t) { return new (t || FormPopupErrorComponent)(i0.ɵɵdirectiveInject(i1$1.LaunchDialogService), i0.ɵɵdirectiveInject(FormComponentService), i0.ɵɵdirectiveInject(i0.ElementRef)); };
FormPopupErrorComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FormPopupErrorComponent, selectors: [["cx-form-popup-error"]], hostBindings: function FormPopupErrorComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵlistener("click", function FormPopupErrorComponent_click_HostBindingHandler($event) { return ctx.handleClick($event); });
        }
    }, decls: 10, vars: 6, consts: [[1, "popup-content-wrapper"], [1, "modal-header"], ["type", "button", "aria-label", "Close", 1, "close", 3, "click"], [1, "modal-body"]], template: function FormPopupErrorComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "h3");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "cxTranslate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "button", 2);
            i0.ɵɵlistener("click", function FormPopupErrorComponent_Template_button_click_5_listener() { return ctx.dismissModal("Cross click"); });
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(6, "div", 3)(7, "h6");
            i0.ɵɵtext(8);
            i0.ɵɵpipe(9, "cxTranslate");
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "dynamicforms.validationErrors"), " ");
            i0.ɵɵadvance(5);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 4, "dynamicforms.fillOutProperly"), " ");
        }
    }, dependencies: [i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormPopupErrorComponent, [{
            type: Component,
            args: [{ selector: 'cx-form-popup-error', template: "<div class=\"popup-content-wrapper\">\n  <div class=\"modal-header\">\n    <h3>\n      {{ 'dynamicforms.validationErrors' | cxTranslate }}\n    </h3>\n    <button\n      type=\"button\"\n      class=\"close\"\n      aria-label=\"Close\"\n      (click)=\"dismissModal('Cross click')\"\n    ></button>\n  </div>\n  <div class=\"modal-body\">\n    <h6>\n      {{ 'dynamicforms.fillOutProperly' | cxTranslate }}\n    </h6>\n  </div>\n</div>\n" }]
        }], function () { return [{ type: i1$1.LaunchDialogService }, { type: FormComponentService }, { type: i0.ElementRef }]; }, { handleClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] });
})();

class DataHolderComponent extends AbstractFormComponent {
}
DataHolderComponent.ɵfac = /*@__PURE__*/ function () { let ɵDataHolderComponent_BaseFactory; return function DataHolderComponent_Factory(t) { return (ɵDataHolderComponent_BaseFactory || (ɵDataHolderComponent_BaseFactory = i0.ɵɵgetInheritedFactory(DataHolderComponent)))(t || DataHolderComponent); }; }();
DataHolderComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataHolderComponent, selectors: [["ng-component"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 0, vars: 0, template: function DataHolderComponent_Template(rf, ctx) { }, encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataHolderComponent, [{
            type: Component,
            args: [{
                    template: '',
                }]
        }], null, null);
})();

const LOAD_FORM_DATA = '[Form Data] Load Form Data';
const LOAD_FORM_DATA_FAIL = '[Form Data] Load Form Data Fail';
const LOAD_FORM_DATA_SUCCESS = '[Form Data] Load Form Data Success';
const SAVE_FORM_DATA = '[Form Data] Save Form Data';
const SAVE_FORM_DATA_FAIL = '[Form Data] Save Form Data Fail';
const SAVE_FORM_DATA_SUCCESS = '[Form Data] Save Form Data Success';
class LoadFormData {
    constructor(payload) {
        this.payload = payload;
        this.type = LOAD_FORM_DATA;
    }
}
class LoadFormDataFail {
    constructor(payload) {
        this.payload = payload;
        this.type = LOAD_FORM_DATA_FAIL;
    }
}
class LoadFormDataSuccess {
    constructor(payload) {
        this.payload = payload;
        this.type = LOAD_FORM_DATA_SUCCESS;
    }
}
class SaveFormData {
    constructor(payload) {
        this.payload = payload;
        this.type = SAVE_FORM_DATA;
    }
}
class SaveFormDataSuccess {
    constructor(payload) {
        this.payload = payload;
        this.type = SAVE_FORM_DATA_SUCCESS;
    }
}
class SaveFormDataFail {
    constructor(payload) {
        this.payload = payload;
        this.type = SAVE_FORM_DATA_FAIL;
    }
}

const LOAD_FORM_DEFINITION = '[Form Definition] Load Form Definition';
const LOAD_FORM_DEFINITION_FAIL = '[Form Definition] Load Form Definition Fail';
const LOAD_FORM_DEFINITION_SUCCESS = '[Form Definition] Load Form Definition Success';
class LoadFormDefinition {
    constructor(payload) {
        this.payload = payload;
        this.type = LOAD_FORM_DEFINITION;
    }
}
class LoadFormDefinitionFail {
    constructor(payload) {
        this.payload = payload;
        this.type = LOAD_FORM_DEFINITION_FAIL;
    }
}
class LoadFormDefinitionSuccess {
    constructor(payload) {
        this.payload = payload;
        this.type = LOAD_FORM_DEFINITION_SUCCESS;
    }
}

const UPLOAD_FILE_SUCCESS = '[File] Upload file Success';
const RESET_FILE_SUCCESS = '[File] Reset file Success';
const REMOVE_FILE = '[File] Remove File';
const REMOVE_FILE_SUCCESS = '[File] Remove File Success';
const REMOVE_FILE_FAIL = '[File] Remove File Fail';
const SET_UPLOADED_FILES = '[File] Set Uploaded Files';
class UploadFileSuccess {
    constructor(payload) {
        this.payload = payload;
        this.type = UPLOAD_FILE_SUCCESS;
    }
}
class ResetFileSuccess {
    constructor(payload) {
        this.payload = payload;
        this.type = RESET_FILE_SUCCESS;
    }
}
class RemoveFile {
    constructor(payload) {
        this.payload = payload;
        this.type = REMOVE_FILE;
    }
}
class RemoveFileSuccess {
    constructor(payload) {
        this.payload = payload;
        this.type = REMOVE_FILE_SUCCESS;
    }
}
class RemoveFileFail {
    constructor(payload) {
        this.payload = payload;
        this.type = REMOVE_FILE_FAIL;
    }
}
class SetUploadedFiles {
    constructor(payload) {
        this.payload = payload;
        this.type = SET_UPLOADED_FILES;
    }
}

const FORM_FEATURE = 'form';
const FORM_DEFINITION_DATA = '[Form Definition] Form Definition Data';

const getFormState = createFeatureSelector(FORM_FEATURE);

const formDataContent = (state) => state.content;
const formDataLoaded = (state) => state.loaded;
const getFormDataState = createSelector(getFormState, (state) => state.formData);
const getFormData$1 = createSelector(getFormDataState, formDataContent);
const getFormDataLoaded = createSelector(getFormDataState, formDataLoaded);

const formDefinitionContent = (state) => state.content;
const formDefinitionLoaded = (state) => state.loaded;
const getFormDefinitionState = createSelector(getFormState, (state) => state.formDefinition);
const getFormDefinition$1 = createSelector(getFormDefinitionState, formDefinitionContent);
const getFormDefinitionLoaded = createSelector(getFormDefinitionState, formDefinitionLoaded);

const uploadContent = (state) => state.content;
const getUploadFilesState = createSelector(getFormState, (state) => state.uploadedFiles);
const getUploadFiles$1 = createSelector(getUploadFilesState, uploadContent);

class OboCustomerService {
    constructor(eventService, userIdService) {
        this.eventService = eventService;
        this.userIdService = userIdService;
        this.sessionStorageKey = 'selectedOboCustomerId';
        this.subscription = new Subscription();
        this.onLogout();
    }
    setSelectedCustomer(user) {
        sessionStorage.setItem(this.sessionStorageKey, user.uid);
    }
    getOboCustomerUserId() {
        return combineLatest([
            of(sessionStorage.getItem(this.sessionStorageKey)),
            this.userIdService.getUserId(),
        ]).pipe(map(([selectedCustomer, userOccId]) => selectedCustomer ? selectedCustomer : userOccId));
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    onLogout() {
        this.subscription.add(this.eventService
            .get(LogoutEvent)
            .pipe(tap(() => sessionStorage.removeItem(this.sessionStorageKey)))
            .subscribe());
    }
}
OboCustomerService.ɵfac = function OboCustomerService_Factory(t) { return new (t || OboCustomerService)(i0.ɵɵinject(i2.EventService), i0.ɵɵinject(i2.UserIdService)); };
OboCustomerService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: OboCustomerService, factory: OboCustomerService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OboCustomerService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i2.EventService }, { type: i2.UserIdService }]; }, null);
})();

class FormDataService {
    constructor(store, userIdService, oboCustomerService) {
        this.store = store;
        this.userIdService = userIdService;
        this.oboCustomerService = oboCustomerService;
        this.submittedForm = new BehaviorSubject(null);
        this.continueToNextStepSource = new BehaviorSubject(false);
        this.continueToNextStep$ = this.continueToNextStepSource.asObservable();
    }
    setContinueToNextStep(isContinueClicked) {
        this.continueToNextStepSource.next(isContinueClicked);
    }
    submit(form) {
        this.submittedForm.next(form);
    }
    getSubmittedForm() {
        return this.submittedForm.asObservable();
    }
    saveFormData(formData) {
        this.oboCustomerService
            .getOboCustomerUserId()
            .pipe(map(userId => {
            this.store.dispatch(new SaveFormData({ formData, userId }));
        }))
            .subscribe()
            .unsubscribe();
    }
    loadFormDefinition(applicationId, formDefinitionId) {
        this.store.dispatch(new LoadFormDefinition({
            applicationId: applicationId,
            formDefinitionId: formDefinitionId,
        }));
    }
    loadFormDefinitions(categoryCode, formDefinitionType) {
        this.store.dispatch(new LoadFormDefinition({
            categoryCode: categoryCode,
            formDefinitionType: formDefinitionType,
        }));
    }
    loadFormData(formDataId) {
        this.oboCustomerService
            .getOboCustomerUserId()
            .pipe(map(userId => {
            this.store.dispatch(new LoadFormData({ formDataId, userId }));
        }))
            .subscribe()
            .unsubscribe();
    }
    getFormData() {
        return this.store.select(getFormDataLoaded).pipe(filter(loaded => loaded), take(1), switchMap(_ => {
            return this.store.select(getFormData$1);
        }));
    }
    getFormDefinition() {
        return this.store.select(getFormDefinitionLoaded).pipe(filter(loaded => loaded), take(1), switchMap(_ => {
            return this.store.select(getFormDefinition$1);
        }));
    }
}
FormDataService.ɵfac = function FormDataService_Factory(t) { return new (t || FormDataService)(i0.ɵɵinject(i1$2.Store), i0.ɵɵinject(i2.UserIdService), i0.ɵɵinject(OboCustomerService)); };
FormDataService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormDataService, factory: FormDataService.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormDataService, [{
            type: Injectable
        }], function () { return [{ type: i1$2.Store }, { type: i2.UserIdService }, { type: OboCustomerService }]; }, null);
})();

class FileAdapter {
}

class FileConnector {
    constructor(uploadAdapter) {
        this.uploadAdapter = uploadAdapter;
    }
    getFile(userId, fileCode, fileType) {
        return this.uploadAdapter.getFileForCodeAndType(userId, fileCode, fileType);
    }
    getFiles(userId, fileCode) {
        return this.uploadAdapter.getFilesForUser(userId, fileCode);
    }
    uploadFile(userId, file) {
        return this.uploadAdapter.uploadFile(userId, file);
    }
    removeFile(userId, fileCode) {
        return this.uploadAdapter.removeFileForUserAndCode(userId, fileCode);
    }
}
FileConnector.ɵfac = function FileConnector_Factory(t) { return new (t || FileConnector)(i0.ɵɵinject(FileAdapter)); };
FileConnector.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FileConnector, factory: FileConnector.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FileConnector, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: FileAdapter }]; }, null);
})();

class FileService {
    constructor(userIdService, fileConnector, store, oboCustomerService) {
        this.userIdService = userIdService;
        this.fileConnector = fileConnector;
        this.store = store;
        this.oboCustomerService = oboCustomerService;
    }
    getFile(fileCode, fileType) {
        return this.userIdService.getUserId().pipe(take(1), switchMap(occUserId => {
            return this.fileConnector.getFile(occUserId, fileCode, fileType);
        }));
    }
    getFiles(fileCodes) {
        return this.userIdService.getUserId().pipe(take(1), switchMap(occUserId => {
            return this.fileConnector.getFiles(occUserId, fileCodes);
        }));
    }
    uploadFile(file) {
        return this.oboCustomerService
            .getOboCustomerUserId()
            .pipe(switchMap(userId => this.fileConnector.uploadFile(userId, file)));
    }
    resetFiles() {
        this.store.dispatch(new ResetFileSuccess({}));
    }
    setFileInStore(body) {
        this.store.dispatch(new UploadFileSuccess({
            body,
        }));
    }
    getUploadedDocuments() {
        return this.store.select(getUploadFiles$1);
    }
    removeFileForCode(userId, fileCode) {
        this.store.dispatch(new RemoveFile({
            user: userId,
            fileCode: fileCode,
        }));
    }
    removeAllFiles(userId, fileList) {
        if ((fileList === null || fileList === void 0 ? void 0 : fileList.length) > 0) {
            fileList.forEach(file => {
                const fileCode = file === null || file === void 0 ? void 0 : file.code;
                if (fileCode) {
                    this.removeFileForCode(userId, fileCode);
                }
            });
        }
    }
    getDocument(document) {
        return this.getFile(document.code, document.mime).pipe(map(downloadedFile => {
            saveAs(downloadedFile, document.altText);
        }));
    }
}
FileService.ɵfac = function FileService_Factory(t) { return new (t || FileService)(i0.ɵɵinject(i2.UserIdService), i0.ɵɵinject(FileConnector), i0.ɵɵinject(i1$2.Store), i0.ɵɵinject(OboCustomerService)); };
FileService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FileService, factory: FileService.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FileService, [{
            type: Injectable
        }], function () { return [{ type: i2.UserIdService }, { type: FileConnector }, { type: i1$2.Store }, { type: OboCustomerService }]; }, null);
})();

function UploadComponent_ng_container_0_ng_container_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
    }
}
function UploadComponent_ng_container_0_ng_container_17_li_2_span_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "span", 24);
        i0.ɵɵelement(1, "i", 25);
        i0.ɵɵelementEnd();
    }
}
function UploadComponent_ng_container_0_ng_container_17_li_2_span_11_Template(rf, ctx) {
    if (rf & 1) {
        const _r14 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "span", 26);
        i0.ɵɵlistener("click", function UploadComponent_ng_container_0_ng_container_17_li_2_span_11_Template_span_click_0_listener() { i0.ɵɵrestoreView(_r14); const file_r6 = i0.ɵɵnextContext().$implicit; const ctx_r12 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r12.downloadFile(file_r6)); });
        i0.ɵɵelement(1, "i", 27);
        i0.ɵɵelementEnd();
    }
}
function UploadComponent_ng_container_0_ng_container_17_li_2_span_12_Template(rf, ctx) {
    if (rf & 1) {
        const _r17 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "span", 28);
        i0.ɵɵlistener("click", function UploadComponent_ng_container_0_ng_container_17_li_2_span_12_Template_span_click_0_listener() { i0.ɵɵrestoreView(_r17); const i_r7 = i0.ɵɵnextContext().index; i0.ɵɵnextContext(2); const _r2 = i0.ɵɵreference(12); const ctx_r15 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r15.removeFile(i_r7, _r2)); });
        i0.ɵɵelement(1, "i", 29);
        i0.ɵɵelementEnd();
    }
}
function UploadComponent_ng_container_0_ng_container_17_li_2_div_15_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 30)(1, "div", 31);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const i_r7 = i0.ɵɵnextContext().index;
        const ctx_r11 = i0.ɵɵnextContext(3);
        i0.ɵɵadvance(1);
        i0.ɵɵstyleProp("width", ctx_r11.individualProgress[i_r7] + "%");
        i0.ɵɵattribute("aria-valuenow", ctx_r11.individualProgress[i_r7]);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r11.individualProgress[i_r7], " ");
    }
}
function UploadComponent_ng_container_0_ng_container_17_li_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "li", 13)(1, "div", 14)(2, "div", 15)(3, "div", 14);
        i0.ɵɵtemplate(4, UploadComponent_ng_container_0_ng_container_17_li_2_span_4_Template, 2, 0, "span", 16);
        i0.ɵɵelementStart(5, "span", 17);
        i0.ɵɵtext(6);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "span", 18);
        i0.ɵɵtext(8);
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(9, "div", 19)(10, "div", 14);
        i0.ɵɵtemplate(11, UploadComponent_ng_container_0_ng_container_17_li_2_span_11_Template, 2, 0, "span", 20);
        i0.ɵɵtemplate(12, UploadComponent_ng_container_0_ng_container_17_li_2_span_12_Template, 2, 0, "span", 21);
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(13, "div", 14)(14, "div", 22);
        i0.ɵɵtemplate(15, UploadComponent_ng_container_0_ng_container_17_li_2_div_15_Template, 3, 4, "div", 23);
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        const file_r6 = ctx.$implicit;
        const i_r7 = ctx.index;
        const ctx_r4 = i0.ɵɵnextContext(3);
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("ngIf", file_r6 == null ? null : file_r6.code);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(file_r6 == null ? null : file_r6.name);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", ctx_r4.convertFileSize(file_r6.size), "");
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", file_r6 == null ? null : file_r6.code);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r4.removeAllDisable);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", ctx_r4.individualProgress[i_r7] > 0 && ctx_r4.individualProgress[i_r7] !== 100);
    }
}
function UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_3_Template(rf, ctx) {
    if (rf & 1) {
        const _r22 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 37);
        i0.ɵɵlistener("click", function UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_3_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r22); i0.ɵɵnextContext(3); const _r2 = i0.ɵɵreference(12); const ctx_r21 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r21.removeAll(_r2)); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.removeAll"), " ");
    }
}
function UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_5_Template(rf, ctx) {
    if (rf & 1) {
        const _r24 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 38);
        i0.ɵɵlistener("click", function UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_5_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r24); const ctx_r23 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r23.uploadFiles(ctx_r23.fileList)); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.upload"), " ");
    }
}
function UploadComponent_ng_container_0_ng_container_17_ng_container_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 32)(2, "div", 33);
        i0.ɵɵtemplate(3, UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_3_Template, 3, 3, "button", 34);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "div", 35);
        i0.ɵɵtemplate(5, UploadComponent_ng_container_0_ng_container_17_ng_container_3_button_5_Template, 3, 3, "button", 36);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r5 = i0.ɵɵnextContext(3);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", ctx_r5.fileList.length > 1 && !ctx_r5.removeAllDisable);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", !ctx_r5.uploadDisable);
    }
}
function UploadComponent_ng_container_0_ng_container_17_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "ul", 11);
        i0.ɵɵtemplate(2, UploadComponent_ng_container_0_ng_container_17_li_2_Template, 16, 6, "li", 12);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(3, UploadComponent_ng_container_0_ng_container_17_ng_container_3_Template, 6, 2, "ng-container", 0);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", ctx_r3.fileList);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", (ctx_r3.fileList == null ? null : ctx_r3.fileList.length) > 0);
    }
}
function UploadComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
        i0.ɵɵtext(4);
        i0.ɵɵtemplate(5, UploadComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(6, "p");
        i0.ɵɵtext(7);
        i0.ɵɵpipe(8, "cxTranslate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(9, "div", 4)(10, "div", 5);
        i0.ɵɵelement(11, "input", 6, 7)(13, "input", 8);
        i0.ɵɵelementStart(14, "label", 9);
        i0.ɵɵtext(15);
        i0.ɵɵpipe(16, "cxTranslate");
        i0.ɵɵelementEnd()()();
        i0.ɵɵtemplate(17, UploadComponent_ng_container_0_ng_container_17_Template, 4, 2, "ng-container", 0);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(18, "cx-error-notice", 10);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate2(" ", i0.ɵɵpipeBind1(8, 17, "dynamicforms.maxFileSize"), " ", ctx_r0.convertFileSize(ctx_r0.config.maxFileSize), " ");
        i0.ɵɵadvance(4);
        i0.ɵɵattribute("aria-describedby", ctx_r0.config.name)("name", ctx_r0.config.name)("multiple", ctx_r0.config.multiple ? ctx_r0.config.multiple : null)("accept", ctx_r0.config.accept);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("formControlName", ctx_r0.config.name);
        i0.ɵɵattribute("name", ctx_r0.config.name + "_hidden");
        i0.ɵɵadvance(1);
        i0.ɵɵattribute("for", ctx_r0.config.name);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(16, 19, "dynamicforms.chooseFile"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r0.fileList.length > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
    }
}
class UploadComponent extends AbstractFormComponent {
    constructor(appConfig, languageService, injector, formService, formDataService, fileUploadService, cd, userIdService, globalMessageService) {
        super(appConfig, languageService, injector, formService);
        this.appConfig = appConfig;
        this.languageService = languageService;
        this.injector = injector;
        this.formService = formService;
        this.formDataService = formDataService;
        this.fileUploadService = fileUploadService;
        this.cd = cd;
        this.userIdService = userIdService;
        this.globalMessageService = globalMessageService;
        this.fileList = [];
        this.individualProgress = {};
        this.files = [];
        this.uploadDisable = false;
        this.removeAllDisable = false;
    }
    handleFiles(event) {
        // Reset when user is choosing files again
        this.resetFileList();
        this.individualProgress = {};
        this.uploadDisable = false;
        const filteredFiles = this.filterFiles(this.config, event.target.files);
        if (this.config.accept.toString() === event.target.accept &&
            this.config.multiple === event.target.multiple) {
            this.fileList = Array.from(filteredFiles);
            this.fileList.splice(this.config.maxUploads);
            if (this.fileList.length === 0) {
                this.setValueAndValidate(null);
            }
        }
        else {
            // triggering reset and validation if something was manipulated through DOM inspector
            // or files are violating config rules
            this.setValueAndValidate(null);
        }
    }
    ngOnInit() {
        super.ngOnInit();
        this.uploadControl = this.group.get(this.config.name);
        this.populateUploadedFiles();
    }
    populateUploadedFiles() {
        this.subscription.add(this.fileUploadService
            .getUploadedDocuments()
            .pipe(map(filesObj => {
            var _a, _b;
            if (Object.keys(filesObj === null || filesObj === void 0 ? void 0 : filesObj.files).length > 0) {
                this.fileList = Array.from(Object.values(filesObj === null || filesObj === void 0 ? void 0 : filesObj.files));
                this.fileList.forEach((file) => {
                    if (!this.files.includes(file.code)) {
                        this.files.push(file.code);
                    }
                });
                (_a = this.uploadControl) === null || _a === void 0 ? void 0 : _a.setValue(this.files);
                this.uploadDisable = true;
                this.cd.detectChanges();
            }
            else {
                (_b = this.uploadControl) === null || _b === void 0 ? void 0 : _b.setValue(null);
            }
        }))
            .subscribe());
    }
    filterFiles(config, files) {
        const filtedFiles = [];
        Array.from(files).forEach(file => {
            if (config.accept.includes(file.type) &&
                file.size <= this.config.maxFileSize) {
                filtedFiles.push(file);
            }
        });
        return filtedFiles;
    }
    convertFileSize(bytes) {
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Number(Math.floor(Math.log(bytes) / Math.log(1024)));
        if (i === 0) {
            return `${bytes} ${sizes[i]}`;
        }
        return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
    }
    uploadFiles(files) {
        this.uploadDisable = true;
        this.removeAllDisable = true;
        this.setValueAndValidate(this.fileList);
        files.forEach((file, index) => {
            this.subscription.add(this.fileUploadService.uploadFile(file).subscribe(event => {
                if ((event === null || event === void 0 ? void 0 : event.type) === HttpEventType.UploadProgress) {
                    this.individualProgress[index] = Math.round((100 * event.loaded) / event.total);
                    this.cd.detectChanges();
                }
                if (event instanceof HttpResponse) {
                    this.handleFileResponse(event);
                }
                // when all files are finished uploading show the remove all button
                this.removeAllDisable = !!this.overallProgressFinished(this.individualProgress);
            }, error => {
                this.globalMessageService.add({
                    key: 'dynamicforms.documentUploadError',
                }, GlobalMessageType.MSG_TYPE_ERROR);
            }));
        });
    }
    removeFile(index, uploadField) {
        this.removeFromStorage(index);
        this.fileList.splice(index, 1);
        if (this.files.length !== 0) {
            this.files.splice(index, 1);
            this.setValueAndValidate(this.files);
        }
        // reset DOM File element to sync it with reactive control
        if (this.fileList.length === 0) {
            uploadField.value = null;
        }
    }
    removeAll(uploadField) {
        this.removeFromStorage();
        this.fileList = [];
        uploadField.value = null;
        this.setValueAndValidate(this.fileList);
    }
    downloadFile(file) {
        this.subscription.add(this.fileUploadService
            .getFile(file.code, file.type ? file.type : file.mime)
            .pipe(map(downloadedFile => {
            saveAs(downloadedFile, file.name);
        }))
            .subscribe());
    }
    removeFromStorage(index) {
        // Execute Http.Delete request to backend
        this.subscription.add(this.userIdService
            .getUserId()
            .pipe(take(1), map(occUserId => {
            var _a;
            const fileCode = (_a = this.fileList[index]) === null || _a === void 0 ? void 0 : _a.code;
            if (fileCode) {
                this.fileUploadService.removeFileForCode(occUserId, fileCode);
                this.setValueAndValidate(null);
            }
            else {
                this.fileUploadService.removeAllFiles(occUserId, this.fileList);
                this.fileUploadService.resetFiles();
            }
        }))
            .subscribe());
    }
    overallProgressFinished(progress) {
        return (Object.keys(progress).filter((_k, i) => progress[i] !== 100).length !== 0);
    }
    setValueAndValidate(value) {
        this.uploadControl.setValue(value);
        this.uploadControl.markAsTouched({ onlySelf: true });
    }
    handleFileResponse(event) {
        this.fileUploadService.setFileInStore(event.body);
        const fileCode = event.body.code;
        if (!this.files.includes(fileCode)) {
            this.files.push(fileCode);
        }
        this.uploadControl.setValue(this.files);
    }
    resetFileList() {
        this.fileList = [];
        this.files = [];
        this.fileUploadService.resetFiles();
    }
    setFileCode(file, event) {
        var _a, _b;
        if ((_a = event.body) === null || _a === void 0 ? void 0 : _a.code) {
            file.code = (_b = event.body) === null || _b === void 0 ? void 0 : _b.code;
        }
        this.cd.detectChanges();
    }
}
UploadComponent.ɵfac = function UploadComponent_Factory(t) { return new (t || UploadComponent)(i0.ɵɵdirectiveInject(DynamicFormsConfig), i0.ɵɵdirectiveInject(i2.LanguageService), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(FormService), i0.ɵɵdirectiveInject(FormDataService), i0.ɵɵdirectiveInject(FileService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i2.UserIdService), i0.ɵɵdirectiveInject(i2.GlobalMessageService)); };
UploadComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: UploadComponent, selectors: [["cx-upload"]], hostBindings: function UploadComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵlistener("change", function UploadComponent_change_HostBindingHandler($event) { return ctx.handleFiles($event); });
        }
    }, features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], [1, "input-group"], [1, "custom-file"], ["type", "file", 1, "custom-file-input"], ["uploadField", ""], ["type", "hidden", 3, "formControlName"], [1, "custom-file-label"], [3, "warn", "parentConfig"], [1, "mb-4"], ["class", "pt-4", 4, "ngFor", "ngForOf"], [1, "pt-4"], [1, "row", "no-gutters"], [1, "col-10"], ["class", "col-1", 4, "ngIf"], [1, "col-8", "text-break"], [1, "col-3"], [1, "col-2"], ["class", "col-6 text-right", "role", "button", 3, "click", 4, "ngIf"], ["class", "col-6 text-right ml-auto", "role", "button", 3, "click", 4, "ngIf"], [1, "col-12"], ["class", "progress", 4, "ngIf"], [1, "col-1"], [1, "fas", "fa-check"], ["role", "button", 1, "col-6", "text-right", 3, "click"], [1, "fas", "fa-download"], ["role", "button", 1, "col-6", "text-right", "ml-auto", 3, "click"], [1, "fas", "fa-trash"], [1, "progress"], ["role", "progressbar", "aria-valuemin", "0", "aria-valuemax", "100", 1, "progress-bar"], [1, "row", "justify-content-between"], [1, "col-md-3", "col-sm-3", "col-12", "mb-3", "mb-sm-0"], ["class", "action-button btn-block", 3, "click", 4, "ngIf"], [1, "col-md-3", "col-sm-3", "col-12"], ["class", "btn-primary btn-block", 3, "click", 4, "ngIf"], [1, "action-button", "btn-block", 3, "click"], [1, "btn-primary", "btn-block", 3, "click"]], template: function UploadComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, UploadComponent_ng_container_0_Template, 19, 21, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgForOf, i1.NgIf, i2$1.DefaultValueAccessor, i2$1.NgControlStatus, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, i2$1.FormControlName, ErrorNoticeComponent, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UploadComponent, [{
            type: Component,
            args: [{ selector: 'cx-upload', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <p>\n        {{ 'dynamicforms.maxFileSize' | cxTranslate }}\n        {{ convertFileSize(config.maxFileSize) }}\n      </p>\n      <div class=\"input-group\">\n        <div class=\"custom-file\">\n          <input\n            #uploadField\n            type=\"file\"\n            class=\"custom-file-input\"\n            [attr.aria-describedby]=\"config.name\"\n            [attr.name]=\"config.name\"\n            [attr.multiple]=\"config.multiple ? config.multiple : null\"\n            [attr.accept]=\"config.accept\"\n          />\n          <input\n            type=\"hidden\"\n            [attr.name]=\"config.name + '_hidden'\"\n            [formControlName]=\"config.name\"\n          />\n          <label class=\"custom-file-label\" [attr.for]=\"config.name\">{{\n            'dynamicforms.chooseFile' | cxTranslate\n          }}</label>\n        </div>\n      </div>\n\n      <ng-container *ngIf=\"fileList.length > 0\">\n        <ul class=\"mb-4\">\n          <li class=\"pt-4\" *ngFor=\"let file of fileList; let i = index\">\n            <div class=\"row no-gutters\">\n              <div class=\"col-10\">\n                <div class=\"row no-gutters\">\n                  <span class=\"col-1\" *ngIf=\"file?.code\"\n                    ><i class=\"fas fa-check\"></i\n                  ></span>\n                  <span class=\"col-8 text-break\">{{ file?.name }}</span>\n                  <span class=\"col-3\"> {{ convertFileSize(file.size) }}</span>\n                </div>\n              </div>\n              <div class=\"col-2\">\n                <div class=\"row no-gutters\">\n                  <span\n                    class=\"col-6 text-right\"\n                    *ngIf=\"file?.code\"\n                    role=\"button\"\n                    (click)=\"downloadFile(file)\"\n                    ><i class=\"fas fa-download\"></i\n                  ></span>\n                  <span\n                    *ngIf=\"!removeAllDisable\"\n                    class=\"col-6 text-right ml-auto\"\n                    role=\"button\"\n                    (click)=\"removeFile(i, uploadField)\"\n                    ><i class=\"fas fa-trash\"></i\n                  ></span>\n                </div>\n              </div>\n            </div>\n            <div class=\"row no-gutters\">\n              <div class=\"col-12\">\n                <div\n                  class=\"progress\"\n                  *ngIf=\"\n                    individualProgress[i] > 0 && individualProgress[i] !== 100\n                  \"\n                >\n                  <div\n                    class=\"progress-bar\"\n                    [style.width]=\"individualProgress[i] + '%'\"\n                    role=\"progressbar\"\n                    [attr.aria-valuenow]=\"individualProgress[i]\"\n                    aria-valuemin=\"0\"\n                    aria-valuemax=\"100\"\n                  >\n                    {{ individualProgress[i] }}\n                  </div>\n                </div>\n              </div>\n            </div>\n          </li>\n        </ul>\n        <ng-container *ngIf=\"fileList?.length > 0\">\n          <div class=\"row justify-content-between\">\n            <div class=\"col-md-3 col-sm-3 col-12 mb-3 mb-sm-0\">\n              <button\n                *ngIf=\"fileList.length > 1 && !removeAllDisable\"\n                class=\"action-button btn-block\"\n                (click)=\"removeAll(uploadField)\"\n              >\n                {{ 'dynamicforms.removeAll' | cxTranslate }}\n              </button>\n            </div>\n            <div class=\"col-md-3 col-sm-3 col-12\">\n              <button\n                *ngIf=\"!uploadDisable\"\n                class=\"btn-primary btn-block\"\n                (click)=\"uploadFiles(fileList)\"\n              >\n                {{ 'dynamicforms.upload' | cxTranslate }}\n              </button>\n            </div>\n          </div>\n        </ng-container>\n      </ng-container>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
        }], function () { return [{ type: DynamicFormsConfig }, { type: i2.LanguageService }, { type: i0.Injector }, { type: FormService }, { type: FormDataService }, { type: FileService }, { type: i0.ChangeDetectorRef }, { type: i2.UserIdService }, { type: i2.GlobalMessageService }]; }, { handleFiles: [{
                type: HostListener,
                args: ['change', ['$event']]
            }] });
})();

function CurrencyComponent_ng_container_0_ng_container_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "cxTranslate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "dynamicforms.optional"), " ");
    }
}
function CurrencyComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "label", 3);
        i0.ɵɵtext(4);
        i0.ɵɵtemplate(5, CurrencyComponent_ng_container_0_ng_container_5_Template, 3, 3, "ng-container", 0);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(6, "div", 4)(7, "div", 5)(8, "span", 6);
        i0.ɵɵtext(9);
        i0.ɵɵpipe(10, "async");
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(11, "input", 7);
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(12, "cx-error-notice", 8);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.group)("hidden", ctx_r0.config.hidden);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.label, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r0.config.required);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 11, ctx_r0.currentCurrency$));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("formControlName", ctx_r0.config.name);
        i0.ɵɵattribute("placeholder", ctx_r0.placeHolder)("name", ctx_r0.config.name)("readonly", ctx_r0.config.readonly ? ctx_r0.config.readonly : null);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("warn", ctx_r0.group.controls[ctx_r0.config.name])("parentConfig", ctx_r0.config);
    }
}
class CurrencyComponent extends AbstractFormComponent {
    constructor(appConfig, languageService, injector, formService, currencyService) {
        super(appConfig, languageService, injector, formService);
        this.appConfig = appConfig;
        this.languageService = languageService;
        this.injector = injector;
        this.formService = formService;
        this.currencyService = currencyService;
        this.currentCurrency$ = this.currencyService.getActive();
    }
}
CurrencyComponent.ɵfac = function CurrencyComponent_Factory(t) { return new (t || CurrencyComponent)(i0.ɵɵdirectiveInject(DynamicFormsConfig), i0.ɵɵdirectiveInject(i2.LanguageService), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(FormService), i0.ɵɵdirectiveInject(i2.CurrencyService)); };
CurrencyComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CurrencyComponent, selectors: [["cx-currency"]], features: [i0.ɵɵInheritDefinitionFeature], decls: 1, vars: 1, consts: [[4, "ngIf"], [1, "dynamic-field", 3, "formGroup", "hidden"], [1, "form-group"], [1, "col-form-label"], [1, "input-group", "mb-3"], [1, "input-group-prepend"], [1, "input-group-text"], ["type", "text", 1, "form-control", 3, "formControlName"], [3, "warn", "parentConfig"]], template: function CurrencyComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, CurrencyComponent_ng_container_0_Template, 13, 13, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.group);
        }
    }, dependencies: [i1.NgIf, i2$1.DefaultValueAccessor, i2$1.NgControlStatus, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, i2$1.FormControlName, ErrorNoticeComponent, i1.AsyncPipe, i2.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CurrencyComponent, [{
            type: Component,
            args: [{ selector: 'cx-currency', template: "<ng-container *ngIf=\"group\">\n  <div class=\"dynamic-field\" [formGroup]=\"group\" [hidden]=\"config.hidden\">\n    <div class=\"form-group\">\n      <label class=\"col-form-label\">\n        {{ label }}\n        <ng-container *ngIf=\"!config.required\">\n          {{ 'dynamicforms.optional' | cxTranslate }}\n        </ng-container>\n      </label>\n      <div class=\"input-group mb-3\">\n        <div class=\"input-group-prepend\">\n          <span class=\"input-group-text\">{{ currentCurrency$ | async }}</span>\n        </div>\n        <input\n          type=\"text\"\n          class=\"form-control\"\n          [attr.placeholder]=\"placeHolder\"\n          [formControlName]=\"config.name\"\n          [attr.name]=\"config.name\"\n          [attr.readonly]=\"config.readonly ? config.readonly : null\"\n        />\n      </div>\n    </div>\n    <cx-error-notice\n      [warn]=\"group.controls[config.name]\"\n      [parentConfig]=\"config\"\n    ></cx-error-notice>\n  </div>\n</ng-container>\n" }]
        }], function () { return [{ type: DynamicFormsConfig }, { type: i2.LanguageService }, { type: i0.Injector }, { type: FormService }, { type: i2.CurrencyService }]; }, null);
})();

const defaultFormPopupErrorDialogLayoutConfig = {
    launch: {
        FORM_POPUP_ERROR: {
            inlineRoot: true,
            component: FormPopupErrorComponent,
            dialogType: DIALOG_TYPE.POPOVER_CENTER_BACKDROP,
        },
    },
};

class ComponentsModule {
}
ComponentsModule.ɵfac = function ComponentsModule_Factory(t) { return new (t || ComponentsModule)(); };
ComponentsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ComponentsModule });
ComponentsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        FormComponentService,
        provideDefaultConfig(defaultFormPopupErrorDialogLayoutConfig),
    ], imports: [CommonModule, ReactiveFormsModule, I18nModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ComponentsModule, [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ReactiveFormsModule, I18nModule],
                    declarations: [
                        FormComponentDirective,
                        AbstractFormComponent,
                        AbstractOptionsComponent,
                        ButtonComponent,
                        DatePickerComponent,
                        ErrorNoticeComponent,
                        DataHolderComponent,
                        InputComponent,
                        RadioComponent,
                        SelectComponent,
                        TextAreaComponent,
                        TimeComponent,
                        TitleComponent,
                        SeparatorComponent,
                        CheckboxComponent,
                        FormPopupErrorComponent,
                        UploadComponent,
                        CurrencyComponent,
                    ],
                    exports: [
                        FormComponentDirective,
                        AbstractFormComponent,
                        AbstractOptionsComponent,
                        ButtonComponent,
                        DatePickerComponent,
                        ErrorNoticeComponent,
                        DataHolderComponent,
                        InputComponent,
                        RadioComponent,
                        SelectComponent,
                        TextAreaComponent,
                        TimeComponent,
                        TitleComponent,
                        SeparatorComponent,
                        CheckboxComponent,
                        FormPopupErrorComponent,
                        UploadComponent,
                        CurrencyComponent,
                    ],
                    providers: [
                        FormComponentService,
                        provideDefaultConfig(defaultFormPopupErrorDialogLayoutConfig),
                    ],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ComponentsModule, { declarations: [FormComponentDirective,
            AbstractFormComponent,
            AbstractOptionsComponent,
            ButtonComponent,
            DatePickerComponent,
            ErrorNoticeComponent,
            DataHolderComponent,
            InputComponent,
            RadioComponent,
            SelectComponent,
            TextAreaComponent,
            TimeComponent,
            TitleComponent,
            SeparatorComponent,
            CheckboxComponent,
            FormPopupErrorComponent,
            UploadComponent,
            CurrencyComponent], imports: [CommonModule, ReactiveFormsModule, I18nModule], exports: [FormComponentDirective,
            AbstractFormComponent,
            AbstractOptionsComponent,
            ButtonComponent,
            DatePickerComponent,
            ErrorNoticeComponent,
            DataHolderComponent,
            InputComponent,
            RadioComponent,
            SelectComponent,
            TextAreaComponent,
            TimeComponent,
            TitleComponent,
            SeparatorComponent,
            CheckboxComponent,
            FormPopupErrorComponent,
            UploadComponent,
            CurrencyComponent] });
})();

// @dynamic
class DefaultFormValidators extends Validators {
    static checkEmptyValue(control) {
        var _a;
        const valid = !!((_a = control.value) === null || _a === void 0 ? void 0 : _a.trim());
        return valid ? null : { required: true };
    }
    static valueComparison(baseValue, comparisonValue, operator) {
        if (baseValue && comparisonValue) {
            switch (operator) {
                case 'shouldBeGreater':
                    return baseValue > comparisonValue
                        ? null
                        : { valueShouldBeGreater: true };
                case 'shouldBeLess':
                    return baseValue < comparisonValue
                        ? null
                        : { valueShouldBeLess: true };
            }
        }
    }
    static getFormControlForCode(formControlCode, formGroup) {
        let abstractFormControl;
        for (const key of Object.keys(formGroup.controls)) {
            const nestedFormGroup = formGroup.get(key);
            if (key === formControlCode) {
                abstractFormControl = formGroup.get(key);
                break;
            }
            else if (nestedFormGroup instanceof UntypedFormGroup) {
                abstractFormControl = this.getFormControlForCode(formControlCode, nestedFormGroup);
                if (abstractFormControl !== undefined) {
                    break;
                }
            }
        }
        return abstractFormControl;
    }
    static regexValidator(regex) {
        return (control) => {
            const field = control.value;
            if (field) {
                if (regex === this.phoneNumberRegex) {
                    return field.match(regex) ? null : { cxInvalidPhoneRegex: true };
                }
                return field.match(regex) ? null : { invalidFormat: true };
            }
            return null;
        };
    }
    static matchFields(controlName, controlName2) {
        return (control) => {
            if (control.get(controlName).value !== control.get(controlName2).value) {
                return { notEqual: true };
            }
        };
    }
    static dateOfBirthValidator(minAge) {
        return (control) => {
            const userAge = new Date(control.value);
            const today = new Date();
            const age = new Date(today.getFullYear() - minAge, today.getMonth(), today.getDate());
            return userAge < age ? null : { invalidAge: true };
        };
    }
    static compareDOBtoAge(comparisonField, operator) {
        return (control) => {
            const userAge = new Date(control.value);
            const today = new Date();
            if (control.parent) {
                const compareToField = DefaultFormValidators.getFormControlForCode(comparisonField, control.root);
                const targetAge = compareToField.value;
                const age = new Date(today.getFullYear() - targetAge, today.getMonth(), today.getDate());
                return DefaultFormValidators.valueComparison(userAge, age, operator);
            }
        };
    }
    static compareAgeToDOB(comparisonField, operator) {
        return (control) => {
            if (control.parent) {
                const compareToField = DefaultFormValidators.getFormControlForCode(comparisonField, control.root);
                const compareToFieldParsed = compareToField.value;
                const DOBtoYear = Number(new Date(compareToFieldParsed).getFullYear());
                const currentYear = Number(new Date().getFullYear());
                const currentAge = Number(control.value);
                const calculatedAge = currentYear - DOBtoYear;
                return DefaultFormValidators.valueComparison(calculatedAge, currentAge, operator);
            }
        };
    }
    static compareNumbers(comparisonField, operator) {
        return (control) => {
            if (control.parent) {
                const currentField = Number(control.value);
                const compareToField = DefaultFormValidators.getFormControlForCode(comparisonField, control.root);
                const compareToFieldParsed = Number(compareToField.value);
                return DefaultFormValidators.valueComparison(currentField, compareToFieldParsed, operator);
            }
        };
    }
    static compareDates(comparisonField, operator) {
        return (control) => {
            if (control.parent) {
                const currentField = Date.parse(control.value);
                const compareToField = DefaultFormValidators.getFormControlForCode(comparisonField, control.root);
                const compareToFieldParsed = Date.parse(compareToField.value);
                return DefaultFormValidators.valueComparison(compareToFieldParsed, currentField, operator);
            }
        };
    }
    static compareToCurrentDate(operator) {
        return (control) => {
            const inputVal = new Date(control.value);
            inputVal.setHours(0, 0, 0, 0);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            switch (operator) {
                case 'shouldBeEqual':
                    return inputVal.getTime() === today.getTime()
                        ? null
                        : { dateShouldBeEqual: true };
                case 'shouldBeGreater':
                    return inputVal.getTime() > today.getTime()
                        ? null
                        : { dateShouldBeGreater: true };
                case 'shouldBeLess':
                    return inputVal.getTime() < today.getTime()
                        ? null
                        : { dateShouldBeLess: true };
                case 'shouldBeGreaterOrEqual':
                    return inputVal.getTime() >= today.getTime()
                        ? null
                        : { dateShouldBeGreaterOrEqual: true };
                case 'shouldBeLessOrEqual':
                    return inputVal.getTime() <= today.getTime()
                        ? null
                        : { dateShouldBeLessOrEqual: true };
            }
        };
    }
    static number(control) {
        const field = control.value;
        const numberRegex = /^[0-9]*$/;
        if (field) {
            const valid = numberRegex.test(field);
            return valid
                ? null
                : {
                    pattern: {
                        requiredPattern: numberRegex,
                        actualValue: control.value,
                    },
                };
        }
        return null;
    }
    static alphanumeric(control) {
        const field = control.value;
        const postalCodeRegex = /^(?=.*[0-9])[A-Za-z0-9\s]+$/;
        if (field) {
            const valid = postalCodeRegex.test(field);
            return valid
                ? null
                : {
                    pattern: {
                        requiredPattern: postalCodeRegex,
                        actualValue: control.value,
                    },
                };
        }
        return null;
    }
    static checkValue(allowedValues) {
        return (control) => {
            const valid = allowedValues.indexOf(control.value) !== -1;
            return valid ? null : { valueConflict: true };
        };
    }
    static shouldContainValue(value) {
        return (control) => {
            const valid = control.value.indexOf(value) !== -1;
            return valid ? null : { noValue: true };
        };
    }
}
DefaultFormValidators.passwordRegex = /^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[!@#$%^*()_\-+{};:.,]).{6,}$/;
DefaultFormValidators.phoneNumberRegex = /^(?:\d{6,20})?$/;

class FormsUtils {
    static convertIfDate(value) {
        const dateRegex = /^\d{1,2}\-\d{1,2}\-\d{4}$/;
        if (dateRegex.test(value)) {
            value = value.split('-').reverse().join('-');
        }
        return value;
    }
    static getValueByPath(fieldPath, object) {
        let currentValue = object;
        const attributes = fieldPath.split('.');
        for (const attribute of attributes) {
            currentValue = this.getValueForAttribute(attribute, currentValue);
            if (!currentValue) {
                break;
            }
        }
        return currentValue;
    }
    static getValueForAttribute(attribute, objectValue) {
        if (attribute.indexOf('[') !== -1) {
            const attributeName = attribute.split('[')[0];
            const arrayPosition = attribute.split('[')[1].slice(0, 1);
            if (objectValue[attributeName]) {
                return objectValue[attributeName][arrayPosition];
            }
        }
        return objectValue[attribute];
    }
}
FormsUtils.ɵfac = function FormsUtils_Factory(t) { return new (t || FormsUtils)(); };
FormsUtils.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormsUtils, factory: FormsUtils.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormsUtils, [{
            type: Injectable
        }], null, null);
})();

class UserPrefillResolver {
    constructor(userAccountFacade) {
        this.userAccountFacade = userAccountFacade;
    }
    getPrefillValue(fieldPath) {
        let currentValue;
        return this.userAccountFacade.get().pipe(map(user => {
            currentValue = FormsUtils.getValueByPath(fieldPath, user);
            return currentValue;
        }));
    }
}
UserPrefillResolver.ɵfac = function UserPrefillResolver_Factory(t) { return new (t || UserPrefillResolver)(i0.ɵɵinject(i1$3.UserAccountFacade)); };
UserPrefillResolver.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: UserPrefillResolver, factory: UserPrefillResolver.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UserPrefillResolver, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: i1$3.UserAccountFacade }]; }, null);
})();

class CurrentDatePrefillResolver {
    constructor(datePipe) {
        this.datePipe = datePipe;
    }
    getPrefillValue() {
        return of(this.datePipe.transform(Date.now(), 'yyyy-MM-dd'));
    }
}
CurrentDatePrefillResolver.ɵfac = function CurrentDatePrefillResolver_Factory(t) { return new (t || CurrentDatePrefillResolver)(i0.ɵɵinject(i1.DatePipe)); };
CurrentDatePrefillResolver.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: CurrentDatePrefillResolver, factory: CurrentDatePrefillResolver.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CurrentDatePrefillResolver, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: i1.DatePipe }]; }, null);
})();

class UserAddressPrefillResolver {
    constructor(userAddressService) {
        this.userAddressService = userAddressService;
    }
    getPrefillValue(fieldPath) {
        const attributes = fieldPath.split('.');
        let currentValue;
        return this.userAddressService.getAddresses().pipe(map(address => {
            currentValue = address[0];
            if (!currentValue) {
                return ' ';
            }
            attributes.forEach(attribute => {
                currentValue = currentValue[attribute];
            });
            return currentValue;
        }));
    }
}
UserAddressPrefillResolver.ɵfac = function UserAddressPrefillResolver_Factory(t) { return new (t || UserAddressPrefillResolver)(i0.ɵɵinject(i2.UserAddressService)); };
UserAddressPrefillResolver.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: UserAddressPrefillResolver, factory: UserAddressPrefillResolver.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UserAddressPrefillResolver, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: i2.UserAddressService }]; }, null);
})();

const defaultFormConfig = {
    dynamicForms: {
        components: {
            button: {
                component: ButtonComponent,
            },
            input: {
                component: InputComponent,
            },
            select: {
                component: SelectComponent,
            },
            title: {
                component: TitleComponent,
            },
            datepicker: {
                component: DatePickerComponent,
            },
            radio: {
                component: RadioComponent,
            },
            textarea: {
                component: TextAreaComponent,
            },
            time: {
                component: TimeComponent,
            },
            checkbox: {
                component: CheckboxComponent,
            },
            separator: {
                component: SeparatorComponent,
            },
            dataHolder: {
                component: DataHolderComponent,
            },
            upload: {
                component: UploadComponent,
            },
            currency: {
                component: CurrencyComponent,
            },
        },
        validators: {
            compareToCurrentDate: {
                validator: DefaultFormValidators.compareToCurrentDate,
            },
            dateOfBirth: {
                validator: DefaultFormValidators.dateOfBirthValidator,
            },
            compareDOBtoAge: {
                validator: DefaultFormValidators.compareDOBtoAge,
            },
            compareAgeToDOB: {
                validator: DefaultFormValidators.compareAgeToDOB,
            },
            maxValue: {
                validator: DefaultFormValidators.max,
            },
            minValue: {
                validator: DefaultFormValidators.min,
            },
            maxLength: {
                validator: DefaultFormValidators.maxLength,
            },
            minLength: {
                validator: DefaultFormValidators.minLength,
            },
            number: {
                validator: DefaultFormValidators.number,
            },
            compareDates: {
                validator: DefaultFormValidators.compareDates,
            },
            checkValue: {
                validator: DefaultFormValidators.checkValue,
            },
            checkEmptyValue: {
                validator: DefaultFormValidators.checkEmptyValue,
            },
            containsValue: {
                validator: DefaultFormValidators.shouldContainValue,
            },
            compareNumbers: {
                validator: DefaultFormValidators.compareNumbers,
            },
            email: {
                validator: DefaultFormValidators.email,
            },
            alphanumeric: {
                validator: DefaultFormValidators.alphanumeric,
            },
        },
        prefill: {
            address: {
                prefillResolver: UserAddressPrefillResolver,
            },
            user: {
                prefillResolver: UserPrefillResolver,
            },
            currentDate: {
                prefillResolver: CurrentDatePrefillResolver,
            },
        },
    },
};

class FormAdapter {
}

class FormConnector {
    constructor(formAdapter) {
        this.formAdapter = formAdapter;
    }
    getFormDefinition(applicationId, formDefinitionId) {
        return this.formAdapter.getFormDefinition(applicationId, formDefinitionId);
    }
    getFormDefinitions(categoryCode, formDefinitionType) {
        return this.formAdapter.getFormDefinitions(categoryCode, formDefinitionType);
    }
    getFormData(formDataId, userId) {
        return this.formAdapter.getFormData(formDataId, userId);
    }
    saveFormData(formData, userId) {
        return this.formAdapter.saveFormData(formData, userId);
    }
}
FormConnector.ɵfac = function FormConnector_Factory(t) { return new (t || FormConnector)(i0.ɵɵinject(FormAdapter)); };
FormConnector.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormConnector, factory: FormConnector.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormConnector, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: FormAdapter }]; }, null);
})();

class FormValidationService {
    constructor(formConfig) {
        this.formConfig = formConfig;
        this.configValidators = this.formConfig.dynamicForms.validators;
    }
    getValidatorsForField(fieldConfig) {
        const validators = [];
        if (fieldConfig) {
            if (fieldConfig.validations) {
                fieldConfig.validations.forEach(fieldValidation => {
                    const validatorFn = this.getValidatorForFunction(fieldValidation);
                    if (validatorFn) {
                        validators.push(validatorFn);
                    }
                });
            }
            if (fieldConfig.required) {
                validators.push(Validators.required);
            }
        }
        return validators;
    }
    getValidatorForFunction(validatorFunction) {
        const validatorMapping = this.configValidators[validatorFunction.name];
        if (validatorMapping && validatorMapping.validator) {
            if (validatorFunction.arguments) {
                return validatorMapping.validator.apply(this, validatorFunction.arguments.map(arg => arg.value));
            }
            else {
                return validatorMapping.validator;
            }
        }
    }
}
FormValidationService.ɵfac = function FormValidationService_Factory(t) { return new (t || FormValidationService)(i0.ɵɵinject(DynamicFormsConfig)); };
FormValidationService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormValidationService, factory: FormValidationService.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormValidationService, [{
            type: Injectable
        }], function () { return [{ type: DynamicFormsConfig }]; }, null);
})();

class FieldDependencyResolverService {
    constructor(formValidationService, formService, fb) {
        this.formValidationService = formValidationService;
        this.formService = formService;
        this.fb = fb;
    }
    /**
     * Method used to enable/disable dependent control based on conditions defined at main control
     *
     * @param controlConfig The dependent field config for which dependencies are resolved
     * @param dependentControl The dependent field control for which dependencies are resolved
     * @param formGroup The form group which tracks value and validity of main form controls
     */
    resolveFormControlDependencies(controlConfig, dependentControl, formGroup) {
        controlConfig.dependsOn.controls.forEach(condition => {
            const mainFormControl = this.formService.getFormControlForCode(condition.controlName, formGroup);
            if (mainFormControl) {
                if (!mainFormControl.value) {
                    if (controlConfig.dependsOn.hide === true) {
                        controlConfig.hidden = true;
                    }
                    this.changeControlEnabled(dependentControl, controlConfig, false);
                }
                mainFormControl.valueChanges.subscribe(fieldValue => {
                    const dependencyValidations = this.geValidationsForCondition(condition);
                    const dependancyControl = this.fb.control({ disabled: false, value: fieldValue }, dependencyValidations);
                    if (dependancyControl.valid) {
                        if (controlConfig.dependsOn.hide === true) {
                            controlConfig.hidden = false;
                        }
                        this.changeControlEnabled(dependentControl, controlConfig, true);
                    }
                    else {
                        if (controlConfig.dependsOn.hide === true) {
                            controlConfig.hidden = true;
                        }
                        this.changeControlEnabled(dependentControl, controlConfig, false);
                    }
                });
            }
        });
    }
    /**
     * Method used to enable/disable control based on input parameter and form configuration value.
     * In case control is from group, check is done for nested controls to see if any of them has configuration set to disabled.
     * If any field config has disabled property set to true, dynamic condition cannot change that.
     *
     * @param dependentControl The dependent field control for which dependencies are resolved
     * @param controlConfig The dependent field config for which dependencies are resolved (control or group)
     * @param enabled The enabled flag which indicates if parent control conditions are met.
     */
    changeControlEnabled(dependentControl, controlConfig, enabled) {
        if (enabled) {
            if (dependentControl.controls && controlConfig.fieldConfigs) {
                controlConfig.fieldConfigs.forEach(childConfig => {
                    childConfig.disabled
                        ? dependentControl.controls[childConfig.name].disable()
                        : dependentControl.controls[childConfig.name].enable();
                });
            }
            else {
                dependentControl.enable();
            }
        }
        else {
            dependentControl.disable();
        }
        dependentControl.updateValueAndValidity({ emitEvent: false });
    }
    geValidationsForCondition(dependencyFn) {
        const dependencyFunctions = [];
        if (dependencyFn && dependencyFn.conditions) {
            dependencyFn.conditions.forEach(conditionFunction => {
                dependencyFunctions.push(this.formValidationService.getValidatorForFunction(conditionFunction));
            });
        }
        return dependencyFunctions;
    }
}
FieldDependencyResolverService.ɵfac = function FieldDependencyResolverService_Factory(t) { return new (t || FieldDependencyResolverService)(i0.ɵɵinject(FormValidationService), i0.ɵɵinject(FormService), i0.ɵɵinject(i2$1.UntypedFormBuilder)); };
FieldDependencyResolverService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FieldDependencyResolverService, factory: FieldDependencyResolverService.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FieldDependencyResolverService, [{
            type: Injectable
        }], function () { return [{ type: FormValidationService }, { type: FormService }, { type: i2$1.UntypedFormBuilder }]; }, null);
})();

class FormBuilderService {
    constructor(fb, formValidationService, fieldDependencyResolverService, userAccountFacade) {
        this.fb = fb;
        this.formValidationService = formValidationService;
        this.fieldDependencyResolverService = fieldDependencyResolverService;
        this.userAccountFacade = userAccountFacade;
    }
    createForm(config) {
        const form = this.fb.group({});
        config.formGroups.forEach(formGroup => {
            const controlGroup = formGroup.groupCode !== undefined ? this.fb.group({}) : form;
            if (formGroup.groupCode !== undefined) {
                form.addControl(formGroup.groupCode, controlGroup);
            }
            formGroup.fieldConfigs.forEach(fieldConfig => {
                fieldConfig.group = controlGroup;
                const fieldControl = this.createControl(fieldConfig);
                controlGroup.addControl(fieldConfig.name, fieldControl);
                if (fieldConfig.dependsOn) {
                    this.fieldDependencyResolverService.resolveFormControlDependencies(fieldConfig, fieldControl, form);
                }
                this.enableFieldsForSellerUserGroup(fieldControl, fieldConfig);
            });
            if (formGroup.dependsOn) {
                this.fieldDependencyResolverService.resolveFormControlDependencies(formGroup, controlGroup, form);
            }
        });
        return form;
    }
    createControl(fieldConfig) {
        const { disabled, value } = fieldConfig;
        const validations = this.formValidationService.getValidatorsForField(fieldConfig);
        return this.fb.control({ disabled, value }, validations);
    }
    /**
     * Method is used to enable all form controls when currently logged in customer is part of seller user group.
     * This is temporary solution. Control property should be defined in the form defintion's JSON metadata.
     */
    enableFieldsForSellerUserGroup(fieldControl, fieldConfig) {
        this.userAccountFacade
            .get()
            .subscribe(user => {
            if (user === null || user === void 0 ? void 0 : user.roles.includes('sellergroup')) {
                fieldControl.enable();
                fieldConfig.readonly = false;
            }
        })
            .unsubscribe();
    }
}
FormBuilderService.ɵfac = function FormBuilderService_Factory(t) { return new (t || FormBuilderService)(i0.ɵɵinject(i2$1.UntypedFormBuilder), i0.ɵɵinject(FormValidationService), i0.ɵɵinject(FieldDependencyResolverService), i0.ɵɵinject(i1$3.UserAccountFacade)); };
FormBuilderService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormBuilderService, factory: FormBuilderService.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormBuilderService, [{
            type: Injectable
        }], function () { return [{ type: i2$1.UntypedFormBuilder }, { type: FormValidationService }, { type: FieldDependencyResolverService }, { type: i1$3.UserAccountFacade }]; }, null);
})();

const DYNAMIC_FORMS_LOCAL_STORAGE_KEY = 'dynamicForms-local-data';
class FormDataStorageService {
    constructor() {
        this.formLocalStorageData = JSON.parse(localStorage.getItem(DYNAMIC_FORMS_LOCAL_STORAGE_KEY));
    }
    clearFormDataLocalStorage() {
        this.formLocalStorageData = null;
    }
    clearFormDataIdFromLocalStorage(formDataId) {
        const formStorageData = this.formLocalStorageData.filter(formOb => formOb.formDataId !== formDataId);
        localStorage.setItem(DYNAMIC_FORMS_LOCAL_STORAGE_KEY, JSON.stringify(formStorageData));
        this.formLocalStorageData = formStorageData;
    }
    setFormDataToLocalStorage(formData) {
        if (!this.formLocalStorageData || this.formLocalStorageData.length === 0) {
            this.formLocalStorageData = [this.createDataForLocalStorage(formData)];
        }
        else {
            const index = this.formLocalStorageData
                .map(sessionData => sessionData.formDefinitionId)
                .indexOf(formData.formDefinition.formId);
            index !== -1
                ? (this.formLocalStorageData[index].formDataId = formData.id)
                : this.formLocalStorageData.push(this.createDataForLocalStorage(formData));
        }
        localStorage.setItem(DYNAMIC_FORMS_LOCAL_STORAGE_KEY, JSON.stringify(this.formLocalStorageData));
    }
    getFormDataIdByDefinitionCode(formDefinitionCode) {
        if (this.formLocalStorageData) {
            return this.formLocalStorageData
                .filter(formObj => formObj.formDefinitionId === formDefinitionCode)
                .map(formObj => formObj.formDataId)[0];
        }
    }
    getFormDataIdByCategory(categoryCode) {
        if (this.formLocalStorageData) {
            return this.formLocalStorageData
                .filter(formObj => formObj.categoryCode === categoryCode)
                .map(formObj => formObj.formDataId)[0];
        }
    }
    createDataForLocalStorage(formData) {
        return {
            formDataId: formData.id,
            formDefinitionId: formData.formDefinition.formId,
            categoryCode: formData.categoryCode,
        };
    }
}
FormDataStorageService.ɵfac = function FormDataStorageService_Factory(t) { return new (t || FormDataStorageService)(); };
FormDataStorageService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormDataStorageService, factory: FormDataStorageService.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormDataStorageService, [{
            type: Injectable
        }], null, null);
})();

class GeneralHelpers {
    static getObjectDepth(data, depth = 0) {
        if (typeof data !== 'object') {
            return depth;
        }
        const [values, depthIncrease] = Array.isArray(data)
            ? [data, 0]
            : [Object.values(data), 1];
        return values.length > 0
            ? Math.max(...values.map(value => {
                return this.getObjectDepth(value, depth + depthIncrease);
            }))
            : depth;
    }
}

function DynamicFormComponent_ng_container_0_ng_container_2_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0, 5);
    }
    if (rf & 2) {
        const field_r4 = ctx.$implicit;
        const formGroup_r2 = i0.ɵɵnextContext().$implicit;
        const ctx_r3 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("config", field_r4)("group", formGroup_r2.groupCode ? ctx_r3.form.controls[formGroup_r2.groupCode] : ctx_r3.form);
    }
}
function DynamicFormComponent_ng_container_0_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 3);
        i0.ɵɵtemplate(2, DynamicFormComponent_ng_container_0_ng_container_2_ng_container_2_Template, 1, 2, "ng-container", 4);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const formGroup_r2 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngClass", formGroup_r2.cssClass)("hidden", formGroup_r2.hidden);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", formGroup_r2.fieldConfigs);
    }
}
function DynamicFormComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "form", 1);
        i0.ɵɵtemplate(2, DynamicFormComponent_ng_container_0_ng_container_2_Template, 3, 3, "ng-container", 2);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngClass", ctx_r0.config.cssClass)("formGroup", ctx_r0.form);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r0.config.formGroups);
    }
}
class DynamicFormComponent {
    constructor(changeDetectorRef, formService, formDataService, formComponentService, formConfig) {
        this.changeDetectorRef = changeDetectorRef;
        this.formService = formService;
        this.formDataService = formDataService;
        this.formComponentService = formComponentService;
        this.formConfig = formConfig;
        //eslint-disable-next-line
        this.submit = new EventEmitter();
        this.subscription = new Subscription();
    }
    get changes() {
        return this.form.valueChanges;
    }
    get valid() {
        return this.form.valid;
    }
    get value() {
        return this.form.value;
    }
    ngOnInit() {
        this.populatedInvalid$ = this.formComponentService.isPopulatedFormInvalid;
        this.subscription.add(this.populatedInvalid$
            .pipe(map((isInvalid) => {
            if (isInvalid) {
                this.subscription.add(this.formComponentService.launchFormPopupError());
            }
        }))
            .subscribe());
        if (this.config) {
            this.form = this.formService.createForm(this.config);
        }
        this.addSubmitEvent();
        if (this.formData) {
            this.subscription.add(this.formData
                .pipe(map(formData => {
                if (formData.content) {
                    this.mapDataToFormControls(JSON.parse(formData.content));
                }
            }))
                .subscribe());
        }
    }
    mapDataToFormControls(formData) {
        for (const groupCode of Object.keys(formData)) {
            if (this.form.get(groupCode) &&
                GeneralHelpers.getObjectDepth(formData[groupCode]) === 0) {
                this.form.get(groupCode).setValue(formData[groupCode]);
            }
            else {
                for (const controlName of Object.keys(formData[groupCode])) {
                    const formGroup = this.form.get(groupCode);
                    if (formGroup && formData[groupCode][controlName] !== ' ') {
                        if (formGroup.get(controlName)) {
                            formGroup
                                .get(controlName)
                                .setValue(formData[groupCode][controlName]);
                        }
                        else {
                            formGroup.setValue(formData[groupCode][controlName]);
                        }
                    }
                }
            }
        }
    }
    addSubmitEvent() {
        this.subscription.add(this.formDataService
            .getSubmittedForm()
            .pipe(map(form => {
            if (this.checkInvalidControls(form)) {
                this.formComponentService.isPopulatedFormInvalidSource.next(true);
                this.markInvalidControls(this.form);
                this.changeDetectorRef.detectChanges();
            }
            else if (form &&
                form.content === undefined &&
                this.form &&
                this.value !== undefined &&
                this.valid) {
                //eslint-disable-next-line
                this.submit.emit({
                    id: form.id,
                    refId: form.refId,
                    content: this.value,
                });
            }
        }))
            .subscribe());
    }
    markInvalidControls(formGroup) {
        for (const key of Object.keys(formGroup.controls)) {
            const formControl = formGroup.get(key);
            if (formControl instanceof UntypedFormGroup) {
                this.markInvalidControls(formControl);
            }
            else {
                const control = formControl;
                if (!control.valid) {
                    control.markAsTouched({ onlySelf: true });
                }
            }
        }
    }
    checkInvalidControls(formData) {
        return !!(formData && !this.valid);
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
DynamicFormComponent.ɵfac = function DynamicFormComponent_Factory(t) { return new (t || DynamicFormComponent)(i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(FormBuilderService), i0.ɵɵdirectiveInject(FormDataService), i0.ɵɵdirectiveInject(FormComponentService), i0.ɵɵdirectiveInject(DynamicFormsConfig)); };
DynamicFormComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DynamicFormComponent, selectors: [["cx-dynamic-form"]], inputs: { formData: "formData", config: "config" }, outputs: { submit: "submit" }, exportAs: ["cx-dynamicForm"], decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "ngClass", "formGroup"], [4, "ngFor", "ngForOf"], [1, "row", 3, "ngClass", "hidden"], ["cxFormComponent", "", 3, "config", "group", 4, "ngFor", "ngForOf"], ["cxFormComponent", "", 3, "config", "group"]], template: function DynamicFormComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, DynamicFormComponent_ng_container_0_Template, 3, 3, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.form && ctx.config);
        }
    }, dependencies: [i1.NgClass, i1.NgForOf, i1.NgIf, i2$1.ɵNgNoValidate, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, FormComponentDirective], encapsulation: 2, changeDetection: 0 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DynamicFormComponent, [{
            type: Component,
            args: [{ exportAs: 'cx-dynamicForm', selector: 'cx-dynamic-form', changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-container *ngIf=\"form && config\">\n  <form [ngClass]=\"config.cssClass\" [formGroup]=\"form\">\n    <ng-container *ngFor=\"let formGroup of config.formGroups\">\n      <div\n        class=\"row\"\n        [ngClass]=\"formGroup.cssClass\"\n        [hidden]=\"formGroup.hidden\"\n      >\n        <ng-container\n          *ngFor=\"let field of formGroup.fieldConfigs\"\n          cxFormComponent\n          [config]=\"field\"\n          [group]=\"\n            formGroup.groupCode ? form.controls[formGroup.groupCode] : form\n          \"\n        >\n        </ng-container>\n      </div>\n    </ng-container>\n  </form>\n</ng-container>\n" }]
        }], function () { return [{ type: i0.ChangeDetectorRef }, { type: FormBuilderService }, { type: FormDataService }, { type: FormComponentService }, { type: DynamicFormsConfig }]; }, { formData: [{
                type: Input
            }], config: [{
                type: Input
            }],
        //eslint-disable-next-line
        submit: [{
                type: Output
            }] });
})();

function FormComponent_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r3 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "cx-dynamic-form", 2, 3);
        i0.ɵɵlistener("submit", function FormComponent_ng_container_2_Template_cx_dynamic_form_submit_1_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.submit($event)); });
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("config", ctx_r0.formConfig)("formData", ctx_r0.formData);
    }
}
class FormComponent {
    constructor(formDataService, formDataStorageService) {
        this.formDataService = formDataService;
        this.formDataStorageService = formDataStorageService;
        this.subscription = new Subscription();
    }
    submit(formData) {
        if (this.form && this.form.valid && formData.content) {
            this.formDataService.saveFormData({
                formDefinition: {
                    formId: this.formId,
                    applicationId: this.applicationId,
                },
                content: formData.content,
                refId: formData.refId,
                id: formData.id,
            });
            this.subscription.add(this.formDataService.getFormData().subscribe(response => {
                const savedForm = {
                    id: response.id,
                    formDefinition: {
                        formId: response.formDefinition.formId,
                    },
                    content: response.content,
                    categoryCode: this.formCategoryCode,
                };
                this.formDataStorageService.setFormDataToLocalStorage(savedForm);
                this.formDataService.submit(response);
            }));
        }
    }
    ngOnDestroy() {
        this.formDataService.submit(null);
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
FormComponent.ɵfac = function FormComponent_Factory(t) { return new (t || FormComponent)(i0.ɵɵdirectiveInject(FormDataService), i0.ɵɵdirectiveInject(FormDataStorageService)); };
FormComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FormComponent, selectors: [["cx-form-component"]], viewQuery: function FormComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(DynamicFormComponent, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.form = _t.first);
        }
    }, inputs: { formCategoryCode: "formCategoryCode", formId: "formId", formSubject: "formSubject", formConfig: "formConfig", applicationId: "applicationId", formData: "formData" }, decls: 3, vars: 2, consts: [[1, "form-title"], [4, "ngIf"], [1, "dynamic-form", "container", 3, "config", "formData", "submit"], ["form", "cx-dynamicForm"]], template: function FormComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "h3", 0);
            i0.ɵɵtext(1);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(2, FormComponent_ng_container_2_Template, 3, 2, "ng-container", 1);
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", ctx.formSubject, "\n");
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.formConfig !== undefined);
        }
    }, dependencies: [i1.NgIf, DynamicFormComponent], encapsulation: 2, changeDetection: 0 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormComponent, [{
            type: Component,
            args: [{ selector: 'cx-form-component', changeDetection: ChangeDetectionStrategy.OnPush, template: "<h3 class=\"form-title\">\n  {{ formSubject }}\n</h3>\n<ng-container *ngIf=\"formConfig !== undefined\">\n  <cx-dynamic-form\n    class=\"dynamic-form container\"\n    #form=\"cx-dynamicForm\"\n    [config]=\"formConfig\"\n    (submit)=\"submit($event)\"\n    [formData]=\"formData\"\n  >\n  </cx-dynamic-form>\n</ng-container>\n" }]
        }], function () { return [{ type: FormDataService }, { type: FormDataStorageService }]; }, { form: [{
                type: ViewChild,
                args: [DynamicFormComponent, { static: false }]
            }], formCategoryCode: [{
                type: Input
            }], formId: [{
                type: Input
            }], formSubject: [{
                type: Input
            }], formConfig: [{
                type: Input
            }], applicationId: [{
                type: Input
            }], formData: [{
                type: Input
            }] });
})();

class FormContainerModule {
}
FormContainerModule.ɵfac = function FormContainerModule_Factory(t) { return new (t || FormContainerModule)(); };
FormContainerModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: FormContainerModule });
FormContainerModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        FormService,
        FormBuilderService,
        FormValidationService,
        FieldDependencyResolverService,
        FormDataStorageService,
        FormConnector,
        FormDataService,
        FileService,
    ], imports: [CommonModule,
        I18nModule,
        RouterModule,
        ReactiveFormsModule,
        ComponentsModule, ComponentsModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormContainerModule, [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        RouterModule,
                        ReactiveFormsModule,
                        ComponentsModule,
                    ],
                    declarations: [FormComponent, DynamicFormComponent],
                    exports: [FormComponent, DynamicFormComponent, ComponentsModule],
                    providers: [
                        FormService,
                        FormBuilderService,
                        FormValidationService,
                        FieldDependencyResolverService,
                        FormDataStorageService,
                        FormConnector,
                        FormDataService,
                        FileService,
                    ],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(FormContainerModule, { declarations: [FormComponent, DynamicFormComponent], imports: [CommonModule,
            I18nModule,
            RouterModule,
            ReactiveFormsModule,
            ComponentsModule], exports: [FormComponent, DynamicFormComponent, ComponentsModule] });
})();

const defaultOccFormConfig = {
    backend: {
        occ: {
            endpoints: {
                formDefinitions: 'formDefinitions',
                formDefinition: 'formDefinitions/${formDefinitionId}',
                formData: 'users/${userId}/formData/${formDataId}',
                createFormData: 'users/${userId}/formData',
                getFile: 'users/${userId}/documents/${fileCode}',
                getFiles: 'users/${userId}/documents',
                uploadFile: 'users/${userId}/documents',
                removeFile: 'users/${userId}/documents/${fileCode}',
            },
        },
    },
};

const FULL_PARAMS$1 = 'FULL';
class OccFormAdapter {
    constructor(http, occEndpointService) {
        this.http = http;
        this.occEndpointService = occEndpointService;
    }
    saveFormData(formData, userId) {
        const url = this.occEndpointService.buildUrl('createFormData', {
            urlParams: {
                userId: userId,
            },
        });
        let params = new HttpParams()
            .set('definitionId', formData.formDefinition.formId)
            .set('applicationId', formData.formDefinition.applicationId)
            .set('fields', FULL_PARAMS$1);
        if (formData.refId) {
            params = params.set('refId', formData.refId);
        }
        if (formData.id) {
            const formDataId = formData.id;
            const updateUrl = this.occEndpointService.buildUrl('formData', {
                urlParams: {
                    userId: userId,
                    formDataId,
                },
            });
            return this.http
                .put(updateUrl, formData.content, { params: params })
                .pipe(catchError((error) => throwError(error.json())));
        }
        return this.http
            .post(url, formData.content, { params: params })
            .pipe(catchError((error) => throwError(error.json())));
    }
    getFormData(formDataId, userId) {
        const url = this.occEndpointService.buildUrl('formData', {
            urlParams: {
                userId: userId,
                formDataId,
            },
        });
        return this.http
            .get(url)
            .pipe(catchError((error) => throwError(error.json())));
    }
    getFormDefinitions(categoryCode, formDefinitionType) {
        const url = this.occEndpointService.buildUrl('formDefinitions');
        const params = new HttpParams()
            .set('categoryCode', categoryCode)
            .set('yFormDefinitionType', formDefinitionType)
            .set('fields', FULL_PARAMS$1);
        return this.http
            .get(url, { params: params })
            .pipe(catchError((error) => throwError(error.json())));
    }
    getFormDefinition(applicationId, formDefinitionId) {
        const url = this.occEndpointService.buildUrl('formDefinition', {
            urlParams: {
                formDefinitionId,
            },
        });
        const params = new HttpParams()
            .set('applicationId', applicationId)
            .set('fields', FULL_PARAMS$1);
        return this.http.get(url, { params: params });
    }
}
OccFormAdapter.ɵfac = function OccFormAdapter_Factory(t) { return new (t || OccFormAdapter)(i0.ɵɵinject(i1$4.HttpClient), i0.ɵɵinject(i2.OccEndpointsService)); };
OccFormAdapter.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: OccFormAdapter, factory: OccFormAdapter.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OccFormAdapter, [{
            type: Injectable
        }], function () { return [{ type: i1$4.HttpClient }, { type: i2.OccEndpointsService }]; }, null);
})();

const FULL_PARAMS = 'FULL';
class OccFileAdapter {
    constructor(http, occEndpointService) {
        this.http = http;
        this.occEndpointService = occEndpointService;
    }
    uploadFile(userId, file) {
        const url = this.occEndpointService.buildUrl('uploadFile', {
            urlParams: {
                userId: userId,
            },
        });
        const params = new HttpParams()
            .set('fileSize', file.size.toString())
            .set('fields', FULL_PARAMS);
        const data = new FormData();
        data.append('file', file);
        return this.http
            .post(url, data, {
            reportProgress: true,
            observe: 'events',
            params: params,
        })
            .pipe(catchError((error) => throwError(error.json())));
    }
    removeFileForUserAndCode(userId, fileCode) {
        const url = this.occEndpointService.buildUrl('removeFile', {
            urlParams: {
                userId,
                fileCode,
            },
        });
        const headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded',
        });
        return this.http
            .delete(url, { headers })
            .pipe(catchError((error) => throwError(error.json())));
    }
    getFileForCodeAndType(userId, fileCode, fileType) {
        const url = this.occEndpointService.buildUrl('getFile', {
            urlParams: {
                userId,
                fileCode,
            },
        });
        return this.http.get(url).pipe(map(document => base64StringToBlob(document, fileType)), catchError((error) => throwError(error.json())));
    }
    getFilesForUser(userId, fileCodes) {
        const url = this.occEndpointService.buildUrl('getFiles', {
            urlParams: {
                userId,
            },
        });
        let params = new HttpParams().set('fields', FULL_PARAMS);
        if (fileCodes) {
            params = params.set('documentCodes', fileCodes.toString());
        }
        return this.http
            .get(url, { params })
            .pipe(catchError((error) => throwError(error.json())));
    }
}
OccFileAdapter.ɵfac = function OccFileAdapter_Factory(t) { return new (t || OccFileAdapter)(i0.ɵɵinject(i1$4.HttpClient), i0.ɵɵinject(i2.OccEndpointsService)); };
OccFileAdapter.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: OccFileAdapter, factory: OccFileAdapter.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OccFileAdapter, [{
            type: Injectable
        }], function () { return [{ type: i1$4.HttpClient }, { type: i2.OccEndpointsService }]; }, null);
})();

class FormOccModule {
}
FormOccModule.ɵfac = function FormOccModule_Factory(t) { return new (t || FormOccModule)(); };
FormOccModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: FormOccModule });
FormOccModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        {
            provide: FormAdapter,
            useClass: OccFormAdapter,
        },
        {
            provide: FileAdapter,
            useClass: OccFileAdapter,
        },
        provideConfig(defaultOccFormConfig),
    ], imports: [CommonModule, HttpClientModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormOccModule, [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, HttpClientModule],
                    providers: [
                        {
                            provide: FormAdapter,
                            useClass: OccFormAdapter,
                        },
                        {
                            provide: FileAdapter,
                            useClass: OccFileAdapter,
                        },
                        provideConfig(defaultOccFormConfig),
                    ],
                }]
        }], null, null);
})();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(FormOccModule, { imports: [CommonModule, HttpClientModule] }); })();

class FormOccConfig extends OccConfig {
}

function FormCMSComponent_ng_container_0_ng_container_1_cx_form_component_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "cx-form-component", 3);
    }
    if (rf & 2) {
        const component_r3 = i0.ɵɵnextContext(2).ngIf;
        const ctx_r6 = i0.ɵɵnextContext();
        i0.ɵɵproperty("formId", component_r3.formId)("formSubject", component_r3.subject)("formConfig", ctx_r6.formConfig)("applicationId", component_r3.applicationId)("formData", ctx_r6.formData$);
    }
}
function FormCMSComponent_ng_container_0_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtemplate(1, FormCMSComponent_ng_container_0_ng_container_1_cx_form_component_1_Template, 1, 5, "cx-form-component", 2);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r4.formConfig);
    }
}
function FormCMSComponent_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtemplate(1, FormCMSComponent_ng_container_0_ng_container_1_Template, 2, 1, "ng-container", 0);
        i0.ɵɵpipe(2, "async");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        const _r1 = i0.ɵɵreference(3);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(2, 2, ctx_r0.formDefinition$))("ngIfElse", _r1);
    }
}
function FormCMSComponent_ng_template_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "cx-spinner");
    }
}
class FormCMSComponent {
    constructor(componentData, formDataService, formDataStorageService) {
        this.componentData = componentData;
        this.formDataService = formDataService;
        this.formDataStorageService = formDataStorageService;
        this.subscription = new Subscription();
    }
    ngOnInit() {
        this.component$ = this.componentData.data$;
        this.loadForm();
    }
    loadForm() {
        this.formDefinition$ = this.formDataService.getFormDefinition().pipe(map(definition => {
            if (definition.content) {
                this.formConfig = JSON.parse(definition.content);
            }
            this.formDataId =
                this.formDataStorageService.getFormDataIdByDefinitionCode(definition.formId);
            if (this.formDataId) {
                this.formDataService.loadFormData(this.formDataId);
                this.formData$ = this.formDataService.getFormData();
            }
            return definition;
        }));
        this.subscription.add(this.component$
            .pipe(take(1), map(component => {
            this.loadFormDefinition(component);
        }))
            .subscribe());
    }
    loadFormDefinition(component) {
        this.formDataService.loadFormDefinition(component.applicationId, component.formId);
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
}
FormCMSComponent.ɵfac = function FormCMSComponent_Factory(t) { return new (t || FormCMSComponent)(i0.ɵɵdirectiveInject(i1$1.CmsComponentData), i0.ɵɵdirectiveInject(FormDataService), i0.ɵɵdirectiveInject(FormDataStorageService)); };
FormCMSComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FormCMSComponent, selectors: [["cx-form-cms"]], decls: 4, vars: 4, consts: [[4, "ngIf", "ngIfElse"], ["loading", ""], [3, "formId", "formSubject", "formConfig", "applicationId", "formData", 4, "ngIf"], [3, "formId", "formSubject", "formConfig", "applicationId", "formData"]], template: function FormCMSComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, FormCMSComponent_ng_container_0_Template, 3, 4, "ng-container", 0);
            i0.ɵɵpipe(1, "async");
            i0.ɵɵtemplate(2, FormCMSComponent_ng_template_2_Template, 1, 0, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
            const _r1 = i0.ɵɵreference(3);
            i0.ɵɵproperty("ngIf", i0.ɵɵpipeBind1(1, 2, ctx.component$))("ngIfElse", _r1);
        }
    }, dependencies: [i1.NgIf, i1$1.SpinnerComponent, FormComponent, i1.AsyncPipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormCMSComponent, [{
            type: Component,
            args: [{ selector: 'cx-form-cms', template: "<ng-container *ngIf=\"component$ | async as component; else loading\">\n  <ng-container *ngIf=\"formDefinition$ | async as formDefinition; else loading\">\n    <cx-form-component\n      *ngIf=\"formConfig\"\n      [formId]=\"component.formId\"\n      [formSubject]=\"component.subject\"\n      [formConfig]=\"formConfig\"\n      [applicationId]=\"component.applicationId\"\n      [formData]=\"formData$\"\n    ></cx-form-component>\n  </ng-container>\n</ng-container>\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n" }]
        }], function () { return [{ type: i1$1.CmsComponentData }, { type: FormDataService }, { type: FormDataStorageService }]; }, null);
})();

class FormCMSModule {
}
FormCMSModule.ɵfac = function FormCMSModule_Factory(t) { return new (t || FormCMSModule)(); };
FormCMSModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: FormCMSModule });
FormCMSModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        SpinnerModule,
        FormContainerModule,
        ConfigModule.withConfig({
            cmsComponents: {
                YFormCMSComponent: {
                    component: FormCMSComponent,
                },
            },
        })] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormCMSModule, [{
            type: NgModule,
            args: [{
                    declarations: [FormCMSComponent],
                    imports: [
                        CommonModule,
                        SpinnerModule,
                        FormContainerModule,
                        ConfigModule.withConfig({
                            cmsComponents: {
                                YFormCMSComponent: {
                                    component: FormCMSComponent,
                                },
                            },
                        }),
                    ],
                    exports: [FormCMSComponent],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(FormCMSModule, { declarations: [FormCMSComponent], imports: [CommonModule,
            SpinnerModule,
            FormContainerModule, i2.ConfigModule], exports: [FormCMSComponent] });
})();

const getFormsState = createFeatureSelector(FORM_FEATURE);
/**
 * Responsible for storing Form state in the browser storage.
 * Uses `StatePersistenceService` mechanism.
 */
class FormPersistenceService {
    constructor(statePersistenceService, store) {
        this.statePersistenceService = statePersistenceService;
        this.store = store;
        this.subscription = new Subscription();
        /**
         * Identifier used for storage key.
         */
        this.key = 'form';
    }
    /**
     * Initializes the synchronization between state and browser storage.
     */
    initSync() {
        this.subscription.add(this.statePersistenceService.syncWithStorage({
            key: this.key,
            state$: this.getUploadedFiles(),
            onRead: state => this.onRead(state),
        }));
    }
    /**
     * Gets and transforms state from different sources into the form that should
     * be saved in storage.
     */
    getUploadedFiles() {
        return this.store.pipe(select(getFormsState), filter(state => !!state), map(state => {
            return {
                files: state.uploadedFiles.content.files,
            };
        }));
    }
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     */
    onRead(state) {
        if (state) {
            this.store.dispatch(new SetUploadedFiles(state.files));
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
}
FormPersistenceService.ɵfac = function FormPersistenceService_Factory(t) { return new (t || FormPersistenceService)(i0.ɵɵinject(i2.StatePersistenceService), i0.ɵɵinject(i1$2.Store)); };
FormPersistenceService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormPersistenceService, factory: FormPersistenceService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormPersistenceService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: i2.StatePersistenceService }, { type: i1$2.Store }]; }, null);
})();

class FormDataEffects {
    constructor(formDataStorageService, actions$, formConnector) {
        this.formDataStorageService = formDataStorageService;
        this.actions$ = actions$;
        this.formConnector = formConnector;
        this.loadFormData$ = createEffect(() => this.actions$.pipe(ofType(LOAD_FORM_DATA), map((action) => action.payload), mergeMap(payload => {
            return this.formConnector
                .getFormData(payload.formDataId, payload.userId)
                .pipe(map((formData) => {
                return new LoadFormDataSuccess(formData);
            }), catchError(error => {
                return of(new LoadFormDataFail(JSON.stringify(error)));
            }));
        })));
        this.saveFormData$ = createEffect(() => this.actions$.pipe(ofType(SAVE_FORM_DATA), map((action) => action.payload), mergeMap(payload => {
            return this.formConnector
                .saveFormData(payload.formData, payload.userId)
                .pipe(map((formData) => {
                return new SaveFormDataSuccess(formData);
            }), catchError(error => {
                return of(new SaveFormDataFail(JSON.stringify(error)));
            }));
        })));
        this.clearFormData$ = createEffect(() => this.actions$.pipe(ofType(AuthActions.LOGOUT), tap(_ => {
            sessionStorage.removeItem('quoteCodes');
            this.formDataStorageService.clearFormDataLocalStorage();
        })), { dispatch: false });
    }
}
FormDataEffects.ɵfac = function FormDataEffects_Factory(t) { return new (t || FormDataEffects)(i0.ɵɵinject(FormDataStorageService), i0.ɵɵinject(i1$5.Actions), i0.ɵɵinject(FormConnector)); };
FormDataEffects.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormDataEffects, factory: FormDataEffects.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormDataEffects, [{
            type: Injectable
        }], function () { return [{ type: FormDataStorageService }, { type: i1$5.Actions }, { type: FormConnector }]; }, null);
})();

class FormDefinitionEffects {
    constructor(actions$, formConnector, globalMessageService) {
        this.actions$ = actions$;
        this.formConnector = formConnector;
        this.globalMessageService = globalMessageService;
        this.loadFormDefinition$ = createEffect(() => this.actions$.pipe(ofType(LOAD_FORM_DEFINITION), map((action) => action.payload), mergeMap(payload => {
            if (payload.formDefinitionId) {
                return this.formConnector
                    .getFormDefinition(payload.applicationId, payload.formDefinitionId)
                    .pipe(map((formDefinition) => {
                    return new LoadFormDefinitionSuccess(formDefinition);
                }), catchError(error => {
                    this.showGlobalMessage('dynamicforms.definitionLoadError');
                    return of(new LoadFormDefinitionFail(JSON.stringify(error)));
                }));
            }
            return this.formConnector
                .getFormDefinitions(payload.categoryCode, payload.formDefinitionType)
                .pipe(map((definitions) => {
                return new LoadFormDefinitionSuccess(definitions.formDefinitions[0]);
            }), catchError(error => {
                this.showGlobalMessage('dynamicforms.definitionLoadError');
                return of(new LoadFormDefinitionFail(JSON.stringify(error)));
            }));
        })));
    }
    showGlobalMessage(text) {
        this.globalMessageService.add({ key: text }, GlobalMessageType.MSG_TYPE_ERROR);
    }
}
FormDefinitionEffects.ɵfac = function FormDefinitionEffects_Factory(t) { return new (t || FormDefinitionEffects)(i0.ɵɵinject(i1$5.Actions), i0.ɵɵinject(FormConnector), i0.ɵɵinject(i2.GlobalMessageService)); };
FormDefinitionEffects.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FormDefinitionEffects, factory: FormDefinitionEffects.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormDefinitionEffects, [{
            type: Injectable
        }], function () { return [{ type: i1$5.Actions }, { type: FormConnector }, { type: i2.GlobalMessageService }]; }, null);
})();

class FilesEffect {
    constructor(actions$, fileConnector) {
        this.actions$ = actions$;
        this.fileConnector = fileConnector;
        this.removeFile$ = createEffect(() => this.actions$.pipe(ofType(REMOVE_FILE), map((action) => action.payload), mergeMap(payload => {
            return this.fileConnector
                .removeFile(payload.user, payload.fileCode)
                .pipe(map(() => {
                return new RemoveFileSuccess(payload.fileCode);
            }), catchError(error => {
                return of(new RemoveFileFail(JSON.stringify(error)));
            }));
        })));
    }
}
FilesEffect.ɵfac = function FilesEffect_Factory(t) { return new (t || FilesEffect)(i0.ɵɵinject(i1$5.Actions), i0.ɵɵinject(FileConnector)); };
FilesEffect.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: FilesEffect, factory: FilesEffect.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FilesEffect, [{
            type: Injectable
        }], function () { return [{ type: i1$5.Actions }, { type: FileConnector }]; }, null);
})();

const effects = [
    FormDefinitionEffects,
    FormDataEffects,
    FilesEffect,
];

const initialState$2 = {
    loaded: false,
    content: {},
};
function reducer$2(state = initialState$2, action) {
    switch (action.type) {
        case SAVE_FORM_DATA:
        case LOAD_FORM_DATA: {
            return Object.assign(Object.assign({}, state), { loaded: false });
        }
        case SAVE_FORM_DATA_SUCCESS:
        case LOAD_FORM_DATA_SUCCESS: {
            const content = Object.assign({}, action.payload);
            return Object.assign(Object.assign({}, state), { content, loaded: true });
        }
    }
    return state;
}
const getFormData = (state) => state.content;
const getLoaded$1 = (state) => state.loaded;

const initialState$1 = {
    loaded: false,
    content: {},
};
function reducer$1(state = initialState$1, action) {
    switch (action.type) {
        case LOAD_FORM_DEFINITION: {
            return Object.assign(Object.assign({}, state), { loaded: false });
        }
        case LOAD_FORM_DEFINITION_SUCCESS: {
            const content = Object.assign({}, action.payload);
            return Object.assign(Object.assign({}, state), { content, loaded: true });
        }
    }
    return state;
}
const getFormDefinition = (state) => state.content;
const getLoaded = (state) => state.loaded;

const initialState = {
    loaded: false,
    content: {
        files: [],
    },
};
function reducer(state = initialState, action) {
    var _a;
    switch (action.type) {
        case UPLOAD_FILE_SUCCESS: {
            let content = Object.assign({}, action.payload);
            const fileContent = Object.assign({}, state.content);
            if ((_a = content === null || content === void 0 ? void 0 : content.body) === null || _a === void 0 ? void 0 : _a.code) {
                fileContent.files = [...fileContent.files, content.body];
            }
            content = Object.assign({}, fileContent);
            return Object.assign(Object.assign({}, state), { content, loaded: true });
        }
        case REMOVE_FILE_SUCCESS: {
            // needed to deep clone state.content object
            const fileContent = JSON.parse(JSON.stringify(state.content));
            const removedFileCode = action.payload;
            fileContent.files.forEach((file, index) => {
                if (file.code === removedFileCode) {
                    fileContent.files.splice(index, 1);
                }
            });
            const content = Object.assign({}, fileContent);
            return Object.assign(Object.assign({}, state), { content, loaded: true });
        }
        case SET_UPLOADED_FILES: {
            let content = Object.assign({}, action.payload);
            const fileContent = Object.assign({}, state.content);
            fileContent.files = content;
            content = Object.assign({}, fileContent);
            return Object.assign(Object.assign({}, state), { content, loaded: true });
        }
        case RESET_FILE_SUCCESS: {
            state = initialState;
        }
    }
    return state;
}
const getUploadFiles = (state) => state.content;

function getReducers() {
    return {
        formDefinition: reducer$1,
        formData: reducer$2,
        uploadedFiles: reducer,
    };
}
const reducerToken = new InjectionToken('FormReducers');
const reducerProvider = {
    provide: reducerToken,
    useFactory: getReducers,
};
function clearFormDefinitionState(reducer) {
    return function (state, action) {
        if (action.type === AuthActions.LOGOUT) {
            state = undefined;
            localStorage.removeItem(DYNAMIC_FORMS_LOCAL_STORAGE_KEY);
        }
        return reducer(state, action);
    };
}
const metaReducers = [clearFormDefinitionState];

function formStatePersistenceFactory(formStatePersistenceService) {
    const result = () => formStatePersistenceService.initSync();
    return result;
}
class FormStoreModule {
}
FormStoreModule.ɵfac = function FormStoreModule_Factory(t) { return new (t || FormStoreModule)(); };
FormStoreModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: FormStoreModule });
FormStoreModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        reducerProvider,
        {
            provide: APP_INITIALIZER,
            useFactory: formStatePersistenceFactory,
            deps: [FormPersistenceService],
            multi: true,
        },
    ], imports: [CommonModule,
        HttpClientModule,
        StateModule,
        StoreModule.forFeature(FORM_FEATURE, reducerToken, {
            metaReducers,
        }),
        EffectsModule.forFeature(effects)] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormStoreModule, [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        HttpClientModule,
                        StateModule,
                        StoreModule.forFeature(FORM_FEATURE, reducerToken, {
                            metaReducers,
                        }),
                        EffectsModule.forFeature(effects),
                    ],
                    providers: [
                        reducerProvider,
                        {
                            provide: APP_INITIALIZER,
                            useFactory: formStatePersistenceFactory,
                            deps: [FormPersistenceService],
                            multi: true,
                        },
                    ],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(FormStoreModule, { imports: [CommonModule,
            HttpClientModule,
            StateModule, i1$2.StoreFeatureModule, i1$5.EffectsFeatureModule] });
})();

class DynamicFormModule {
}
DynamicFormModule.ɵfac = function DynamicFormModule_Factory(t) { return new (t || DynamicFormModule)(); };
DynamicFormModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: DynamicFormModule });
DynamicFormModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [{ provide: DynamicFormsConfig, useExisting: Config }, DatePipe], imports: [CommonModule,
        I18nModule,
        FormContainerModule,
        FormCMSModule,
        FormStoreModule,
        FormOccModule,
        ConfigModule.withConfig(defaultFormConfig),
        ComponentsModule, FormContainerModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DynamicFormModule, [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        FormContainerModule,
                        FormCMSModule,
                        FormStoreModule,
                        FormOccModule,
                        ConfigModule.withConfig(defaultFormConfig),
                        ComponentsModule,
                    ],
                    exports: [FormContainerModule],
                    providers: [{ provide: DynamicFormsConfig, useExisting: Config }, DatePipe],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(DynamicFormModule, { imports: [CommonModule,
            I18nModule,
            FormContainerModule,
            FormCMSModule,
            FormStoreModule,
            FormOccModule, i2.ConfigModule, ComponentsModule], exports: [FormContainerModule] });
})();

const dynamicforms$1 = {
    dynamicforms: {
        optional: '(Optional)',
        maxFileSize: 'Maximum file size allowed',
        chooseFile: 'Choose file(s)',
        startUpload: 'Start upload',
        removeAll: 'Remove all',
        upload: 'Upload',
        pleaseSelect: 'Please select:',
        enterValidValue: 'Please enter valid value',
        validationErrors: 'There are validation errors',
        definitionLoadError: 'Error occurred. Form could not be loaded.',
        documentUploadError: 'An error occurred during the documents upload. Please try again.',
        fillOutProperly: 'Please retry once all of the fields have been properly filled-out.',
    },
};

const dynamicformsTranslations = {
    dynamicforms: dynamicforms$1,
};

const dynamicforms = {
    dynamicforms: {
        optional: '(Optional)',
        maxFileSize: 'Maximal zulässige Dateigröße',
        chooseFile: 'Datei(en) auswählen',
        startUpload: 'Upload starten',
        removeAll: 'Alles entfernen',
        upload: 'Hochladen',
        pleaseSelect: 'Wählen Sie:',
        enterValidValue: 'Bitte geben Sie einen gültigen Wert ein',
        validationErrors: 'Es liegen Validierungsfehler vor',
        definitionLoadError: 'Ein Fehler ist aufgetreten. Das Formular konnte nicht geladen werden.',
        documentUploadError: '[DE] An error occurred during the documents upload. Please try again.',
        fillOutProperly: 'Bitte Versuchen Sie es erneut, sobald alle Felder ordnugsgemäß',
    },
};

const dynamicformsTranslationsDe = {
    dynamicforms,
};

/*
 * Public API Surface of dynamicforms
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AbstractFormComponent, AbstractOptionsComponent, ButtonComponent, CheckboxComponent, ComponentsModule, CurrencyComponent, DYNAMIC_FORMS_LOCAL_STORAGE_KEY, DataHolderComponent, DatePickerComponent, DefaultFormValidators, DynamicFormComponent, DynamicFormModule, DynamicFormsConfig, ErrorNoticeComponent, FileService, FormAdapter, FormBuilderService, FormCMSComponent, FormCMSModule, FormComponent, FormComponentConfig, FormComponentDirective, FormConnector, FormContainerModule, FormDataService, FormDataStorageService, FormDateConfig, FormOccConfig, FormOccModule, FormPopupErrorComponent, FormService, FormsUtils, InputComponent, OboCustomerService, OccFileAdapter, OccFormAdapter, PrefillConfig, RadioComponent, SelectComponent, SeparatorComponent, TextAreaComponent, TimeComponent, TitleComponent, UploadComponent, UserAddressPrefillResolver, UserPrefillResolver, ValidatorConfig, defaultFormConfig, dynamicformsTranslations, dynamicformsTranslationsDe };
//# sourceMappingURL=fsa-dynamicforms.mjs.map
